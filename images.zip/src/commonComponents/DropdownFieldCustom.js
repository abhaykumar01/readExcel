import React, { Component } from 'react';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Notification } from '@zambezi/sdk/notification';

const dropdownfieldcustom = ({ title,customLabel, customCss, classname, data, errorStatus, onChange, errorMessage, selectedValue, isDisabled  }) => {
    return (
        <div className="form-group row">
            <label for="inputState" className={"col-sm-4 col-form-label  "+" "+customLabel} >{title}</label>
            <div className="col-sm-7">
                <Select
                    defaultValue={selectedValue}
                    suggestions={data}
                    placeholder='Select'
                    className={classname}
                    isError={errorStatus}
                    onChange={onChange}
                    isDisabled={isDisabled}
                />
                
            </div>
            <div>
                {
                    errorStatus ?
                <div className="form-group row">
                <label className={"col-sm-4 col-form-label field_label_model"+" "+customCss} style={{marginLeft: '35px'}}></label>
                <div className="col-sm-6" style= {{marginTop:'10px'}}>
                            <Notification 
                                status='error'
                                size='small'
                                withArrow
                                arrowPosition='14px'
                                className="error_notification"
                            >
                                {errorMessage} 
                            </Notification>
                        </div>
                    </div>
                     : null
                }
                </div>
        </div>
    );
};

export default dropdownfieldcustom