import React from 'react';
import help from '../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import { Notification } from '@zambezi/sdk/notification';
import LocaleFormattedValue from './LocaleFormattedValue';

const outputLabel = ({ fieldTitle, helpIcon, helpIconValue, maxlength, id, helpID, value, inputType,
    name, onChange, placeholder, errorStatus, errorMessage, postFixData, type }) => {

        if(value == null || value == undefined || value === 'N/A'){
            postFixData = '';
        }
        return(
            <div>
                <label className="Customer-MGS-SPV-Mod" style = {{width:'250px'}}>{fieldTitle}</label>
                 <label className="Customer-MGS-SPV-Mod" style = {{color:'#black-two'}}>
                    <LocaleFormattedValue type={type ? type : ''} value={value}/>
                 </label>
                 
                <label className="Customer-MGS-SPV-Mod" style = {{color:'#black-two'}}>{postFixData}</label>
                 
            </div>
        );

    }

    export default outputLabel