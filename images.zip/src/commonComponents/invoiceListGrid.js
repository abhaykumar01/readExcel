import React from 'react';
import ReactTable from 'react-table';
import "react-table/react-table.css";
import withFixedColumns from "react-table-hoc-fixed-columns";
import 'react-table/react-table.css';
import Pagination from './pagination.js';
import UserData from './ApiData.js';
import matchSorter from 'match-sorter'
import { HttpPost, HttpGet } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import DatePicker from '@zambezi/sdk/date-picker';
import checkboxHOC from "react-table/lib/hoc/selectTable";
import {Checkbox}  from '@zambezi/sdk/form-elements';
import LocaleFormattedValue from './LocaleFormattedValue';

const ReactTableFixedColumns = withFixedColumns(ReactTable);
// const rawData = getPartyCustomer();
        let tempRowData =[];
class invoiceListGrid extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "10",
            customerRecord: [],
            loading: false,
            selected: null,
            invoiceListType:'Index',
            actionNeededFlag:'No'
        }
        this.selectInvoiceData = this.selectInvoiceData.bind(this);
        this.toggleAll=this.toggleAll.bind(this);
    }

    componentDidMount() {
        //this.updateData('No','Interest');
        this.updateData('No','Index');
        // let output = [];
        // this.setState({ loading: true })
        // var currentComponent = this;
        // let endPoint = API_ENDPOINT.GET_ALL_INVOICES + '/Yes'+ '/Index';
        // let output1 = HttpGet(endPoint).then(function (response) {
        //     for (var i = 0; i < response.data.length; i++) {
                
        //         let userAddress = "";
        //         if (response.data[i].streetAddressLine1 != null) {
        //             userAddress = response.data[i].streetAddressLine1;
        //         }
        //         if (response.data[i].streetAddressLine2 != null) {
        //             userAddress += ' ' + response.data[i].streetAddressLine2;
        //         }
        //         // if (response.data[i].street_Address_Line_3 != null) {
        //         //     userAddress += response.data[i].street_Address_Line_3;
        //         // }

        //         var obj = moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        //         let time = moment(obj).format("DD/MM/YYYY");
                
        //         output.push({
        //             spv: response.data[i].spv,
        //             customer: response.data[i].customer,
        //             currency: response.data[i].currency,
        //             leasefee:  response.data[i].leaseFee,
        //             pmtterms:  response.data[i].pmtTerms,
        //             actionneeded:  response.data[i].actionNeeded,
        //             status:  response.data[i].status,
        //             invoicetype:  response.data[i].invoiceType,
        //             type: response.data[i].customer,
        //             address: response.data[i].currency,
                    
        //             created: time,
        //             ID: response.data[i].partyID
        //         });
        //     }

        //     currentComponent.setState({customerRecord: output});
        //     currentComponent.setState({ loading: false })
        //     //  return output;
        // })
        //     .catch(function (error) {
        //         currentComponent.setState({ loading: false })
        //     })
    }

    updateData(actionNeeded, invoiceType ) {
        this.setState({invoiceListType:invoiceType});
        this.setState({actionNeededFlag:actionNeeded});
        let output = [];
        this.setState({ loading: true })
        var currentComponent = this;
        let endPoint = API_ENDPOINT.GET_ALL_INVOICES //+ '/'+actionNeeded+ '/'+invoiceType;
        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            let invoicingFrequency  = [];
            let invoicingPeriod = [];
            for (var i = 0; i < response.data.length; i++) {
                console.log('response.data[i]: '+response.data[0]);
                // let userAddress = "";
                // if (response.data[i].streetAddressLine1 != null) {
                //     userAddress = response.data[i].streetAddressLine1;
                // }
                // if (response.data[i].streetAddressLine2 != null) {
                //     userAddress += ' ' + response.data[i].streetAddressLine2;
                // }
                // if (response.data[i].street_Address_Line_3 != null) {
                //     userAddress += response.data[i].street_Address_Line_3;
                // }
                // userAddress += response.data[i].street_Address_Line_3;
// }
                if(response.data[i].invoiceFrequency != null){
                    if(response.data[i].invoiceFrequency == 1){
                        invoicingFrequency.push('Annually');
                    }
                    else if(response.data[i].invoiceFrequency == 2){
                        invoicingFrequency.push('Semi-Annually');
                    }
                    else if(response.data[i].invoiceFrequency == 4){
                        invoicingFrequency.push('Quarterly');
                    }
                    else if(response.data[i].invoiceFrequency == 12){
                        invoicingFrequency.push('Monthly');
                    }
                    else {
                        invoicingFrequency.push('Invalid Data');
                    }
                }
                
                if(response.data[i].invoiceEndDate != null && response.data[i].invoiceStartDate != null){
                    // var startDate  = moment(response.data[i].invoiceStartDate).format('YYYY-MM-DD');
                    // var endDate    = moment(response.data[i].invoiceEndDate).format('YYYY-MM-DD');
                    var startDate  = response.data[i].invoiceStartDate;
                    var endDate    = response.data[i].invoiceEndDate;
                    invoicingPeriod.push([startDate, endDate]);
                    // invoicingPeriod.push(startDate+' - '+endDate)
                };

                var obj = moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
                let time = moment(obj).format("DD/MM/YYYY");
                var validDate = null;
                if(response.data[i].bpsAdjValidDate  != null){
                    validDate = response.data[i].bpsAdjValidDate;
                }
                output.push({
                    
                    spv: response.data[i].spv, //
                    customer: response.data[i].customer, //
                    comments: response.data[i].comments,
                    currency: response.data[i].currency, //
                    bookValueScaler: response.data[i].bookValueScaler,//
                    leasefee:   Math.round((response.data[i].leaseFee+ Number.EPSILON) * 100) / 100 ,//
                    pmtterms:  response.data[i].pmtTerms,//
                    actionneeded:  response.data[i].actionNeeded,//
                    status:  response.data[i].status,//
                    invoicetype:  response.data[i].invoiceType,//
                   // address: response.data[i].currency,
                    invoicingfrequency:invoicingFrequency[i],//response.data[i].invoiceFrequency,//
                    invoicingperiod: invoicingPeriod[i],//                  
                    created: time,//
                    ID: response.data[i].invoiceId,//
                    invoiceId: response.data[i].invoiceId,
                    leaseContractId: response.data[i].leaseContractId,
                    leaseContractNumber: response.data[i].leaseContractNumber,
                    areaCode: response.data[i].areaCode,//
                    baseRent: response.data[i].baseRent,//
                    depreciation: response.data[i].depreciation,//
                    franchiseName: response.data[i].franchiseName,//
                    futureValue: response.data[i].futureValue,//
                    index: response.data[i].index,//
                    indexAdjustment: response.data[i].indexAdjustment,//
                    indexBaseDate: response.data[i].indexBaseDate,//
                    indexBaseNo: response.data[i].indexBaseNo,//
                    indexFloor: response.data[i].indexFloor,//
                    indexName: response.data[i].indexName,//
                    indexReviewDate: response.data[i].indexReviewDate,//
                    indexReviewNo: response.data[i].indexReviewNo,//
                    indexScaling: response.data[i].indexScaling,//
                    indexType: response.data[i].indexType,//
                    interestAdjustment: response.data[i].interestAdjustment,//
                    interestRateFloor:response.data[i].interestRateFloor,//
                    interestRateName: response.data[i].interestRateName,//
                    interestRateReviewDate: response.data[i].interestRateReviewDate,//
                    invoiceCreatedDate:response.data[i].invoiceCreatedDate,//
                    invoiceEndDate: response.data[i].invoiceEndDate,//
                    invoicePeriod: response.data[i].invoicePeriod,//
                    invoiceStartDate: response.data[i].invoiceStartDate,//
                    invoiceUpdatedDate: moment().utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"),//
                    //2019-05-17T00:00:00.000+0000
                    margin: response.data[i].margin,//
                    numberBpsAdjustment: response.data[i].numberBpsAdjustment,//
                    presentValue: response.data[i].presentValue,//
                    propertyTax: response.data[i].propertyTax,//
                    rentAdjustment: response.data[i].rentAdjustment,//
                    rentAdjustmentBps:response.data[i].rentAdjustmentBps,//
                    rentRebate: response.data[i].rentRebate,//
                    tlp: response.data[i].tlp,//
                    totalRent: response.data[i].totalRent,
                    vatableProportion: response.data[i].vatableProportion,
                    isChecked: false,
                    baseRentFixed:response.data[i].baseRentFixed,
                    bookValueScalerFixed:response.data[i].bookValueScalerFixed,
                    interestAdjFixed:response.data[i].interestAdjFixed,
                    interestRateFixed:response.data[i].interestRateFixed,
                    totalRentFixed:response.data[i].totalRentFixed,
                    baseRentDescription:response.data[i].baseRentDescription,
                    indexAdjDescription:response.data[i].indexAdjDescription,
                    interestAdjDescription:response.data[i].interestAdjDescription,
                    propertyTaxDescription:response.data[i].propertyTaxDescription,
                    rentAdjDescription:response.data[i].rentAdjDescription,
                    rentRebateDescription:response.data[i].rentRebateDescription,
                    requestedBy:response.data[i].requestedBy,
                    respondedBy:response.data[i].respondedBy,
                    reasonForRejection:response.data[i].reasonForRejection,
                    dealCaptain:response.data[i].dealCaptain,
                    invoiceCreditStatus : response.data[i].invoiceCreditStatus,
                    bpsAdjValidDate: validDate
                });
            }
            console.log(output)
            currentComponent.setState({customerRecord: output});
            currentComponent.setState({ loading: false })
            console.log('output:' +JSON.stringify(output))
             // return output;
        })
            .catch(function (error) {
                currentComponent.setState({ loading: false })
            })
    }

    // handleRowClick() {
    //     // this.props.history.push({'/lms/viewCustomerDetail/${this.state.selected}'});
    //     this.props.history.push({
    //         namename: '/lms/viewCustomerDetail',
    //         state: { rowID: this.state.selected }
    //     })
    //     // this.props.history.push(/lms/viewCustomerDetail:${this.state.selected})
    // }

    generateData(type) {
        const data = [];
        if (type == "currencyType") {
            data.push(
                "All",
                "EUR",
                "NOK",
                "SEK",
                "DKK",
                //"GBP",
            );
        }else if (type == "pmtTermsType") {
            data.push(
                "All",
                "NR In Arrears",
                "NR In Advance"
                
            ); 
        }
                
        else if (type == "actionneeded") {
            data.push(
                "All",
                "Yes",
                "No"
                
            ); 
        }
        else if (type == "invoicetype") {
            
            data.push(
                "All",
                "Index",
                "Interest"
                
            ); 
            
        }
        else if (type == "invoiceCreditStatus") {
            
            data.push(
                "All",
                "Yes",
                "Yes – Invoiced",
                "yes – Credit Only",
                "Pending – Invoiced", 
                "Pending – Credit Only", 
                "No"
                 ); 
            
        }
        else if (type == "status") {
            data.push(
                "All",
                "Pending Approval",
                "Not Started",
                "In Progress",
                "Finance Review",
                "Approved",
                "Rejected",
                "Exported",
                "Export failed"
                // "Edit Request Approved",
                // "Edit Request Rejected"
                ); 
        }
        else if (type == "invoicingfrequency") {
            data.push(
                "All",
                "Monthly",
                "Quarterly",
                "Semi-Annually",
                "Annually",
                
            );
        }
        
        return data
    }
    toggleRow(data,rowData,e){
        e.stopPropagation();
        var completeData = this.state.customerRecord;
        if(completeData != undefined && completeData.length > 0 && completeData != null){
            for(var i =0 ; i < completeData.length ; i++){
                if(completeData[i].ID != undefined && completeData[i].ID != null){
                    if(completeData[i].ID == rowData.ID){
                        if(completeData[i].isChecked == false){
                            completeData[i].isChecked=true;
                        }
                        else{
                                completeData[i].isChecked=false;
                        }
                        
                    }
                }
            }
        }
         this.props.getGridData(completeData);
        let enable = false;
         if(completeData != undefined && completeData.length > 0 && completeData != null){
            for(var i =0 ; i < completeData.length ; i++){
                if(completeData[i].ID != undefined && completeData[i].ID != null){
					if(completeData[i].isChecked == true){
                        if(completeData[i].actionneeded =="No"){
                            if(completeData[i].status.toLowerCase() == "approved") {
                                enable = true;
                            } else {
                                enable = false;
                                break;
                            }

                        }
                        else {
                            enable = false;
                                break;
                        }
                        
                    }
                }
                // if(completeData[i].ID != undefined && completeData[i].ID != null){
				// 	if(completeData[i].isChecked == true){
                //         if(completeData[i].status.toLowerCase() == "approved") {
                //             enable = true;
                //         } else {
                //             enable = false;
                //             break;
                //         }
                //     }
                // }
            }
            this.props.exportBtnState(!enable);
        }
        let requestEnable = false;
         if(completeData != undefined && completeData.length > 0 && completeData != null){
            for(var i =0 ; i < completeData.length ; i++){
                
                if(completeData[i].ID != undefined && completeData[i].ID != null){
					if(completeData[i].isChecked == true){
                        if(completeData[i].actionneeded =="No"){
                                if(completeData[i].status.toLowerCase() == "not started"
                                 || completeData[i].status.toLowerCase() == "finance review"){
                                    requestEnable = true;
                                }else{
                                    requestEnable = false;
                                    break;
                                }
                        }
                        else {
                            requestEnable = false;
                            break;
                        }
                    }
                }
            }
            this.props.requestApprovalBtn(!requestEnable);
        }

    }

    toggleAll(){
        
        var completeData = this.state.customerRecord;
        if(completeData != undefined && completeData.length > 0 && completeData != null){
            for(var i =0 ; i < completeData.length ; i++){
                if(completeData[i].ID != undefined && completeData[i].ID != null){
                        if(completeData[i].isChecked == false){
                            completeData[i].isChecked=true;
                        }
                        else{
                            completeData[i].isChecked=false;
                        }
                }
            }
        }
    }

    selectInvoiceData(row){
        return (
                <span>
                <Checkbox type="checkbox" value={row.original.isChecked}
                 key={row.original.ID}
                 onChange={this.toggleRow.bind(this,row,row.original)}
                 name={"'"+row.original.ID+"'"}/>
                 </span>
        )
    }

    render() {
        ////2019-05-17T00:00:00.000+0000
        //console.log(moment().utc().format('YYYY-MM-DDTHH:mm:SSS[Z].ssZZ'))
        //moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ'); 
        //console.log(moment().utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"))
        
         const columns = [
            {
                id: '_select',
                Header: props => <div><input className="hide" type="checkbox"  onClick={this.toggleAll} /></div>,
                accessor: '_select', // String-based value accessors!
                headerClassName: 'theader',
                width: 50,
                Cell: this.selectInvoiceData,
                filterable: false,
                sortable: false
            },
       {
            id: 'spv',
            Header: props => <div><span className="table_nameprop">SPV</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
            accessor: 'spv', // String-based value accessors!
            headerClassName: 'theader',
            width: 150,
            filterable: true,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'spv'}] }), 
            filterAll: true,
             Filter: ({ filter, onChange }) => (
                 <div className="form-group row view_search" style={{ marginLeft: '-16px' }}>
                     <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                         <input type="text"
                             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                             value={filter ? filter.value : ''}
                             maxLength= {30}
                             style={{
                                 width: '100%',
                                 height: '44px'
                             }} />
                     </div>
                     <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                         <Icon name="search-small" size="small" title=""/>
                     </div>
                 </div>
            ),
            // filterable: false
        },{
            id: 'customer',
            Header: 'Customer',
            accessor: 'customer', // String-based value accessors!
            headerClassName: 'theader',
            width: 150,
            filterable: true,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'customer'}] }),
            filterAll: true,
             Filter: ({ filter, onChange }) => (
                 <div className="form-group row view_search" style={{ marginLeft: '-16px' }}>
                     <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                         <input type="text"
                             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                             value={filter ? filter.value : ''}
                             maxLength= {30}
                             style={{
                                 width: '100%',
                                 height: '44px'
                             }} />
                     </div>
                     <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                         <Icon name="search-small" size="small" title=""/>
                     </div>
                 </div>
            ),
            // filterable: false
        }, {
            id: 'currency',
            Header: 'Currency',
            accessor: 'currency',
            headerClassName: 'theader',
            width: 150,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "EUR") {
                        return row[filter.id] == 'EUR';
                    }
                    if (filter.value === "NOK") {
                        return row[filter.id] == 'NOK';
                    }
                    if (filter.value === "SEK") {
                        return row[filter.id] == 'SEK';
                    }
                    if (filter.value === "DKK") {
                        return row[filter.id] == 'DKK';
                    }
                    if (filter.value === "GBP") {
                        return row[filter.id] == 'GBP';
                    }
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('currencyType')}
                        className='customerType_selection'
                        isError={false}
                        
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        },{
            id: 'leasefee',
            Header: props => <div><span className="table_nameprop">Lease fee</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
            accessor: 'leasefee', // String-based value accessors!
            headerClassName: 'theader',
            Cell : (row)=> <LocaleFormattedValue type={'currency'} value={row.value}/>,
            filterable: false
        },{
            id: 'invoicingperiod',
            Header: props => <div><span className="table_nameprop">Invoicing period</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
            accessor: 'invoicingperiod', // String-based value accessors!
            headerClassName: 'theader',
           width: 200,
           Cell : (row)=> <LocaleFormattedValue type={'dateRange'} delimiter={'-'} value={row.value}/>,
            filterable: true,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'invoicingperiod'}] }),
            filterAll: true,
             Filter: ({ filter, onChange }) => (
                 <div className="form-group row view_search" style={{ marginLeft: '-16px' }}>
                     <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                         <input type="text"
                             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                             value={filter ? filter.value : ''}
                             maxLength= {30}
                             style={{
                                 width: '100%',
                                 height: '44px'
                             }} />
                     </div>
                     <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                         <Icon name="search-small" size="small" title=""/>
                     </div>
                 </div>
            ),
            // filterable: false
        }, {
            id: 'pmtterms',
            Header: 'PMT terms',
            accessor: 'pmtterms',
            headerClassName: 'theader',
            width: 150,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "NR In Arrears" || filter.value === "NR In arrears") {
                        //this.updateData('Yes',this.state.invoiceListType)
                        return row[filter.id] == 'NR In Arrears';
                    }
                    if (filter.value === "NR In Advance" || filter.value === "NR In advance") {
                       // this.updateData('Yes',this.state.invoiceListType)
                        return row[filter.id] == 'NR In Advance';
                    }
                   
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('pmtTermsType')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        }, {
            id: 'invoicingfrequency',
            Header: 'Invoicing frequency',
            accessor: 'invoicingfrequency',
            headerClassName: 'theader',
            width: 150,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "Annually") {
                        //this.updateData('Yes',this.state.invoiceListType)
                        return row[filter.id] == 'Annually';
                    }
                    if (filter.value === "Semi-Annually") {
                       // this.updateData('Yes',this.state.invoiceListType)
                        return row[filter.id] == 'Semi-Annually';
                    }
                    if (filter.value === "Quarterly") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == 'Quarterly';
                     }
                     if (filter.value === "Monthly") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == 'Monthly';
                     }
                   
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('invoicingfrequency')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        },  {
            id: 'invoicetype',
            Header: 'Invoice type',
            accessor: 'invoicetype',
            headerClassName: 'theader',
            width: 150,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    var actionNeededFlag = this.state.actionNeededFlag;
                    if (filter.value === 'All') {
                        return true;
                    }
                    if (filter.value === 'Interest') {
                       // this.setState({invoiceListType:'Interest'});
                       //this.updateData(actionNeededFlag,'Interest');
                        return row[filter.id] == 'Interest';
                    }
                    if (filter.value === 'Index') {
                        
                        //this.updateData(actionNeededFlag ,'Index');
                         return row[filter.id] == 'Index';
                     }
                   
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('invoicetype')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : 'All'}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        },{
            id: 'leasecontractid',
            Header: 'Deal ID',
            accessor: 'leaseContractId', // String-based value accessors!
            headerClassName: 'theader',
            width: 150,
            filterable: true,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'leasecontractid'}] }),
            filterAll: true,
             Filter: ({ filter, onChange }) => (
                 <div className="form-group row view_search" style={{ marginLeft: '-10%' }}>
                     <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                         <input type="text"
                             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                             value={filter ? filter.value : ''}
                             maxLength= {30}
                             style={{
                                 width: '100%',
                                 height: '44px'
                             }} />
                     </div>
                     <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                         <Icon name="search-small" size="small" title=""/>
                     </div>
                 </div>
            ),
            // filterable: false
        },{
            id: 'invoiceCreditStatus',
            Header: 'Credit invoice status',
            accessor: 'invoiceCreditStatus',
            headerClassName: 'theader',
            width: 200,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "Yes") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == "Yes";
                     }
                     if (filter.value === "Yes – Invoiced") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == "Yes – Invoiced";
                     }
                     if (filter.value === "yes – Credit Only") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == "yes – Credit Only";
                     }
                     if (filter.value === "Pending – Invoiced") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == "Pending – Invoiced";
                     }
                     if (filter.value === "Pending – Credit Only") {
                        // this.updateData('Yes',this.state.invoiceListType)
                         return row[filter.id] == "Pending – Credit Only";
                     }
                    if (filter.value ===   "No") {
                        //this.updateData('Yes',this.state.invoiceListType)
                        return row[filter.id] == "No";
                    }
                    
                    
                     
                   
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue="All"
                        suggestions={this.generateData('invoiceCreditStatus')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        }, {
            id: 'status',
            Header: 'Status',
            accessor: 'status',
            headerClassName: 'theader',
            width: 150,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === 'Pending Approval') {
                        return row[filter.id] == 'Pending Approval';
                    }
                    if (filter.value === 'In Progress') {
                        return row[filter.id] == 'In Progress';
                    }
                    if (filter.value === 'Finance Review') {
                        return row[filter.id] == 'Finance Review';
                        }
                    if (filter.value === 'Approved') {
                        return row[filter.id] == 'Approved';
                    }
                    if (filter.value === 'Rejected') {
                        return row[filter.id] == 'Rejected';
                    }
                    if (filter.value === 'Exported') {
                        return row[filter.id] == 'Exported';
                    }
                    if (filter.value === 'Export failed') {
                        return row[filter.id] == 'Export failed';
                    }
                    if (filter.value === 'Not Started') {
                        return row[filter.id] == 'Not Started';
                    }
                    if (filter.value === 'Edit Request Approved') {
                        return row[filter.id] == 'Edit Request Approved';
                    }
                    if (filter.value === 'Edit Request Rejected') {
                        return row[filter.id] == 'Edit Request Rejected';
                    }
                                      
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('status')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        },  {
            id: 'actionneeded',
            Header: 'Action needed',
            accessor: 'actionneeded',
            headerClassName: 'theader',
            width: 150,
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    var invoiceType = this.state.invoiceListType;
                   // var actionNeededFlag = this.state.actionNeededFlag;
                   if (filter.value === "All") {
                    return true;
                }
                    if (filter.value === 'No') {
                       // this.updateData('No',invoiceType);
                        return row[filter.id] == 'No';
                    }
                    if (filter.value === 'Yes') {
                       // this.updateData('Yes',invoiceType);
                        return row[filter.id] == 'Yes';
                    }
                   
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('actionneeded')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : 'All'}
                        onChange={(event, { value, method }) => onChange(value)} 
                    />
        }
]

        return <ReactTableFixedColumns
            data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
            columns={columns}
            loading={this.state.loading}
            showPagination = {true}
            showPaginationTop = {false}
            showPaginationBottom = {true}
            showPageSizeOptions = {true}
            className= 'tabledata'
            // style = {"border: 1px solid blue"}
            
            
            // headerClassName= 'theader'
            // pageSizeOptions = {[5, 10, 20, 25, 50, 100]}
            defaultPageSize = {5}
            pageSize={this.props.selectedRecord}
            PaginationComponent={Pagination}
            onFilteredChange = {undefined}
            defaultSortDesc = {false}
            // onFilteredChange={(filtered, column) => {... }
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            noDataText= 'No rows found'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
            filterable
            defaultFilterMethod={(filter, row) =>
                String(row[filter.id]) === filter.value}
            getTrProps={(state, rowInfo) => {
                
                if (rowInfo && rowInfo.row) {
                    return {
                        onClick: (e) => {
                            localStorage.setItem('datasave', 'false');
                            
                            this.setState({
                                selected: rowInfo.index
                            });
                            localStorage.setItem("Message", '');
                                //if(rowInfo.original.invoicetype =="Interest" && rowInfo.original.actionneeded== "Yes" &&  rowInfo.original.status== "Not Started"){
                                    if(rowInfo.original.invoicetype =="Interest" && rowInfo.original.status=="Exported"){
                                        this.props.history.push({
                                        // pathname: '/lms/interestInvoicingForm',
                                        pathname: '/lms/creditInvoiceInterest',
                                        state: { rowID: rowInfo}
                                        })
                                        }
                                else if(rowInfo.original.invoicetype =="Interest" && rowInfo.original.status!="Exported"){
                                this.props.history.push({
                                // pathname: '/lms/creditInvoiceInterest',
                                pathname: '/lms/calculateInterest',
                                state: { rowID: rowInfo}
                                })
                                }
                                //if(rowInfo.original.invoicetype == "Index" && rowInfo.original.status== "Not Started" || rowInfo.original.status== "Pending Approval") {
                                    if(rowInfo.original.invoicetype =="Index"  && rowInfo.original.status=="Exported" ){
                                        this.props.history.push({
                                        //  pathname: '/lms/calculateIndexInvoice',
                                        pathname: '/lms/creditInvoice',
                                        state: { rowID: rowInfo}
                                        })
                                        localStorage.setItem('rowData', rowInfo);
                                        }
                                else if(rowInfo.original.invoicetype == "Index" && rowInfo.original.status!="Exported" ) {
                                this.props.history.push({
                                    
                                // pathname: '/lms/viewInvoicingDetail',
                                pathname: '/lms/calculateIndexInvoice',
                                state: { rowID: rowInfo}
                                })
                                } 
                                
                        },
                        // style: {
                        //     background: rowInfo.index === this.state.selected ? '#009FAC' : 'white',
                        //     color: rowInfo.index === this.state.selected ? 'white' : 'black'
                        // }
                    }
                } else {
                    return {}
                }
            }}
            // sorted={[{ // the sorting model for the table
            //     id: 'cname',
            //     desc: true
            // }]}
            // filterAll = {true}
            // filterMethod ={ (filter, row, column) => {
            //     const id = filter.id
            //     return row[id] !== undefined ? String(row[id]).startsWith(this.props.searchInput) : true
            // }}
            // filtered={[{ // the current filters model
            //     id: 'cname',
            //     value: this.props.searchInput 
            // }]}
            // getTrProps={() => {
            //     return {
            //         className: 'row_data'
            //     }
            // }}
            // getPaginationProps = {(state, rowInfo, column, instance) => ({
            // })}
            // expanderDefaults = {
            //   sortable : false
            //   resizable = {false}
            //   filterable = {false}
            //   width = {35}
            // }
        />
    }
}

export default withRouter(invoiceListGrid);