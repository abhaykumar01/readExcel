import React from 'react';
import help from '../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { Notification } from '@zambezi/sdk/notification';

const inputDealPercField = ({ fieldTitle, helpIcon, id, helpIconValue, helpID, value, inputType, name, onChange, placeholder, errorStatus, errorMessage, mandateField, isReadOnly }) => {
    return (
        <div className="form-group row">
            <div>
            <label className="col-sm-4 col-form-label field_label_model">{fieldTitle}{helpIcon ? 
                <FlyoutTrigger
                    showOn='hover'
                    position='bottom'
                    flyout={
                        <Flyout>
                            {helpIconValue}
                        </Flyout>
                    }>
                    <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                </FlyoutTrigger>
            : null}</label>
            <div className="col-sm-1">
                <input type={inputType} value={value} name={name} id={id} onChange={onChange} 
                    className={"form-control input_FieldsDealPercent " + (errorStatus ? 'error_messageDealPercent' : '')}
                    placeholder={placeholder} readOnly={isReadOnly} />
                {/* {errorStatus ? (<div className="error_message">{errorMessage}</div>) : null} */}
            </div>
            <span className="col-sm-1 postfix_title">%</span>
        </div>
        <div>
        {
                errorStatus ?
            <div className="form-group row" style= {{marginTop:'16px', marginLeft:'-73px'}}>
            <label className="col-sm-3 col-form-label field_label_model" style= {{marginTop:'16px', marginLeft:'-73px'}}></label>
            <div className="col-sm-5" style= {{marginTop:'16px', marginLeft:'-73px'}}>
                        <Notification 
                            status='error'
                            size='small'
                            withArrow
                            arrowPosition='14px'
                            className="error_notification errorWidthField"
                        >
                            {errorMessage} 
                        </Notification>
                    </div>
                 </div>
                : null
            }
        </div>
    </div>
    );
};

export default inputDealPercField