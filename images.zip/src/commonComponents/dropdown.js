import React, { Component } from 'react';
import help from '../assets/images/help.png';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { Notification } from '@zambezi/sdk/notification';

const dropdownfield = ({ title, helpIcon,isDisabled, helpIconValue, selectedValue, helpID, classname, data, errorStatus, errorMessage, onChange, hideSelectedOptions, selectedvalueMap }) => {
     /*console.log("Inside DropDown::---- Map ", selectedvalueMap );*/

    return (
        <div>
            <div className="form-group row">
                <label for="inputState" className="col-sm-4 col-form-label field_label">{title}{helpIcon ?
                    <FlyoutTrigger
                        showOn='hover'
                        position='bottom'
                        flyout={
                            <Flyout>
                                {helpIconValue}
                            </Flyout>
                        }>
                        <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                    </FlyoutTrigger>
                    : null}</label>
                <div className="col-sm-8">
                    <Select
                        isDisabled={isDisabled}
                        defaultValue={selectedValue}
                        value={selectedValue}
                        suggestions={data}
                        placeholder='Select'
                        className={classname}
                        isError={errorStatus}
                        onChange={onChange}
                        // onSuggestionSelected={onSuggestionSelected}
                        // renderSuggestion={renderSuggestion}
                        // getSuggestionValue={getSuggestionValue}
                    />
                </div>
            </div>

            {
                errorStatus ?
                    <div className="form-group row">
                        <label className="col-sm-4 col-form-label field_label_model" style={{ marginLeft: '0px' }}></label>
                        <div className="col-sm-5" style={{ width: '47%' }}>
                            <Notification
                                status='error'
                                size='small'
                                withArrow
                                arrowPosition='14px'
                                className="error_notification"
                            >
                                {errorMessage}
                            </Notification>
                        </div>
                    </div>
                    : null
            }
        </div>
    );
};

export default dropdownfield