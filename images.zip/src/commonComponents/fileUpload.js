import React from 'react';
import '../components/fileUpload.css';

class fileUpload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // selectedFile: null
        }
    }

    render() {
        return (
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <form method="post" action="#" id="#">
                            <div class="form-group files custom_file">
                                {/* <label>Upload Your File </label> */}
                                <input type="text" disabled={true} class="form-control file_upload_tlp" onChange={this.props.onChange} />
                                <input type="file" ref={this.props.reference} class="form-control file_upload_hide" accept=".msg" onChange={this.props.onChange} />
                            </div>

                            {/* <button type="button" id="btt" class="btn btn-primary save_btn" onClick={this.onClickHandler}>Upload</button> */}
                        </form>     
	                </div>
                </div>
            </div>
        )
    }
}

export default fileUpload;