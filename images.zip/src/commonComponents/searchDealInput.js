import React from 'react';
import help from '../assets/images/help.png';
import ReactTooltip from 'react-tooltip';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'

const searchinputfield = ({ fieldTitle, helpIcon, helpIconValue, helpID, inputType, value, name, onChange, onClick, placeholder }) => {
    return (
        <div class="form-group row">
            <label for="" class="col-sm-3 col-form-label field_label_model">{fieldTitle}{helpIcon ? 
                <FlyoutTrigger
                    showOn='hover'
                    position='bottom'
                    flyout={
                        <Flyout>
                            {helpIconValue}
                        </Flyout>
                    }>
                    <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                </FlyoutTrigger>
            : null}</label>
            <div class="col-sm-4 inner-addon right-addon search_column">
                <input type={inputType} value={value} onChange={onChange} name={name} class="form-control input_Fields_searchDeal" placeholder={placeholder} />
                <div class="input-group-btn">
                    <button class="btn btn-default search_btn_model" onClick={onClick}>
                        <i class="glyphicon glyphicon-search"></i>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default searchinputfield