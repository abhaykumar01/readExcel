import React from 'react';
import '../components/fileUpload.css';

class docUpload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // selectedFile: null
        }
    }

    render() {
        return (
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <form method="post" action="#" id="#">
                            <div class="form-group files custom_file">
                                <input type="text" disabled={true} 
                                    className={"form-control file_upload_tlp " + (this.props.docStatus ? 'errorTextBox' : '')} onChange={this.props.onChange} />
                                <input type="file" ref={this.props.reference} class="form-control file_upload_hide"
                                    accept="application/pdf,image/png, image/jpeg, .xls,.xlsx,.pptx,.doc,.docx,application/msword" onChange={this.props.onChange} multiple/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

export default docUpload;