import React from 'react';
import { Lease_Constants } from '../models/LeaseConstants';
import { RadioButton } from '@zambezi/sdk/form-elements'

class popupmessage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedWorkFlow : Lease_Constants.WORKFOW_NEW_WORKFLOW,
        }
    }

    onSelectWorkFlow(workflow, e, isSelected){
        if(isSelected){
            this.state.selectedWorkFlow=workflow;
        }
    }

    render() {
        return (
            <div id={this.props.datatarget} class="modal fade"
                // className={"modal fade " + (this.props.openDialog ? 'showDialog' : 'closeDialog')}
                role="dialog">
                <div class="modal-dialog dealPopUp">
                    <div class="modal-content">
                        <div class="modal-header">
                            {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                            <h4 class="modal-title header_title">{this.props.headerTitle}</h4>
                        </div>
                        <div class="modal-body">
                            <p className="header_body">Select an option for approval workflow</p>
                            <div className=".zb-row-is-6">
                                <label className="-New-workflow-is-r optionLabel" >1.New workflow is required</label>
                                <RadioButton id="workflow-radio-1" name="workFlowOptions" defaultChecked onChange={this.onSelectWorkFlow.bind(this, Lease_Constants.WORKFOW_NEW_WORKFLOW)}/>
                            </div>
                            <br />
                            <div className=".zb-row-is-6">
                                <label className="-New-workflow-is-r optionLabel" >2.Partial update is required</label>
                                <RadioButton id="workflow-radio-2" name="workFlowOptions" onChange={this.onSelectWorkFlow.bind(this, Lease_Constants.WORKFLOW_PARTIAL_WORKFLOW)}/>
                            </div>
                            <br />
                            <div className=".zb-row-is-6">
                                <label className="-New-workflow-is-r optionLabel" >3.No update is required</label>
                                <RadioButton id="workflow-radio-3" name="workFlowOptions" onChange={this.onSelectWorkFlow.bind(this, Lease_Constants.NO_UPDATE_REQUIRED)}/>
                            </div>
                             
                        </div>
                        <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '20px' }}>
                            <button className='zb-button zb-button-primary save_pop_btn' data-dismiss="modal" onClick={()=>this.props.onClick(this.state.selectedWorkFlow)}>{this.props.buttontext1}</button>
                            <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss='modal'>{this.props.buttontext2}</button>
                         </div>
                    </div>

                </div>
            </div>
        )
    }
}


export default popupmessage