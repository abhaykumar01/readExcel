import React from 'react';

const towWayButtonGroup = ({fieldTitle, toggleOn, buttonName1, buttonName2}, btnWidth, groupbtnWidth, onclickEle) =>{
    return(
        <div class="form-group row">
            <label for="" class="col-sm-4 col-form-label field_label_model">{fieldTitle}</label>
                <div className="col-sm-4">
                    <div class="idxn_type_model">
                        <div class="btn-group" >
                            <button type="button" className={"btn btn-primary twoWay_btn_idxn " + ({toggleOn} ? 'twoWayBnt_selected' : 'twoWayBnt_notselected')} style = {{btnWidth}} onClick={onclickEle}>{buttonName1}</button>
                            <button type="button" className={"btn btn-primary twoWay_btn_idxn " + (!{toggleOn} ? 'twoWayBnt_selected' : 'twoWayBnt_notselected')} style = {{btnWidth}} onClick={onclickEle}>{buttonName2}</button>
                    </div>
                </div>
            </div>
        </div>
    );
    
}

export default towWayButtonGroup;