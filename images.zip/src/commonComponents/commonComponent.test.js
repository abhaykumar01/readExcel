import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import renderer from 'react-test-renderer';
import { BrowserRouter as Router } from 'react-router-dom';
import Dropdownfield from './DropdownField'
import FileUpload from './fileUpload'
import CalenderInput from './calenderInput'
import ApiData from './ApiData'
import Form from './form'
import Gridpage from './gridpage'
import Header from './header'
import InputDealField from './inputDealField'
import InputField from './inputField'
import Pagination from './pagination'
import PopupMessage from './popupMessage'
import SearchDealInput from './searchDealInput'
import Searchinput from './searchinput'
import SPV from './spv'
import Table from './table'
import TLPGrid from './TLPGrid'
import TLPGridStructure from './TLPGridStructure'
import UpdateTLPGrid from './updateTLPGrid'

Enzyme.configure({ adapter: new Adapter() });

describe("Dropdown component", () => {
    test("renders", () => {
        const wrapper = shallow(<Dropdownfield />);
        expect(wrapper.exists()).toBe(true);
    });
});

describe("FileUpload component", () => {
    test("renders", () => {
        const wrapper = shallow(<FileUpload />);
        expect(wrapper.exists()).toBe(true);
    });
});

describe("CalenderInput component", () => {
    test("renders", () => {
        const wrapper = shallow(<CalenderInput />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("Form component", () => {
    test("renders", () => {
        const wrapper = shallow(<Form />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("Gridpage component", () => {
    test("renders", () => {
        const wrapper = shallow(<Gridpage />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("Header component", () => {
    test("renders", () => {
        const wrapper = shallow(<Header />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("InputDealField component", () => {
    test("renders", () => {
        const wrapper = shallow(<InputDealField />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("InputField component", () => {
    test("renders", () => {
        const wrapper = shallow(<InputField />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("Pagination component", () => {
    test("renders", () => {
        const wrapper = shallow(<Pagination />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("PopupMessage component", () => {
    test("renders", () => {
        const wrapper = shallow(<PopupMessage />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("SearchDealInput component", () => {
    test("renders", () => {
        const wrapper = shallow(<SearchDealInput />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("Searchinput component", () => {
    test("renders", () => {
        const wrapper = shallow(<Searchinput />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("SPV component", () => {
    test("renders", () => {
        const wrapper = shallow(<SPV />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("Table component", () => {
    test("renders", () => {
        const wrapper = shallow(<Table />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("TLPGrid component", () => {
    test("renders", () => {
        const wrapper = shallow(<TLPGrid />);
        expect(wrapper.exists()).toBe(true);
    });
});
describe("UpdateTLPGrid component", () => {
    test("renders", () => {
        const wrapper = shallow(<UpdateTLPGrid />);
        expect(wrapper.exists()).toBe(true);
    });
});