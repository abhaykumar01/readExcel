import React from 'react';
import DatePicker from '@zambezi/sdk/date-picker';
import { allowedFormats } from '@zambezi/sdk/date-picker'
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import '@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/icons';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import { Notification } from '@zambezi/sdk/notification';
import moment from 'moment';

const calenderinputfieldCustom = ({ fieldTitle, inputType,errorMessage, onError, errorStatus, value,
    name, onChange, onClick, placeholder, getOptionInputDate, id, className }) => {
    return (
        <div>
            <div class="form-group row">
                <label for="" class="col-sm-4 col-form-label field_label_cust ">{fieldTitle}</label>
                <div className="col-sm-4 inner-addon right-addon search_column">
                    <DatePicker
                        className={className}  
                        date={value}
                        onChange={onChange}
                        placeholder='DD MM'
                        onError={onError}
                        onInputChange={getOptionInputDate}
                        error={errorStatus}
                        name={name}
                        dateFormat='DD MM YY'
                        id={id}
                    // isMobile={true}
                    // allowedFormats='DD/MM/YYYY'
                    />
                </div>
            </div>
            {errorStatus ?
                <div className="form-group row">
                    <label className="col-sm-4 col-form-label field_label_model"></label>
                    <div className="col-sm-4 " >
                        <Notification
                            status='error'
                            size='small'
                            withArrow
                            arrowPosition='14px'
                            className="error_notification zb_datePicker"
                        >
                            {errorMessage}
                        </Notification>
                    </div>
                </div>
                : null}
        </div>
    );
};

export default calenderinputfieldCustom