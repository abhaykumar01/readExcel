import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { Route, withRouter } from 'react-router-dom';
import { loadData } from '../commonComponents/TLPGridStructure';
import { HttpPost, HttpGet, HttpPut, HttpPutWithoutBody } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { stat } from 'fs';
import { saveApproverGridStatus } from '../models/dataModel.js';
import { AuthorizationContext } from '../components/authContext/index';
import { ECM_TOGGLE } from '../config/config';
// const rawData = getPartyCustomer();
const PING = process.env.REACT_APP_PING;
class UpdateTLPGrid extends React.Component {
    static contextType = AuthorizationContext;
    constructor(props) {
        super(props);
        this.state = this.getInitialState();
        // this.renderEditableNumber = this.renderEditableNumber.bind(this);
        this.renderEditabletext = this.renderEditabletext.bind(this);
        this.renderEditableCalender = this.renderEditableCalender.bind(this);
        this.renderEditableNumberGBP = this.renderEditableNumberGBP.bind(this);
        this.renderEditableNumberTenore = this.renderEditableNumberTenore.bind(this);
        this.renderEditabletextcurve = this.renderEditabletextcurve.bind(this);
        this.renderEditableNumberSEK = this.renderEditableNumberSEK.bind(this);
        this.renderEditableNumberEUR = this.renderEditableNumberEUR.bind(this);
        this.renderEditableNumberNOK = this.renderEditableNumberNOK.bind(this);
        this.renderEditableNumberDKK = this.renderEditableNumberDKK.bind(this);
        this.renderEditableNumberCHF = this.renderEditableNumberCHF.bind(this);
        this.renderEditableNumberUSD = this.renderEditableNumberUSD.bind(this);
        this.renderEditableNumberJPY = this.renderEditableNumberJPY.bind(this);
    }

    componentDidMount() {
        this.props.onRef(this);
        var getObject;
        if (localStorage.getItem('viewRecord') != ""){
             getObject = JSON.parse(localStorage.getItem('viewRecord'));
        }else {
            getObject = [];
        }
        const { name } = this.context;
        this.setState({ userName: name });
        if(getObject.length > 0){
            var status = localStorage.getItem('approvalPending');
            localStorage.setItem('requestNumber', getObject[0].request_number);
            if(status == 'true'){
                this.props.approvalPending();
                this.props.enableApproveButton();
            }
            this.setState({ updateGridStatus: true });
            this.setState({
                tlpRecord: getObject,
                tlpUpdateRecord: getObject
            });
        }else {
            
            this.setState({ updateGridStatus: false });
            this.setState({ tlpRecord: loadData()});
        }
        var id;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log("reterive permission data");
            console.log(usersDetails);
            console.log(usersDetails.userID);
            id = usersDetails.userID;
        } else {
            let racfid = localStorage.getItem('racfID');
            id = racfid;
        }
        this.setState({
            racfID: id
        });
        
    }

    componentDidCatch(error, errorInfo) {
    }

    getInitialState = () => {
        const initialState = {
            currentpageSize: "16",
            tlpRecord: [],
            tlpUpdateRecord: [],
            loading: false,
            selected: null,
            updateGridStatus: false,
            tlp_request_no: 0,
            userName: '',
            racfID: '',
            dateCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            gbpCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            eurCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            usdCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            chfCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            dkkCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            sekCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            nokCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
            jpyCellStatus: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
        };
        return initialState;
    }

    renderEditabletext(cellInfo) {
        return (
            <input type="text"
                className="tlp_grid_cell"
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onChange={e => {
                        let data = [...this.state.tlpRecord];
                        data[cellInfo.index][cellInfo.column.id] = e.target.value;
                        this.setState({ data });
                        this.props.save();
                    }} />
        );
    }

    renderEditabletextcurve(cellInfo) {
        return (
            <input type="text"
                className="tlp_grid_cell"
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                disabled={true}
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }

    validateDateField(val) { 
        let input_date = val.original.Date;
        let time = moment(input_date, 'DD-MM-YYYY').format('DD/MM/YYYY');

        if (time == "Invalid date") {
            this.state.dateCellStatus[val.index] = true;
            this.forceUpdate();
        } else { 
            this.state.dateCellStatus[val.index] = false;
            this.state.tlpRecord[val.index][val.column.id] = time;
            this.forceUpdate();
        }
    }

    
// className={"tlp_grid_cell " + (this.state.dateCellStatus[cellInfo.index] ? 'cell_error' : '')}
    renderEditableCalender(cellInfo) {
        return (
            <input type="text"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.dateCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[0][cellInfo.column.id]}
                placeholder="DD/MM/YYYY"
                disabled={cellInfo.index == 0 ? false: true}
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }}
                onBlur={
                    this.validateDateField.bind(this, cellInfo)
            } 
            />
        );
    }

    // handleChange = (e, info) => {
    //     if (info.target.name == ("gbp" + e.index)) { 
    //         const data = [...this.state.tlpRecord];
    //         data[e.index][e.column.id] = info.target.value;
    //         this.setState({ data }, function () { 
    //             let elemID = "gbp" + e.index;
    //             document.getElementById(elemID).focus();
    //         });
    //         // this.state.tlpRecord = data;
    //         // this.forceUpdate();
    //         // this.props.save();
           
    //         // e.foc
    //     }
       
    // }
  
    renderEditableNumberGBP(cellInfo) {
        return (
            <input type="number"
                className={"tlp_grid_cell " + (this.state.gbpCellStatus[cellInfo.index] ? 'cell_error' : '')}
                placeholder="Enter"
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    // this.state.tlpRecord = data;
                    this.props.save();
                }}
            />            
        );
    }
    renderEditableNumberEUR(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.eurCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                placeholder= "Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
    renderEditableNumberUSD(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.usdCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onkeydown="return event.keyCode !== 69"
                placeholder="Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
    renderEditableNumberCHF(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.chfCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onkeydown="return event.keyCode !== 69"
                placeholder="Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
    renderEditableNumberDKK(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.dkkCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onkeydown="return event.keyCode !== 69"
                placeholder="Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
    renderEditableNumberSEK(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.sekCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onkeydown="return event.keyCode !== 69"
                placeholder="Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
    renderEditableNumberNOK(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.nokCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onkeydown="return event.keyCode !== 69"
                placeholder="Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
    renderEditableNumberJPY(cellInfo) {
        return (
            <input type="number"
                // className="tlp_grid_cell"
                className={"tlp_grid_cell " + (this.state.jpyCellStatus[cellInfo.index] ? 'cell_error' : '')}
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                onkeydown="return event.keyCode !== 69"
                placeholder="Enter"
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }
//{this.state.updateGridStatus}
    renderEditableNumberTenore(cellInfo) {
        return (
            <input type="number"
                className="tlp_grid_cell"
                value={this.state.tlpRecord[cellInfo.index][cellInfo.column.id]}
                disabled={true}
                onChange={e => {
                    let data = [...this.state.tlpRecord];
                    data[cellInfo.index][cellInfo.column.id] = e.target.value;
                    this.setState({ data });
                    this.props.save();
                }} />
        );
    }

    componentWillUnmount() {
        this.props.onRef(null)
    }

    importFromExcel(data){
        var output = [];
        var count = data.length;
        let tenor = [0.5, 1, 1.5, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30];
        let gbp = '';
        let eur = '';
        let usd = '';
        let chf = '';
        let dkk = '';
        let sek = '';
        let nok = '';
        let jpy = '';

        if (count >= 16 && count <= 17) {
            for (var i = 1; i < count; i++) {
                if (data[0][i - 1] == 'GBP') {
                    gbp = i - 1;
                } else if (data[0][i - 1] == 'EUR') {
                    eur = i - 1;
                } else if (data[0][i - 1] == 'USD') {
                    usd = i - 1;
                } else if (data[0][i - 1] == 'CHF') {
                    chf = i - 1;
                } else if (data[0][i - 1] == 'DKK') {
                    dkk = i - 1;
                } else if (data[0][i - 1] == 'SEK') {
                    sek = i - 1;
                } else if (data[0][i - 1] == 'NOK') {
                    nok = i - 1;
                } else if (data[0][i - 1] == 'JPY') {
                    jpy = i - 1;
                }
            }
            for (var i = 1; i < count; i++) {
                let time = moment(data[i][1]).format('DD/MM/YYYY');
                if (typeof (data[i][3]) == "string" || typeof (data[i][4]) == "string" || typeof (data[i][5]) == "string" ||
                    typeof (data[i][6]) == "string" || typeof (data[i][7]) == "string" || typeof (data[i][8]) == "string" ||
                    typeof (data[i][9]) == "string" || typeof (data[i][10]) == "string" || time == "Invalid date") {
                    output.push({
                        "Tenors": tenor[i - 1],
                        "Date": '',
                        "Curve": 'ALCo TLP',
                        "GBP": '',
                        "EUR": '',
                        "USD": '',
                        "CHF": '',
                        "DKK": '',
                        "SEK": '',
                        "NOK": '',
                        "JPY": ''
                    });
                    this.props.importFileValueFailed();
                } else {
                    // let time = moment(data[i][1]).format('DD/MM/YYYY');
                    output.push({
                        "Tenors": tenor[i - 1],
                        "Date": time,
                        "Curve": 'ALCo TLP',
                        "GBP": data[i][gbp],
                        "EUR": data[i][eur],
                        "USD": data[i][usd],
                        "CHF": data[i][chf],
                        "DKK": data[i][dkk],
                        "SEK": data[i][sek],
                        "NOK": data[i][nok],
                        "JPY": data[i][jpy]
                    });
                }

            }
            this.setState({ tlpRecord: output });
            this.props.save();
        } else {
            this.props.importFileFailed();
        }
        
    }

    saveTLPData() {
        console.log('save TLP record');
        console.log(this.state.tlpRecord);
        console.log("userName:: " + this.state.userName);
        var username = this.state.racfID;
        // if (this.state.userName == '' || this.state.username == undefined) {
        //     username = 'LmsUser'
        // }
            let tlpData = [];
            var recordCount = this.state.tlpRecord.length;
            var data = this.state.tlpRecord;
            var updateData = this.state.tlpUpdateRecord;
            var count = 0;
            for (var i = 0; i < recordCount; i++) {
                var no = 0;
                for (var j = count; j < count + 16; j++) {
                    let time = moment(data[no].Date, 'DD-MM-YYYY').format('DD/MM/YYYY');
                    
                    if (data[no].Date === "" || Math.sign(data[no].Date) === -1 || data[no].Date === null || time == "Invalid date") {
                        this.state.dateCellStatus[no] = true;
                    } else {
                        this.state.dateCellStatus[no] = false;
                    }
                    var date_input = moment(data[0].Date, 'DD/MM/YYYY').format('YYYY-MM-DD');
                    var request_no = data[no].request_number;
                    var created_on = data[no].created_On;
                    var base_ID_gbp = data[no].base_ID_gbp;
                    var base_ID_eur = data[no].base_ID_eur;
                    var base_ID_usd = data[no].base_ID_usd;
                    var base_ID_chf = data[no].base_ID_chf;
                    var base_ID_dkk = data[no].base_ID_dkk;
                    var base_ID_sek = data[no].base_ID_sek;
                    var base_ID_nok = data[no].base_ID_nok;
                    var base_ID_jpy = data[no].base_ID_jpy;
                    if (this.state.updateGridStatus) {
                        request_no = updateData[no].request_number;
                        created_on = updateData[no].created_On;
                        base_ID_gbp = updateData[no].base_ID_gbp;
                        base_ID_eur = updateData[no].base_ID_eur;
                        base_ID_usd = updateData[no].base_ID_usd;
                        base_ID_chf = updateData[no].base_ID_chf;
                        base_ID_dkk = updateData[no].base_ID_dkk;
                        base_ID_sek = updateData[no].base_ID_sek;
                        base_ID_nok = updateData[no].base_ID_nok;
                        base_ID_jpy = updateData[no].base_ID_jpy;
                    }
                    if (request_no == undefined) {
                        request_no = "";
                        base_ID_gbp = "";
                        base_ID_eur = "";
                        base_ID_usd = "";
                        base_ID_chf = "";
                        base_ID_dkk = "";
                        base_ID_sek = "";
                        base_ID_nok = "";
                        base_ID_jpy = "";
                        created_on = "";
                    }
                   
                    if (j < 16) {
                        if (data[no].GBP === "" || Math.sign(data[no].GBP) === -1 || data[no].GBP === null) {
                            this.state.gbpCellStatus[no] = true;
                        } else {
                            this.state.gbpCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_gbp,
                            "currency_Name": "GBP",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].GBP,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 32) {
                        if (data[no].EUR === "" || Math.sign(data[no].EUR) === -1 || data[no].EUR === null) {
                            this.state.eurCellStatus[no] = true;
                        } else { 
                            this.state.eurCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_eur,
                            "currency_Name": "EUR",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].EUR,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 48) {
                        if (data[no].USD === "" || Math.sign(data[no].USD) === -1 || data[no].USD === null) {
                            this.state.usdCellStatus[no] = true;
                        } else {
                            this.state.usdCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_usd,
                            "currency_Name": "USD",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].USD,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 64) {
                        if (data[no].CHF === "" || Math.sign(data[no].CHF) === -1 || data[no].CHF === null) {
                            this.state.chfCellStatus[no] = true;
                        } else {
                            this.state.chfCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_chf,
                            "currency_Name": "CHF",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].CHF,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 80) {
                        if (data[no].DKK === "" || Math.sign(data[no].DKK) === -1 || data[no].DKK === null) {
                            this.state.dkkCellStatus[no] = true;
                        } else {
                            this.state.dkkCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_dkk,
                            "currency_Name": "DKK",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].DKK,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 96) {
                        if (data[no].SEK === "" || Math.sign(data[no].SEK) === -1 || data[no].SEK === null) {
                            this.state.sekCellStatus[no] = true;
                        } else {
                            this.state.sekCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_sek,
                            "currency_Name": "SEK",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].SEK,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 112) {
                        if (data[no].NOK === "" || Math.sign(data[no].NOK) === -1 || data[no].NOK === null) {
                            this.state.nokCellStatus[no] = true;
                        } else {
                            this.state.nokCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_nok,
                            "currency_Name": "NOK",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].NOK,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    } else if (j < 128) {
                        if (data[no].JPY === "" || Math.sign(data[no].JPY) === -1 || data[no].JPY === null) {
                            this.state.jpyCellStatus[no] = true;
                        } else {
                            this.state.jpyCellStatus[no] = false;
                        }
                        tlpData.push({
                            "created_On": created_on,
                            "tlp_BaseTable_Request_Number": request_no,
                            "tlp_Base_ID": base_ID_jpy,
                            "currency_Name": "JPY",
                            "tlp_Tenore_In_Yr": data[no].Tenors,
                            "tlp_Base_Date": date_input,
                            "tlp_Curve": data[no].Curve,
                            "tlp_Value": data[no].JPY,
                            "tlp_User": username,
                            "tlp_Status": "Draft",
                            "ui_Sequence": no,
                        });
                    }
                    no += 1;
                }
                count += 16;
        }
        this.forceUpdate();
            if (this.state.dateCellStatus.includes(true) || this.state.gbpCellStatus.includes(true) || this.state.eurCellStatus.includes(true)
                || this.state.usdCellStatus.includes(true) || this.state.chfCellStatus.includes(true) || this.state.dkkCellStatus.includes(true)
                || this.state.sekCellStatus.includes(true) || this.state.nokCellStatus.includes(true) || this.state.jpyCellStatus.includes(true)) {
                // return true;
                this.props.pageError();
            } else { 
                this.props.noStatus();
                var currentComponent = this;
                let endPoint = API_ENDPOINT.TLP_BASE_GRID;
                if (!this.state.updateGridStatus) {
                    console.log("save data")
                    let output1 = HttpPost(currentComponent, tlpData, endPoint).then(function (response) {
                        console.log("Saved response received from server");
                        console.log(response.data);
                        localStorage.setItem('requestNumber', response.data);
                        if (ECM_TOGGLE == 'false') {
                            currentComponent.props.saveConfirm();
                            currentComponent.props.disableSave();
                            localStorage.setItem('approvalPending', 'true');
                        } else {
                            currentComponent.approveRequest();
                        }
                    })
                        .catch(function (error) {
                            // currentComponent.props.saveConfirm();
                        })
                } else {
                    let output1 = HttpPut(currentComponent, tlpData, endPoint).then(function (response) {
                        console.log("updated response received from server");
                        console.log(response.data);
                        if (ECM_TOGGLE == 'false') {
                            currentComponent.props.saveConfirm();
                            currentComponent.props.disableSave();
                            localStorage.setItem('approvalPending', 'true');
                        } else {
                            currentComponent.approveRequest();
                        }
                    })
                        .catch(function (error) {
                        })
                }
            }
       
    }

    approveRequest() {
        // this.setState({ loader: true });
        var requestno = localStorage.getItem('requestNumber');
        if (requestno) {
            var currentComponent = this;
            let payLoadData = saveApproverGridStatus(requestno, "");
            let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/Approved';
            let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
                console.log("approved Response received from server");
                console.log(response.data);
                currentComponent.props.saveConfirm();
                currentComponent.props.disableSave();
                // localStorage.setItem('approvalPending', 'Approved');
                // localStorage.setItem('status', 'approved');
                // currentComponent.setState({ status: 'approved' });
                // currentComponent.setState({ approveBtn: true });
                // currentComponent.setState({ rejectBtn: true });
                // currentComponent.setState({ loader: false });
                // currentComponent.handleSelectTab(1);

            })
                .catch(function (error) {
                    currentComponent.setState({ loader: false });
                })
        }
    }

    sendForApproval() {
        var requestno = localStorage.getItem('requestNumber');
        var racfID = this.state.racfID;
        var currentComponent = this;
        let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/Pending_For_Approval/' + requestno + '/' + racfID;
        console.log(endPoint);
        let output1 = HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
            localStorage.setItem('approvalPending', 'false');
            currentComponent.props.approvalConfirmation();
            
        })
            .catch(function (error) {
                // currentComponent.props.approvalConfirmation();
            })
    }

    render() {
        const columns = [{
            id: 'Tenors',
            Header: 'Tenors',
            accessor: 'tenors', // String-based value accessors!
            headerClassName: 'tlpheader',
            filterable: false,
            Cell: this.renderEditableNumberTenore,
            width: 76
        }, {
            id: 'Date',
            Header: 'Date',
            accessor: 'date',
            headerClassName: 'tlpheader',
            sortable: false,
            filterable: false,
                Cell: this.renderEditableCalender,
                width: 106
        }, {
                id: 'Curve', // Required because our accessor is not a string
            Header: 'Curve',
            accessor: 'curve',//d => d.friend.name // Custom value accessors!
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
                Cell: this.renderEditabletextcurve,
                width: 99
            }, {
                id: 'SEK',
                Header: 'SEK',//props => <span>Friend Age</span>, // Custom header components!
                accessor: 'sek',
                headerClassName: 'tlpheader',
                filterable: false,
                sortable: false,
                Cell: this.renderEditableNumberSEK,
                width: 73
            },{
            id: 'EUR',
            Header: 'EUR',//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'eur',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
                Cell: this.renderEditableNumberEUR,
                width: 73
            }, {
                id: 'NOK',
                Header: 'NOK',//props => <span>Friend Age</span>, // Custom header components!
                accessor: 'nok',
                headerClassName: 'tlpheader',
                filterable: false,
                sortable: false,
                Cell: this.renderEditableNumberNOK,
                width: 73
            }, {
                id: 'DKK',
                Header: 'DKK',//props => <span>Friend Age</span>, // Custom header components!
                accessor: 'dkk',
                headerClassName: 'tlpheader',
                filterable: false,
                sortable: false,
                Cell: this.renderEditableNumberDKK,
                width: 73
            }, {
            id: 'GBP',
            Header: 'GBP',//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'gbp',
            headerClassName: 'tlpheader',
            sortable: false,
            filterable: false,
                Cell: this.renderEditableNumberGBP,
                width: 73
            }, {
                id: 'CHF',
                Header: 'CHF',//props => <span>Friend Age</span>, // Custom header components!
                accessor: 'chf',
                headerClassName: 'tlpheader',
                filterable: false,
                sortable: false,
                Cell: this.renderEditableNumberCHF,
                width: 73
            },  {
            id: 'USD',
            Header: 'USD',//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'usd',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
                Cell: this.renderEditableNumberUSD,
                width: 73
        },  {
            id: 'JPY',
            Header: 'JPY',//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'jpy',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
                Cell: this.renderEditableNumberJPY,
                width: 73
        }]

        return <ReactTable
            data={this.state.tlpRecord}//{UserData}//{this.state.tlpRecord}
            columns={columns}
            // loading={this.state.loading}
            showPagination={false}
            showPaginationTop={false}
            showPaginationBottom={false}
            showPageSizeOptions={false}
            className='viewTabledata'
            // style = {"border: 1px solid blue"}
            headerClassName='tlpheader'
            defaultPageSize={16}
            defaultSortDesc={false}
        />
    }
}

export default withRouter(UpdateTLPGrid);

