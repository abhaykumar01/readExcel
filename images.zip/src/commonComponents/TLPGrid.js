import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { Route, withRouter } from 'react-router-dom';
import { HttpPost, HttpGet } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import { TLPGridData, loadData } from './TLPGridStructure';
import moment from 'moment';
import { AuthorizationContext } from '../components/authContext/index';
// const rawData = getPartyCustomer();
const PING = process.env.REACT_APP_PING;
class TLPGrid extends React.Component {
    static contextType = AuthorizationContext;
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "16",
            tlpRecord: [],
            loading: false,
            selected: null,
            viewTLPRecord: TLPGridData,
            userName: '',
        }

    }

    componentDidMount() {
        console.log("Component mount on TLP grid");
        console.log(this.context);
        // const { name, usersDetails } = this.context;
        const { name } = this.context;

        let output = [];
        for (var i = 0; i < 16; i++) {
            output.push({
                "Tenors": "-",
                "Date": "-",
                "Curve": "-",
                "SEK": "-",
                "EUR": "-",
                "NOK": "-",
                "DKK": "-",
                "GBP": "-",
                "CHF": "-",
                "USD": "-",
                "JPY": "-"
            });
        }
        var username = '';
        if (PING == 'true') {
            let { usersDetails } = this.context;
            username = usersDetails.userID;
        } else {
            username = localStorage.getItem('racfID');
        }

        this.setState({ tlpRecord: output });
        this.setState({ userName: username }, function () {
            this.fetchTLPRecords();
        });
    }

    fetchTLPRecords() {
        var currentComponent = this;
        var gridStatus = 'Approved';
        var status = localStorage.getItem('approvalPending');
        var notificationSelected = localStorage.getItem("NotificationSelected");
        console.log("call statuss  ", status)
        if (status == 'false') {
            gridStatus = 'Pending_For_Approval';
        } else if (status == 'Approved') {
            gridStatus = 'Approved';
        } else if (status == 'Rejected') {
            gridStatus = 'Rejected';
        } else {
            gridStatus = 'Draft';
        }
        var username = this.state.userName;
        if (this.state.userName == '' || this.state.userName == undefined) {
            username = localStorage.getItem('racfID');
        }
        if (notificationSelected == 'true') {
            let response = localStorage.getItem('Message');
            let data = JSON.parse(response);
            username = data.requestedBy;
        }
        let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/' + gridStatus;
        console.log(endPoint);
        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            console.log("response received from server for TLP");
            console.log(response.data);
            if (response.data.length > 0) {
                // var data = response.data;
                currentComponent.FetchTlpData(response.data, currentComponent);
            } else {
                let endPoint1 = API_ENDPOINT.TLP_BASE_GRID + '/Approved';
                HttpGet(currentComponent, endPoint1).then(function (response) {
                    console.log("response received from server");
                    console.log(response.data);
                    if (response.data.length > 0) {
                        currentComponent.FetchTlpData(response.data, currentComponent);
                    }
                })
                    .catch(function (error) {
                        localStorage.setItem('viewRecord', "");
                        currentComponent.props.updateGridStatus('');
                    })
                localStorage.setItem('viewRecord', "");
                currentComponent.props.updateGridStatus('');
            }
        })
            .catch(function (error) {
                localStorage.setItem('viewRecord', "");
                currentComponent.props.updateGridStatus('');
            })
    }

    FetchTlpData(data, currentComponent) {
        console.log("Get data");
        console.log(data);
        var recordCount = data.length;
        var gridStatus = data[0].tlp_Status;
        console.log(data.length);
        console.log(data[0].tlp_Status);
        localStorage.setItem('requestNumber', data[0].tlp_BaseTable_Request_Number);
        var output = [];
        var dataFormat = {
            "Tenors": 0,
            "Date": "",
            "Curve": "",
            "SEK": 0,
            "EUR": 0,
            "NOK": 0,
            "DKK": 0,
            "GBP": 0,
            "CHF": 0,
            "USD": 0,
            "JPY": 0,
            "request_number": 0,
            "base_ID_date": 0,
            "base_ID_gbp": 0,
            "base_ID_eur": 0,
            "base_ID_usd": 0,
            "base_ID_chf": 0,
            "base_ID_dkk": 0,
            "base_ID_sek": 0,
            "base_ID_nok": 0,
            "base_ID_jpy": 0,
            "created_On": ""
        }
        var count = 0;
        for (var i = 0; i < 16; i++) {
            var no = 0;
            // var j = i;
            for (var j = 0; j < recordCount; j++) {
                if (data[j].ui_Sequence == i) {
                    let baseID = moment(data[j].tlp_Base_Date).format('DD/MM/YYYY');
                    // let createdOn = moment(data[j].created_On).format('YYYY-MM-DD');
                    dataFormat.request_number = data[j].tlp_BaseTable_Request_Number;
                    dataFormat.Tenors = data[j].tlp_Tenore_In_Yr;
                    dataFormat.Date = baseID;
                    dataFormat.Curve = data[j].tlp_Curve;
                    // dataFormat.base_ID_gbp = data[j].tlp_Base_ID;
                    dataFormat.base_ID_date = data[j].tlp_Base_ID;
                    dataFormat.created_On = data[j].created_On;
                    // dataFormat.EUR = data[j].tlp_Value;
                    if (data[j].currency_Name === "GBP") {
                        dataFormat.GBP = data[j].tlp_Value;
                        dataFormat.base_ID_gbp = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "EUR") {
                        dataFormat.EUR = data[j].tlp_Value;
                        dataFormat.base_ID_eur = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "USD") {
                        dataFormat.USD = data[j].tlp_Value;
                        dataFormat.base_ID_usd = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "CHF") {
                        dataFormat.CHF = data[j].tlp_Value;
                        dataFormat.base_ID_chf = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "DKK") {
                        dataFormat.DKK = data[j].tlp_Value;
                        dataFormat.base_ID_dkk = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "SEK") {
                        dataFormat.SEK = data[j].tlp_Value;
                        dataFormat.base_ID_sek = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "NOK") {
                        dataFormat.NOK = data[j].tlp_Value;
                        dataFormat.base_ID_nok = data[j].tlp_Base_ID;
                    } else if (data[j].currency_Name === "JPY") {
                        dataFormat.JPY = data[j].tlp_Value;
                        dataFormat.base_ID_jpy = data[j].tlp_Base_ID;
                    }

                }

            }
            var obj = JSON.parse(JSON.stringify(dataFormat));
            output.push(obj);

        }
        console.log("AFter data push");
        console.log(gridStatus);
        console.log(output);
        currentComponent.props.updateGridStatus(gridStatus);//tlp_Status
        currentComponent.setState({ tlpRecord: output });
        if (gridStatus == 'Draft') {
            localStorage.setItem('viewRecord', JSON.stringify(output));
        }

    }

    render() {
        const columns = [{
            id: 'Tenors',
            Header: 'Tenors',
            accessor: 'Tenors',
            headerClassName: 'tlpheader',
            filterable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 80
        }, {
            id: 'Date',
            Header: 'Date',
            accessor: 'Date',
            headerClassName: 'tlpheader',
            sortable: false,
            filterable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 110
        }, {
            id: 'Curve',
            Header: 'Curve',
            accessor: 'Curve',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 103
        }, {
            id: 'SEK',
            Header: 'SEK',
            accessor: 'SEK',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'EUR',
            Header: 'EUR',
            accessor: 'EUR',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'NOK',
            Header: 'NOK',
            accessor: 'NOK',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'DKK',
            Header: 'DKK',
            accessor: 'DKK',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'GBP',
            Header: 'GBP',
            accessor: 'GBP',
            headerClassName: 'tlpheader',
            sortable: false,
            filterable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'CHF',
            Header: 'CHF',
            accessor: 'CHF',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'USD',
            Header: 'USD',
            accessor: 'USD',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 77
        }, {
            id: 'JPY',
            Header: 'JPY',
            accessor: 'JPY',
            headerClassName: 'tlpheader',
            filterable: false,
            sortable: false,
            className: 'tlp_grid_cell_empty',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width: 81
        }]



        return <ReactTable
            data={this.state.tlpRecord}//{UserData}//{this.state.tlpRecord}
            columns={columns}
            // loading={this.state.loading}
            showPagination={false}
            showPaginationTop={false}
            showPaginationBottom={false}
            showPageSizeOptions={false}
            className='-striped -highlight emptyTable'
            // style = {"border: 1px solid blue"}
            headerClassName='tlpheader'
            defaultPageSize={16}
            defaultSortDesc={false}
        />
    }
}

export default withRouter(TLPGrid);