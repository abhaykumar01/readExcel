import React from 'react';
import { connect } from "react-redux";
import { formatDate, formatCurrencyValue , formatDateRange } from './localeFormattingFunctions';

class LocaleFormattedValue extends React.Component{
    constructor(props){
        super(props);
        this.state={
            locale : props.locale,
        };
    }

    componentWillReceiveProps(props){
        this.setState({
            locale : props.locale,
        }, this.formatValue);
    }

    componentWillMount(){
        this.formatValue();
    }

    formatValue(){
        let displayValue ='';
        let delimiter = this.props.delimiter ? this.props.delimiter : '-';

        if(this.props.type && this.props.type==='date'){
            displayValue = formatDate(this.props.value, this.props.locale);
        } else if(this.props.type && this.props.type==='dateRange'){
            displayValue = formatDateRange(this.props.value, delimiter, this.props.locale);
        } else if(this.props.type && this.props.type==='currency'){
            displayValue = formatCurrencyValue(this.props.value, this.props.locale);
        } else {
            if(this.props.value !== null && this.props.value !== undefined){
                displayValue = this.props.value;
            }
        }

        this.setState({
            displayValue : displayValue,
        });
    }

    render(){
        return <span>{this.state.displayValue}</span>
    }
}

const mapStateToProps = state => {
    return {
         locale: state.dataFormat,
    }
    
};

LocaleFormattedValue = connect(mapStateToProps)(LocaleFormattedValue);
export default LocaleFormattedValue;