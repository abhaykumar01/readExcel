import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from './pagination.js';
import UserData from './ApiData.js';
import matchSorter from 'match-sorter'
import { HttpPost, HttpGet } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import DatePicker from '@zambezi/sdk/date-picker';

// const rawData = getPartyCustomer();

class gridPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "5",
            customerRecord: [],
            loading: false,
            selected: null
        }
    }

    componentDidMount() {
        console.log("Component mount");
        let output = [];
        console.log("Call service");
        this.setState({ loading: true })
        var currentComponent = this;
        let endPoint = API_ENDPOINT.PARTY_PROCESS_LIST + '/0/50/partyID/';
        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            console.log("response received from server");
            console.log(response.data);
            for (var i = 0; i < response.data.length; i++) {
                
                let userAddress = "";
                if (response.data[i].streetAddressLine1 != null) {
                    userAddress = response.data[i].streetAddressLine1;
                }
                if (response.data[i].streetAddressLine2 != null) {
                    userAddress += ' ' + response.data[i].streetAddressLine2;
                }
                // if (response.data[i].street_Address_Line_3 != null) {
                //     userAddress += response.data[i].street_Address_Line_3;
                // }

                var obj = moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
                let time = moment(obj).format("DD/MM/YYYY");
                console.log("Date format");
                console.log(time); 
                var dummyCustomerSector = 'CPB';
                var dummyCountry = 'Denmark';
                var dummyMGS = '40128'
                var dummyBV = '12880'
                var dummyStatus = 'Archived'
                var dummyAnnualReviewDate = time;
            
                output.push({
                    name: response.data[i].partyName,
                    type: response.data[i].partyType,
                    address: userAddress,
                    status: dummyStatus, // response.data[i].partyStatus,
                    created: time,
                    ID: response.data[i].partyID,
                    customerSector: dummyCustomerSector, //--
                    country:  response.data[i].country,
                    mgs:  response.data[i].mgs,
                    bv: dummyBV,
                    annualReviewDate:  response.data[i].annualReviewDate
                });
            }

            currentComponent.setState({customerRecord: output});
            currentComponent.setState({ loading: false })
            //  return output;
        })
            .catch(function (error) {
                currentComponent.setState({ loading: false })
                console.log("Error received123");
                console.log(error);
            })
    }

    // handleRowClick() {
    //     console.log("Row click");//{`/users/${user.id}`}
    //     console.log(this.state.selected);
    //     // this.props.history.push({'/lms/viewCustomerDetail/${this.state.selected}'});
    //     this.props.history.push({
    //         pathname: '/lms/viewCustomerDetail',
    //         state: { rowID: this.state.selected }
    //     })
    //     // this.props.history.push(/lms/viewCustomerDetail:${this.state.selected})
    // }

    generateData(type) {
        console.log(type);
        const data = [];
        if (type == "customerType") {
            data.push(
                "All",
                "Customer",
                "Seller",
                "SPV"
            );
        }else if (type == "customerStatus") {
            data.push(
                "All",
                "Active",
                "Inactive",
                "Pending"
            );
        }
        return data
    }

    render() {
        console.log("Select record::  ");
        console.log(this.props.selectedRecord);
        const columns = [{
            id: 'cname',
            Header: props => <div><span className="table_nameprop">Name</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
            accessor: 'name', // String-based value accessors!
            headerClassName: 'theader',
            filterable: true,
            filterMethod: (filter, rows) =>
                matchSorter(rows, filter.value, { keys: ["cname"] }),
            filterAll: true,
             Filter: ({ filter, onChange }) => (
                 <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
                     <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                         <input type="text"
                             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                             value={filter ? filter.value : ''}
                             maxLength= {30}
                             style={{
                                 width: '100%',
                                 height: '44px'
                             }} />
                     </div>
                     <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                         <Icon name="search-small" size="small" title=""/>
                     </div>
                 </div>
            ),
            // filterable: false
        }, {
            id: 'cstatus',
            Header: 'Status',//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'status',
            headerClassName: 'theader',
                sortable: false,
            Cell: row => (
            <div>
                    <span class ={
                        row.value === 'Pending'
                            ? 'inactive' // CPBNRP-1447
                            : ''
                    }
                    ><span className={
                        row.value === 'Pending'
                            ? 'row_text'
                            : row.value === 'Inactive'
                                ? 'inactive'
                                : ''
                    }>{row.value}</span></span>
            </div>
            ),
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "Active") {
                        return row[filter.id] == 'Active';
                    }
                    if (filter.value === "Inactive") {
                        return row[filter.id] == 'Inactive';
                    }
                    if (filter.value === "Pending") {
                        return row[filter.id] == 'Pending';
                    }
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="active">Active</option>
                    //     <option value="inactive">Inactive</option>
                    //     <option value="pending">Pending</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('customerStatus')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
                // filterable: false
                //Cell: props => className: 'row_data' // Custom cell components!
            
        },{
            id: 'customersector', // Required because our accessor is not a string
            Header: 'Customer Sector',
            accessor: 'customerSector',//d => d.friend.name // Custom value accessors!
            headerClassName: 'theader',
            filterable: true,
            sortable: false,
            filterMethod: (filter, rows) =>
                matchSorter(rows, filter.value, { keys: ["address"] }),
            filterAll: true,
            className: 'des_cell',
            Filter: ({ filter, onChange }) => (
                <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
                    <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            maxLength={100}
                            style={{
                                width: '100%',
                                height: '44px'
                            }} />
                    </div>
                    <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                        <Icon name="search-small" size="small" title=""/>
                    </div>
                </div>
            ),
    },  {
        id: 'country', // Required because our accessor is not a string
        Header: 'Country',
        accessor: 'country',//d => d.friend.name // Custom value accessors!
        headerClassName: 'theader',
        filterable: true,
        sortable: false,
        filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: ["address"] }),
        filterAll: true,
        className: 'des_cell',
        Filter: ({ filter, onChange }) => (
            <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
                <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                    <input type="text"
                        onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                        value={filter ? filter.value : ''}
                        maxLength={100}
                        style={{
                            width: '100%',
                            height: '44px'
                        }} />
                </div>
                <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                    <Icon name="search-small" size="small" title=""/>
                </div>
            </div>
        ),
},	 {
    id: 'mgs', // Required because our accessor is not a string
    Header: 'Mgs',
    accessor: 'mgs',//d => d.friend.name // Custom value accessors!
    headerClassName: 'theader',
    filterable: true,
    sortable: false,
    filterMethod: (filter, rows) =>
        matchSorter(rows, filter.value, { keys: ["address"] }),
    filterAll: true,
    className: 'des_cell',
    Filter: ({ filter, onChange }) => (
        <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
            <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                <input type="text"
                    onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                    value={filter ? filter.value : ''}
                    maxLength={100}
                    style={{
                        width: '100%',
                        height: '44px'
                    }} />
            </div>
            <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                <Icon name="search-small" size="small" title=""/>
            </div>
        </div>
    ),
}, {
    id: 'bv', // Required because our accessor is not a string
    Header: 'BV',
    accessor: 'bv',//d => d.friend.name // Custom value accessors!
    headerClassName: 'theader',
    filterable: true,
    sortable: false,
    filterMethod: (filter, rows) =>
        matchSorter(rows, filter.value, { keys: ["address"] }),
    filterAll: true,
    className: 'des_cell',
    Filter: ({ filter, onChange }) => (
        <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
            <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                <input type="text"
                    onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                    value={filter ? filter.value : ''}
                    maxLength={100}
                    style={{
                        width: '100%',
                        height: '44px'
                    }} />
            </div>
            <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                <Icon name="search-small" size="small" title=""/>
            </div>
        </div>
    ),
},	 {
    id: 'annualReviewDate', // Required because our accessor is not a string
    Header: 'Annual Review Date',
    accessor: 'annualReviewDate',//d => d.friend.name // Custom value accessors!
    headerClassName: 'theader',
    filterable: true,
    sortable: false,
    filterMethod: (filter, rows) =>
        matchSorter(rows, filter.value, { keys: ["address"] }),
    filterAll: true,
    className: 'des_cell',
    Filter: ({ filter, onChange }) => (
        <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
            <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                <input type="text"
                    onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                    value={filter ? filter.value : ''}
                    maxLength={100}
                    style={{
                        width: '100%',
                        height: '44px'
                    }} />
            </div>
            <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                <Icon name="search-small" size="small" title=""/>
            </div>
        </div>
    ),
},
{
            id: 'ctype',
            Header: 'Type',
            accessor: 'type',
            headerClassName: 'theader',
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "Customer") {
                        return row[filter.id] == 'Customer';
                    }
                    if (filter.value === "Seller") {
                        return row[filter.id] == 'Seller';
                    }
                    if (filter.value === "SPV") {
                        return row[filter.id] == 'SPV';
                    }
                },
                Filter: ({ filter, onChange }) =>
                    // <select
                    //     onChange={event => onChange(event.target.value)}
                    //     style={{ width: "100%" }}
                    //     value={filter ? filter.value : "all"}
                    // >
                    //     <option value="all">All</option>
                    //     <option value="customer">Customer</option>
                    //     <option value="seller">Seller</option>
                    //     <option value="spv">SPV</option>
                    // </select>
                
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('customerType')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        }, {
                id: 'address', // Required because our accessor is not a string
                Header: 'Address',
                accessor: 'address',//d => d.friend.name // Custom value accessors!
                headerClassName: 'theader',
                filterable: true,
                sortable: false,
                filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["address"] }),
                filterAll: true,
                className: 'des_cell',
                Filter: ({ filter, onChange }) => (
                    <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
                        <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                            <input type="text"
                                onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                                value={filter ? filter.value : ''}
                                maxLength={100}
                                style={{
                                    width: '100%',
                                    height: '44px'
                                }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" title=""/>
                        </div>
                    </div>
                ),
        }, {
                id: 'cdate',
                Header: 'Created on',//props => <span>Friend Age</span>, // Custom header components!
                accessor: 'created',
                headerClassName: 'theader',
                filterable: true,
                // sortable: false,
                filterMethod: (filter, row) => {
                    // var today = new Date();
                    console.log("filter value:: " + filter.id);
                    console.log(filter.value);
                    console.log(row);
                    console.log(row._original.created);
                    var date = moment(filter.value, 'DD/MM/YYYY').format('DD/MM/YYYY');
                    console.log("filter value1");
                    console.log(date);
                    return row._original.created == date;
                },
                    // matchSorter(rows, filter.value, { keys: ["cdate"] }),
                // filterAll: true,
                Filter: ({ filter, onChange }) => (
                    <div className="form-group view_search" style={{ marginLeft: '16px' }}>
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            {/* <input type="date"
                                onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                                value={filter ? filter.value : ''}
                                style={{
                                    width: '100%',
                                    height: '44px'
                                }} /> */}
                            <DatePicker
                                date={filter ? filter.value : ''}
                                onChange={event => onChange(event)}
                                onInputChange={event => onChange(event)}
                                // onInputChange={this.getInputRangeEndDate.bind(this)}
                                placeholder='DD/MM/YYYY'
                                error={false}
                                dateFormat='DD/MM/YYYY'
                            />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="calendar-small" size="small" title=""/>
                        </div>
                    </div>

                    // <div class="form-group col-xs-12 view_search">
                    //     <div class="inner-addon right-addon table_input_search">
                    //         <Icon name="calendar-small" size="small" style={{
                    //             position: 'absolute',
                    //             marginTop: '10px',
                    //             marginLeft: '125px'
                    //         }}/>
                    //         {/* <i class="glyphicon glyphicon-calendar" ></i> */}
                    //         <input type="date"
                    //             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                    //             value={filter ? filter.value : ''}
                    //             style={{
                    //                 width: '100%',
                    //                 height: '44px'
                    //             }} />
                    //     </div>
                    // </div>
                    // <DatePicker
                    //     date={filter ? filter.value : ''}
                    //     onChange={event => onChange(event)}
                    //     className="customerDate"
                    //     // onChange={this.getRangeStartDate.bind(this)}
                    //     // onInputChange={this.getInputRangeStartDate.bind(this)}
                    //     placeholder='DD/MM/YYYY'
                    //     error={false}
                    // />
                ),
        }]

        return <ReactTable
            data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
            columns={columns}
            loading={this.state.loading}
            showPagination = {true}
            showPaginationTop = {false}
            showPaginationBottom = {true}
            showPageSizeOptions = {true}
            className= 'tabledata'
            // style = {"border: 1px solid blue"}
            
            
            // headerClassName= 'theader'
            // pageSizeOptions = {[5, 10, 20, 25, 50, 100]}
            defaultPageSize = {5}
            pageSize={this.props.selectedRecord}
            PaginationComponent={Pagination}
            onFilteredChange = {undefined}
            defaultSortDesc = {false}
            // onFilteredChange={(filtered, column) => {... }
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            noDataText= 'No rows found'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
            filterable
            defaultFilterMethod={(filter, row) =>
                String(row[filter.id]) === filter.value}
            getTrProps={(state, rowInfo) => {
                // console.log(state);
                
                if (rowInfo && rowInfo.row) {
                    return {
                        onClick: (e) => {
                            console.log(rowInfo.original.ID);
                            localStorage.setItem('datasave', 'false');
                            
                            this.setState({
                                selected: rowInfo.index
                            });
                            localStorage.setItem("Message", '');
                            this.props.history.push({
                                pathname: '/lms/viewCustomerDetail',
                                state: { rowID: rowInfo.original.ID }
                            })
                        },
                        // style: {
                        //     background: rowInfo.index === this.state.selected ? '#009FAC' : 'white',
                        //     color: rowInfo.index === this.state.selected ? 'white' : 'black'
                        // }
                    }
                } else {
                    return {}
                }
            }}
            // sorted={[{ // the sorting model for the table
            //     id: 'cname',
            //     desc: true
            // }]}
            // filterAll = {true}
            // filterMethod ={ (filter, row, column) => {
            //     const id = filter.id
            //     console.log("Filter:: ", id);
            //     console.log(row[id])
            //     console.log(column[id])
            //     return row[id] !== undefined ? String(row[id]).startsWith(this.props.searchInput) : true
            // }}
            // filtered={[{ // the current filters model
            //     id: 'cname',
            //     value: this.props.searchInput 
            // }]}
            // getTrProps={() => {
            //     return {
            //         className: 'row_data'
            //     }
            // }}
            // getPaginationProps = {(state, rowInfo, column, instance) => ({
            //     // console.log(state);
            // })}
            // expanderDefaults = {
            //   sortable : false
            //   resizable = {false}
            //   filterable = {false}
            //   width = {35}
            // }
        />
    }
}

export default withRouter(gridPage);