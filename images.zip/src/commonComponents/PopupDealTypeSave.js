import React from 'react';

class popupmessage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // selectedFile: null
        }
    }

    render() {
        return (
            <div id={this.props.datatarget} class="modal fade"
                className={"modal fade " + (this.props.openDialog ? 'showDialog' : 'closeDialog')}
                role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                            <h4 class="modal-title header_title">{this.props.headerTitle}</h4>
                        </div>
                        <div class="modal-body">
                            <p className="header_body">{this.props.headerbody}</p>
                        </div>
                        <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '20px' }}>
                            <button className='zb-button zb-button-primary save_pop_btn' data-dismiss="modal" onClick={this.props.onClickButton1}>{this.props.buttontext1}</button>
                            <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss='modal' onClick={this.props.onClickButton2}>{this.props.buttontext2}</button>
                            
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}


export default popupmessage