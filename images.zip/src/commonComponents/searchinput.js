import React from 'react';
// import '../components/addCustomer/customer.css';
import { Icon } from '@zambezi/sdk/icons'


const searchinputfield = ({ fieldTitle, inputType, isDisabled, maxlength, id, value, name, onChange, onClick, placeholder }) => {
    return (
        <div className="form-group row">
            <label className="col-sm-4 col-form-label field_label">{fieldTitle}</label>

            <div className="col-sm-4">
                <input type={inputType} disabled={isDisabled} value={value} maxlength={maxlength} name={name} id={id} onChange={onChange} className="form-control input_Fields" placeholder={placeholder} />
                
            </div>
            <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-34px'}}>
                <Icon name="search-small" size="small" onClick={onClick} title=""/>
            </div>
        </div>
    );
};

export default searchinputfield