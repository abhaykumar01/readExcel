import React from 'react';

const spv = () => {
    return (
        <div className="row" style={{ margin: '2% 10% 2% -1%' }}>
            <div class="col-xs-12">
                <label className="spv_title">SPV1 number</label>
                <span className="spv_number">SPV7463276328763875</span>
            </div>
        </div>
    )
}

export default spv;