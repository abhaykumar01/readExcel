import React from 'react';
import DatePicker from '@zambezi/sdk/date-picker';
import { allowedFormats } from '@zambezi/sdk/date-picker'
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import '@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/icons';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import { Notification } from '@zambezi/sdk/notification';
import moment from 'moment';
import '../components/intrestInvoicingForm/calculateInterest.css';

const calenderinputfield = ({ fieldTitle, inputType,errorMessage, onError, errorStatus, value,
    name, onChange, onClick, placeholder, getOptionInputDate, id }) => {
    return (
        <div>
            <div class="form-group row">
                <label for="" class="col-sm-4 col-form-label field_label_model">{fieldTitle}</label>
                <div className="col-sm-7 inner-addon right-addon search_column">
                    <DatePicker
                        className="large-date-picker zb_datePicker widthFix"
                        date={value}
                        onChange={onChange}
                        placeholder='DD/MM/YYYY'
                        onError={onError}
                        onInputChange={getOptionInputDate}
                        error={errorStatus}
                        name={name}
                        dateFormat='DD/MM/YYYY'
                        id={id}
                    // isMobile={true}
                    // allowedFormats='DD/MM/YYYY'
                    />
                </div>
            </div>
            {errorStatus ?
                <div className="form-group row">
                    <label className="col-sm-4 col-form-label field_label_model"></label>
                    <div className="col-sm-7 " >
                        <Notification
                            status='error'
                            size='small'
                            withArrow
                            arrowPosition='14px'
                            className="error_notification zb_datePicker widthFix"
                        >
                            {errorMessage}
                        </Notification>
                    </div>
                </div>
                : null}
        </div>
    );
};

export default calenderinputfield