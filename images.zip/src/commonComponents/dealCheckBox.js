import React, { Component } from 'react';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Notification } from '@zambezi/sdk/notification';
import help from '../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import {Checkbox}  from '@zambezi/sdk/form-elements';

const DealCheckBox = ({ title, classname, data, errorStatus, onChangeDepreciation, OnChangeInvoicing,
     errorMessage , depreciationValue, invoicingValue , helpIcon, helpIconValue, isdisabled}) => {
    return (
        <div className="form-group row">
            <label for="inputState" className="col-sm-4 col-form-label field_label_model">{title}{helpIcon ? 
                <FlyoutTrigger
                    showOn='hover'
                    position='bottom'
                    flyout={
                        <Flyout>
                            {helpIconValue}
                        </Flyout>
                    }>
                    <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                </FlyoutTrigger>
            : null}</label>
            <div className="col-sm-7">
                                        
                <Checkbox type="checkbox" checked={depreciationValue} disabled = {isdisabled}
                    onChange={onChangeDepreciation} name="isDepreciation"/> 
                <label  class=" field_label_model_checkbox">Depreciation</label>

                <Checkbox type="checkbox" checked={invoicingValue} disabled = {isdisabled}
                    onChange={OnChangeInvoicing} name="isInvoicing"/> 
                <label class=" field_label_model_checkbox">Invoicing</label>
                
            </div>  
            <div>
                {
                    errorStatus ?
                <div className="form-group row">
                <label className="col-sm-4 col-form-label field_label_model" style={{marginLeft: '35px'}}></label>
                <div className="col-sm-6" style= {{marginTop:'10px'}}>
                            <Notification 
                                status='error'
                                size='small'
                                withArrow
                                arrowPosition='14px'
                                className="error_notification"
                            >
                                {errorMessage} 
                            </Notification>
                        </div>
                    </div>
                     : null
                }
                </div>
        </div>
    );
};

export default DealCheckBox