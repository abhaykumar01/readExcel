import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from './pagination.js';
import UserData from './ApiData.js';
import matchSorter from 'match-sorter'
import { HttpPost, HttpGet, HttpPutWithoutBody, HttpDownloadFile, HttpPut, HttpDelete } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import DatePicker from '@zambezi/sdk/date-picker';
import { Select, DropdownList } from '@zambezi/sdk/dropdown-list';
import { docRetrieveData } from '../commonComponents/TLPGridStructure';
import { Nav, NavItem, NavMenu, NavMenuGroup, NavMenuItem, NavSubMenu } from '@zambezi/sdk/nav';
import { object } from 'prop-types';
import { createNotification, deleteDocument, approveUploadRequest } from '../models/dataModel';
import { connect } from "react-redux";
import { submitRequest } from '../models/dataModel';
import { addNotification } from "../redux/actions/index";
import { ECM_TOGGLE } from '../config/config';
import { Notification } from '@zambezi/sdk/notification';
import { AuthorizationContext } from '../components/authContext/index.js'
const PING = process.env.REACT_APP_PING;
// const rawData = getPartyCustomer();

class assetdocumentGridPage extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "5",
            customerRecord: [],
            loading: false,
            selected: null,
            documentRecord: {},
            expanded: {},
            selectedDoc: '',
            selectedDocID: 0,
            docDeleteRequest: false,
            requestedDocDeleted: [],
            rangeStartDate: '',
            rangeEndDate: '',
            showDateRange: false,
            dateFilterApply: true,
            selectedClass: '',
            notificationData: [],
            selectedDocData: null,
            startDateError: false,
            endDateError: false,
            uploadSort: false,
            dateSort: false,
            permissionData: {},
            racf: '',
            spvID: 1,
            roleName: ''
        }
        this.renderDocName = this.renderDocName.bind(this);
        this.getRangeEndDate = this.getRangeEndDate.bind(this);
        this.getInputRangeEndDate = this.getInputRangeEndDate.bind(this);
        this.getRangeStartDate = this.getRangeStartDate.bind(this);
        this.getInputRangeStartDate = this.getInputRangeStartDate.bind(this);
        // this.uploadSorting = this.uploadSorting.bind(this);
    }

    componentDidMount() {
        this.setState({ notificationData: this.props.notifications });
        var userID;
        var data;
        var roleName = '';
        if (PING == 'true') {
            let { usersDetails } = this.context;
            userID = usersDetails.userID;
            data = usersDetails.permissions;
            roleName = usersDetails.memberOf;
        } else {
            let response = localStorage.getItem('permissions');
            userID = localStorage.getItem('racfID');
            data = JSON.parse(response);
             roleName = localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racf: userID,
            roleName: roleName
        });
        let output = [];
        this.setState({ customerRecord: output });
        this.setState({ loading: true })

        var currentComponent = this;
        let id = parseInt(localStorage.getItem('userID'));
        let endPoint; 
        console.log("SPV ID::");
        console.log(this.props.location.state.spvID);
        console.log(localStorage.getItem('spvId'));
        if(this.props.location.state.spvID){
            endPoint = API_ENDPOINT.DOCUMENT_PROPERTY + "/" + this.props.location.state.spvID;
            this.setState({ spvID: this.props.location.state.spvID });
        }else{
            endPoint = API_ENDPOINT.DOCUMENT_PROPERTY + '/1'; //+ id;
            this.setState({ spvID: 1 });
        }
        

        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            console.log("response received from server");
            console.log(response.data);//documentMediaType
            currentComponent.setState({ documentRecord: response.data });
            for (var i = 0; i < response.data.length; i++) {
                // var obj = new Date(response.data[i].createdOn);
                var obj = moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
                let time = moment(obj).format('DD/MM/YYYY');

                if (response.data[i].isflaggedForDeletion == 1 || response.data[i].uploadStatus == "PendingApproval") {
                    var joined = currentComponent.state.requestedDocDeleted.concat(response.data[i].documentId);
                    currentComponent.setState({
                        requestedDocDeleted: joined,
                    }, () => {
                        console.log("updated request doc deleted list");
                        console.log(currentComponent.state.requestedDocDeleted);
                    })
                }
                // time = time.toUpperCase();
                var img_class_obj = '';
                var img_name = '';
                let mediaType = response.data[i].documentMediaType.toLowerCase();
                if (mediaType == 'pdf') {
                    img_class_obj = 'pdf_img';
                    img_name = 'PDF';
                } else if (mediaType == 'doc') {
                    img_class_obj = 'doc_img';
                    img_name = 'W'
                } else if (mediaType == 'png') {
                    img_class_obj = 'png_img';
                    img_name = 'PNG'
                } else if (mediaType == 'jpg') {
                    img_class_obj = 'jpg_img';
                    img_name = 'JPG'
                } else if (mediaType == 'excel' || mediaType == 'xls') {
                    img_class_obj = 'xcel_img';
                    img_name = 'X'
                } else if (mediaType == 'txt') {
                    img_class_obj = 'msg_img';
                    img_name = ''
                } else if (mediaType == 'msg') {
                    img_class_obj = 'msg_img';
                    img_name = 'MSG'
                } else if (mediaType == 'ppt') {
                    img_class_obj = 'ppt_img';
                    img_name = 'PPT'
                }
                output.push({
                    name: response.data[i].documentName,
                    description: response.data[i].documentDescription,
                    uploadedBy: response.data[i].uploadedUser,
                    created: time,
                    ID: response.data[i].documentId,
                    img_name: img_name,
                    imgClass: img_class_obj,
                    date: response.data[i].createdOn,
                    ecmDocID: response.data[i].ecmDocumentId,
                    docData: response.data[i],
                    requestedBy: response.data[i].requestedBy,
                    isflaggedForDeletion: response.data[i].isflaggedForDeletion,
                    highRiskRecord: response.data[i].highRiskRecord,
                    uploadStatus: response.data[i].uploadStatus
                });
            }

            currentComponent.setState({ customerRecord: output });
            currentComponent.setState({ loading: false })
            //  return output;
        })
            .catch(function (error) {
                currentComponent.setState({ loading: false })
            })
    }

    componentWillReceiveProps(newProps) {
        this.setState({ notificationData: newProps.notifications });
    }

    sendRequestForDocuemntDeletion() {
        if (ECM_TOGGLE == 'false') {
            let ID = localStorage.getItem('selectDocID');
            let partyID = parseInt(localStorage.getItem('userID'));
            var currentComponent = this;
            let endPoint = API_ENDPOINT.PROPERTY_SUBMIT_DELETION_REQUEST + '/1/' + ID + '/' + this.state.racf;
            
            let description = "Document deletion request for " + localStorage.getItem('username') + " is pending your approval";
            let partyName = localStorage.getItem('username');
            let docName = this.state.selectedDoc;
            console.log("Doc data:: ");
            console.log(this.state.racf);
            console.log("Document deletion request for " + localStorage.getItem('username') + " is pending your approval")
            console.log(this.state.selectedDocData);
           
            // let payLoadData = submitRequest(parseInt(ID), docName, null, null, 'Riddarholmen', null, null, 1);
            let docType = 0;
            if ((this.state.selectedDocData.highRiskRecord).toLowerCase() == "high risk") {
                docType = 1;
            }
            var userID = '';
            var roleName = '';
            if (PING == 'true') {
                let { usersDetails } = this.context;
                userID = usersDetails.userID;
                roleName = usersDetails.memberOf;
            } else {
                userID = localStorage.getItem('racfID');
                roleName = localStorage.getItem('roleName');
            }
            let endPoint1 = API_ENDPOINT.LMS_NOTIFICATION + '/getNotificationByUserIDAndRoleName/' + userID + '/' + roleName;
            // docID, docName, notificationID, partyID, partyName, reason, leaseContractID, propertyID,
            //     requestedBy, respondedBy, docType
            let payLoadData = submitRequest(parseInt(ID), docName, null, null, partyName,
                null, null, null, this.state.racf, "", docType, parseInt(this.state.spvID), 0, docType);
            console.log("Payload data:: ");
            console.log(payLoadData);
            let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
                console.log("Send request Response received from server");
                console.log(response.data);

                let output = HttpGet(currentComponent, endPoint1).then(function (response) {
                    console.log("Notification response received from server");
                    console.log(response.data);
                    console.log(response.data.length);
                    let count = 0;
                    currentComponent.props.addNotification(response.data);
                })
                    .catch(function (error) {
                    })
                if (!(currentComponent.state.requestedDocDeleted.indexOf(parseInt(ID)) > -1)) {
                    var joined = currentComponent.state.requestedDocDeleted.concat(parseInt(ID));
                    currentComponent.setState({ requestedDocDeleted: joined }, function () {
                        currentComponent.setState({ docDeleteRequest: true });
                        currentComponent.props.DocumentDeleteRequestSent();
                    })
                } else { 
                    currentComponent.setState({ docDeleteRequest: true });
                    currentComponent.props.DocumentDeleteRequestSent();
                }
                
            })
                .catch(function (error) {
                })
        } else {
            let ID = localStorage.getItem('selectDocID');
            let partyID = parseInt(localStorage.getItem('userID'));
            var currentComponent = this;
            let endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/asset';
            let deletePayLoadData = deleteDocument(this.state.selectedDocData);
            console.log("deletePayLoadData:: ");
            console.log(deletePayLoadData);
            let output1 = HttpDelete(currentComponent, deletePayLoadData, endPoint).then(function (response) {
                console.log("delete document Response received from server");
                console.log(response.data);
                currentComponent.props.documentDeleted();
            })
                .catch(function (error) {
                })
        }
    }

    approveUploadRequest() {
        let ID = localStorage.getItem('selectDocID');
        let notificationID = this.getNotificationID(ID);
        let partyID = parseInt(localStorage.getItem('userID'));
        console.log("Deletion request");
        console.log(this.state.requestedDocDeleted);
        console.log("RacfID:: " + this.state.racf);
        console.log(this.state.selectedDocData);

        var currentComponent = this;//ECM_TOGGLE == 'true'
        var endPoint = API_ENDPOINT.LMS_DOCUMENT_PROPERTY_UPLOADSTATUS + '/Update/' + ID + '/Approved';
        let endPoint1 = API_ENDPOINT.LMS_NOTIFICATION;
        let partyName = localStorage.getItem('username');
        let docName = this.state.selectedDoc;
        let docType = 0;
        if ((this.state.selectedDocData.highRiskRecord).toLowerCase() == "high risk") {
            docType = 1;
        }
        // docID, docName, notificationID, partyID, partyName, reason, leaseContractID, propertyID,
        //     requestedBy, respondedBy, docType, spvID
        let payLoadData = approveUploadRequest(parseInt(ID), docName, notificationID, partyID, partyName,
            null, null, null, this.state.selectedDocData.uploadRequestedBy, this.state.racf, docType, null);
        console.log("Payload data:: ");
        console.log(this.props.userData);
        console.log(payLoadData);
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
            console.log("Send upload Response received from server");
            console.log(response.data);
            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                    console.log("Cancel Deletion request");
                    console.log(currentComponent.state.requestedDocDeleted);
                    currentComponent.props.uploadApprovalStatus(currentComponent.state.selectedDoc, currentComponent.props.userData.spvName);
                });
            } else {
                currentComponent.props.uploadApprovalStatus(currentComponent.state.selectedDoc, currentComponent.props.userData.spvName);
            }

        })
            .catch(function (error) {
            })
    }

    rejectUploadRequest() {
        let ID = localStorage.getItem('selectDocID');
        let { name } = this.context;
        let notificationID = this.getNotificationID(ID);
        console.log("Notification id::: ", notificationID);
        let partyID = parseInt(localStorage.getItem('userID'));
        console.log("ID:: " + ID);
        console.log("Delete doc");
        console.log(this.state.requestedDocDeleted);
        console.log(this.state.selectedDocData);
        var reason = this.state.rejectReasonText;
        if (!reason) {
            reason = null;
        }
        var currentComponent = this;
        let endPoint = API_ENDPOINT.LMS_ECM_REJECTDOC + '/asset/' + notificationID;
        let deletePayLoadData = deleteDocument(this.state.selectedDocData, reason);
        console.log("endPoint:: ");
        console.log(endPoint);
        console.log(deletePayLoadData);
        console.log(currentComponent.state.selectedDocData);

        let output1 = HttpDelete(currentComponent, deletePayLoadData, endPoint).then(function (response) {
            console.log("delete document Response received from server");
            console.log(response.data);
            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                    console.log("Document deleted");
                    console.log(currentComponent.state.requestedDocDeleted);
                    currentComponent.props.uploadRejectStatus(currentComponent.state.selectedDoc, reason, name);
                });
            } else {
                currentComponent.props.uploadRejectStatus(currentComponent.state.selectedDoc, reason, name);
            }
        })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
            })
    }

    documenttDeletion() {
        let ID = localStorage.getItem('selectDocID');
        console.log("Selected doc ID:: ", ID);
        console.log(this.state.selectedDocData);
        console.log(this.props.userData);
        let notificationID = this.getNotificationID(ID);
        let partyID = parseInt(localStorage.getItem('userID'));
        var currentComponent = this;
        let endPoint = '';
        if (notificationID) {
            endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/asset/' + notificationID;
        } else {
            endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/asset';
        }
        let deletePayLoadData = deleteDocument(this.state.selectedDocData);
        console.log("endPoint:: ");
        console.log(endPoint);
        let output1 = HttpDelete(currentComponent, deletePayLoadData, endPoint).then(function (response) {
            console.log("delete document Response received from server");
            console.log(response.data);
            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                    this.props.deletionStatus(
                        currentComponent.state.requestedDocDeleted.length, this.state.selectedDoc, currentComponent.props.userData.spvName);
                });
            } else {
                currentComponent.props.deletionStatus(
                    currentComponent.state.requestedDocDeleted.length, currentComponent.state.selectedDoc, currentComponent.props.userData.spvName);
            }
        })
            .catch(function (error) {
            })
    }

    getRejectionReason(value) {
        this.setState({ rejectReasonText: value });
    }

    rejectDocuemntDeletion() {
        let ID = localStorage.getItem('selectDocID');

        let notificationID = this.getNotificationID(ID);
        let partyID = parseInt(localStorage.getItem('userID'));
        var currentComponent = this;
        var reason = this.state.rejectReasonText;
        if (!reason) {
            reason = null;
        }
        console.log("Selected Data::")
        console.log(this.state.selectedDocData);
        let endPoint = API_ENDPOINT.PROPERTY_REJECT_DELETION_REQUEST + '/0/0/' + ID + '/' + reason;
        let docName = this.state.selectedDoc;
        let partyName = localStorage.getItem('username');
        let docType = 0;
        if ((this.state.selectedDocData.highRiskRecord).toLowerCase() == "high risk") {
            docType = 1;
        }
        let payLoadData = submitRequest(parseInt(ID), docName, notificationID, partyID, partyName,
            reason, null, null, this.state.selectedDocData.deleteRequestedBy, this.state.racf, docType, parseInt(this.state.spvID), 0, docType);
            console.log("payload data");
        console.log(payLoadData);
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
            console.log("Cancel document Response received from server");
            console.log(response.data);
            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                    console.log("Cancel Deletion request");
                    console.log(currentComponent.state.requestedDocDeleted);
                    currentComponent.props.rejectStatus(currentComponent.state.selectedDoc);
                });
            } else {
                currentComponent.props.rejectStatus(currentComponent.state.selectedDoc);
            }
        })
            .catch(function (error) {
            })
    }

    getCancelDocumentID(e, name, data) {
        localStorage.setItem('selectDocID', e);
        this.setState({
            selectedDoc: name,
            selectedDocData: data
        });
    }

    getDeleteDocumentID(e, ID) {
        localStorage.setItem('selectDocID', e);
    }

    downloadDocument(dName, dID) {
        var currentComponent = this;
        let name = dName.replace(/\s/g, '');
        let endPoint = API_ENDPOINT.LMS_ECM + '/' + dID + '/' + name;
        let output1 = HttpDownloadFile(currentComponent, endPoint).then(function (response) {
            console.log("Download document Response received from server");
            console.log(response);
            console.log(response.data);

            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                console.log("SaveorOpenBlob:: ");
                window.navigator.msSaveOrOpenBlob(response.data, dName);
            } else {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                console.log(url);
                const link = document.createElement('a');
                console.log("Link:: ", link);
                link.href = url;
                console.log("Link1:: ", link);
                link.setAttribute('download', dName); //or any other extension
                console.log("Link2:: ", link);
                document.body.appendChild(link);
                console.log("Link3:: ", link);
                link.click();

            }  
        })
            .catch(function (error) {
            })
    }

    getNotificationID(docID) {
        let count = Object.keys(this.state.notificationData).length;
        let data = this.state.notificationData;
        for (var i = 0; i < count; i++) {
            if (data[i].propertyDocumentID == docID && data[i].status == "Pending") {
                return data[i].notificationID;
            }
        }

    }

    sendRequestForCancelDocuemntDeletion() {
        let ID = localStorage.getItem('selectDocID');
        let notificationID = this.getNotificationID(ID);
        let partyID = parseInt(localStorage.getItem('userID'));
        var currentComponent = this;
        let endPoint = API_ENDPOINT.PROPERTY_CANCEL_DELETION_REQUEST + '/0/' + ID + '/' + this.state.racf;
        let docName = this.state.selectedDoc;
        let partyName = localStorage.getItem('username');
        let docType = 0;
        if ((this.state.selectedDocData.highRiskRecord).toLowerCase() == "high risk") {
            docType = 1;
        }
        let payLoadData = submitRequest(parseInt(ID), docName, notificationID, null, partyName,
            null, null, 1, this.state.racf, "", docType, parseInt(this.state.spvID));
        console.log("payLoadData:: " + payLoadData);
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
            console.log("Cancel document Response received from server");
            console.log(response.data);

            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                });
            }
            localStorage.setItem("approver", "false");
            localStorage.setItem("docUpload", "userDocUpload");
            currentComponent.props.DocumentDeleteCancelRequestSent();
        })
            .catch(function (error) {
            })
    }

    setDocName(name, ID, data) {
        this.setState({
            selectedDoc: name,
            selectedDocData: data
        });
        localStorage.setItem('selectDocID', ID);
        this.setState({ selectedDoc: name });
    }

    getRangeStartDate(e) {
        this.setState({ rangeStartDate: e });
        if (e != "" && this.state.rangeEndDate != "") {
            console.log("start Date range validation::");
            console.log(e);
            console.log(this.state.rangeEndDate);
            console.log(moment(e).isAfter(this.state.rangeEndDate))
            if (moment(e).isAfter(this.state.rangeEndDate)) {
                this.setState({
                    dateFilterApply: false,
                    endDateError: false,
                    startDateError: false,
                });
            } else {
                this.setState({
                    endDateError: true,
                    dateFilterApply: true,
                });
            }
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getInputRangeStartDate(value) {
        this.setState({ rangeStartDate: value });
        if (value != "" && this.state.rangeEndDate != "") {
            console.log("start Input Date range validation::");
            console.log(value);
            console.log(this.state.rangeEndDate);
            console.log(moment(value).isAfter(this.state.rangeEndDate))
            if (moment(value).isAfter(this.state.rangeEndDate)) {
                this.setState({
                    dateFilterApply: false,
                    startDateError: false,
                    endDateError: false,
                }, function () {
                    this.forceUpdate();
                });
            } else {
                this.setState({
                    endDateError: true,
                    dateFilterApply: true,
                }, function () {
                    this.forceUpdate();
                });
            }
        } else {
            console.log("Inside start date")
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getInputRangeEndDate(value) {
        this.setState({ rangeEndDate: value });
        if (value != "" && this.state.rangeStartDate != "") {
            console.log("End Input Date range validation::");
            console.log(this.state.rangeStartDate);
            console.log(value);
            console.log(moment(this.state.rangeStartDate).isAfter(value))
            if (moment(this.state.rangeStartDate).isAfter(value)) {
                console.log("start date less then end date");
                this.setState({
                    dateFilterApply: false,
                    startDateError: false,
                    endDateError: false,
                }, function () {
                    this.forceUpdate();
                });
            } else {
                console.log("start date greater then end date");
                this.setState({
                    startDateError: true,
                    dateFilterApply: true,
                }, function () {
                    this.forceUpdate();
                });
            }

        } else {
            console.log("Inside end date")
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getRangeEndDate(e) {
        this.setState({ rangeEndDate: e });
        if (e != "" && this.state.rangeStartDate != "") {
            console.log("End Date range validation::");
            console.log(this.state.rangeStartDate);
            console.log(e);
            console.log(moment(this.state.rangeStartDate).isAfter(e))
            if (moment(this.state.rangeStartDate).isAfter(e)) {
                this.setState({
                    dateFilterApply: false,
                    startDateError: false,
                    endDateError: false,
                });
            } else {
                this.setState({
                    startDateError: true,
                    dateFilterApply: true,
                });
            }
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getRangeData() {
        this.setState({ showDateRange: false });
    }

    setRangeData(e) {
        this.setState({ filtered: { id: e.filtered[0].id, value: e.filtered[0].value } });
    }

    expand_row(row) {
        var expanded = { ...this.state.expanded };
        if (row) {
            if (expanded[row.index]) {
                expanded[row.index] = !expanded[row.index];
            } else {
                expanded[row.index] = true;
            }
        }

        this.setState({
            expanded: expanded
        }, function () {
            this.forceUpdate();
        });

    }

    renderDocName(cellInfo) {
        return (
            <div className="form-group row ">
                <div className="col-sm-1">
                    <div className={cellInfo.original.imgClass}><label style={{
                        color: '#fff',
                        fontSize: '8px',
                        marginTop: '-9px',
                        // position: 'absolute',
                        verticalAlign: 'middle'
                    }}>{cellInfo.original.img_name}</label></div>
                </div>
                <div className="col-sm-2">
                    <span style={{ marginLeft: '-13px' }}>{cellInfo.original.name}</span>
                </div>
            </div>
        );
    }

    generateData(type) {
        const data = [];
        if (type == "date") {
            data.push(
                "All",
                "Today",
                "This week",
                "This month",
                "Last month",
                "Last 3 months",
                "Date range"
            );
        }

        return data
    }

    getWeekDates() {
        let now = new Date();
        let dayOfWeek = now.getDay(); //0-6
        let numDay = now.getDate();
        let start = new Date(now); //copy
        start.setDate(numDay - dayOfWeek);
        start.setHours(0, 0, 0, 0);
        let end = new Date(now); //copy
        end.setDate(numDay + (7 - dayOfWeek));
        end.setHours(0, 0, 0, 0);
        return [start, end];
    }
    getCurrentMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        var firstDay = new Date(y, m, 1);
        var lastDay = new Date(y, m + 1, 0);
        return [firstDay, lastDay];
    }
    getLastMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 1;
        var firstDay = new Date(y, m, 1);
        var lastDay = new Date(y, m + 1, 0);
        return [firstDay, lastDay];
    }
    getLastThreeMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 3;
        var lastDay = moment(date).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        date.setMonth(date.getMonth() - 3);
        var firstDay = moment(date).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        console.log("First day:: ", firstDay);
        console.log("Last day::: ", lastDay);
        return [firstDay, lastDay];
    }
    cancelDateFilter() {
        this.setState({
            showDateRange: false,
            rangeStartDate: "",
            rangeEndDate: "",
            startDateError: false,
            endDateError: false,
        }, function () {
            this.forceUpdate();
        });
    }
    uploadSorting() { 
        // this.state.uploadSort = !this.state.uploadSort;
        
    }
    render() {
        const columns = [{
            expander: true,
            width: 42,
            className: 'arrow_cell',
            Expander: ({ isExpanded, ...rest }) => {
                return (
                    <div>{isExpanded ? <span><Icon name="chev-up-xsmall" size="xsmall" title="" /></span> : <span><Icon name="chev-down-xsmall" size="xsmall" title=""/></span>}</div>
                );
                
                // return <span />;
            }
        },
        {
            id: 'cname',
            Header: <div style={{
                textAlign: 'left',
                // marginLeft: '20px',
                color: '#AD1982',
                textDecoration: 'underline',

            }}>Document name<Icon name="sort-down-xsmall" style={{ marginLeft: '10px' }} />
                {/* <span class="table_columnprop">Document name</span> */}
            </div>,
            accessor: 'name', // String-based value accessors!
            headerClassName: 'theader_docname',
            filterable: true,
            sortable: true,
            Cell: this.renderDocName,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'cname'}] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search" style={{ marginLeft: '-16px' }}>
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            right: '5px'
                        }} title=""/>
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px',
                            }} />
                    </div>
                </div>
            ),
            width: 450,
            className: 'docheader'
            // filterable: false
        }, {
            id: 'description',
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '16px',
            }}>Description</div>,
            accessor: 'description',
            headerClassName: 'theader',
            // expander: true,
            sortable: false,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'description'}] }),
            filterAll: true,
            filterable: true,
            width: 350,
            className: 'des_cell',
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search">
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            right: '5px'
                        }} title=""/>
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
        }, {
            id: 'uploadedBy', // Required because our accessor is not a string
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '20px'
            }}><span class="table_columnprop">Uploaded by</span><Icon name="sort-down-xsmall" style={{ marginLeft: '10px'}}/></div>,
            accessor: 'uploadedBy',//d => d.friend.name // Custom value accessors!
            headerClassName: 'theader',
            filterable: true,
            sortable: true,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'uploadedBy'}] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search">
                        <Icon name="search-small" size='small' style={{
                                marginTop: '11px',
                                position: 'absolute',
                            right: '5px'
                        }} title=""/>
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
        }, {
            id: 'cdate',
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '22px',
            }}>Uploaded on</div>,//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'created',
            headerClassName: 'theader_date',
            filterable: true,
            sortable: false,
            filterMethod: (filter, row) => {
                if (typeof (filter.value) == 'object' && !this.state.showDateRange) {
                    filter.value = "All"
                }
                if (filter.value === "All") {
                    return true;
                }
                if (filter.value === "Today") {
                    var today = new Date();
                    var date = moment(today).format('DD/MM/YYYY')
                    return row[filter.id] == date;
                }
                if (filter.value === "This week") {
                    let [start, end] = this.getWeekDates();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "This month") {
                    let [start, end] = this.getCurrentMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Last month") {
                    let [start, end] = this.getLastMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    console.log("isSameStart: ", isSameStart);
                    console.log("isSameEnd: ", isSameEnd);
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Last 3 months") {
                    let [start, end] = this.getLastThreeMonth();
                    console.log("start: ", start);
                    console.log("end: ", end);
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    console.log("date: ", date);
                    console.log("isSameStart: ", isSameStart);
                    console.log("isAfter: ", isAfter);
                    console.log("isBefore: ", isBefore);
                    console.log("isSameEnd: ", isSameEnd);
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Date range") {
                    this.setState({
                        showDateRange: true,
                        rangeStartDate: "",
                        rangeEndDate: ""
                    });
                    return row[filter.id] == filter.value;
                }
                if (typeof (filter.value) == 'object' && this.state.showDateRange) {
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(this.state.rangeStartDate).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(this.state.rangeEndDate);
                    var isBefore = moment(row._original.date).isAfter(this.state.rangeStartDate);
                    var isSameEnd = moment(this.state.rangeEndDate).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }

            },
            // Custom cell components!
            Filter: ({ filter, onChange }) =>
                //  date = moment(event).format('DD/MM/YYYY')
                <div>
                    {!this.state.showDateRange ?
                        <Select
                            defaultValue='All'
                            suggestions={this.generateData('date')}
                            className='dropdown_date_selection'
                            isError={false}
                            value={filter ? filter.value : "All"}
                            onChange={(event, { value, method }) => onChange(value)}
                        />
                        : null}

                    {this.state.showDateRange ?
                        <div>
                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                        From
                                                        </label>
                                    <div className="col-sm-4" style={{ marginLeft: '10px' }}>
                                        <DatePicker
                                            date={this.state.rangeEndDate}
                                            keepDateInRange
                                            onChange={this.getRangeEndDate}
                                            onUserChange={this.getInputRangeEndDate}
                                            placeholder='DD/MM/YYYY'
                                            error={this.state.startDateError}
                                            dateFormat='DD/MM/YYYY'
                                        />
                                    </div>

                                </div>
                            </div>

                            {this.state.startDateError ? <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                    </label>
                                    <div className="col-sm-4" style={{ marginLeft: '38px', width: '429px' }}>
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            <span>The ‘From’ date must occur before the ‘To’ date.</span>
                                        </Notification>
                                    </div>

                                </div>
                            </div> : null}
                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property">
                                        To
                                                        </label>
                                    <div className="col-sm-4" style={{ marginLeft: '10px' }}>
                                        <DatePicker
                                            date={this.state.rangeStartDate}
                                            keepDateInRange
                                            onChange={this.getRangeStartDate}
                                            onUserChange={this.getInputRangeStartDate}
                                            placeholder='DD/MM/YYYY'
                                            error={this.state.endDateError}
                                            dateFormat='DD/MM/YYYY'
                                        />
                                    </div>
                                  
                                </div>
                            </div>

                            {this.state.endDateError ? <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                    </label>
                                    <div className="col-sm-4" style={{ marginLeft: '38px', width: '429px' }}>
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            <span>The ‘To’ date must occur after the ‘From’ date.</span>
                                        </Notification>
                                    </div>

                                </div>
                            </div> : null}

                            <div className="form-group row">
                                <div className="col-sm-12 ">

                                    {/* <div className="col-sm-1"> */}
                                    <button type="button" style={{
                                        minWidth: '50px',
                                        width: '85px',
                                        marginLeft: '15px',
                                    }} id="Apply" disabled={this.state.dateFilterApply}
                                        class="zb-button zb-button-primary" onClick={event => onChange(event)}>
                                        Apply
                                                </button>
                                    {/* </div> */}
                                    {/* <div className="col-sm-1"> */}
                                    <button type="button" style={{
                                        minWidth: '50px',
                                        width: '85px',
                                        marginLeft: '5px',
                                    }} id="Cancel" class="zb-button zb-button-primary"
                                        onClick={this.cancelDateFilter.bind(this)}>
                                        Cancel
                                                </button>
                                    {/* </div> */}
                                </div>
                            </div>
                        </div> : null}


                </div>
            ,
            Cell: props => <span style={{ marginLeft: '10px' }}>{props.value}</span>,
        }]



        return (
            <div>
                <ReactTable
                    data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
                    columns={columns}
                    loading={this.state.loading}
                    showPagination={true}
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    showPageSizeOptions={true}
                    className='documentdata'
                    // expanded={this.state.expanded}
                    // pivotBy={["cname", "description"]}
                    // style = {"border: 1px solid blue"}

                    // headerClassName= 'theader'
                    freezeWhenExpanded={true}
                    defaultPageSize={10}
                    pageSize={this.props.selectedRecord}
                    PaginationComponent={Pagination}
                    // onFilteredChange={undefined}
                    // defaultSortDesc={false}
                    // onFilteredChange={(filtered, column) => {... }
                    previousText='Previous'
                    nextText='Next'
                    loadingText='Loading...'
                    noDataText='No rows found'
                    pageText='Page'
                    ofText='of'
                    rowsText='rows'
                filterable
                    // expander= {false}
                    // defaultFilterMethod={(filter, row) =>
                    //         String(row[filter.id]) === filter.value}
                    // onExpandedChange={(newExpanded, index, event) => {
                    // }} 
                    getTrProps={(state, rowInfo) => {

                        if (rowInfo && rowInfo.row) {
                            return {
                                onClick: (e) => {
                                    this.state.selected = rowInfo.index;
                                    // this.expand_row(rowInfo);
                                    //selectedClass
                                    // showRowSubComponent(nestingPath, e);
                                },
                                style: {
                                    // background: rowInfo.index == this.state.selected ? (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'rgb(77,170,233, 0.1)') : 'white',
                                    background: rowInfo.index == this.state.selected ? (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'rgb(77,170,233, 0.1)')
                                        : (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'white'),
                                    color: rowInfo.index === this.state.selected ? '#000000' : 'black',
                                    textAlign: 'left'
                                }
                            }
                        } else {
                            return {}
                        }
                    }}
                    // getTheadThProps={(state, rowInfo, column, instance) => { 
                    //     return {
                    //         onClick: (e) => {
                    //             console.log("header click");
                    //             // console.log(e);
                    //             // console.log(state);
                    //             // console.log(rowInfo);
                    //             console.log(column);
                    //             console.log(column.id);
                    //             if (column.id == "uploadedBy") { 
                    //                 // this.setState({ uploadSort: !this.state.uploadSort });
                    //             }
                    //         },
                    //     }
                    // }}
                    // onSortingChange={() => { console.log("Sorting changed"); }}
                    // this.setState({uploadSort: !this.state.uploadSort });
                    // getTdProps={(state, rowInfo, column, instance) => {
                    //     return {
                    //         onClick: (e, handleOriginal) => {
                    //             this.expand_row(rowInfo);
                    //             if (handleOriginal) {
                    //                 handleOriginal()
                    //             }
                    //         },
                    //         style: {
                    //             textAlign: 'left',
                    //             marginLeft: '8px'
                    //         }
                    //     }
                    // }}
                    SubComponent={({ row, nestingPath, toggleRowSubComponent }) => {
                        console.log("row expanded")
                        console.log(toggleRowSubComponent);
                        console.log(nestingPath);
                        console.log(this.state.requestedDocDeleted);
                        console.log(row._original.ID);
                        console.log(this.state.requestedDocDeleted.indexOf(row._original.ID) > -1);
                        console.log(row);
                        console.log(row.cname);

                        console.log(row._index);
                        console.log(row._original.docData.deleteRequestedBy)
                        console.log(row._original.docData.highRiskRecord.toLowerCase())
                        console.log(row._original.docData.isflaggedForDeletion)
                        localStorage.setItem('selectDocID', row._original.ID);

                        var perData = this.state.permissionData;
                        var datalen;
                        if (perData) {
                            datalen = perData.length;
                        } else {
                            datalen = 0;
                        }
                        var requestApprovalBtnEnable = false;
                        var approvalbtnEnable = false;
                        var approveHighRiskBtnEnable = false;
                        var assetDocCancelDeletion = false;
                        var uploadPendingReview = false;
                        var uploadApprovalbtnEnable = false;
                        var deleteHighRiskDoc = false;
                        var approveUploadHighRiskDoc = false;
                        if (this.state.roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1
                            && row._original.docData.uploadStatus == "Approved") {
                            deleteHighRiskDoc = true;
                        }
                        if (this.state.roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1
                            && (row._original.docData.highRiskRecord).toLowerCase() == "high risk"
                            && row._original.docData.uploadStatus == "PendingApproval") {
                            approveUploadHighRiskDoc = true;
                        }
                        if (row._original.uploadStatus == "PendingApproval" && row._original.docData.uploadRequestedBy == this.state.racf) {
                            uploadPendingReview = true;
                        }
                        if (row._original.uploadStatus == "PendingApproval" && row._original.docData.uploadRequestedBy != this.state.racf) {
                            uploadApprovalbtnEnable = true;
                        }
                        for (var i = 0; i < datalen; i++) {
                            if (perData[i] == "Asset_Doc_Request_Deletion" && row._original.uploadStatus == "Approved") {
                                requestApprovalBtnEnable = true;
                            }
                            if (perData[i] == "Asset_Doc_Approve_Deletion_High_Risk" &&
                                (row._original.docData.highRiskRecord).toLowerCase() == "high risk" &&
                                row._original.uploadStatus == "Approved") {
                                approveHighRiskBtnEnable = true;
                            }
                            if (perData[i] == "Asset_Doc_Approve_Deletion" &&
                                row._original.docData.deleteRequestedBy != this.state.racf &&
                                row._original.docData.deleteRequestedBy != null &&
                                (row._original.docData.highRiskRecord).toLowerCase() != "high risk" &&
                                row._original.uploadStatus == "Approved") {
                                approvalbtnEnable = true;
                            }
                            if (perData[i] == "Asset_Doc_Cancel_Deletion" && row._original.uploadStatus == "Approved" &&
                                (row._original.docData.deleteRequestedBy == this.state.racf ||
                                    row._original.docData.deleteRequestedBy == null)) {
                                assetDocCancelDeletion = true;
                            }
                        }
                        console.log("assetDocCancelDeletion");
                        console.log(row._original.docData.deleteRequestedBy);

                        // console.log(requestApprovalBtnEnable);
                        console.log(assetDocCancelDeletion);

                        // this.setState({selectedDoc: row.cname})
                        return (
                            // <div className={row._index == this.state.selected ? (this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ? 'deleted_row_style' : 'selected_row_style') : null}>
                            <div className={this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ? 'deleted_row_style' : 'selected_row_style'}>
                                <div className="expand_doc_row">
                                    {this.state.documentRecord[row._index].documentDescription}<br></br>
                                    <label className="expand_doc_row_detail">RBS classification</label>
                                    <span className="expand_doc_row_value">
                                        {this.state.documentRecord[row._index].documentClassification}
                                    </span><br></br>
                                    <label className="expand_doc_row_detail">RBS record class code</label>
                                    <span className="expand_doc_row_value">
                                        {this.state.documentRecord[row._index].recordClassCode}
                                    </span><br></br>
                                    <label className="expand_doc_row_detail">High risk record</label>
                                    <span className="expand_doc_row_value">
                                        {this.state.documentRecord[row._index].highRiskRecord}
                                    </span><br></br>
                                    {assetDocCancelDeletion ? (this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ?
                                        <div className="delete_doc_warning">
                                            <div style={{
                                                marginTop: '10px',
                                                marginLeft: '20px'
                                            }}>
                                                <Icon name="warning-small" size="small" title="" />
                                                <label className="text_property" style={{ marginLeft: '10px', position: 'absolute' }}>
                                                    Deletion request pending review
                                    </label>
                                            </div>
                                        </div>
                                        : null)
                                        : null}

                                    {uploadPendingReview ? (this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ?
                                        <div className="delete_doc_warning">
                                            <div style={{
                                                marginTop: '10px',
                                                marginLeft: '20px'
                                            }}>
                                                <Icon name="warning-small" size="small" title="" />
                                                <label className="text_property" style={{ marginLeft: '10px', position: 'absolute' }}>
                                                    Upload request is pending approval.
                                    </label>
                                            </div>
                                        </div>
                                        : null)
                                        : null}

                                    {approveUploadHighRiskDoc ? (this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ?
                                        <div className="delete_doc_warning">
                                            <div style={{
                                                marginTop: '10px',
                                                marginLeft: '20px'
                                            }}>
                                                <Icon name="warning-small" size="small" title="" />
                                                <label className="text_property" style={{ marginLeft: '10px', position: 'absolute' }}>
                                                    {row._original.uploadedBy} requested to upload this document on {row._original.created}.
                                    </label>
                                            </div>
                                        </div>
                                        : null)
                                        : null}
                                </div>

                                <div className="expand_line"></div>

                                {uploadPendingReview ? <div>
                                    <div className="col-sm-1" style={{ marginTop: '-5px' }}>
                                        <Icon name="download-small" size="small" style={{ marginTop: '16px' }} title="" />
                                    </div>
                                    <div className="col-sm-2" style={{ marginLeft: '-80px', marginTop: '-5px' }}>
                                        <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                    </div>
                                </div> : null}

                                {!(this.state.requestedDocDeleted.indexOf(row._original.ID) > -1) ? <div className="form-group row" >
                                    <div className="col-sm-1" >
                                        <Icon name="download-small" size="small" style={{ marginTop: '16px', marginLeft: '54px' }} title="" />
                                    </div>
                                    <div className="col-sm-2" style={{ marginLeft: '-54px' }}>
                                        <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                    </div>
                                    {requestApprovalBtnEnable ? <div>
                                        <div className="col-sm-1" style={{ marginLeft: '-126px' }}>
                                            <Icon name="trash-small" size="small" style={{ marginTop: '16px' }} title="" />
                                        </div>
                                        <div className="col-sm-2" style={{ marginLeft: '-99px' }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                            {!deleteHighRiskDoc ? <label className="doc_download" data-toggle="modal" data-target="#delete" onClick={this.getDeleteDocumentID.bind(this, row._original.ID)}>
                                                Request deletion
                                    </label> : null}
                                            {deleteHighRiskDoc ? <label className="doc_download" data-toggle="modal" data-target="#deleteHighRisk"
                                                onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                                Request deletion
                                    </label> : null}
                                        </div>
                                    </div> : null}
                                </div> : null}


                                {approvalbtnEnable || approveHighRiskBtnEnable ? (this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ?
                                    <div className="form-group row" style={{
                                        marginTop: '10px',
                                        marginLeft: '36px'
                                    }}>
                                        <div className="col-sm-2">
                                            <button className='zb-button zb-button-primary approval_btn'
                                                data-toggle="modal" data-target="#approvedelete"
                                                style={{ width: '246px' }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                                Approve deletion request
                                                </button>

                                        </div>
                                        <div className="col-sm-2 ">
                                            <button className='zb-button zb-button-secondary update_save_btn'
                                                data-toggle="modal" data-target="#rejectDelete"
                                                style={{
                                                    width: '246px',
                                                    marginLeft: '-36px'
                                                }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>Reject deletion request</button>
                                            {/* <button type="button" class="btn btn-default update_save_btn" data-toggle="modal" data-target="#myModal" disabled={this.state.buttonSave}>Save updates</button> */}
                                        </div>
                                        <div className="col-sm-1" style={{ marginTop: '-5px', marginLeft: '-24px' }}>
                                            <Icon name="download-small" size="small" style={{ marginTop: '16px' }} title="" />
                                        </div>
                                        <div className="col-sm-2" style={{ marginLeft: '-75px', marginTop: '-5px' }}>
                                            <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                        </div>
                                    </div>

                                    : null)
                                    : null}

                                {approveUploadHighRiskDoc ? (this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ?
                                    <div className="form-group row" style={{
                                        marginTop: '10px',
                                        marginLeft: '-26px'
                                    }}>
                                        <div className="col-sm-3">
                                            <button className='zb-button zb-button-primary approval_btn'
                                                data-toggle="modal" data-target="#approveupload"
                                                style={{ width: '246px' }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                                Approve upload request
                                                </button>

                                        </div>
                                        <div className="col-sm-2 " style={{
                                            marginLeft: '-140px'
                                        }}>
                                            <button className='zb-button zb-button-secondary update_save_btn'
                                                data-toggle="modal" data-target="#rejectUploadDoc"
                                                style={{
                                                    width: '246px',
                                                }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                                Reject upload request</button>
                                            {/* <button type="button" class="btn btn-default update_save_btn" data-toggle="modal" data-target="#myModal" disabled={this.state.buttonSave}>Save updates</button> */}
                                        </div>
                                        <div className="col-sm-1" style={{ marginTop: '-5px' }}>
                                            <Icon name="download-small" size="small" style={{ marginTop: '16px' }} title="" />
                                        </div>
                                        <div className="col-sm-2" style={{ marginLeft: '-82px', marginTop: '-5px' }}>
                                            <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                        </div>

                                        {/* <div className="col-sm-1" style={{ marginTop: '-7px', marginLeft: '-83px'}}>
                                        <Icon name="edit-small" size="small" style={{ marginTop: '16px' }} title="" />
                                    </div>
                                    <div className="col-sm-2" style={{ marginLeft: '-46px', marginTop: '-5px' }}>
                                        <label className="doc_download">Edit document</label>
                                    </div> */}
                                    </div>

                                    : null)
                                    : null}
                                
                                <div id="deleteHighRisk" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                <div className="col-sm-1" style={{ marginTop: '6px' }}>
                                                    <Icon name="warning-small" size="small" title="" />
                                                </div>
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Delete High risk document</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">
                                                    Are you sure you want to delete high risk document <br></br>
                                                    {this.state.selectedDoc} it will be permanently deleted and you will not be able to retrieve it again?</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '42px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.documenttDeletion.bind(this)}
                                                    style={{ width: '218px' }}>Delete</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="approvedelete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Approve deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to approve deletion request for <br></br>
                                                    {this.state.selectedDoc}</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.documenttDeletion.bind(this)}
                                                    style={{ width: '218px' }}>Yes, approve deletion</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="approveupload" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Approve deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to approve the upload request for  <br></br>
                                                    {this.state.selectedDoc} ?</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.approveUploadRequest.bind(this)}
                                                    style={{ width: '218px' }}>Yes, approve upload</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="rejectDelete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Reject deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">
                                                    Are you sure you want to reject deletion request for <br></br>
                                                    {this.state.selectedDoc}
                                                </p>

                                                <div className="form-group row" style={{ marginTop: '50px' }}>
                                                    <div className="col-sm-8">
                                                        <span className="header_body" style={{ color: '#666666' }}>
                                                            Provide a reason for rejecting (optional)
                                                            </span>
                                                    </div>
                                                    <div className="col-sm-4" style={{ marginLeft: '-25px' }}>
                                                        <span className="header_body" style={{ color: '#666666' }}>
                                                            max 255 characters
                                                            </span>
                                                    </div>
                                                </div>

                                                <div className="form-group row">
                                                    <div className="col-sm-9">
                                                        <input type="text" val={this.state.rejectReasonText} maxlength="255"
                                                            onChange={e => this.getRejectionReason(e.target.value)}
                                                            className="reason_input" placeholder="Input text here..." />

                                                    </div>

                                                </div>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.rejectDocuemntDeletion.bind(this)}
                                                    style={{ width: '218px' }}>Yes, reject deletion</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="rejectUploadDoc" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Reject upload request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">
                                                    Are you sure you want to reject the upload request for <br></br>
                                                    {this.state.selectedDoc} ?<br></br>
                                                    This will delete the document from LMS.
                                            </p>

                                                <div className="form-group row" style={{ marginTop: '50px' }}>
                                                    <div className="col-sm-8">
                                                        <span className="header_body" style={{ color: '#666666' }}>
                                                            Provide a reason for rejecting (optional)
                                                            </span>
                                                    </div>
                                                    <div className="col-sm-4" style={{ marginLeft: '-25px' }}>
                                                        <span className="header_body" style={{ color: '#666666' }}>
                                                            max 255 characters
                                                            </span>
                                                    </div>
                                                </div>

                                                <div className="form-group row">
                                                    <div className="col-sm-9">
                                                        <input type="text" val={this.state.rejectReasonText} maxlength="255"
                                                            onChange={e => this.getRejectionReason(e.target.value)}
                                                            className="reason_input" placeholder="Input text here..." />

                                                    </div>

                                                </div>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.rejectUploadRequest.bind(this)}
                                                    style={{ width: '218px' }}>Yes, reject upload</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>


                                {assetDocCancelDeletion ? (
                                    this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ? <div className="form-group row" >
                                        <div className="col-sm-1">
                                            <Icon name="close-plain-xsmall" size="xsmall" style={{ marginTop: '20px', marginLeft: '54px' }} title="" />
                                        </div>
                                        <div className="col-sm-2" style={{ marginLeft: '-51px' }}>
                                            <label className="doc_download"
                                                data-toggle="modal" data-target="#cancelDelete"
                                                onClick={this.getCancelDocumentID.bind(this, row._original.ID, row.cname, row._original.docData)} >
                                                Cancel deletion request
                                </label>
                                            {/* <label id="cancelDeleteLabel" data-dismiss="modal" data-toggle="modal" data-target="#cancelDeleteFailed"></label> */}
                                        </div>
                                        <div className="col-sm-1" style={{ marginLeft: '-92px' }}>
                                            <Icon name="download-small" size="small" style={{ marginTop: '16px' }} title="" />
                                        </div>
                                        <div className="col-sm-2" style={{ marginLeft: '-85px' }} >
                                            <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                        </div>
                                    </div> : null
                                )
                                    : null}

                                <div id="delete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Request deletion</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to request deletion for <br></br>
                                                    {this.state.selectedDoc} ?</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn ' data-dismiss="modal" onClick={this.sendRequestForDocuemntDeletion.bind(this)}>Yes, request deletion</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="cancelDeleteFailed" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Cancel deletion request failed</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">
                                                    The document has been already removed.Please contact the authoriser for more information.</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn delete_doc_btn' data-dismiss="modal" >Close</button>
                                                {/* <button className='zb-button zb-button-secondary cancel_pop_btn delete_doc_btn' data-dismiss="modal">Cancel</button> */}

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="cancelDelete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss='modal'>&times;</button>
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Cancel deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to cancel deletion request for <br></br>
                                                    {this.state.selectedDoc}</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn cancel_doc_btn'
                                                    data-dismiss="modal" onClick={this.sendRequestForCancelDocuemntDeletion.bind(this)}>
                                                    Yes, cancel deletion
                                        </button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn cancel_doc_btn'
                                                    data-dismiss="modal">No, don’t cancel deletion
                                        </button>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        );
                    }}
                />
            </div>
        )
    }
}

const mapStateToProps = state => {
    // return { usernotifications: state.user };
    return {
        // notifications: Object.assign({}, state.user),
        notifications: state.user,
    }

};

function mapDispatchToProps(dispatch) {
    return {
        addNotification: article => dispatch(addNotification(article))
    };
}

// export default withRouter(documentGrid);

const assetdocumentGrid = connect(mapStateToProps, mapDispatchToProps)(assetdocumentGridPage);

export default withRouter(assetdocumentGrid)