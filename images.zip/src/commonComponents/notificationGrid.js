import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from './pagination.js';
import { HttpPost, HttpGet, HttpPutWithoutBody } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
// import { notificationRetrieveData } from '../commonComponents/TLPGridStructure';
import { Select } from '@zambezi/sdk/dropdown-list';
import { connect } from "react-redux";
import { selectedTab } from "../redux/actions/index";

// const rawData = getPartyCustomer();



class notification extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "10",
            customerRecord: [],
            loading: false,
            selected: null,
            documentRecord: {},
            nType: true,
        }
    }

    componentWillReceiveProps(newProps) { 
        let output = [];
        let notificationRetrieveData = newProps.notifications;
        for (var i = 0; i < notificationRetrieveData.length; i++) {
            var obj = new Date(notificationRetrieveData[i].createdOn);
            let time = moment(obj).format('DD/MM/YYYY HH:mm A');
            var img_class_obj = '';
            var img_name = '';
            if (notificationRetrieveData[i].status == 'Rejected') {
                img_name = 'Rejected';
            } else if (notificationRetrieveData[i].status == 'Pending') {
                img_name = 'Pending'
            } else if (notificationRetrieveData[i].status == 'Approved') {
                img_name = 'Approved'
            }
            output.push({
                notificationDescription: notificationRetrieveData[i].description,
                created: time,
                img_name: img_name,
                imgClass: img_class_obj,
                partyID: notificationRetrieveData[i].partyID,
                notificationID: notificationRetrieveData[i].notificationID,
                type: notificationRetrieveData[i].type,
                read: notificationRetrieveData[i].hasRead,
                status: notificationRetrieveData[i].status,
                isActionCompleted: notificationRetrieveData[i].isActionCompleted,
                group: notificationRetrieveData[i].group,
                propertyID: notificationRetrieveData[i].propertyID,
                category: notificationRetrieveData[i].category,
                spvID: notificationRetrieveData[i].spvID,
                leaseContractID: notificationRetrieveData[i].leaseContractID,
            });
        }
        this.setState({ customerRecord: output });
    }



    componentDidMount() {
        // let output = [];
        // for (var i = 0; i < notificationRetrieveData.length; i++) {
        //     var obj = new Date(notificationRetrieveData[i].created);
        //         let time = moment(obj).format('DD/MM/YYYY');
        //         // time = time.toUpperCase();
        //         var img_class_obj = '';
        //         var img_name = '';
        //     if (notificationRetrieveData[i].type == 'Rejected') {
        //         // img_class_obj = 'pdf_img';
        //         img_name = 'Rejected';
        //     } else if (notificationRetrieveData[i].type == 'Pending') {
        //         // img_class_obj = 'doc_img';
        //         img_name = 'Pending'
        //     } else if (notificationRetrieveData[i].type == 'Approved') {
        //         // img_class_obj = 'doc_img';
        //         img_name = 'Approved'
        //     }
        //     output.push({
        //         notificationDescription: notificationRetrieveData[i].notificationDescription,
        //         created: time,
        //         // ID: response.data[i].documentId,
        //         img_name: img_name,
        //         imgClass: img_class_obj,
        //     });
        //     }
        // this.setState({ customerRecord: output });

    }

    renderNotofocationImage(cellInfo) {
        return (
            <span>
                {cellInfo.original.img_name == "Pending" && cellInfo.original.isActionCompleted == 0 ? <Icon name="warning-small" size="small" title=""/> : null}
                {cellInfo.original.img_name == "Pending" && cellInfo.original.isActionCompleted == 1 ? <Icon name="warning-small" size="small" style={{ opacity: '0.4' }} title=""/> : null}
                {/* {cellInfo.original.img_name == "Pending" && cellInfo.original.isActionCompleted == 1 ? <Icon name="information-small" size="small" /> : null} */}
                {cellInfo.original.img_name == "Approved" ? <Icon name="confirmation-small" size="small" title=""/> : null}
                {cellInfo.original.img_name == "Rejected" ? <Icon name="error-small" size="small" title=""/> : null}
            </span>
        );
    }

    renderNotofocationDescription(cellInfo) {
        return (
            <span>
                {cellInfo.original.read == 0 && cellInfo.original.isActionCompleted == 0 ? <span style={{ fontWeight: 'bold' }}>{cellInfo.original.notificationDescription}</span> : null}
                {cellInfo.original.isActionCompleted == 1 && cellInfo.original.img_name == "Pending" ? <span style={{opacity: '0.4'}}>{cellInfo.original.notificationDescription}</span> : null}
                {cellInfo.original.read == 1 && cellInfo.original.isActionCompleted == 0 ? <span>{cellInfo.original.notificationDescription}</span> : null}
            </span>
        );
    }

    readNotification(nObject) {
        
        localStorage.setItem('visitedFrom', 'notification');
        console.log("Object property");
        console.log(nObject);
        console.log("Read notification:: ", nObject.notificationID);
        console.log("Read party ID:: ", nObject.partyID);
        console.log("Read type:: ", nObject.type);
        if ((nObject.group).toLowerCase() == "party" && (nObject.category).toLowerCase() == "document") {
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", '');
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;

                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    // currentComponent.props.selectedTab("Customer");
                    localStorage.setItem('selectedTab', "Customer");
                    currentComponent.props.history.push({
                        pathname: '/lms/viewCustomerDetail',
                        state: { rowID: nObject.partyID }
                    })
                })
                    .catch(function (error) {
                    })
            }
        } else if ((nObject.group).toLowerCase() == "asset" && (nObject.category).toLowerCase() == "document") {
            //viewAssetDetail
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                console.log("Property");
                this.setState({
                    activeTabClassName: "Asset",
                })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    localStorage.setItem("docUpload", "approverDocUpload1");
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("docUpload", "userDocUpload1");
                    localStorage.setItem("Message", JSON.stringify(nObject));
                }
                console.log("Property message");
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;
                console.log("Property message set");
                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    currentComponent.props.history.push({
                        pathname: '/lms/asset',
                        state: { spvID: nObject.spvID }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        }else if ((nObject.group).toLowerCase() == "invoice") {
            //invoice approver grid
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                // this.setState({
                //     activeTabClassName: "Invoicing",
                // })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", "");
                    console.log('Approver set to true');
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to false');
                }
                console.log("Property message");
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;
                console.log("Property message set");
                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    currentComponent.props.history.push({
                        pathname: '/lms/invoiceListApprover',
                        state: { notificationData: nObject }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        } else if ((nObject.group).toLowerCase() == "lease" && (nObject.category).toLowerCase() == "document" || (nObject.category).toLowerCase() == "manage approval") { 
            console.log("Under lease")
            console.log(nObject);
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    localStorage.setItem("docUpload", "approverDocUpload1");
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("docUpload", "userDocUpload1");
                    localStorage.setItem("Message", JSON.stringify(nObject));
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;
                console.log("property notifications");
                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server from lease document");
                    console.log(response.data);
                    // currentComponent.props.selectedTab("Customer");
                    localStorage.setItem('selectedTab', "deals");
                    currentComponent.props.history.push({
                        pathname: '/lms/mainSummaryTabsPage',
                        state: { leaseContractId: nObject.leaseContractID }
                    })
                })
                    .catch(function (error) {
                    })
            }
        } else if ((nObject.group).toLowerCase() == "lease" && (nObject.category).toLowerCase() == "tlp") {
            console.log('Under Lease for TLP grid');
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                // this.setState({
                //     activeTabClassName: "deals",
                // })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to true');
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to false');
                    if (nObject.status == "Approved") {
                        localStorage.setItem('approvalPending', 'Approved');
                    } else if (nObject.status == "Rejected") {
                        localStorage.setItem('approvalPending', 'Rejected');
                    }
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;

                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server for tlp");
                    console.log(response.data);
                    if (nObject.type == "Action") {
                        currentComponent.props.history.push({
                            pathname: '/lms/ApproveTLPGrid',
                            state: { rowID: nObject.partyID }
                        })
                    } else {
                        currentComponent.props.history.push({
                            pathname: '/lms/emptyTLPGrid',
                            state: { rowID: nObject.partyID }
                        })
                    }
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        }
        else if ((nObject.group).toLowerCase() == "party" && (nObject.category).toLowerCase() == "general approval") {
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                } else {
                    localStorage.setItem("approver", 'false');
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;

                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    // currentComponent.props.selectedTab("Customer");
                    localStorage.setItem('selectedTab', "Customer");
                    currentComponent.props.history.push({
                        pathname: '/lms/viewCustomerDetail',
                        state: { rowID: nObject.partyID }
                    })
                })
                    .catch(function (error) {
                    })
            }
        }
        
    }

    renderNotificationDate(cellInfo) { 
        return (
            <span>
                {cellInfo.original.isActionCompleted == 1 && cellInfo.original.img_name == "Pending" ? <span style={{ opacity: '0.4' }}>{cellInfo.original.created}</span> : null}
                {cellInfo.original.isActionCompleted == 0 ? <span>{cellInfo.original.created}</span> : null}
            </span>
        );
    }

    renderNotificationArrow(cellInfo) {
        return (
            <span>
                {/* {cellInfo.original.isActionCompleted == 1 ? <span style={{ opacity: '0.4' }}>{cellInfo.original.created}</span> : null} */}
                {cellInfo.original.isActionCompleted == 0 ? <Icon name="chev-right-xsmall" size="xsmall" title=""/> : null}
            </span>
        );
    }

    selectNotificationType(nType) {
        if (nType === 'All') {
            this.setState({ nType: true });
        } else {
            this.setState({ nType: false });
        }
        return true;
    }

    render() {
        const columns = [{
            width: 50,
            className: 'notification_cell_icon',
            Cell: this.renderNotofocationImage
        },{
            id: 'notificationDescription',
            accessor: 'notificationDescription', // String-based value accessors!
            headerClassName: 'theader_docname',
                width: 850,
                Cell: this.renderNotofocationDescription,
                className: 'notification_desc',
                filterable: true,
                filterMethod: (filter, row) => {
                    // this.setState({ nType: true });
                    if (filter.value == 'All') {
                        this.state.nType = true;
                    } else { 
                        this.state.nType = false;
                    }
                    if (filter.value == 'All') {
                        return true;
                        // this.selectNotificationType.bind(this, 'All');
                    }
                    if (filter.value === "Action") {
                        // this.selectNotificationType.bind(this, 'All');
                        return row._original.type == "Action" && row._original.isActionCompleted == 0;
                        
                    }
                },
                // Custom cell components!
                Filter: ({ filter, onChange }) =>
                    <div className="form-group row" style={{ marginTop:  '-3px'}}>
                        <div className="col-sm-3">
                            <div class="notification_type">
                                <div class="btn-group">
                                    <div
                                        className={"btn btn-primary notification_type_all " + (this.state.nType ? 'dealtype_selected' : 'dealtype_notselected')}
                                        // onClick={this.selectNotificationType.bind(this, 'All')}
                                        onClick={event => onChange('All')}>All</div>
                                    <div className={"btn btn-primary notification_type_action " + (!this.state.nType ? 'dealtype_selected' : 'dealtype_notselected')}
                                        // onClick={this.selectNotificationType.bind(this, 'Action')}
                                        onClick={event => onChange('Action')}>Requiring action</div>
                                </div>
                            </div>
                        </div>
                    </div>
                ,
        }, {
            id: 'sdate',
            Header: '',
            accessor: 'created',
            headerClassName: 'theader',
            width: 225,
            Cell: this.renderNotificationDate,
            className: 'notification_desc_date',
        }, {
                width: 50,
                className: 'notification_cell_icon',
                Cell: this.renderNotificationArrow//props => 
            }
        ]

        return (
            <div>
                <ReactTable
                    data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
                    columns={columns}
                    loading={this.state.loading}
                    showPagination={true}
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    showPageSizeOptions={true}
                    className='notificationdata'
                    defaultPageSize={10}
                    pageSize={this.props.selectedRecord}
                    PaginationComponent={Pagination}
                    onFilteredChange={undefined}
                    defaultSortDesc={false}
                    previousText='Previous'
                    nextText='Next'
                    loadingText='Loading...'
                    noDataText='No rows found'
                    pageText='Page'
                    ofText='of'
                    rowsText='rows'
                    getTrProps={(state, rowInfo) => {

                        if (rowInfo && rowInfo.row) {
                            return {
                                onClick: (e) => {
                                    this.state.selected = rowInfo.index;
                                    this.readNotification(rowInfo.original);
                                },
                                style: {
                                    background: rowInfo.index === this.state.selected ? 'rgb(77,170,233, 0.1)' : 'white',
                                    color: rowInfo.index === this.state.selected ? '#000000' : 'black'
                                },
                            }
                        } else {
                            return {}
                        }
                    }}
                    
                   
                />


            </div>
        )
    }
}

const mapStateToProps = state => {
    return { notifications: state.user };
};

// function mapDispatchToProps(dispatch) {
//     return {
//         selectedTab: article => dispatch(selectedTab(article))
//     };
// }

const notificationGrid = connect(mapStateToProps)(notification);

export default withRouter(notificationGrid)