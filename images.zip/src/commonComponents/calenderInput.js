import React from 'react';
import DatePicker from '@zambezi/sdk/date-picker';
import { allowedFormats } from '@zambezi/sdk/date-picker'
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/icons.js';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import { Notification } from '@zambezi/sdk/notification';
import moment from 'moment';

const calenderinputfield = ({ fieldTitle, inputType, onError, errorStatus, value,
     name, onChange, onClick, placeholder, getOptionInputDate, id , errorMessage, isReadOnly, isDisabled, onUserChange }) => {
    console.log("error status");
    // console.log(errorStatus);
    // console.log('Formats:  ' + allowedFormats)
    return (
        <div>
            <div class="form-group row">
                <label for="" class="col-sm-4 col-form-label field_label_model">{fieldTitle}</label>
                <div className="col-sm-7 inner-addon right-addon search_column">
                    <DatePicker
                        className="large-date-picker zb_datePicker"
                        date={value}
                        onChange={onChange}
                        placeholder='DD/MM/YYYY'
                        onError={onError}
                        onInputChange={getOptionInputDate}
                        onUserChange={onUserChange}
                        error={errorStatus}
                        name={name}
                        dateFormat='DD/MM/YYYY'
                        id={id}
                        readOnly={isReadOnly}
                        disabled ={isDisabled}
                        // isMobile={true}
                        // allowedFormats='DD/MM/YYYY'
                    />
                    </div>
            </div>
            {errorStatus ?
                <div className="form-group row">
                    <label className="col-sm-4 col-form-label field_label_model"></label>
                    <div className="col-sm-7 " >
                        <Notification
                            status='error'
                            size='small'
                            withArrow
                            arrowPosition='14px'
                            className="error_notification zb_datePicker"
                        >
                            {errorMessage ?
                            errorMessage:"Please complete this field"
                            }
                        </Notification>
                    </div>
                </div>
                : null}
        </div> 
    );
};

export default calenderinputfield