
const userData = [{
    name: 'Tanner Linsley',
    type: 'Customer',
    address: 'London',
    status: 'Active',
    created: '12-06-2019',
    ID: 201
},
{
    name: 'panner Linsley',
    type: 'Customer',
    address: 'Gondon',
    status: 'Pending',
    created: '2019-06-18, 12:40 pm',
    ID: 202
},
{
    name: 'Aanner Linsley',
    type: 'Seller',
    address: 'Aondon',
    status: 'Active',
    created: '12-08-2018',
    ID: 203
}, {
    name: 'Ganner Linsley',
    type: 'Seller',
    address: 'Kondon',
    status: 'Pending',
    created: '12-08-2018',
    ID: 204
}, {
    name: 'kanner Linsley',
    type: 'Customer',
    address: 'Aondon',
    status: 'Active',
    created: '12-08-2018',
    ID: 205
}, {
    name: 'banner Linsley',
    type: 'Customer',
    address: 'Oondon',
    status: 'Inactive',
    created: '12-08-2018',
    ID: 206
}, {
    name: 'wanner Linsley',
    type: 'SPV',
    address: 'London',
    status: 'Active',
    created: '12-08-2018',
    ID: 207
}, {
    name: 'manner Linsley',
    type: 'SPV',
    address: 'London',
    status: 'Inactive',
    created: '12-08-2018'
}, {
    name: 'aanner Linsley',
    type: 'Customer',
    address: 'London',
    status: 'Active',
    created: '12-08-2018'
}, {
    name: 'tanner Linsley',
    type: 'Customer',
    address: 'London',
    status: 'Pending',
    created: '12-08-2018'
}, {
    name: 'banner Linsley',
    type: 'SPV',
    address: 'London',
    status: 'Active',
    created: '12-08-2018'
}, {
    name: 'wanner Linsley',
    type: 'Seller',
    address: 'London',
    status: 'Active',
    created: '12-08-2018'
}]

export default userData;