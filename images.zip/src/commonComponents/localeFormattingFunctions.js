import moment from 'moment';

export const formatDate = function(dateString, locale){
    if(dateString !== null && dateString !== ''){
        if(moment(dateString).isValid()){
            return moment(dateString).toDate().toLocaleDateString(locale, {timezone: 'UTC', dateStyle:'short'});    
        } else {
            return '';
        } 
    } else {
        return '';
    }
}

export const formatDateRange = function (dates, delimiter, locale) {
    if (dates && dates.length > 0) {
        let result = "";

        dates.forEach((item) => {
            let date = item;
            if (typeof (date) === 'string') {
                date = date.trim()
            }
            let tempFormattedDate = formatDate(date, locale);
            result = result + ' ' + tempFormattedDate + ' ' + delimiter;
        });

        return result.slice(0, -2);
    } else {
        return '';
    }
}

export const formatCurrencyValue = function(value, locale){
    if(null != value && value !== ''){
        let newVal
        if(typeof(value)==='string'){
            newVal = parseFloat(removeComma(value));
            if(isNaN(newVal)){
                return value;
            }
        } else if(typeof(value)==='number') {
            newVal = value;
        } else {
            return value;
        }
        return newVal.toLocaleString(locale, {maximumFractionDigits : 2});
    }else {
        return '';
    }
}

export function removeComma(str) {
    let strWithoutComma = '';
    if(str != '' && str != undefined){
        if(str !== undefined && str != '') {
            strWithoutComma = str.replace(/,/g, '');
        }
    }
    
    return strWithoutComma;
}