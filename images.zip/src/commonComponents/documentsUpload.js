import React from 'react';
import DocUpload from './docUpload';
import { Icon } from '@zambezi/sdk/icons';
import { Checkbox } from '@zambezi/sdk/form-elements';
import { Notification } from '@zambezi/sdk/notification';
import { Select } from '@zambezi/sdk/dropdown-list';

class documentUpload extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dialogDismissState: ''
            // selectedFile: null
        }
    }

    componentWillMount() {
        
        this.setState({ dialogDismissState: this.props.dialogDismiss})
     }

    generateData(type) {
        const data = [];
        
        if (type == "Classification") {
            data.push(
                "",
                "Public",
                "Internal",
                "Confidential",
                "Secret"
            );
        } else if (type == "Record") {
            if (this.props.actionType == "party") {
                data.push(
                    "",
                    "Policy Procedures",
                    "Customer Records",
                    "General Contract Agreement",
                    "Litigation",
                    "Customer Management",
                    "Fraud & Investigations",
                    "Regulatory Risk Compliance",
                    "Regulatory Risk Enforcement & Investigations",
                    "Advice Services "
                );
            } else if (this.props.actionType == "asset") { 
                data.push(
                    "",
                    "Policy Procedures",
                    "Environmental Testing & Monitoring",
                    "Maintenance Repairs & Inspections",
                    "Real Estate Appraisals",
                    "Property Related Contract Agreement",
                    "Litigation",
                    "Customer Management",
                    "Fraud & Investigations",
                    "Regulatory Risk Compliance",
                    "Regulatory Risk Enforcement & Investigations",
                    "Advice Services"

                );
            }
            else if (this.props.actionType == "deal") { 
                data.push(
                    "",
                    "Policy Procedures",
                    "Lending & Credit Records",
                    "General Contract Agreement ",
                    "Property Related Contract Agreement ",
                    "Litigation Customer Management ",
                    "Fraud & Investigations ",
                    "Regulatory Risk Compliance ",
                    "Regulatory Risk Enforcement & Investigations ",
                    "Advice Services"
                );
            }
           
        } else if (type == "Risk") {
            data.push(
                "",
                "High Risk",
                "Secondary Risk",
                "Historical"
            );
        }

        return data
    }

    render() {
        console.log("Render Upload documents");
        console.log(this.props.highRiskStatus);
        // const dialogstate = this.props.dialogDismiss;
        return (
            <div id="upload" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                            <h4 class="modal-title header_title">Upload document</h4>
                        </div>

                        <div class="modal-body">
                            {this.props.fileName == '' ? <div>
                                <div className="form-group row" style={{ marginTop: '10px' }}>
                                    <div className="col-sm-9">
                                        <span className="docupload_header_body">Upload 1 document, up to 2GB</span>

                                    </div>
                                    <div className="col-sm-3" onClick={this.props.onClick}>
                                        <div style={{
                                            textDecoration: 'underline',
                                            color: '#ad1982',
                                            marginLeft: '41px',
                                            fontSize: '16px'
                                        }} >Browse</div>
                                    </div>
                                    </div>

                                <div className="form-group row" style={{ marginTop: '10px' }}>
                                    <div className="col-sm-11">
                                        <label className="docupload_header_body">Documents must follow the naming convention of date, document title, risk classification and version.<br></br>
                                         e.g. 2020-02-02NewRecordsHRV01.01.docx</label>
                                    </div>
                                </div>
                                <DocUpload onChange={this.props.onChangeDoc} reference={this.props.reference} docStatus={this.props.docLengthStatus} />
                                {this.props.docLengthStatus ?
                                    <div className="form-group row" style={{
                                        margin: '-14px auto 24px 3px',
                                        width: '600px'
                                    }}>
                                        <div className="col-sm-11" style={{ width: '93%' }}>
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                            >
                                                {this.props.errorMessage}
                                                    </Notification>
                                        </div>
                                    </div>
                                : null}
                            </div>
                        : null}
                           

                            {this.props.fileName != '' ? <div style={{ marginTop: '10px' }}>
                                <label className="documents_header_body">You’ve reached the document limit upload. To upload more documents, you need to complete this upload and start again.</label>
                                <div className="documents_section">
                                    <div style={{ marginLeft: '4px' }}>
                                        <div className="form-group row ">
                                            <div style={{ marginTop: '20px', paddingBottom: '45px' }}>
                                                {this.props.docType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ? <div className="col-sm-1">
                                                    <div style={{ backgroundColor: '#429448', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center' }}>
                                                        <label style={{
                                                            color: '#fff', fontSize: '11px', verticalAlign: 'middle', marginBottom:'10px'
                                                        }}>X</label></div>
                                                </div> : null}
                                                {this.props.docType == "application/vnd.ms-excel" ? <div className="col-sm-1">
                                                    <div style={{ backgroundColor: '#429448', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center' }}>
                                                        <label style={{
                                                            color: '#fff', fontSize: '11px', verticalAlign: 'middle', marginBottom: '10px' }}>X</label></div>
                                                </div> : null}
                                                {this.props.docType == "application/pdf" ? <div className="col-sm-1">
                                                    <div style={{ backgroundColor: '#ce3b57', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center' }}>
                                                        <label style={{
                                                            color: '#fff', fontSize: '7px', verticalAlign: 'middle', marginBottom: '10px' }}>PDF</label></div>
                                                </div> : null}
                                                {this.props.docType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || this.props.docType == "application/msword" ? <div className="col-sm-1">
                                                    <div style={{
                                                        backgroundColor: '#516cb3', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center'
                                                    }}>
                                                        <label style={{
                                                            color: '#fff', fontSize: '11px', verticalAlign: 'middle', marginBottom: '10px' }}>W</label></div>
                                                </div> : null}
                                                {this.props.docType == "image/png" ? <div className="col-sm-1">
                                                    <div style={{
                                                        backgroundColor: '#42145F', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center'
                                                    }}><label style={{
                                                            color: '#fff', fontSize: '7px', verticalAlign: 'middle', marginBottom: '10px' }}>PNG</label></div>
                                                </div> : null}
                                                {this.props.docType == "image/jpeg" ? <div className="col-sm-1">
                                                    <div style={{
                                                        backgroundColor: '#009FAC', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center'
                                                    }}><label style={{
                                                            color: '#fff', fontSize: '7px', verticalAlign: 'middle', marginBottom: '10px' }}>JPG</label></div>
                                                </div> : null}
                                                {this.props.docType == "application/vnd.openxmlformats-officedocument.presentationml.presentation" || this.props.docType == " application/vnd.ms-powerpoint" ? <div className="col-sm-1">
                                                    <div style={{
                                                        backgroundColor: '#AD1982', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center'
                                                    }}><label style={{
                                                        color: '#fff', fontSize: '7px', verticalAlign: 'middle', marginBottom:'10px' }}>PPT</label></div>
                                                </div> : null}
                                                {this.props.docType == "" ? <div className="col-sm-1">
                                                    <div style={{
                                                        backgroundColor: '#6F2C91', width: '16px', height: '16px', marginLeft: '28px', marginTop: '5px', textAlign: 'center'
                                                    }}><label style={{
                                                            color: '#fff', fontSize: '7px', verticalAlign: 'middle', marginBottom: '10px' }}>MSG</label></div>
                                                </div> : null}
                                                <div className="col-sm-6">
                                                    <span className="header_body" style={{ marginLeft: '0px' }}>{this.props.fileName}</span>
                                                </div>

                                                <div className="col-sm-4" style={{ marginLeft: '22px' }} onClick={ this.props.deleteDoc }>
                                                    <Icon name="trash-small" size="small" style={{ float: 'right' }} title=""/>
                                                </div>
                                            </div>

                                            <div className="form-group row">
                                                <div className="col-sm-7" style={{ marginLeft: '20px' }}>
                                                    <span className="docupload_header_body" style={{ color: '#666666' }}>Document description</span>

                                                </div>
                                                <div className="col-sm-4" onClick={this.props.onClick}>
                                                    <div style={{
                                                        color: '#666666',
                                                        marginLeft: '54px',
                                                        fontSize: '13px'
                                                    }} >max 255 characters</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group row" style={{
                                            margin: '-14px auto 24px 8px',
                                            width: '600px'
                                        }}>
                                            <div className="col-sm-8">
                                                <input type="text" value={this.props.value} maxLength='255' name="" id="" onChange={this.props.onChange}
                                                    className={"form-control input_Fields " + (this.props.errorStatus ? 'errorTextBox' : '')}
                                                    placeholder="Enter" style={{ width: '534px' }} />
                                            </div>
                                        </div>
                                        {this.props.errorStatus ?
                                            <div className="form-group row" style={{
                                                margin: '-14px auto 24px 8px',
                                                width: '600px'
                                            }}>
                                                <div className="col-sm-11" style={{ width: '94%' }}>
                                                    <Notification
                                                        status='error'
                                                        size='small'
                                                        withArrow
                                                        arrowPosition='14px'
                                                        className="error_notification"
                                                    >
                                                        {this.props.textErrorMessage}
                                                </Notification>
                                                </div>
                                            </div>
                                            : null}

                                        <div className="form-group row">
                                            <div className="col-sm-7" style={{ marginLeft: '3px' }}>
                                                <span className="docupload_header_body" style={{ color: '#666666' }}>RBS classification</span>
                                            </div>
                                        </div>
                                        <div className="form-group row" style={{
                                            margin: '0px auto 24px 8px',
                                            width: '600px'
                                        }}>
                                            <div className="col-sm-8">
                                                <Select
                                                    defaultValue=''
                                                    value={this.props.rbsClassificationVal}
                                                    suggestions={this.generateData('Classification')}
                                                    placeholder='Select'
                                                    className='dropdown_config_custom'
                                                    isError={this.props.rbsClassificationValErrorStatus}
                                                    onChange={this.props.getDropdownItem.bind(this, 'Classification')}
                                                />
                                            </div>
                                        </div>

                                        {this.props.rbsClassificationValErrorStatus ?
                                            <div className="form-group row" style={{
                                                margin: '-14px auto 24px 8px',
                                                width: '600px'
                                            }}>
                                                <div className="col-sm-11" style={{ width: '94%' }}>
                                                    <Notification
                                                        status='error'
                                                        size='small'
                                                        withArrow
                                                        arrowPosition='14px'
                                                        className="error_notification"
                                                    >
                                                        {this.props.rbsClassificationValErrorMessage}
                                                </Notification>
                                                </div>
                                            </div>
                                            : null}
                                        

                                        <div className="form-group row">
                                            <div className="col-sm-7" style={{ marginLeft: '3px' }}>
                                                <span className="docupload_header_body" style={{ color: '#666666' }}>RBS record class code</span>
                                            </div>
                                        </div>
                                        <div className="form-group row" style={{
                                            margin: '0px auto 24px 8px',
                                            width: '600px'
                                        }}>
                                            <div className="col-sm-8">
                                                <Select
                                                    defaultValue=''
                                                    value={this.props.rbsRecordVal}
                                                    suggestions={this.generateData('Record')}
                                                    placeholder='Select'
                                                    className='dropdown_config_custom'
                                                    isError={this.props.rbsRecordValErrorStatus}
                                                    onChange={this.props.getDropdownItem.bind(this, 'Record')}
                                                />
                                            </div>
                                        </div>

                                        {this.props.rbsRecordValErrorStatus ?
                                            <div className="form-group row" style={{
                                                margin: '-14px auto 24px 8px',
                                                width: '600px'
                                            }}>
                                                <div className="col-sm-11" style={{ width: '94%' }}>
                                                    <Notification
                                                        status='error'
                                                        size='small'
                                                        withArrow
                                                        arrowPosition='14px'
                                                        className="error_notification"
                                                    >
                                                        {this.props.rbsRecordValErrorMessage}
                                                    </Notification>
                                                </div>
                                            </div>
                                            : null}


                                        <div className="form-group row">
                                            <div className="col-sm-7" style={{ marginLeft: '3px' }}>
                                                <span className="docupload_header_body" style={{ color: '#666666' }}>High risk record</span>
                                            </div>
                                        </div>
                                        <div className="form-group row" style={{
                                            margin: '0px auto 24px 8px',
                                            width: '600px'
                                        }}>
                                            <div className="col-sm-8">
                                                <Select
                                                    defaultValue=''
                                                    value={this.props.rbsRiskVal}
                                                    suggestions={this.generateData('Risk')}
                                                    placeholder='Select'
                                                    className='dropdown_config_custom'
                                                    isError={this.props.rbsRiskValErrorStatus}
                                                    onChange={this.props.getDropdownItem.bind(this, 'Risk')}
                                                />
                                            </div>
                                        </div>

                                        {this.props.rbsRiskValErrorStatus ?
                                            <div className="form-group row" style={{
                                                margin: '-14px auto 24px 8px',
                                                width: '600px'
                                            }}>
                                                <div className="col-sm-11" style={{ width: '94%' }}>
                                                    <Notification
                                                        status='error'
                                                        size='small'
                                                        withArrow
                                                        arrowPosition='14px'
                                                        className="error_notification"
                                                    >
                                                        {this.props.rbsRiskValErrorMessage}
                                                    </Notification>
                                                </div>
                                            </div>
                                            : null}

                                    </div>
                                </div>

                                <div className="form-group row" style={{
                                    width: '600px',
                                    margin: '25px auto 0 0px'
                                }}>
                                    <div className="col-sm-12">
                                        <Checkbox defaultChecked={false} id='uncontrolled-checkbox' onChange={this.props.onCheckboxChange}/>
                                        {this.props.highRiskStatus ? <label htmlFor='uncontrolled-checkbox' className="col-sm-10 confirmCheckbox"
                                            style={{ float: 'right', position: 'absolute', left: '32px' }}>This document is classified as High Risk  and 
                                        will be sent for approval for upload .Tick to confirm you want to upload the document </label> :
                                            <label htmlFor='uncontrolled-checkbox' className="col-sm-10 confirmCheckbox" style={{ float: 'right', position: 'absolute', left: '32px' }}>I confirm I want to upload documents</label> 
                                            }
                                    </div>
                                </div>
                            </div>
                                : null}
                        </div>
                        <div class="modal-footer" style={{ display: 'table', border: 'none', margin: '-24px 0px 20px 24px' }}>
                             {!this.props.highRiskStatus ? <button className='zb-button zb-button-primary save_pop_btn' style={{ width: '201px' }} data-dismiss={this.props.dialogDismiss}
                                disabled={this.props.uploadStatus} onClick={this.props.onUpload}>Upload documents</button>:
                                <button className='zb-button zb-button-primary save_pop_btn' style={{ width: '201px' }} data-dismiss={this.props.dialogDismiss}
                                    disabled={this.props.uploadStatus} onClick={this.props.onUpload}>Request approval</button>

                                }
                            <button className='zb-button zb-button-secondary cancel_pop_btn' style={{ width: '201px', marginTop: '27px'}} data-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default documentUpload;