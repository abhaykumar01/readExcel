import React, { Component } from 'react';
import '../style.css';
import logo from '../assets/images/logo.png';
import AccountIcon from '../assets/images/user.png';
import UserSelect from '../assets/images/user_select.png';
import NotificationIcon from '../assets/images/notification-icon.png';
import { Link } from 'react-router-dom';
import { Route, withRouter } from 'react-router-dom';
import { AuthorizationContext } from '../components/authContext/index'
import { HttpGet, HttpPutWithoutBody } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { connect } from "react-redux";
import { addNotification, selectedDataFormat } from "../redux/actions/index";
import { Icon } from '@zambezi/sdk/icons';
import { ECM_TOGGLE } from '../config/config';

// const mapStateToProps = state => {
//     console.log("receive tab data");
//     console.log(state.user);
//     return { selectedTab: state.user };
// };
const PING = process.env.REACT_APP_PING;
class head extends Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            activeTabClassName: "",
            activeUser: false,
            dealType: true,
            showUserDetail: true,
            showDealModelPage: false,
            activeNotification: false,
            notificationdata: '',
            notificationCount: '',
            toggle: false,
            dataFormat: localStorage.getItem('dataFormat') ? localStorage.getItem('dataFormat') : 'en-GB',
        };
        this.props.selectedDataFormat('en-GB');
    }


    componentDidMount() {
        console.log("Header Mount received");
        console.log(ECM_TOGGLE);
        this.setState({ toggle: ECM_TOGGLE });
        localStorage.setItem('selectedTab', '');
        this.getNotifications();
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log("reterive permission data");
            console.log(usersDetails);
            console.log(usersDetails.permissions);
        } else {
            let groupName = API_ENDPOINT.LMS_RBAC_ROLEPERMISSION + '/' + 'rAppNordiskLMS-SeniorApproverUser'; //response.data.memberOf
            HttpGet(this, groupName)
                .then(function (response) {
                    console.log("Permissions received for top management");
                    console.log(response);
                    console.log(response.data);
                    localStorage.setItem('permissions', JSON.stringify(response.data));
                    localStorage.setItem('ID', 'testRacf');
                    localStorage.setItem('racfID', 'lmsgf');
                    localStorage.setItem('roleName', 'rAppNordiskLMS-SeniorApproverUser')
                }).catch(function (error) {
                    console.log("Error received from Permission user");
                    console.log(error);
                })
        }
    }

    componentWillReceiveProps(nextProps) {
        console.log("header Props received");
        console.log(nextProps);
        let tabval = localStorage.getItem('selectedTab');
        if (tabval == "Customer") {
            this.setState({
                activeTabClassName: tabval,
            })
        }

        if (tabval == "deals") {
            this.setState({
                activeTabClassName: tabval,
            })
        }
        this.getNotifications();
    }

    getNotifications() {
        if (ECM_TOGGLE == 'false') {
            this.setState({ activeNotification: false });
            var currentComponent = this;
            var userID = '';
            var roleName = '';
            if (PING == 'true') {
                let { usersDetails } = this.context;
                userID = usersDetails.userID;
                roleName = usersDetails.memberOf;
            } else {
                userID = 'lmsgf';
                roleName = 'rAppNordiskLMS-GeneralFinanceUser';
            }
            let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/getNotificationByUserIDAndRoleName/' + userID + '/' + roleName;

            let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
                console.log("Notification response received from server");
                console.log(response);
                console.log(response.data);
                console.log(response.data.length);
                localStorage.setItem("allNotifications", JSON.stringify(response.data));
                let count = 0;
                let notificationRecord = [];
                // currentComponent.props.addNotification(response.data);
                for (var i = 0; i < response.data.length; i++) {
                    if (response.data[i].hasRead == 0) {
                        count += 1;
                    }
                    // if (response.data[i].requestedBy != userID) {
                    //     console.log("fetch individual notification data");
                    //     console.log(response.data[i]);
                    //     notificationRecord.push(response.data[i]);
                    // }
                }
                // console.log("fetch notification record");
                // console.log(notificationRecord);
                // if(notificationRecord){
                //     for (var i = 0; i < notificationRecord.length; i++) {
                //         if (notificationRecord[i].hasRead == 0) {
                //             count += 1;
                //         }
                //     }
                // }

                currentComponent.props.addNotification(response.data);
                currentComponent.setState({
                    notificationCount: count,
                    notificationdata: response.data
                });
            })
                .catch(function (error) {
                    console.log("Error received");
                    console.log(error);
                })
            let showDeal = API_ENDPOINT.DEAL_MODEL_TAB;
            if (showDeal === "showdealpage") {
                currentComponent.setState({ showDealModelPage: true });
            } else {
                currentComponent.setState({ showDealModelPage: false });
            }
        }
    }


    selectDealType(dealtype) {
        console.log("Deal type", dealtype);
        if (dealtype === 'standard') {
            this.setState({ dealType: true });
        } else {
            this.setState({ dealType: false });
        }
    }

    toggleDataFormat(dataFormat) {
        this.setState({ 'dataFormat': dataFormat });
        this.props.selectedDataFormat(dataFormat);
    }

    tabClick(tabval) {
        console.log(tabval);
        localStorage.setItem('recordview', 10);
        this.setState({
            activeUser: false,
            activeNotification: false
        });

        localStorage.setItem('datasave', '');
        localStorage.setItem('datachange', '');
        if (tabval == "deals" || tabval == "Asset") {
            this.setState({ showUserDetail: true });
            localStorage.setItem("approver", 'false');
            localStorage.setItem("docUpload", "userDocUpload1");
            localStorage.setItem("Message", "");
        } else {
            this.setState({ showUserDetail: false });
        }
        this.setState({
            showUserDetail: true,
            activeTabClassName: tabval,
        })
        if (tabval == "Asset") {
            localStorage.setItem("approver", 'false');
            localStorage.setItem("docUpload", "userDocUpload1");
            localStorage.setItem("Message", "");
        }
    }

    userClick() {
        if (this.state.showUserDetail) {
            this.setState({
                activeUser: !this.state.activeUser,
                activeNotification: false
            });
        }
    }

    openNotificationPanel(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log("Active notification");
        console.log(this.state.activeNotification);
        let count = this.state.notificationdata.length;
        if (count > 0) {
            this.setState({ activeNotification: !this.state.activeNotification });
        } else {
            this.setState({ activeNotification: false });
        }

    }

    goHomePage() {
        this.setState({
            activeTabClassName: "",
        })
        this.props.history.push({
            pathname: '/lms/Home'
        })
    }

    tlpGrid() {
        this.setState({ activeUser: false });
        localStorage.setItem('cancelstatus', false);
        localStorage.setItem('Approvalstatus', false);
        localStorage.setItem("NotificationSelected", 'false');
        this.props.history.push({
            pathname: '/lms/emptyTLPGrid'
        })
    }

    hideUserInfo() {
        this.setState({ activeUser: false });
    }



    viewNotification() {
        this.props.history.push({
            pathname: '/lms/Notification'
        })
    }

    readNotification(nObject) {
        localStorage.setItem('visitedFrom', 'notification');
        console.log("Read notification:: ", nObject);
        console.log("Read notification:: ", nObject.group);
        if ((nObject.group).toLowerCase() == "party" && (nObject.category).toLowerCase() == "document") {
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                this.setState({
                    activeTabClassName: "Customer",
                })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", "");
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;

                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    currentComponent.props.history.push({
                        pathname: '/lms/viewCustomerDetail',
                        state: { rowID: nObject.partyID }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        } else if ((nObject.group).toLowerCase() == "asset" && (nObject.category).toLowerCase() == "document") {
            //viewAssetDetail
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                console.log("Property");
                this.setState({
                    activeTabClassName: "Asset",
                })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    localStorage.setItem("docUpload", "approverDocUpload1");
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("docUpload", "userDocUpload1");
                    localStorage.setItem("Message", JSON.stringify(nObject));
                }
                console.log("Property message");
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;
                console.log("Property message set");
                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    currentComponent.props.history.push({
                        pathname: '/lms/asset',
                        state: { spvID: nObject.spvID }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        }else if ((nObject.group).toLowerCase() == "invoice") {
            console.log(nObject)
            localStorage.setItem("NotifObj", JSON.stringify(nObject));
            //invoice approver grid
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                // this.setState({
                //     activeTabClassName: "Invoicing",
                // })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", "");
                    console.log('Approver set to true');
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to false');
                }
                console.log("Property message");
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;
                console.log("Property message set");
                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    currentComponent.props.history.push({
                        pathname: '/lms/invoiceListApprover',
                        state: { notificationData: nObject }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        }
         else if ((nObject.group).toLowerCase() == "lease" && (nObject.category).toLowerCase() == "document" || (nObject.category).toLowerCase() == "manage approval") {
            console.log('Under Lease');
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                this.setState({
                    activeTabClassName: "deals",
                })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to true');
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to false');
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;
                console.log("lease document");
                console.log(endPoint);
                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server lease notification");
                    console.log(response.data);
                    console.log(nObject.leaseContractID);
                    currentComponent.props.history.push({
                        pathname: '/lms/mainSummaryTabsPage',
                        state: { leaseContractId: nObject.leaseContractID }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        } else if ((nObject.group).toLowerCase() == "lease" && (nObject.category).toLowerCase() == "tlp") {
            console.log('Under Lease for TLP grid');
            localStorage.setItem("NotificationSelected", 'true');
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                // this.setState({
                //     activeTabClassName: "deals",
                // })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to true');
                } else {
                    localStorage.setItem("approver", 'false');
                    localStorage.setItem("Message", JSON.stringify(nObject));
                    console.log('Approver set to false');
                    if (nObject.status == "Approved") {
                        localStorage.setItem('approvalPending', 'Approved');
                    } else if (nObject.status == "Rejected") {
                        localStorage.setItem('approvalPending', 'Rejected');
                    }

                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;

                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server for tlp");
                    console.log(response.data);
                    console.log(localStorage.getItem('approvalPending'));
                    if (nObject.type == "Action") {
                        currentComponent.props.history.push({
                            pathname: '/lms/ApproveTLPGrid',
                            state: { rowID: nObject.partyID }
                        })
                    } else {
                        currentComponent.props.history.push({
                            pathname: '/lms/emptyTLPGrid',
                            state: { rowID: nObject.partyID }
                        })
                    }

                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        }
        else if ((nObject.group).toLowerCase() == "party" && (nObject.category).toLowerCase() == "general approval") {
            if (nObject.isActionCompleted == 1 && nObject.status == "Pending") { }
            else {
                this.setState({
                    activeTabClassName: "Customer",
                })
                if (nObject.type == "Action") {
                    localStorage.setItem("approver", 'true');
                } else {
                    localStorage.setItem("approver", 'false');
                }
                var currentComponent = this;
                let endPoint = API_ENDPOINT.LMS_NOTIFICATION + '/setReadFlag/1/' + nObject.notificationID;

                HttpPutWithoutBody(currentComponent, endPoint).then(function (response) {
                    console.log("Notification read response received from server");
                    console.log(response.data);
                    currentComponent.props.history.push({
                        pathname: '/lms/viewCustomerDetail',
                        state: { rowID: nObject.partyID }
                    })
                })
                    .catch(function (error) {
                        console.log("Error received");
                        console.log(error);
                    })
            }
        }
    }

    render() {
        let { name } = this.context;
        if (!name) {
            name = "Joe Doe";
        }
        const serverDown = localStorage.getItem('serverDown');
        // name = "Joe Doe";
        if (!name) {
            name = "Joe Doe";
        }
        console.log("get login details");
        console.log(name);
        return (
            (serverDown == 'true' ?
                <nav className="navbar navbar-inverse header_container">
                    <div className="header_top">
                        <div className="navbar-header header_up" style={{ marginBottom: '32px' }}>
                            <img src={logo} className="logo" />
                        </div>
                    </div>
                </nav>
                :
                <div>
                    <nav className="navbar navbar-inverse header_container">
                        <div className="header_top">
                            <div className="form-group row">
                                <div className="col-sm-7 navbar-header header_up">
                                    <img src={logo} className="logo" onClick={this.goHomePage.bind(this)} />
                                </div>
                                {!this.state.activeNotification && ECM_TOGGLE == 'false' ?
                                    <div>
                                        <div className="col-sm-2 userinfo" style={{ marginLeft: '70px', textAlign: 'right' }}>
                                            <div className="Notification_icon">
                                                <img src={NotificationIcon} />
                                                <div class="badge">{this.state.notificationCount != 0 ? this.state.notificationCount : null}</div>
                                            </div>
                                            <span className="username" onClick={this.openNotificationPanel.bind(this)}>Notifications</span>
                                        </div>
                                    </div> : null}
                                {this.state.activeNotification && ECM_TOGGLE == 'false' ?
                                    <div className="col-sm-2 notification_active" style={{ marginLeft: '158px' }}>
                                        <div>
                                            <div style={{
                                                margin: '12px 0px 0px auto'
                                            }}>
                                                <img src={AccountIcon} className />
                                                <label className="notification_select" onClick={this.openNotificationPanel.bind(this)}>Notifications</label>
                                            </div>
                                            <div className="notification_inner_container" style={{
                                                margin: '0',
                                                display: 'block',
                                                textAlign: 'center',
                                                marginTop: '12px'
                                            }}>
                                                {this.state.notificationdata.map((object, i) => (
                                                    (i < 5 ?
                                                        <button
                                                            className={"zb-feature-button " + (object.hasRead == 0 ? 'notification_container_btn' : 'notification_container_btn_read')}
                                                            onClick={this.readNotification.bind(this, object)}>
                                                            {object.hasRead == 0 ?
                                                                <div className="form-group row">
                                                                    <div className="col-sm-1" style={{ marginTop: '5px' }}>
                                                                        {object.status == "Pending" && object.isActionCompleted == 0 ? <Icon name="warning-small" size="small" title="" /> : null}
                                                                        {object.status == "Pending" && object.isActionCompleted == 1 ? <Icon name="warning-small" size="small" title="" style={{ opacity: '0.4' }} /> : null}
                                                                        {object.status == "Approved" ? <Icon name="confirmation-small" size="small" title="" /> : null}
                                                                        {object.status == "Rejected" ? <Icon name="error-small" size="small" title="" /> : null}
                                                                    </div>
                                                                    {object.isActionCompleted == 1 ? <div className="col-sm-10">
                                                                        <span className='zb-feature-button-arrowed-content text_property'
                                                                            style={{ fontWeight: 'bold', opacity: '0.4' }}> {object.description} </span>
                                                                    </div> : <div className="col-sm-10">
                                                                            <span className='zb-feature-button-arrowed-content text_property'
                                                                                style={{ fontWeight: 'bold' }}> {object.description} </span>
                                                                        </div>}
                                                                </div>
                                                                :
                                                                <div className="form-group row">
                                                                    <div className="col-sm-1" style={{ marginTop: '5px' }}>
                                                                        {object.status == "Pending" && object.isActionCompleted == 0 ? <Icon name="warning-small" size="small" title="" /> : null}
                                                                        {object.status == "Pending" && object.isActionCompleted == 1 ? <Icon name="warning-small" size="small" style={{ opacity: '0.4' }} title="" /> : null}
                                                                        {object.status == "Approved" ? <Icon name="confirmation-small" size="small" title="" /> : null}
                                                                        {object.status == "Rejected" ? <Icon name="error-small" size="small" title="" /> : null}
                                                                    </div>
                                                                    {object.isActionCompleted == 1 ? <div className="col-sm-10">
                                                                        <span className='zb-feature-button-arrowed-content text_property'
                                                                            style={{ fontWeight: 'bold', opacity: '0.4' }}> {object.description} </span>
                                                                    </div> : <div className="col-sm-10">
                                                                            <span className='zb-feature-button-arrowed-content text_property'
                                                                                style={{ fontWeight: 'bold' }}> {object.description} </span>
                                                                        </div>}
                                                                </div>
                                                            }
                                                            <div className="form-group row">
                                                                <div className="col-sm-1"></div>
                                                                <div className="col-sm-10" style={{
                                                                    marginTop: '-10px',
                                                                    marginBottom: '-13px'
                                                                }}>
                                                                    {object.status == "Pending" && object.isActionCompleted == 1 ?
                                                                        <label className="text_property" style={{ marginTop: '10px', color: '#666666', opacity: '0.4' }}>{moment(object.createdOn).format("YYYY-MM-DD HH:mm:ss")}</label>
                                                                        :
                                                                        <label className="text_property" style={{ marginTop: '10px', color: '#666666' }}>{moment(object.createdOn).format("YYYY-MM-DD HH:mm:ss")}</label>
                                                                    }
                                                                </div>
                                                            </div>
                                                        </button>
                                                        : null)
                                                ))}
                                                <div className="notification_line"></div>
                                                <div className="view_notification_panel" onClick={this.viewNotification.bind(this)}>
                                                    <label className="view_notifications">View all notifications</label>
                                                </div>
                                            </div>

                                        </div>
                                    </div> : null}
                                {/* className={"btn btn-primary interest_rate_yes " + (this.state.dealType ? 'dealtype_selected' : 'dealtype_notselected')} */}
                                {!this.state.activeUser ? <div className={(ECM_TOGGLE == 'false' ? 'userinfo' : 'userinfo_toggle')}
                                >
                                    <img src={AccountIcon} className />
                                    <span className="username" onClick={this.userClick.bind(this)}>{name}</span>
                                </div> : null}
                                {this.state.activeUser ? <div className={(ECM_TOGGLE == 'false' ? 'userinfo_active' : 'userinfo_active_toggle')}
                                >
                                    <div style={{
                                        margin: '0',
                                        display: 'block',
                                        textAlign: 'center',
                                        marginTop: '12px'
                                    }}>
                                        <img src={UserSelect} className />
                                        <span className="username_select" onClick={this.hideUserInfo.bind(this)}>{name}</span>
                                        <div className="user_inner_container">
                                            <div class="form-group row date_format_row">
                                                <label for="" class="col-sm-3 col-form-label date_format_type">Data format</label>
                                                <div className="col-sm-8">
                                                    <div class="dataFormatSelectBtn_grp">
                                                        <div class="btn-group">
                                                            <button type="button" className={"btn btn-primary selectBtn " + (this.state.dataFormat === 'sv' ? 'dataFormat_selected' : 'dataFormat_notselected')} onClick={this.toggleDataFormat.bind(this, 'sv')}>Swedish</button>
                                                            <button type="button" className={"btn btn-primary selectBtn " + (this.state.dataFormat === 'en-GB' ? 'dataFormat_selected' : 'dataFormat_notselected')} onClick={this.toggleDataFormat.bind(this, 'en-GB')} >UK</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {/* <div class="line_format"></div> */}
                                            <span className="tlp_grid_name" onClick={this.tlpGrid.bind(this)}>Current TLP Grid</span>
                                        </div>
                                    </div>
                                </div> : null}
                            </div>
                        </div>


                        <div className="line">
                            <hr className="header_line" />
                        </div>
                        <div className="container-fluid text_container">
                            <ul className="nav navbar-nav tab_name">
                                <li className={(this.state.activeTabClassName == "deals") ? "active" : ""} onClick={this.tabClick.bind(this, "deals")}><a href="#"><Link to="/lms/viewDealList">Deals</Link></a></li>
                                <li className={(this.state.activeTabClassName == "Customer") ? "active" : ""} onClick={this.tabClick.bind(this, "Customer")}><a href="#"><Link to="/lms/viewCustomerList">Customers</Link></a></li>
                                <li className={(this.state.activeTabClassName == "Asset") ? "active" : ""} onClick={this.tabClick.bind(this, "Asset")}><a href="#"><Link to="/lms/viewAssetDetail">Assets</Link></a></li>
                                <li className={(this.state.activeTabClassName == "Invoicing") ? "active" : ""} onClick={this.tabClick.bind(this, "Invoicing")}><a href="#"><Link to="/lms/invoiceList">Invoicing</Link></a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            )
        )
    }
}

function mapDispatchToProps(dispatch) {
    return {
        addNotification: article => dispatch(addNotification(article)),
        selectedDataFormat: article => dispatch(selectedDataFormat(article))
    };
}

const header = connect(null, mapDispatchToProps)(head);

export default withRouter(header)