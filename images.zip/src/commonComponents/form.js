import React from 'react';
import '../components/addCustomer/customer.css';
import Inputfield from '../commonComponents/inputField.js';
import Dropdown from '../commonComponents/dropdown.js';
import { Icon } from '@zambezi/sdk/icons';

class form extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    generateData(type) {
        const data = [];
        if (type == "country") {
            data.push(
                "",
                "Denmark",
                "Finland",
                "Norway",
                "Sweden"
            );
        }

        return data
    }

    render() {
        return (
            <form class="form_content">
                <label class="col-xs-5 label_title" style={{
                    fontSize: '16px',
                    marginLeft: '141px'
                }}>Contact {this.props.name}</label>

                <div className="col-xs-3" style={{ marginTop: '25px', marginLeft: '-9px' }} >
                    <Icon name="trash-small" size="small" title=""/><span style={{ marginLeft: '5px', position: 'absolute' }}>Remove Contact</span>
                </div>

                <Inputfield fieldTitle="Contact name" id={"input" + this.props.name} mandateField={this.props.mandateField}
                    value={this.props.contactNameValue} inputType="text" name={"contactname" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={ this.props.nameStatus } errorMessage={ this.props.nameMessage} />
                <Inputfield fieldTitle="Contact role" mandateField={ this.props.mandateField } value={ this.props.contactRoleValue } inputType="text" name={"contactrole" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.roleStatus} errorMessage={this.props.roleMessage} />
                <Inputfield fieldTitle="Office number" mandateField={this.props.mandateField} value={this.props.contactOfficeValue} inputType="number" name={"officename" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.officeStatus} errorMessage={this.props.officeMessage} />
                <Inputfield fieldTitle="Mobile number" mandateField={this.props.mandateField} value={this.props.contactMobileValue} inputType="number" name={"mobilenumber" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.mobileStatus} errorMessage={this.props.mobileMessage} />
                <Inputfield fieldTitle="Email address" mandateField={this.props.mandateField} value={this.props.contactEmailValue} inputType="text" name={"email" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.emailStatus} errorMessage={this.props.emailMessage} />
                <Inputfield fieldTitle="Address line 1" value={this.props.contactAddress1Value} inputType="text" name={"addressline1" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.addressStatus} errorMessage={this.props.addressMessage} />
                <Inputfield fieldTitle="Address line 2" value={this.props.contactAddress2Value} inputType="text" name={"addressline2" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" />
                <Inputfield fieldTitle="City" id={"city" + this.props.name} mandateField={this.props.mandateField} value={this.props.contactNameValue} inputType="text" name={"city" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.nameStatus} errorMessage={this.props.nameMessage} />
                <Inputfield fieldTitle="Postcode" value={this.props.contactPostcodeValue} inputType="number" name={"postcode" + this.props.name} onChange={this.props.onChange}
                    placeholder="Enter" errorStatus={this.props.postStatus} errorMessage={this.props.postcodeMessage} />
                
                <Dropdown title="Country" classname="font_config_custom" data={this.generateData('country')} errorStatus={false} onChange={this.props.onChange} />
            </form>
        )
    }

}

export default form;