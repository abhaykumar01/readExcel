import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from './pagination.js';
import UserData from './ApiData.js';
import matchSorter from 'match-sorter'
import { HttpPost, HttpGet, HttpPut, HttpDelete, HttpDownloadFile } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import DatePicker from '@zambezi/sdk/date-picker';
import { Select, DropdownList } from '@zambezi/sdk/dropdown-list';
import { docRetrieveData } from '../commonComponents/TLPGridStructure';
import { Nav, NavItem, NavMenu, NavMenuGroup, NavMenuItem, NavSubMenu } from '@zambezi/sdk/nav';
import { createNotification, deleteDocument, updateNotification, submitRequest } from '../models/dataModel';
import { object } from 'prop-types';
import { connect } from "react-redux";
import { Notification } from '@zambezi/sdk/notification';

// const rawData = getPartyCustomer();

class approverLeaseDocument extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "5",
            customerRecord: [],
            loading: false,
            selected: null,
            documentRecord: {},
            expanded: {},
            selectedDoc: '',
            selectedDocID: 0,
            docDeleteRequest: false,
            requestedDocDeleted: [],
            rangeStartDate: '',
            rangeEndDate: '',
            showDateRange: false,
            dateFilterApply: true,
            selectedClass: '',
            pendingCount: 0,
            rejectReasonText: '',
            selectedDocData: null,
            notificationData: [],
        }
        this.renderDocName = this.renderDocName.bind(this);
    }

    componentDidMount() {
        this.getDocuments();
    }

    componentWillReceiveProps(newProps) {
        this.setState({ notificationData: newProps.notifications });
    }

    componentDidUpdate(newProps) { 
    }

    getDocuments() {
        let output = [];
        this.setState({ loading: true })
        var currentComponent = this;
        //var id = parseInt(localStorage.getItem('leaseContractId'));
        var  id = 1;
        let endPoint = API_ENDPOINT.LEASE_DOCUMENT + '/' + id;


        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            console.log("response received from service1");
            console.log(response.data);//documentMediaType
            currentComponent.setState({ documentRecord: response.data });
            for (var i = 0; i < response.data.length; i++) {
                var obj = new Date(response.data[i].createdOn);
                let time = moment(obj).format('DD/MM/YYYY');
                if (response.data[i].isflaggedForDeletion == 1) {
                    var joined = currentComponent.state.requestedDocDeleted.concat(response.data[i].documentId);
                    currentComponent.setState({
                        requestedDocDeleted: joined,
                    })
                }

                // time = time.toUpperCase();
                var img_class_obj = '';
                var img_name = '';
                let mediaType = response.data[i].documentMediaType.toLowerCase();
                if (mediaType == 'pdf') {
                    img_class_obj = 'pdf_img';
                    img_name = 'PDF';
                } else if (mediaType == 'doc') {
                    img_class_obj = 'doc_img';
                    img_name = 'W'
                } else if (mediaType == 'png') {
                    img_class_obj = 'png_img';
                    img_name = 'PNG'
                } else if (mediaType == 'jpg') {
                    img_class_obj = 'jpg_img';
                    img_name = 'JPG'
                } else if (mediaType == 'excel' || mediaType == 'xls') {
                    img_class_obj = 'xcel_img';
                    img_name = 'X'
                } else if (mediaType == 'txt') {
                    img_class_obj = 'msg_img';
                    img_name = ''
                } else if (mediaType == 'msg') {
                    img_class_obj = 'msg_img';
                    img_name = 'MSG'
                } else if (mediaType == 'ppt') {
                    img_class_obj = 'ppt_img';
                    img_name = 'PPT'
                }
                output.push({
                    name: response.data[i].documentName,
                    description: response.data[i].documentDescription,
                    uploadedBy: response.data[i].uploadedUser,
                    created: time,
                    ID: response.data[i].documentId,
                    img_name: img_name,
                    imgClass: img_class_obj,
                    date: response.data[i].createdOn,
                    docData: response.data[i],
                    ecmDocID: response.data[i].ecmDocumentId,
                });
            }
            currentComponent.setState({
                customerRecord: output,
                pendingCount: currentComponent.state.requestedDocDeleted.length,
                loading: false
            }, function () {
                currentComponent.props.pendingCount(this.state.pendingCount);
            });
            //  return output;
        })
            .catch(function (error) {
                currentComponent.setState({ loading: false })
            })
    }

    getNotificationID(docID) { 
        let count = this.state.notificationData.length;
        let data = this.state.notificationData;
        for (var i = 0; i < count; i++) { 
            if (data[i].leaseDocumentID == docID && data[i].status == "Pending") { 
                return data[i].notificationID;
            }
        }
    }

    documenttDeletion() {
        let ID = localStorage.getItem('selectDocID');
       
        let notificationID = this.getNotificationID(ID);
        let partyID = parseInt(localStorage.getItem('userID'));
        var currentComponent = this;
        // let endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/customer/' + notificationID;
        let endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/lease/' + notificationID;
        let deletePayLoadData = deleteDocument(this.state.selectedDocData);
        console.log("endPoint:: ");
        console.log(endPoint);
        let output1 = HttpDelete(currentComponent, deletePayLoadData, endPoint).then(function (response) {
            console.log("delete document Response received from server");
            console.log(response.data);
            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                    this.props.deletionStatus(
                        currentComponent.state.requestedDocDeleted.length, this.state.selectedDoc, this.props.userData.partyName);
                });
            }
        })
            .catch(function (error) {
            })
    }

    getRejectionReason(value) {
        this.setState({ rejectReasonText: value });
    }

    rejectDocuemntDeletion() {
        let ID = localStorage.getItem('selectDocID');

        let notificationID = this.getNotificationID(ID);
        let partyID = parseInt(localStorage.getItem('userID'));
        var currentComponent = this;
        var reason = this.state.rejectReasonText;
        if (!reason) { 
            reason = null;
        }
        let endPoint = API_ENDPOINT.ECM_REJECT_DELETION_REQUEST + '/0/0/' + ID + '/' + reason;
        let docName = this.state.selectedDoc;
        let partyName = localStorage.getItem('username');
        let payLoadData = submitRequest(parseInt(ID), docName, notificationID, partyID, partyName, reason);
    
        let output1 = HttpPut(payLoadData, endPoint).then(function (response) {
            var array = [...currentComponent.state.requestedDocDeleted]; // make a separate copy of the array
            var index = array.indexOf(parseInt(ID))
            if (index !== -1) {
                array.splice(index, 1);
                currentComponent.setState({ requestedDocDeleted: array }, function () {
                });
            }
            currentComponent.props.rejectStatus(currentComponent.state.selectedDoc);
        })
            .catch(function (error) {
            })
    }

    downloadDocument(dName, dID) {
        var currentComponent = this;
        let name = dName.replace(/\s/g, '');
        let endPoint = API_ENDPOINT.LMS_ECM + '/' + dID + '/' + name;
        let output1 = HttpDownloadFile(currentComponent, endPoint).then(function (response) {
            console.log("Download document Response received from server");
            console.log(response);
            // console.log(response.data);
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', dName); //or any other extension
            document.body.appendChild(link);
            link.click();
        })
            .catch(function (error) {
            })
    }

    setDocName(name, ID, data) {
        this.setState({
            selectedDoc: name,
            selectedDocData: data
        });
        localStorage.setItem('selectDocID', ID);
    }

    getRangeStartDate(e) {
        this.setState({ rangeStartDate: e });
        if (e != "" && this.state.rangeEndDate != "") {
            this.setState({ dateFilterApply: false });
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getInputRangeStartDate(value) {
        this.setState({ rangeStartDate: value });
        if (value != "" && this.state.rangeEndDate != "") {
            this.setState({ dateFilterApply: false });
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getInputRangeEndDate(value) {
        this.setState({ rangeEndDate: value });
        if (value != "" && this.state.rangeStartDate != "") {
            this.setState({ dateFilterApply: false });
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getRangeEndDate(e) {
        this.setState({ rangeEndDate: e });
        if (e != "" && this.state.rangeStartDate != "") {
            this.setState({ dateFilterApply: false });
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getRangeData() {
        // this.setState({ filtered: [] })
        this.setState({ showDateRange: false });
    }

    setRangeData(e) {
        this.setState({ filtered: { id: e.filtered[0].id, value: e.filtered[0].value } });
    }

    expand_row(row) {
        var expanded = { ...this.state.expanded };
        if (row) {
            if (expanded[row.index]) {
                expanded[row.index] = !expanded[row.index];
            } else {
                expanded[row.index] = true;
            }
        }

        this.setState({
            expanded: expanded
        }, function () {
            this.forceUpdate();
        });

    }

    renderDocName(cellInfo) {
        return (
            <div className="form-group row ">
                <div className="col-sm-1">
                    <div className={cellInfo.original.imgClass}><label style={{
                        color: '#fff',
                        fontSize: '8px',
                        marginTop: '-9px',
                        // position: 'absolute',
                        verticalAlign: 'middle'
                    }}>{cellInfo.original.img_name}</label></div>
                </div>
                <div className="col-sm-2">
                    <span style={{ marginLeft: '-13px' }}>{cellInfo.original.name}</span>
                </div>
            </div>
        );
    }

    generateData(type) {
        const data = [];
        if (type == "date") {
            data.push(
                "All",
                "Today",
                "This week",
                "This month",
                "Last month",
                "Last 3 months",
                "Date range"
            );
        }

        return data
    }

    getWeekDates() {
        let now = new Date();
        let dayOfWeek = now.getDay(); //0-6
        let numDay = now.getDate();
        let start = new Date(now); //copy
        start.setDate(numDay - dayOfWeek);
        start.setHours(0, 0, 0, 0);
        let end = new Date(now); //copy
        end.setDate(numDay + (7 - dayOfWeek));
        end.setHours(0, 0, 0, 0);
        return [start, end];
    }
    getCurrentMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        var firstDay = new Date(y, m, 1);
        var lastDay = new Date(y, m + 1, 0);
        return [firstDay, lastDay];
    }
    getLastMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 1;
        var firstDay = new Date(y, m, 1);
        var lastDay = new Date(y, m + 1, 0);
        return [firstDay, lastDay];
    }
    getLastThreeMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 3;
        var lastDay = moment(date).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        date.setMonth(date.getMonth() - 3);
        var firstDay = moment(date).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        console.log("First day:: ", firstDay);
        console.log("Last day::: ", lastDay);
        return [firstDay, lastDay];
    }
    cancelDateFilter() {
        this.setState({
            showDateRange: false,
            rangeStartDate: "",
            rangeEndDate: ""
        }, function () {
            this.forceUpdate();
        });
    }
    render() {
        const columns = [{
            id: 'cname',
            Header: <div style={{
                textAlign: 'left',
                // marginLeft: '20px',
                color: '#AD1982',
                textDecoration: 'underline',

            }}>Document name
                {/* <span class="table_columnprop">Document name</span> */}
            </div>,
            accessor: 'name', // String-based value accessors!
            headerClassName: 'theader_docname',
            filterable: true,
            Cell: this.renderDocName,
            filterMethod: (filter, rows) =>
                matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'cname'}] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search" style={{ marginLeft: '-16px' }}>
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            marginLeft: '170px'
                        }} />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
            width: 450,
            className: 'docheader'
            // filterable: false
        }, {
            id: 'description',
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '16px',
            }}>Description</div>,
            accessor: 'description',
            headerClassName: 'theader',
            // expander: true,
            sortable: false,
                className: 'des_cell',
            filterMethod: (filter, rows) =>
                matchSorter(rows, filter.value, { keys: ["description"] }),
            filterAll: true,
            filterable: true,
            width: 350,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search">
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            marginLeft: '120px'
                        }} />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
            // Filter: ({ filter, onChange }) => (
            //     <div class="form-group col-xs-12 view_search">
            //         <div class="inner-addon right-addon table_input_search">
            //             <Icon name="calendar-small" size='small' style={{
            //                 marginTop: '5px',
            //                 position: 'absolute',
            //                 marginLeft: '55px'
            //             }} />
            //             <input type="text"
            //                 onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
            //                 value={filter ? filter.value : ''}
            //                 style={{
            //                     width: '100%',
            //                 }} />
            //         </div>
            //     </div>
            // ),

        }, {
            id: 'uploadedBy', // Required because our accessor is not a string
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '20px'
            }}><span class="table_columnprop">Uploaded by</span><Icon name="sort-down-xsmall" style={{ marginLeft: '10px'}}/></div>,
            accessor: 'uploadedBy',//d => d.friend.name // Custom value accessors!
            headerClassName: 'theader',
            filterable: true,
            sortable: true,
            filterMethod: (filter, rows) =>
                matchSorter(rows, filter.value, { keys: ["uploadedBy"] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search">
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            marginLeft: '46px',
                        }} />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
        }, {
            id: 'cdate',
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '20px'
            }}><span class="table_columnprop">Uploaded on</span><Icon name="sort-down-xsmall" style={{ marginLeft: '10px' }} /></div>,//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'created',
            headerClassName: 'theader_date',
            filterable: true,
            // sortable: false,
            filterMethod: (filter, row) => {
                if (typeof (filter.value) == 'object' && !this.state.showDateRange) {
                    filter.value = "All"
                }
                if (filter.value === "All") {
                    return true;
                }
                if (filter.value === "Today") {
                    var today = new Date();
                    var date = moment(today).format('DD/MM/YYYY')
                    return row[filter.id] == date;
                }
                if (filter.value === "This week") {
                    let [start, end] = this.getWeekDates();
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    return isAfter == true && isBefore == false;
                }
                if (filter.value === "This month") {
                    let [start, end] = this.getCurrentMonth();
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    return isAfter == true && isBefore == false;
                }
                if (filter.value === "This week") {
                    let [start, end] = this.getWeekDates();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "This month") {
                    let [start, end] = this.getCurrentMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Last month") {
                    let [start, end] = this.getLastMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Last 3 months") {
                    let [start, end] = this.getLastThreeMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Date range") {
                    this.setState({
                        showDateRange: true,
                        rangeStartDate: "",
                        rangeEndDate: ""
                    });
                    return row[filter.id] == filter.value;
                }
                if (typeof (filter.value) == 'object' && this.state.showDateRange) {
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(this.state.rangeStartDate).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(this.state.rangeEndDate);
                    var isBefore = moment(row._original.date).isAfter(this.state.rangeStartDate);
                    var isSameEnd = moment(this.state.rangeEndDate).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }


            },
            // Custom cell components!
            Filter: ({ filter, onChange }) =>
                //  date = moment(event).format('DD/MM/YYYY')
                <div>
                    {!this.state.showDateRange ?
                        <Select
                            defaultValue='All'
                            suggestions={this.generateData('date')}
                            className='dropdown_date_selection'
                            isError={false}
                            value={filter ? filter.value : "All"}
                            onChange={(event, { value, method }) => onChange(value)}
                        />
                        : null}

                    {this.state.showDateRange ?
                        <div>
                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                        From
                                                        </label>
                                    <div className="col-sm-4" style={{ marginLeft: '10px' }}>
                                        <DatePicker
                                            date={this.state.rangeEndDate}
                                            keepDateInRange
                                            onChange={this.getRangeEndDate}
                                            onUserChange={this.getInputRangeEndDate}
                                            placeholder='DD/MM/YYYY'
                                            error={this.state.startDateError}
                                            dateFormat='DD/MM/YYYY'
                                        />
                                    </div>

                                </div>
                            </div>

                            {this.state.startDateError ? <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                    </label>
                                    <div className="col-sm-4" style={{ marginLeft: '38px', width: '429px' }}>
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            <span>The ‘From’ date must occur before the ‘To’ date.</span>
                                        </Notification>
                                    </div>

                                </div>
                            </div> : null}
                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property">
                                        To
                                                        </label>
                                    <div className="col-sm-4" style={{ marginLeft: '10px' }}>
                                        <DatePicker
                                            date={this.state.rangeStartDate}
                                            keepDateInRange
                                            onChange={this.getRangeStartDate}
                                            onUserChange={this.getInputRangeStartDate}
                                            placeholder='DD/MM/YYYY'
                                            error={this.state.endDateError}
                                            dateFormat='DD/MM/YYYY'
                                        />
                                    </div>

                                </div>
                            </div>

                            {this.state.endDateError ? <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                    </label>
                                    <div className="col-sm-4" style={{ marginLeft: '38px', width: '429px' }}>
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            <span>The ‘To’ date must occur after the ‘From’ date.</span>
                                        </Notification>
                                    </div>

                                </div>
                            </div> : null}


                            <div className="form-group row">
                                <div className="col-sm-12 ">

                                    {/* <div className="col-sm-1"> */}
                                    <button type="button" style={{
                                        minWidth: '50px',
                                        width: '85px',
                                        marginLeft: '15px',
                                    }} id="Apply" disabled={this.state.dateFilterApply}
                                        class="zb-button zb-button-primary" onClick={event => onChange(event)}>
                                        Apply
                                                </button>
                                    {/* </div> */}
                                    {/* <div className="col-sm-1"> */}
                                    <button type="button" style={{
                                        minWidth: '50px',
                                        width: '85px',
                                        marginLeft: '5px',
                                    }} id="Cancel" class="zb-button zb-button-primary"
                                        onClick={this.cancelDateFilter.bind(this)}>
                                        Cancel
                                                </button>
                                    {/* </div> */}
                                </div>
                            </div>
                        </div> : null}


                </div>
            ,
            Cell: props => <span style={{ marginLeft: '10px' }}>{props.value}</span>,
        }]



        return (
            <div>
                <ReactTable
                    data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
                    columns={columns}
                    loading={this.state.loading}
                    showPagination={true}
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    showPageSizeOptions={true}
                    className='documentdata'
                    expanded={this.state.expanded}
                    // pivotBy={["cname", "description"]}
                    // style = {"border: 1px solid blue"}

                    // headerClassName= 'theader'
                    // pageSizeOptions = {[5, 10, 20, 25, 50, 100]}
                    defaultPageSize={10}
                    pageSize={this.props.selectedRecord}
                    PaginationComponent={Pagination}
                    onFilteredChange={undefined}
                    defaultSortDesc={false}
                    // onFilteredChange={(filtered, column) => {... }
                    previousText='Previous'
                    nextText='Next'
                    loadingText='Loading...'
                    noDataText='No rows found'
                    pageText='Page'
                    ofText='of'
                    rowsText='rows'
                    filterable
                    defaultFilterMethod={(filter, row) =>
                        String(row[filter.id]) === filter.value}
                    // filtered={this.state.filtered}
                    // onFilteredChange={filtered => { this.setState({ filtered }) }}
                    // onFilteredChange={filtered => this.setRangeData({ filtered })}
                    getTrProps={(state, rowInfo) => {

                        if (rowInfo && rowInfo.row) {
                            return {
                                onClick: (e) => {
                                    this.state.selected = rowInfo.index;
                                },
                                style: {
                                    background: rowInfo.index == this.state.selected ? (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'rgb(77,170,233, 0.1)')
                                        : (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'white'),
                                    color: rowInfo.index === this.state.selected ? '#000000' : 'black'
                                }
                            }
                        } else {
                            return {}
                        }
                    }}
                    getTdProps={(state, rowInfo, column, instance) => {
                        return {
                            onClick: (e, handleOriginal) => {
                                this.expand_row(rowInfo);
                                if (handleOriginal) {
                                    handleOriginal()
                                }
                            },
                            style: {
                                textAlign: 'left',
                                marginLeft: '8px'
                            }
                        }
                    }}
                    SubComponent={({ row, nestingPath, toggleRowSubComponent }) => {
                        localStorage.setItem('selectDocID', row._original.ID);
                        // this.setState({selectedDoc: row.cname})
                        return (
                            <div className={this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ? 'deleted_row_style' : 'selected_row_style'}>
                                <div className="expand_doc_row">
                                    {this.state.documentRecord[row._index].documentDescription}<br></br>
                                    <label className="expand_doc_row_detail">RBS classification</label>
                                    <span className="expand_doc_row_value">
                                        {this.state.documentRecord[row._index].documentClassification}
                                    </span><br></br>
                                    <label className="expand_doc_row_detail">RBS record class code</label>
                                    <span className="expand_doc_row_value">
                                        {this.state.documentRecord[row._index].recordClassCode}
                                    </span><br></br>
                                    <label className="expand_doc_row_detail">High risk record</label>
                                    <span className="expand_doc_row_value">
                                        {this.state.documentRecord[row._index].highRiskRecord}
                                    </span><br></br>
                                    {this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ?
                                        <div className="delete_doc_warning">
                                            <div style={{
                                                marginTop: '10px',
                                                marginLeft: '20px'
                                            }}>
                                                <Icon name="warning-small" size="small" />
                                                <label className="text_property" style={{ marginLeft: '10px', position: 'absolute' }}>
                                                    {this.props.userData.partyName} requested to delete this document on {this.state.customerRecord[row._index].created}.
                                    </label>
                                            </div>
                                        </div>
                                        : null}
                                </div>

                                <div className="expand_line"></div>

                                {this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ? 
                                    <div className="form-group row" style={{ 
                                        marginTop: '10px',
                                        marginLeft: '36px'
                                    }}>
                                        <div className="col-sm-3">
                                            <div className='zb-button zb-button-primary approval_btn'
                                                data-toggle="modal" data-target="#approvedelete"
                                                style={{ width: '246px' }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                                Approve deletion request
                                                </div>

                                        </div>
                                        <div className="col-sm-2 ">
                                            <div className='zb-button zb-button-secondary update_save_btn'
                                                data-toggle="modal" data-target="#rejectDelete"
                                                style={{
                                                    width: '246px',
                                                    marginLeft: '-36px'
                                                }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>Reject deletion request</div>
                                            {/* <button type="button" class="btn btn-default update_save_btn" data-toggle="modal" data-target="#myModal" disabled={this.state.buttonSave}>Save updates</button> */}
                                        </div>
                                        <div className="col-sm-1" style={{ marginTop: '-5px' }}>
                                            <Icon name="download-small" size="small" style={{ marginTop: '16px' }} />
                                        </div>
                                        <div className="col-sm-2" style={{ marginLeft: '-24px', marginTop: '-5px' }}>
                                            <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                        </div>
                                    </div>
                                    
                                 : null}

                                <div id="approvedelete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Approve deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to approve deletion request for <br></br>
                                                    {this.state.selectedDoc}</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.documenttDeletion.bind(this)}
                                                    style={{ width: '218px'}}>Yes, approve deletion</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div id="rejectDelete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Reject deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">
                                                    Are you sure you want to reject deletion request for <br></br>
                                                    {this.state.selectedDoc}
                                                </p>

                                                <div className="form-group row" style={{ marginTop: '50px'}}>
                                                    <div className="col-sm-8">
                                                        <span className="header_body" style={{ color: '#666666' }}>
                                                            Provide a reason for rejecting (optional)
                                                            </span>
                                                    </div>
                                                    <div className="col-sm-4" style={{ marginLeft: '-25px'}}>
                                                        <span className="header_body" style={{ color: '#666666' }}>
                                                            max 255 characters
                                                            </span>
                                                    </div>
                                                </div>

                                                <div className="form-group row">
                                                    <div className="col-sm-9">
                                                        <input type="text" val={this.state.rejectReasonText}
                                                            onChange={e => this.getRejectionReason(e.target.value)}
                                                            className="reason_input" placeholder="Input text here..." />

                                                    </div>

                                                </div>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn'
                                                    data-dismiss="modal" onClick={this.rejectDocuemntDeletion.bind(this)}
                                                    style={{ width: '218px' }}>Yes, reject deletion</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn'
                                                    data-dismiss="modal"
                                                    style={{ width: '218px' }}>Cancel</button>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                {/* <div id="cancelDelete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss='modal'>&times;</button>
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Cancel deletion request</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to cancel deletion request for <br></br>
                                                    {this.state.selectedDoc}</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn cancel_doc_btn'
                                                    data-dismiss="modal" onClick={this.rejectDocuemntDeletion.bind(this)}>
                                                    Yes, cancel deletion
                                        </button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn cancel_doc_btn'
                                                    data-dismiss="modal">No, don’t cancel deletion
                                        </button>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                             */}
                            
                            </div>
                        );
                    }}
                />


            </div>
        )
    }
}

const mapStateToProps = state => {
    return { notifications: state.user };
};

// export default withRouter(approverDocumentGrid);

const approverLeaseDocumentGrid = connect(mapStateToProps)(approverLeaseDocument);

export default withRouter(approverLeaseDocumentGrid)