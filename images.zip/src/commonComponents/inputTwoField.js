import React from 'react';
import help from '../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import { Notification } from '@zambezi/sdk/notification';

const inputTwoField = ({customClass, fieldTitle, helpIcon,customClass2,id2, id,FieldUOM, helpIconValue,
     helpID, value, value2, inputType,inputType2, name,name2, onChange,onChange2, placeholder,placeholder2,
     errorStatus2,errorStatus, errorMessage2,errorMessage, mandateField }) => {
    return (
        <div className="form-group row">
        <label className="col-sm-4 col-form-label field_label_model">{fieldTitle}{helpIcon ? 
                <FlyoutTrigger
                    showOn='hover'
                    position='bottom'
                    flyout={
                        <Flyout>
                            {helpIconValue}
                        </Flyout>
                    }>
                    <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                </FlyoutTrigger>
            : null}</label>   
            <div className="col-sm-3">
                <input type={inputType} value={value} name={name} id={id} onChange={onChange} 
                className={"form-control"+" "+customClass+""  + (errorStatus ? 'error_message' : '')} 
                placeholder={placeholder} />
                
                {/* {errorStatus ? (<div className="error_message">{errorMessage}</div>) : null} */}
            </div>
            <div className="col-sm-1 inputFieldLeft">%</div>
            <div>
                {
                    errorStatus ?
                <div className="form-group row">
                <label className="col-sm-4 col-form-label field_label_model" style={{marginLeft: '35px'}}></label>
                <div className="col-sm-6" style= {{marginTop:'10px'}}>
                            <Notification 
                                status='error'
                                size='small'
                                withArrow
                                arrowPosition='14px'
                                className="error_notification"
                            >
                                {errorMessage} 
                            </Notification>
                        </div>
                    </div>
                     : null
                }
            </div>
            <div  className="col-sm-3">
            <input type={inputType2} value={value2} name={name2} id={id2} onChange={onChange2} 
                className={"form-control"+" "+customClass2+""  + (errorStatus2 ? 'error_message' : '')} 
                placeholder={placeholder2} />
            </div>
            <div className="col-sm-1 inputFieldRight">%</div>
            <div>
                {
                    errorStatus2 ?
                <div className="form-group row">
                <label className="col-sm-4 col-form-label field_label_model" style={{marginLeft: '35px'}}></label>
                <div className="col-sm-6" style= {{marginTop:'10px'}}>
                            <Notification 
                                status='error'
                                size='small'
                                withArrow
                                arrowPosition='14px'
                                className="error_notification"
                            >
                                {errorMessage2} 
                            </Notification>
                        </div>
                    </div>
                     : null
                }
            </div>
        </div>
    );
};

// {mandateField?(<span>*</span>):null}



export default inputTwoField