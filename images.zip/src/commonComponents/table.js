
import React from 'react';

class table extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // selectedFile: null
        }
    }

    render() {
        let customerType = "Primary";
        let creditrating = '';
        let creditrating1 = '';
        let creditrating2 = '';
        let creditrating3 = '';
        console.log("User data");
        console.log(this.props.userData);
        if (this.props.userData != undefined) { 
            if (this.props.userData.customerTypeID == 200) {
                customerType = "Primary";
            } else if (this.props.userData.customerTypeID == 201) {
                customerType = "Secondary";
            } else if (this.props.userData.customerTypeID == 202) {
                customerType = "Tenant";
            }
        }
       
        if (this.props.userData != undefined) {
            let len = 0;
             if (this.props.userData.partyCreditRatings) { 
                len = this.props.userData.partyCreditRatings.length;
             }
            if (this.props.userData.partyCreditRatings) { 
                if (len > 0) {
                    if (this.props.userData.partyCreditRatings[0].creditRating != "" && this.props.userData.partyCreditRatings[0].creditRating != null) {
                        creditrating1 = this.props.userData.partyCreditRatings[0].creditRating;
                    }
                    if (this.props.userData.partyCreditRatings[0].creditRatingSource != "" && this.props.userData.partyCreditRatings[0].creditRatingSource != null) {
                        creditrating1 += " / " + this.props.userData.partyCreditRatings[0].creditRatingSource;
                    }
                    if (this.props.userData.partyCreditRatings[0].ratingSourceWebpage != "" && this.props.userData.partyCreditRatings[0].ratingSourceWebpage != null) {
                        creditrating1 += " ( " + this.props.userData.partyCreditRatings[0].ratingSourceWebpage + " ) ";
                    }
                }

                if (len > 1) {
                    if (this.props.userData.partyCreditRatings[1].creditRating != "" && this.props.userData.partyCreditRatings[1].creditRating != null) {
                        creditrating2 = this.props.userData.partyCreditRatings[1].creditRating;
                    }
                    if (this.props.userData.partyCreditRatings[1].creditRatingSource != "" && this.props.userData.partyCreditRatings[1].creditRatingSource != null) {
                        creditrating2 += " / " + this.props.userData.partyCreditRatings[1].creditRatingSource;
                    }
                    if (this.props.userData.partyCreditRatings[1].ratingSourceWebpage != "" && this.props.userData.partyCreditRatings[1].ratingSourceWebpage != null) {
                        creditrating2 += " ( " + this.props.userData.partyCreditRatings[1].ratingSourceWebpage + " ) ";
                    }
                }

                if (len > 2) {
                    if (this.props.userData.partyCreditRatings[2].creditRating != "" && this.props.userData.partyCreditRatings[2].creditRating != null) {
                        creditrating3 = this.props.userData.partyCreditRatings[2].creditRating;
                    }
                    if (this.props.userData.partyCreditRatings[2].creditRatingSource != "" && this.props.userData.partyCreditRatings[2].creditRatingSource != null) {
                        creditrating3 += " / " + this.props.userData.partyCreditRatings[2].creditRatingSource;
                    }
                    if (this.props.userData.partyCreditRatings[2].ratingSourceWebpage != "" && this.props.userData.partyCreditRatings[2].ratingSourceWebpage != null) {
                        creditrating3 += " ( " + this.props.userData.partyCreditRatings[2].ratingSourceWebpage + " ) ";
                    }
                }
            }
        }
        
        return (
            <div className="row" style={{ margin: '0% 10% 2% 2%' }}>
                <div class="col-xs-12">
                    <label className="customer_detail_title">Company details</label>
                    <table className="customer_table">
                        <tbody>
                            <tr>
                                <td><label>Customer name</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.partyName : ''}</td>
                            </tr>
                            <tr>
                                <td><label>Customer type</label></td>
                                <td class="text-right">{customerType}</td>
                            </tr>
                            <tr>
                                <td><label>Customer sector/sub-sector</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.sector: ''}</td>
                            </tr>
                            <tr>
                                <td><label>Company type</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.companyType: ''}</td>
                            </tr>
                            <tr>
                            <td><label>Country</label></td>
                                 <td class="text-right">{this.props.userData ? 'Sweden': 'Sweden'}</td>  {/*this.props.userData.country: ''} */}
                            </tr>
                            <tr>
                                <td><label>CIS code</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.cisCode: ''}</td>
                            </tr>
                            <tr>
                                <td><label>Organisation number</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.organisationNo: ''}</td>
                            </tr>
                            <tr>
                            <td><label>Annual review date</label></td>
                                 <td class="text-right">{this.props.userData ? '30 June': ''}</td> {/*this.props.userData.organisationNo: ''} */}
                            </tr>
                            <tr>
                                <td><label>Credit rating 1</label></td>
                                <td class="text-right">{creditrating1}</td>
                            </tr>
                            <tr>
                                <td><label>Credit rating 2</label></td>
                                <td class="text-right">{creditrating2}</td>
                            </tr>
                            <tr>
                                <td><label>Credit rating 3</label></td>
                                <td class="text-right">{creditrating3}</td>
                            </tr>
                            <tr>
                                <td><label>MGS</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.masterGradingScale:''}</td>
                            </tr>
                            <tr>
                                <td><label>KYC status</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.kycStatus: ''}</td>
                            </tr>
                            <tr>
                                <td><label>Peers</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.competitors: ''}</td>
                            </tr>
                            <tr>
                                <td><label>Webpage</label></td>
                                <td class="text-right">{this.props.userData ? this.props.userData.webPageUrl: ''}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}
    
export default table;