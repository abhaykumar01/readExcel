import React from 'react';
import Modal from '@zambezi/sdk/modal'

class popupmessage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // selectedFile: null
        }
    }

    render() {
        return (
            <Modal
                title={this.props.headerTitle}
                className='popup_dialog_custom'
                open={this.props.openDialog}
                renderFooter={(onConfirm, onCancel) => {
                    return (
                        <div className="form-group row">
                            <div className="col-sm-12">
                                <div class="col-sm-6">
                                    <button className='zb-button zb-button-primary save_pop_btn' onClick={onConfirm}>{this.props.buttontext1}</button>
                                </div>
                                <div class="col-sm-6">
                                    <button className='zb-button zb-button-secondary cancel_pop_btn' onClick={onCancel}>{this.props.buttontext2}</button>
                                </div>
                            </div>
                        </div>
                    )
                }}
                onConfirm={() => {
                      this.props.onClick() 
                }}
                onCancel={() => {
                    this.props.toggleDialog()
                }}>
                {this.props.headerbody}
      </Modal>
            // <div id={this.props.datatarget} class="modal fade"
            //     className={"modal fade " + (this.props.openDialog ? 'showDialog' : 'closeDialog')}
            //     role="dialog">
            //     <div class="modal-dialog">
            //         <div class="modal-content">
            //             <div class="modal-header">
            //                 {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
            //                 <h4 class="modal-title header_title">{this.props.headerTitle}</h4>
            //             </div>
            //             <div class="modal-body">
            //                 <p className="header_body">{this.props.headerbody}</p>
            //             </div>
            //             <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '20px' }}>
            //                 <button className='zb-button zb-button-primary save_pop_btn' data-dismiss="modal" onClick={this.props.onClick}>{this.props.buttontext1}</button>
            //                 <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss='modal'>{this.props.buttontext2}</button>
            //                 {/* <button type="button" class="btn btn-default save_pop_btn" data-dismiss="modal" onClick={onClick}>{buttontext1}</button>
            //             <button type="button" class="btn btn-default cancel_pop_btn" data-dismiss="modal">{buttontext2}</button> */}
            //             </div>
            //         </div>

            //     </div>
            // </div>
        )
    }
}

export default popupmessage