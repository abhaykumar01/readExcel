import React from 'react';

class contactTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // selectedFile: null
        }
    }

    render() {
        let address = this.props.userContact.streetAddressLine1
        if (this.props.userContact.streetAddressLine2) { 
            address += ' ' + this.props.userContact.streetAddressLine2
        }
        // let address =  this.props.userContact.streetAddressLine1 + ' ' + this.props.userContact.streetAddressLine2;
        return (
            <div class="col-xs-6">
                <label className="contact_detail_title">Contact {this.props.index}</label>
                <table className="customer_contact">
                    <tbody style={{ lineHeight: '27px'}}>
                        <tr>
                            <td><label>Contact name</label></td>
                            <td class="text-right">{this.props.userContact.contactName}</td>
                        </tr>
                        <tr>
                            <td><label>Contact role</label></td>
                            <td class="text-right">{this.props.userContact.contactRole}</td>
                        </tr>
                        <tr>
                            <td><label>Office number</label></td>
                            <td class="text-right">{this.props.userContact.officeTelephoneNumber}</td>
                        </tr>
                        <tr>
                            <td><label>Mobile number</label></td>
                            <td class="text-right">{this.props.userContact.mobileTelephoneNumber}</td>
                        </tr>
                        <tr>
                            <td><label>Email address</label></td>
                            <td class="text-right">{this.props.userContact.businessEmailAddress}</td>
                        </tr>
                        <tr>
                            <td><label>Address</label></td>
                            <td class="text-right">{address}</td>
                        </tr>
                        <tr>
                            <td><label>City</label></td>
                            <td class="text-right">{this.props.userContact.cityName}</td>
                        </tr>
                        <tr>
                            <td><label>Postcode</label></td>
                            <td class="text-right">{this.props.userContact.postCode}</td>
                        </tr>
                        <tr>
                            <td><label>Country</label></td>
                            <td class="text-right">{this.props.userContact.countryName}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }
}

export default contactTable