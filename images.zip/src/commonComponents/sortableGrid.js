import React, {Component} from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from './pagination.js';
import matchSorter from 'match-sorter'
import { HttpGet } from '../services/api.js';
import { API_ENDPOINT } from '../config/config.js';
import moment from 'moment';
import { withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';

class SortableGridComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "5",
            customerRecord: [],
            loading: false,
            selected: null
        }
    }

    componentDidMount() {
        console.log("Component mount");
        let output = [];
        console.log("Call service");
        this.setState({ loading: true })
        var currentComponent = this;
        let endPoint = API_ENDPOINT.PARTY_PROCESS_LIST + '/0/50/partyID/';
        let output1 = HttpGet(currentComponent, endPoint).then( (response) => {
            console.log("response received from server");
            console.log(response.data);
            for (var i = 0; i < response.data.length; i++) {
                
                let userAddress = "";
                if (response.data[i].streetAddressLine1 != null) {
                    userAddress = response.data[i].streetAddressLine1;
                }
                if (response.data[i].streetAddressLine2 != null) {
                    userAddress += ' ' + response.data[i].streetAddressLine2;
                }
                // if (response.data[i].street_Address_Line_3 != null) {
                //     userAddress += response.data[i].street_Address_Line_3;
                // }
                var obj = new Date(response.data[i].createdOn);
                let time = moment(obj).format('DD-MM-YYYY');
                output.push({
                    name: response.data[i].partyName,
                    type: response.data[i].partyType,
                    address: userAddress,
                    status: response.data[i].partyStatus,
                    created: time,
                    ID: response.data[i].partyID
                });
            }

            this.setState({customerRecord: output});
            this.setState({ loading: false })
        }).catch( (error) => {
                this.setState({ loading: false })
                console.log("Error received", error);
            })
    }

    generateData(type) {
        console.log(type);
        const data = [];
        if (type == "customerType") {
            data.push(
                "All",
                "Customer",
                "Seller",
                "SPV"
            );
        }else if (type == "customerStatus") {
            data.push(
                "All",
                "Active",
                "Inactive",
                "Pending"
            );
        }
        return data
    }

    render() {
        console.log("Select record::  ");
        console.log(this.props.selectedRecord);
        const columns = [{
            id: 'cname',
            Header: props => <div><span className="table_nameprop">SPV Number</span><Icon name="chev-down-small" size="xsmall" className="arrow_down"/></div>,
            accessor: 'name', // String-based value accessors!
            headerClassName: 'theader',
            filterable: true,
            filterMethod: (filter, rows) =>
                matchSorter(rows, filter.value, { keys: ["cname"] }),
            filterAll: true,
             Filter: ({ filter, onChange }) => (
                 <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
                     <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                         <input type="text"
                             onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                             value={filter ? filter.value : ''}
                             style={{
                                 width: '100%',
                                 height: '44px'
                             }} />
                     </div>
                     <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                         <Icon name="search-small" size="small" />
                     </div>
                 </div>
            ),
            // filterable: false
        }, {
            id: 'ctype',
            Header: 'SPV Name',
            accessor: 'type',
            headerClassName: 'theader',
                sortable: false,
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "Customer") {
                        return row[filter.id] == 'Customer';
                    }
                    if (filter.value === "Seller") {
                        return row[filter.id] == 'Seller';
                    }
                    if (filter.value === "SPV") {
                        return row[filter.id] == 'SPV';
                    }
                },
                Filter: ({ filter, onChange }) =>
                      <Select
                        defaultValue='All'
                        suggestions={this.generateData('customerType')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
        }, {
                id: 'address', // Required because our accessor is not a string
                Header: 'Customer',
                accessor: 'address',//d => d.friend.name // Custom value accessors!
                headerClassName: 'theader',
                filterable: true,
                sortable: false,
                filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["address"] }),
                filterAll: true,
                Filter: ({ filter, onChange }) => (
                    <div className="form-group row view_search" style={{ marginLeft: '16px' }}>
                        <div className="col-sm-8 table_input_search" style={{ width: '95%' }}>
                            <input type="text"
                                onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                                value={filter ? filter.value : ''}
                                style={{
                                    width: '100%',
                                    height: '44px'
                                }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                ),
        }, {
            id: 'cstatus',
            Header: 'Book Value',//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'status',
            headerClassName: 'theader',
                sortable: false,
            Cell: row => (
            <div>
                    <span class ={
                        row.value === 'Pending'
                            ? 'glyphicon glyphicon-time pending'
                            : ''
                    }
                    ><span className={
                        row.value === 'Pending'
                            ? 'row_text'
                            : row.value === 'Inactive'
                                ? 'inactive'
                                : 'active'
                    }>{row.value}</span></span>
            </div>
            ),
                filterable: true,
                filterMethod: (filter, row) => {
                    if (filter.value === "All") {
                        return true;
                    }
                    if (filter.value === "Active") {
                        return row[filter.id] == 'Active';
                    }
                    if (filter.value === "Inactive") {
                        return row[filter.id] == 'Inactive';
                    }
                    if (filter.value === "Pending") {
                        return row[filter.id] == 'Pending';
                    }
                },
                Filter: ({ filter, onChange }) =>
                   
                    <Select
                        defaultValue='All'
                        suggestions={this.generateData('customerStatus')}
                        className='customerType_selection'
                        isError={false}
                        value={filter ? filter.value : "All"}
                        onChange={(event, { value, method }) => onChange(value)}
                    />
                
            
        }, {
                id: 'cdate',
                Header: 'Option Date',//props => <span>Friend Age</span>, // Custom header components!
                accessor: 'created',
                headerClassName: 'theader',
                filterable: true,
                // sortable: false,
                filterMethod: (filter, rows) =>
                    matchSorter(rows, filter.value, { keys: ["cdate"] }),
                filterAll: true,
                Filter: ({ filter, onChange }) => (
                    <div className="form-group view_search" style={{ marginLeft: '16px' }}>
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="date"
                                onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                                value={filter ? filter.value : ''}
                                style={{
                                    width: '100%',
                                    height: '44px'
                                }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="calendar-small" size="small" />
                        </div>
                    </div>
                ),
        }]

        return <ReactTable
            data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
            columns={columns}
            loading={this.state.loading}
            showPagination = {true}
            showPaginationTop = {false}
            showPaginationBottom = {true}
            showPageSizeOptions = {true}
            className= 'tabledata'
            // style = {"border: 1px solid blue"}
            
            
            // headerClassName= 'theader'
            // pageSizeOptions = {[5, 10, 20, 25, 50, 100]}
            defaultPageSize = {5}
            pageSize={this.props.selectedRecord}
            PaginationComponent={Pagination}
            onFilteredChange = {undefined}
            defaultSortDesc = {false}
            // onFilteredChange={(filtered, column) => {... }
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            noDataText= 'No rows found'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
            filterable
            defaultFilterMethod={(filter, row) =>
                String(row[filter.id]) === filter.value}
            getTrProps={(state, rowInfo) => {
                // console.log(state);
                
                if (rowInfo && rowInfo.row) {
                    return {
                        onClick: (e) => {
                            console.log(rowInfo.original.ID);
                            localStorage.setItem('datasave', 'false');
                            
                            this.setState({
                                selected: rowInfo.index
                            });
                            localStorage.setItem("Message", '');
                            this.props.history.push({
                                pathname: '/lms/viewCustomerDetail',
                                state: { rowID: rowInfo.original.ID }
                            })
                        },
                        style: {
                            background: rowInfo.index === this.state.selected ? '#009FAC' : 'white',
                            color: rowInfo.index === this.state.selected ? 'white' : 'black'
                        }
                    }
                } else {
                    return {}
                }
            }}            
        />
    }
}

export default withRouter(SortableGridComponent);