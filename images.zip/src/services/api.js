import React from 'react';
import axios from 'axios';
import { BASE_URL, API_TIMEOUT } from '../config/config.js';
import { transitions, positions, Provider as AlertProvider, useAlert } from 'react-alert'
import AlertTemplate from 'react-alert-template-basic'


// var AUTH_TOKEN, REQUEST_BODY;
// const alert = useAlert()
// alert(<div style={{ color: 'blue' }}>Some Message</div>)
export function HttpPost(currentcomp, body, apiendpoint) {

    var response = axios.post(BASE_URL + apiendpoint, body, {
        headers: {
            'Content-Type': "application/json",
        },
        timeout: API_TIMEOUT
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);
            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // console.log("API URL");
    // console.log(BASE_URL + apiendpoint);
    // return axios.post(BASE_URL + apiendpoint, body, {
    //     headers: {
    //         'Content-Type': "application/json",
    //     },
    //     timeout: API_TIMEOUT
    // })
}

export function HttpDownloadExcelFile(currentcomp, data, apiendpoint) {
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios.post(BASE_URL + apiendpoint, data, {
        headers: {
            'Content-Type': "application/json",
        },
        timeout: 80000000
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);

            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // console.log("API URL");
    // console.log(BASE_URL + apiendpoint);
    // return axios.post(BASE_URL + apiendpoint, data, {
    //     timeout: API_TIMEOUT
    // })
    
}

export function HttpPostDocuments(currentcomp, data, apiendpoint) {
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios.post(BASE_URL + apiendpoint, data, {
        timeout: API_TIMEOUT
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);

            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // console.log("API URL");
    // console.log(BASE_URL + apiendpoint);
    // return axios.post(BASE_URL + apiendpoint, data, {
    //     timeout: API_TIMEOUT
    // })
    
}

export function HttpGet(currentcomp, apiendpoint) {
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios.get(BASE_URL + apiendpoint, {
        timeout: API_TIMEOUT
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);
            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else { 
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }
                
            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else { 
            localStorage.setItem('serverDown', 'false');
        }
        
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage",  "Server is not responding");
            // currentcomp.props.history.push({
            //     pathname: '/lms/serverDown'
            // })
        })
    return response;
    
    // console.log("Http get URL");
    // console.log(BASE_URL + apiendpoint);
    // return axios.get(BASE_URL + apiendpoint, {
    //     timeout: API_TIMEOUT
    // });
}

export function HttpPut(currentcomp, body, apiendpoint) {
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios.put(BASE_URL + apiendpoint, body, {
        headers: {
            'Content-Type': "application/json;charset=UTF-8",
        },
        timeout: API_TIMEOUT
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);
            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // return axios.put(BASE_URL + apiendpoint, body, {
    //     headers: {
    //         'Content-Type': "application/json;charset=UTF-8",
    //     },
    //     timeout: API_TIMEOUT
    // })
}

export function HttpPutWithoutBody(currentcomp, apiendpoint) {
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios.put(BASE_URL + apiendpoint, {
        headers: {
            'Content-Type': "application/json;charset=UTF-8",
        },
        timeout: API_TIMEOUT
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);
            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // console.log("API URL");
    // console.log(BASE_URL + apiendpoint);
    // return axios.put(BASE_URL + apiendpoint, {
    //     headers: {
    //         'Content-Type': "application/json;charset=UTF-8",
    //     },
    //     timeout: API_TIMEOUT
    // })
}

export function HttpDelete(currentcomp, body, apiendpoint) {
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios.delete(
        BASE_URL + apiendpoint,
        {
            headers: {
                'Content-Type': "application/json;charset=UTF-8",
            },
            data: body
        }
    );
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);
            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // console.log(BASE_URL + apiendpoint);
    // return axios.delete(
    //     BASE_URL + apiendpoint,
    //     {
    //         headers: {
    //             'Content-Type': "application/json;charset=UTF-8",
    //         },
    //         data: body
    //     }
    // );
}

export function HttpDownloadFile(currentcomp, apiendpoint) { 
    console.log("Http get URL");
    console.log(BASE_URL + apiendpoint);
    var response = axios({
        url: BASE_URL + apiendpoint, //your url
        method: 'GET',
        responseType: 'blob', // important
    })
    console.log(response);
    response.then(function (res) {
        console.log("Success response from get service.");
        console.log(res);
        console.log(res.response);
        var resObj = JSON.stringify(res.response);
        console.log("Success response after service calling.");
        if (resObj) {
            var reverseJson = JSON.parse(resObj);
            console.log("Object not undefined.");
            console.log(reverseJson);
            console.log(reverseJson.data);
            console.log(reverseJson.status);
            if (reverseJson.status == 404) {
                console.log("inside 404 3")
                console.log(reverseJson.data);
                var data = reverseJson.data;
                if (reverseJson.data.indexOf('404 Not Found:') > -1) {
                    console.log("hello found inside your_string");
                    data = "LMS process is down.An auto alert has been raised and LMS App Management Team are working to resolve this issue.Please contact the LMS App Management Team if the error Persists.Service Desk CPBApplicationManagementNordiskRenting@rbos.co.uk"
                    alert(data);
                } else {
                    localStorage.setItem('serverDown', 'false');
                    localStorage.setItem("ServerErrorMessage", (reverseJson ? data : "Server is not responding"));
                    console.log("hello found outside your_string");
                    currentcomp.props.history.push({
                        pathname: '/lms/serverDown'
                    })
                }

            } else {
                localStorage.setItem('serverDown', 'false');
                alert(reverseJson ? reverseJson.statusText : "Server is not responding");
            }
        } else {
            localStorage.setItem('serverDown', 'false');
        }
    })
        .catch(function (error) {
            console.log("Error received21432412");
            console.log(error.response);
            localStorage.setItem('serverDown', 'false');
            localStorage.setItem("ServerErrorMessage", (error.response ? error.response.data : "Server is not responding"));
            currentcomp.props.history.push({
                pathname: '/lms/serverDown'
            })
        })
    return response;

    // return axios({
    //     url: BASE_URL + apiendpoint, //your url
    //     method: 'GET',
    //     responseType: 'blob', // important
    // })
}
