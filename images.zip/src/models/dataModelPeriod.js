import moment from 'moment';


function getformattedDate(date){
    var formattedDate = null;
    if(date !== null && date !== undefined){
        formattedDate = moment(date).format('YYYYMMDD')
    }
    return formattedDate;
};

export function RegisterForPeriod(leaseData){

    let invoicefeq = 1;
    if(leaseData.invoicing ==='Monthly') {
        invoicefeq = 12;
    } else if(leaseData.invoicing ==='Quarterly'){
        invoicefeq = 4;
    } else if(leaseData.invoicing ==='Semi-Annually'){
        invoicefeq = 2;
    } else if(leaseData.invoicing ==='Annually'){
        invoicefeq = 1;
    }

    return {
        'invoicingFrequency':invoicefeq,
        'leaseStartDate':getformattedDate(leaseData.leaseStartDate),
        'leaseEndDate':getformattedDate(leaseData.leaseEndDate),
        'tenor':leaseData.leaseTenure,
    };

}