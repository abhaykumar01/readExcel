import moment from 'moment';
import { Lease_Constants } from './LeaseConstants.js';

function getformattedDate(date){
    var formattedDate = null;
    if(date !== null && date !== undefined && date !== ''){
        formattedDate = moment(date).format('YYYYMMDD')
    }

    return formattedDate;
};

function removeCommas(str) {
    if(str != "" && str != null && str != undefined){
        while (str.search(",") >= 0) {
            str = (str + "").replace(',', '');
        }
        return str;
      }else{
        return str;
        }
};

export function RegisterLeaseModel(leaseData, isInvoicing) {

    let indexationVal = [];
    let interestRateVal = [];
    let optionVal = [];

    let dealTypeData = 'Standard';
    if(leaseData.dealType === false){
        dealTypeData = 'Construction';
    } 

    let paymentType = 'Arrears'
    if(leaseData.paymentterm ==="Advanced"){
        paymentType = 'Advance';
    }
    
    let turnover = leaseData.turnover;
    if(leaseData.turnover == '' || leaseData.turnover == undefined || leaseData.turnover == null){
        turnover = 0;
    }

    let invoicefeq = 1;
    if(leaseData.invoicing ==='Monthly') {
        invoicefeq = 12;
    } else if(leaseData.invoicing ==='Quarterly'){
        invoicefeq = 4;
    } else if(leaseData.invoicing ==='Semi-Annually'){
        invoicefeq = 2;
    } else if(leaseData.invoicing ==='Annually'){
        invoicefeq = 1;
    }

    var leaseId = '';
    var reqType = localStorage.getItem('DealRequestType');
        if(reqType == "EDIT_DEAL"){
            leaseId = leaseData.editContractid;
        }

    //Indexation 
    for (var i = 0; i < leaseData.indexasionStateval.length; i++) {
        let indexationTypevar = 'Fixed';
        if(leaseData.indexasionStateval[i].indexationType == false){
            indexationTypevar = 'CPI';
        }

        var indexId = '';
        if(reqType == "EDIT_DEAL"){
            indexId = leaseData.indexasionStateval[i].editIndexationId;
        }

        if(leaseData.indexasionStateval[i].indexationPercentage !== '' && 
            leaseData.indexasionStateval[i].indexationPercentage !== null && leaseData.indexasionStateval[i].indexationPercentage !== undefined){
                indexationVal.push({
                    'indexationId':indexId,
                    'leaseContractId':leaseId,
                    'indexationDate':getformattedDate(leaseData.indexasionStateval[i].indexationDate),
                    'floor':leaseData.indexasionStateval[i].floor,
                    'indexationPercentage':leaseData.indexasionStateval[i].indexationPercentage,
                    'indexationName':leaseData.indexasionStateval[i].indexationName,
                    'baseIndexName':leaseData.indexasionStateval[i].baseIndexName,
                    // 'baseIndexDate':getformattedDate(leaseData.indexasionStateval[i].baseIndexDate),
                    'baseIndexNumber':leaseData.indexasionStateval[i].baseIndexNumber,
                    'indexationScaling':leaseData.indexasionStateval[i].indexationScaling,
                    'indexationType':indexationTypevar,
                });
        }
        
    }

    // interest Rate
    for (var i = 0; i < leaseData.interestRtStateVal.length; i++) {

        var interestId = '';
        if(reqType == "EDIT_DEAL"){
            interestId = leaseData.interestRtStateVal[i].editInterestRtId;
        }

        var marginval = 0;
        if(leaseData.modeltypeData !== "Solving for margin"){
            marginval = leaseData.interestRtStateVal[i].marginPeriod;
        }

        if(leaseData.interestRtStateVal[i].tlpPeriod !== '' &&
            leaseData.interestRtStateVal[i].tlpPeriod !== null && leaseData.interestRtStateVal[i].tlpPeriod !== undefined){
                interestRateVal.push({
                    'leaseInterestRateID':interestId,
                    'leaseContractId':leaseId,
                    'interestRateDate':getformattedDate(leaseData.interestRtStateVal[i].date),
                    'tlpPeriodPerc':leaseData.interestRtStateVal[i].tlpPeriod,
                    'marginPeriodPerc':marginval,
                    'refRatePeriodPerc':leaseData.interestRtStateVal[i].ReferencePeriod,
                });
            }
    }

    // Options

    for (var i = 0; i < leaseData.optionStateval.length; i++) {

        let applytoVal = 'SPV';
        if(leaseData.optionStateval[i].applyto == false){
            applytoVal = 'Property';
        }

        let applyTypeVal = 'Call';
        if(leaseData.optionStateval[i].type == false){
            applyTypeVal = 'Put';
        }
        
        //Need to chk - Thejaswini
        var optionId = '';
        if(reqType == "EDIT_DEAL"){
            optionId = leaseData.optionStateval[i].editOptionId;
        }


        let applyTypePremium = "Amount";
        if(leaseData.optionStateval[i].premiumType == false){
            applyTypePremium = '%';
        }
        let formatUpfromPremium = '';
            if(applyTypePremium == '%'){
        formatUpfromPremium = (leaseData.optionStateval[i].upfrontPremium);
            }else{
            formatUpfromPremium = leaseData.optionStateval[i].upfrontPremium;
            }
        
        let applyTypeExcisePremium = "Amount";
        if(leaseData.optionStateval[i].exciseType == false){
            applyTypeExcisePremium = '%';
        }
        let formatExcisePremium = '';
        if(applyTypeExcisePremium == '%'){
            formatExcisePremium = (leaseData.optionStateval[i].exercisePremium);
        }else{
            formatExcisePremium = leaseData.optionStateval[i].exercisePremium;
        }
        
        if(leaseData.optionStateval[i].upfrontPremium !== '' &&
            leaseData.optionStateval[i].upfrontPremium !== null && 
            leaseData.optionStateval[i].upfrontPremium !== undefined){
            optionVal.push({
                "leaseOptionId":optionId,
                'leaseContractId':leaseId,
                'appliesTo':applytoVal,
                //Select property not defined. need to define in DB.
                // 'spv':leaseData.optionStateval[i].spv,
                'optionType':applyTypeVal,
                //Need to chk shivani code
                //'upfrontOptionPremium':leaseData.optionStateval[i].upfrontPremium,
                'upfrontOptionPremium':formatUpfromPremium,
                // DataType mismatch.
                //Need to chk shivani code
                //'premiumPaidOptionExDate':leaseData.optionStateval[i].exercisePremium,
                'premiumPaidOptionExDate':formatExcisePremium,
                'optionDate':getformattedDate(leaseData.optionStateval[i].optiondate),
                'latestNoticeDate':getformattedDate(leaseData.optionStateval[i].latestnoticedate),
                'earliestOptionDate':getformattedDate(leaseData.optionStateval[i].earliernoticedate),
                'upfrontPremiumType':leaseData.optionStateval[i].upfrontPremiumType,
                'exerciseDateType':leaseData.optionStateval[i].exerciseDateType,
            });
        }
    }

    var dealStatus = leaseData.status;
    if(reqType == "SAVE_DEAL"){
        dealStatus= Lease_Constants.LEASE_STATUS_MODELLED;
    }

    var dealNum = null;
    var dealRefNum = null;
    if(reqType = "EDIT_DEAL"){
        dealNum = leaseData.dealNumber;
        dealRefNum = leaseData.dealReferenceNumber;
    }
    

    var isindexed = 0;
    if(leaseData.invoivingMethod == "Index"){
        isindexed = 1;
    }
    
    var dealUsage = "";
    if(isInvoicing && leaseData.isInvoicing){
        dealUsage = Lease_Constants.DEAL_USAGE_INVOICING;
    } else if (isInvoicing == false && leaseData.isDepreciation){
        dealUsage = Lease_Constants.DEAL_USAGE_DEPRECIATION;
    }

    return {
        'leaseContractId':leaseId,
        'dealType':dealTypeData,
        'customerName':leaseData.customerName,
        'spv':leaseData.spv,
        'spvId':leaseData.spvId,
        'partyIdCustomer': leaseData.partyIdCustomer,
        'leaseType':leaseData.leasetype,
        'areaId' : leaseData.areaId,
        // 'modelType':'ArrearsPaymSolvLeaseFee',
        'modelType':leaseData.modeltypeData,
        'paymentTerms':paymentType,
        'contractDescription':leaseData.description,
        'tenor':leaseData.leaseTenure,
        'periodTenore': leaseData.leaseTenurePeriod,
        // 'spv':leaseData.spv
        // 'spv':leaseData.spv,
        'lossGivenDefault':leaseData.LGD,
        'tlp':leaseData.tlp_value,
        // 'residualVal':leaseData.customerName;
        'returnsModel':leaseData.returnmodel,
        'vacantPossesionValue':removeCommas(leaseData.vpvValue),
        'leaseStartDate':getformattedDate(leaseData.leaseStartDate),
        'leaseEndDate':getformattedDate(leaseData.leaseEndDate),
        'invoicingFrequencyPerAnnum':invoicefeq,
        'fxRate':leaseData.faxRate,
        // 'franchiseName':leaseData.customerName,
        'firstPeriodReleaseFee':removeCommas(leaseData.firstPeriodLeaseFeeValue),
        'currency':leaseData.currencyName,
        'contractType':leaseData.leasetype,
        'acquistionCost':removeCommas(leaseData.aquisitioncost),
        'masterGradingScale':leaseData.mgs,
        // 'upfrontFeePercentage':leaseData.customerName,
        'residualVal':removeCommas(leaseData.residualValue), // need to find out which is residual value.
        'reLetValue':removeCommas(leaseData.rvlValue),
        'maintenance':leaseData.maintenance,
        // 'upfrontFee':leaseData.upfrontFee,
        //Need to chk
        'upfrontFeePercentage':leaseData.upfrontFee,

        //Indexation
        'leaseIndexations':indexationVal,

        //Interest Rate
        'leaseInterestRates':interestRateVal,

        //Options
        'leaseOptions':optionVal,
        // turnover
        'turnOver':removeCommas(turnover),
        // 'status':dealStatus,
        // 'dealNumber':dealNum,
        // 'dealReferenceNumber':dealRefNum,
        'dealUsability':dealUsage,
        'isLeaseIndexed':isindexed,
    }
}

export function RegisterLeaseParent(leaseData, leaseParentData){

    // if invoice or Depreciation is selected either i deal is generated,
    // if both are selected 2 deals for invoice and depreciation are generated.
    var invoicingContract = null;
    if(leaseData.isInvoicing == true) {
        invoicingContract = RegisterLeaseModel(leaseData, true);
    }
    var depreciationContract = null;
    if(leaseData.isDepreciation == true) {
        depreciationContract = RegisterLeaseModel(leaseData, false);
    }
    
    return{
        'depreciationLeaseContract':depreciationContract,
        'invoicingLeaseContract':invoicingContract,
        'status':leaseParentData.status,
        'dealNumber':leaseParentData.dealNumber,
        'dealReferenceNumber':leaseParentData.dealReferenceNumber,
        'leaseParentId':leaseParentData.leaseParentId,
        'currentWorkflowNumber': leaseParentData.currentWorkflowNumber,
        'onlineSolution': leaseParentData.onlineSolution,
        'offlineSolution': leaseParentData.offlineSolution,
        'dealCaptainRoleID': leaseParentData.dealCaptainRoleID
    };
}

export function RegisterLeaseInvoDepDeal(leaseInvoDepData, invoicingDeal, depreciationDeal){


    var invoicingContract = null;
    if(invoicingDeal !== undefined){
        invoicingContract = invoicingDeal;
    }
    
    var depreciationContract = null;
    if(depreciationDeal !== undefined){
        depreciationContract = depreciationDeal;
    }
        
    
    return{
        'depreciationLeaseContract':depreciationContract,
        'invoicingLeaseContract':invoicingContract,
        'status':leaseInvoDepData.status,
        'dealNumber':leaseInvoDepData.dealNumber,
        'dealReferenceNumber':leaseInvoDepData.dealReferenceNumber,
        'leaseParentId':leaseInvoDepData.leaseParentId,
        'currentWorkflowNumber': leaseInvoDepData.currentWorkflowNumber,
        'onlineSolution': leaseInvoDepData.onlineSolution,
        'offlineSolution': leaseInvoDepData.offlineSolution,
        'dealCaptainRoleID': leaseInvoDepData.dealCaptainRoleID
    };
}
