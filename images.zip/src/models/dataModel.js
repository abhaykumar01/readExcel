//import console = require("console");
import moment from 'moment';

export function RegisterParty(partydata, contactCount) {
    //get racfDeatils from above argument, and use it below
    console.log("entered data");
    console.log(partydata);
    let customerType = partydata.customerType;
    let mgs =parseInt(partydata.mgs);
    let userstatus = ''
    let creditrating = [];
    let userAccess = [];
    let userContact = [];
    let partyModel= [];
    if (customerType == "Primary") {
        customerType = 200;
    } else if (customerType == "Secondary") {
        customerType = 201;
    } else if (customerType == "Tenant") {
        customerType = 202;
    }
    if (partydata.kycStatus == "Verified") {
        userstatus = 'Active';
    } else if (partydata.kycStatus == "Unverified"){ 
        userstatus = 'Pending';
    }
    for (var i = 0; i < partydata.creditState.length; i++) {
        if (partydata.creditState[i].rating || partydata.creditState[i].source || partydata.creditState[i].webpage) { 
            creditrating.push({
                "creditRating": partydata.creditState[i].rating,
                "creditRatingSource": partydata.creditState[i].source,
                "ratingSourceWebpage": partydata.creditState[i].webpage               
            });
        }
    }
    for (var i = 0; i < partydata.userState.length; i++) {
        if (partydata.userState[i].name) {
            userAccess.push({
                "userName": partydata.userState[i].name
            });
        }
    }

    for (var i = 0; i < partydata.userData.length; i++) {
        console.log(partydata.userData);
        if (partydata.userData[i].isChecked) {
            console.log("if")
            partyModel.push({
                "createdBy": partydata.userData[i].userCreatedBy,	
                "createdOn": partydata.userData[i].userCreatedOn,	
                "franchiseName": partydata.userData[i].franchiseName,	
                "updatedBy": partydata.userData[i].userUpdatedBy,	
                "updatedOn": partydata.userData[i].userUpdatedOn,	
                "userName": partydata.userData[i].userName,	
                "userID":partydata.userData[i].userID
            });
        }
    }
    for (var i = 0; i < partydata.contactState.length; i++) {
        if (partydata.contactState[i].email || partydata.contactState[i].city || partydata.contactState[i].name ||
            partydata.contactState[i].role || partydata.contactState[i].name || partydata.contactState[i].moobileno ||
            partydata.contactState[i].officeno || partydata.contactState[i].postcode || partydata.contactState[i].address1 ||
            partydata.contactState[i].address2 || partydata.contactState[i].country) {
            let type;
            if (i == 0) {
                type = 1;
            } else { 
                type = 0;
            }
            userContact.push({
                "businessEmailAddress": partydata.contactState[i].email,
                "cityName": partydata.contactState[i].city,
                "contactName": partydata.contactState[i].name,
                "contactRole": partydata.contactState[i].role,
                "countryName": partydata.contactState[i].country,
                "iSPrimaryContact": type,
                "mobileTelephoneNumber": partydata.contactState[i].moobileno,
                "officeTelephoneNumber": partydata.contactState[i].officeno,
                "postCode": partydata.contactState[i].postcode,
                "streetAddressLine1": partydata.contactState[i].address1,
                "streetAddressLine2": partydata.contactState[i].address2
            });
        }
    }
    return {
        //"isAllowedToAllUsers":partydata.isAllowedToAllUsers,
        "cisCode": partydata.CISCode,
        "companyType": partydata.companytype,
        "competitors": partydata.peers,
        "customerTypeID": customerType,
        "isCustomer": "Y",
        "isSPV": "N",
        "isSeller": "N",
        "isTenant": "N",
        "kycStatus": partydata.kycStatus,
        "masterGradingScale": mgs,
        "organisationNo": partydata.orgNumber,
        "partyContacts": userContact,
        "partyCreditRatings": creditrating,
        "partyName": partydata.customerName,
        "partyStatus": userstatus,
        "partyUsers": userAccess,
        "sector": partydata.customerSector,
        "webPageUrl": partydata.webpage,
        "partyRestrictions":partyModel,
        "country":partydata.companyCountry,
        "annualReviewDate":partydata.annualReviewDate
    }
    
}

export function UpdateParty(partydata) {
    //get racfDeatils from above argument, and use it below
    let customerType = partydata.customerType;
    let mgs = parseInt(partydata.mgs);
    let userstatus = ''
    let creditrating = [];
    let userAccess = [];
    let userContact = [];
    let partyModel = [];
    if (customerType == "Primary") {
        customerType = 200;
    } else if (customerType == "Secondary") {
        customerType = 201;
    } else if (customerType == "Tenant") {
        customerType = 202;
    }
    if (partydata.kycStatus == "Verified") {
        userstatus = 'Active';
    } else if (partydata.kycStatus == "Unverified") {
        userstatus = 'Pending';
    }
  
    for (var i = 0; i <  partydata.creditState.length; i++) {
        if (partydata.creditState[i].rating || partydata.creditState[i].source || partydata.creditState[i].webpage) {
            creditrating.push({
                "creditRating": partydata.creditState[i].rating,
                "creditRatingSource": partydata.creditState[i].source,
                "ratingSourceWebpage": partydata.creditState[i].webpage,
                "partyID": partydata.partyid,
                "creditRatingFlag": partydata.creditState[i].creditRatingFlag === null || '' || undefined ? 0 : partydata.creditState[i].creditRatingFlag
            });
        }
    }
    for (var i = 0; i < partydata.userState.length; i++) {
        if (partydata.userState[i].name) {
            userAccess.push({
                "userName": partydata.userState[i].name,
                "partyID": partydata.partyid,
                "partyUserId": partydata.userState[i].userID
            });
        }
    }
    for (var i = 0; i < partydata.userDataArrDeep.length; i++) {
        console.log(partydata);
        console.log(partydata.userDataArrDeep);
        if (partydata.userDataArrDeep[i].isChecked) {
            console.log("if")
                partyModel.push({
                    "createdBy": partydata.userDataArrDeep[i].userCreatedBy,	
                    "createdOn": partydata.userDataArrDeep[i].userCreatedOn,	
                    "franchiseName": partydata.userDataArrDeep[i].franchiseName,	
                    "updatedBy": partydata.userDataArrDeep[i].userUpdatedBy,	
                    "updatedOn": partydata.userDataArrDeep[i].userUpdatedOn,
                    "userName": partydata.userDataArrDeep[i].userName,
                    "userID":partydata.userDataArrDeep[i].userID,
                });                   
        }
    }
    
    for (var i = 0; i < partydata.contactState.length; i++) {
        if (partydata.contactState[i].email || partydata.contactState[i].city || partydata.contactState[i].name ||
            partydata.contactState[i].role || partydata.contactState[i].name || partydata.contactState[i].moobileno ||
            partydata.contactState[i].officeno || partydata.contactState[i].postcode || partydata.contactState[i].address1 ||
            partydata.contactState[i].address2 || partydata.contactState[i].country) {
            let type;
            if (i == 0) {
                type = 1;
            } else {
                type = 0;
            }
            userContact.push({
                "businessEmailAddress": partydata.contactState[i].email,
                "cityName": partydata.contactState[i].city,
                "contactName": partydata.contactState[i].name,
                "contactRole": partydata.contactState[i].role,
                "countryName": partydata.contactState[i].country,
                "iSPrimaryContact": type,
                "mobileTelephoneNumber": partydata.contactState[i].moobileno,
                "officeTelephoneNumber": partydata.contactState[i].officeno,
                "postCode": partydata.contactState[i].postcode,
                "streetAddressLine1": partydata.contactState[i].address1,
                "streetAddressLine2": partydata.contactState[i].address2,
                "partyID": partydata.partyid,
                "contactID": partydata.contactState[i].contactID,
                "contactFlag": partydata.contactState[i].contactFlag === null || '' || undefined ?
                 0 : partydata.contactState[i].contactFlag
            });
        }
    }
    return {
        //"isAllowedToAllUsers":partydata.isAllowedToAllUsers,
        "cisCode": partydata.CISCode,
        "companyType": partydata.companytype,
        "competitors": partydata.peers,
        "customerTypeID": customerType,
        "isCustomer": "Y",
        "isSPV": "N",
        "isSeller": "N",
        "isTenant": "N",
        "kycStatus": partydata.kycStatus,
        "masterGradingScale": mgs,
        "organisationNo": partydata.orgNumber,
        "partyContacts": userContact,
        "partyCreditRatings": creditrating,
        "partyName": partydata.customerName,
        "partyStatus": partydata.userstatus,
        "partyUsers": userAccess,
        "sector": partydata.customerSector,
        "webPageUrl": partydata.webpage,
        "partyID": partydata.partyid,
        "createdOn": partydata.createdOn,
        "partyRestrictions":partyModel,
        "partyFlag": partydata.partyFlag,
        "partyHistoryID": partydata.partyHistoryId,
        "removedPartyCreditRatings": partydata.removedPartyCreditRatings,
        "removedPartyContacts": partydata.removedContacts
    }

}

export function saveApproverGridStatus(requestno, comment) {
    return {
        "comment": comment,
        "ecmDocumentLink": "",
        "tlpBaseGridStatusId": 0,
        "tlpBaseTableRequestNumber": requestno
    }
}



export function uploadDocuments(name, type, description, ID, ClassificationVal,
    RecordVal, RiskVal, propertyID, leaseContractID, racfID, spvID, uploadedStatus, isApprovalRequired, isHighRisk, uploadedUser) {
    let racf = racfID;
    if (!racf) {
        racf = "";
    }
    return {
        "documentDescription": description,
        "documentMediaType": type,
        "documentName": name,
        "isflaggedForDeletion": 0,
        "highRiskRecord": RiskVal,
        "documentClassification": ClassificationVal,
        "recordClassCode": RecordVal,
        "uploadedUser": uploadedUser,
        "partyID": ID,
        "propertyID": propertyID,
        "leaseContractId": leaseContractID,
        "spvID": spvID,
        "uploadRequestedBy": racf,
        "uploadStatus": uploadedStatus,    // PendingApproval, Approved, Rejected
        "isApprovalRequired": isApprovalRequired, // 1 - Required and 0 - Not Required
        "isHighRiskDocument": isHighRisk // 0 - No and 1 -Yes
    }
}

export function createNotification(category, desc, group, name, partyID, type, status, userID, leaseContractID, propertyID, tlpBaseTableRequestNo, docID) {
    return [{
        "category": category,
        "description": desc,
        "group": group,
        "leaseContractID": leaseContractID,
        "name": name,
        "partyID": partyID,
        "propertyID": propertyID,
        "tlpBaseTableRequestNo": tlpBaseTableRequestNo,
        "type": type,
        "status": status,
        "userID": userID,
        "hasRead": 0,
        "isActionCompleted": 0,
        "isDeleted": 0,
        "documentID": docID,
    }]
}

export function submitRequest(docID, docName, notificationID, partyID, partyName, reason, leaseContractID, propertyID,
    requestedBy, respondedBy, docType, spvID, isApprovalRequired, isHighRisk) { 
    return {
        "documentID": docID,
        "documentName": docName,
        "leaseContractID": leaseContractID,
        "notificationID": notificationID,
        "partyID": partyID,
        "partyName": partyName,
        "reasonForRejection": reason,
        "propertyID": propertyID,
        "requestedBy": requestedBy,
        "respondedBy": respondedBy,
        "highRiskDocument": docType,
        "spvID": spvID,
        "userToBeNotified": requestedBy,
        "isApprovalRequired": isApprovalRequired, // 1 - Required and 0 - Not Required
        "isHighRiskDocument": isHighRisk // 0 - No and 1 -Yes
    }
}

export function approveUploadRequest(docID, docName, notificationID, partyID, partyName, reason, leaseContractID, propertyID,
    requestedBy, respondedBy, docType, spvID) {
    return {
        "documentID": docID,
        "documentName": docName,
        "leaseContractID": leaseContractID,
        "notificationID": notificationID,
        "partyID": partyID,
        "partyName": partyName,
        "reasonForRejection": reason,
        "propertyID": propertyID,
        "requestedBy": requestedBy,
        "respondedBy": respondedBy,
        "highRiskDocument": docType,
        "spvID": spvID,
        "userToBeNotified": requestedBy,
        "isHighRiskDocument": docType,
    }
}

export function updateNotification(
    category, desc, group, name, partyID, type, status, userID, leaseContractID,
    propertyID, tlpBaseTableRequestNo) {
    return [{
        "category": category,
        "description": desc,
        "group": group,
        "leaseContractID": leaseContractID,
        "name": name,
        "partyID": partyID,
        "propertyID": propertyID,
        "tlpBaseTableRequestNo": tlpBaseTableRequestNo,
        "type": type,
        "status": status,
        "userID": userID,
        "hasRead": 0,
        "isActionCompleted": 1,
        "isDeleted": 0,
    }]
}









export function deleteDocument(docData, reason) {
    return {
        "createdOn": docData.createdOn,
        "deleteRequestedBy": docData.deleteRequestedBy,
        "documentClassification": docData.documentClassification,
        "documentDescription": docData.documentDescription,
        "documentId": docData.documentId,
        "documentIdentifier": docData.documentIdentifier,
        "documentMediaType": docData.documentMediaType,
        "documentName": docData.documentName,
        "ecmDocumentId": docData.ecmDocumentId,
        "ecmVersionNumber": docData.ecmVersionNumber,
        "highRiskRecord": docData.highRiskRecord,
        "isDeleted": 1,
        "isflaggedForDeletion": docData.isflaggedForDeletion,
        "lastUpdatedOn": docData.lastUpdatedOn,
        "leaseContractId": docData.leaseContractId,
        "partyID": docData.partyID,
        "reasonForRejection": reason,
        "recordClassCode": docData.recordClassCode,
        "tlpBaseTableReqNo": docData.tlpBaseTableReqNo,
        "uploadRequestedBy": docData.uploadRequestedBy,
        "uploadedUser": docData.uploadedUser,
        "spvID": docData.spvID,
    }
}

export function manualInvoiceForm(value) {
    var currentDate = new Date();
    var invoiceFrequencyCount = 0;
if(value != "") {
if(value.invoicingFrequency ==='Monthly' || value.invoicingFrequency === 12) {
invoiceFrequencyCount = 12;

} else if(value.invoicingFrequency ==='Quarterly' || value.invoicingFrequency ===4){
invoiceFrequencyCount =4;

} else if(value.invoicingFrequency ==='Semi-Annually' || value.invoicingFrequency ===2){
invoiceFrequencyCount =2;
} else if(value.invoicingFrequency ==='Annually' || value.invoicingFrequency ===1){
invoiceFrequencyCount =1;

}
} 
    return [
        {
          "areaCode": value.areaCode,
          "baseRent": value.baseRent,
          "bookValueScaler": 0,
          "comments": value.otherSupportingComments,
          "currency": value.currencyName,
          "customer": value.customer,
          "depreciation": 0,
          "franchiseName":"LMS",
          "futureValue": 0,
          "index": value.index,
          "propertyTax": value.propertyTax, 
          "indexAdjustment": value.indexAdjustment,
          "indexBaseDate": value.indexBaseDate,
          "indexBaseNo": value.indexBaseNumber,
          "indexFloor": value.indexFloor,
          "indexName": value.indexName,
          "indexScaling": value.indexScaling,
          "indexType": value.indexType,
          "indexReviewDate": value.indexReviewDate,
          "indexReviewNo": value.indexReviewNumber,
          "interestAdjustment": value.interestAdjustment,
          "interestRateName": null,
          "interestRateReviewDate": "",
          "interestRateFloor": null,
          "invoiceCreatedDate": currentDate,
          "invoiceEndDate": value.invoicingEndDate,
          "invoiceFrequency": invoiceFrequencyCount ,
          "invoicePeriod": 0,
          "invoiceStartDate": value.invoicingStartDate, //"2019-11-19T13:16:13.393Z",
          "invoiceType": value.invoiceType,
          "invoiceUpdatedDate": currentDate,
          "leaseFee": value.leaseFee,
          "margin": 0,
          "numberBpsAdjustment": value.numberOfBpsAdjustment,
          "pmtTerms": value.pmtTerms,
          "presentValue": 0,
          "leaseContractId": value.leaseContractId,
          "rentAdjustment": value.rentAdjustment,
          "rentAdjustmentBps": value.rentAdjustmentPerBps,
          "rentRebate": value.rentRebate,
          "spv": value.spv,
          "tlp": 0,
          "totalRent": value.totalRent,
          "vatableProportion": value.vatableProportion,
          "baseRentDescription":value.baseRentDesc,
          "indexAdjDescription": value.indexAdjustmentDesc,
          "interestAdjDescription": value.interestAdjustmentDesc,
         "rentRebateDescription": value.rentRebateDesc,
          "rentAdjDescription": value.rentAdjustmentDesc,
         "propertyTaxDescription": value.propertyTaxDesc,
        }
      ]
}


export function intrestManualInvoiceForm(value) {
    var currentDate = new Date();
    var invoiceFrequencyCount = 0;
    if(value != "") {
    if(value.invoicingFrequency ==='Monthly' || value.invoicingFrequency === 12) {
    invoiceFrequencyCount = 12;
    
    } else if(value.invoicingFrequency ==='Quarterly' || value.invoicingFrequency ===4){
    invoiceFrequencyCount =4;
    
    } else if(value.invoicingFrequency ==='Semi-Annually' || value.invoicingFrequency ===2){
    invoiceFrequencyCount =2;
    } else if(value.invoicingFrequency ==='Annually' || value.invoicingFrequency ===1){
    invoiceFrequencyCount =1;
    
    }
    }
    return [
        {
          "areaCode": value.areaCode,
          "baseRent": value.baseRent,
          "bookValueScaler": value.bookValueScaler,
          "comments": value.otherSupportingComments,
          "leaseContractId": value.leaseContractId,
          "currency": value.currencyName,
          "customer": value.customer,
          "depreciation": value.depreciation,
          "futureValue": value.fv,
          "propertyTax": value.propertyTax, 
          "index": value.index,
          "indexAdjustment": value.indexAdjustment,
          "indexBaseDate": value.indexBaseDate,
          "indexBaseNo": value.indexBaseNumber,
          "indexFloor": value.indexFloor,
          "indexName": value.indexName,
          "indexScaling": value.indexScaling,
          "indexType": value.indexType,
          "indexReviewDate": "",
          "indexReviewNo": 0,
          "interestAdjustment": value.interestAdjustment,
          "interestRateName": value.interestRateName,
          "interestRateReviewDate": value.intrestRateReviewDate,
          "interestRateFloor": value.applyIntrestRateFloor,
          "invoiceCreatedDate": currentDate,
          "invoiceEndDate": value.invoicingEndDate,
          "invoiceFrequency": invoiceFrequencyCount ,
          "invoicePeriod": value.invoicePeriodNumberOfDays,
          "invoiceStartDate": value.invoicingStartDate, //"2019-11-19T13:16:13.393Z",
          "invoiceType": value.invoiceType,
          "invoiceUpdatedDate": currentDate,
          "leaseFee": value.leaseFee,
          "margin": value.margin,
          "numberBpsAdjustment": value.numberOfBpsAdjustment,
          "pmtTerms": value.pmtTerms,
          "presentValue": value.pv,
          "franchiseName":"LMS",
          "rentAdjustment": value.rentAdjustment,
          "rentAdjustmentBps": value.rentAdjustmentPerBps,
          "rentRebate": value.rentRebate,
          "spv": value.spv,
          "tlp": value.tlp,
          "totalRent": value.totalRent,
          "vatableProportion": value.vatableProportion,
          "baseRentDescription":value.baseRentDesc,
          "indexAdjDescription": value.indexAdjustmentDesc,
          "interestAdjDescription": value.interestAdjustmentDesc,
         "rentRebateDescription": value.rentRebateDesc,
          "rentAdjDescription": value.rentAdjustmentDesc,
         "propertyTaxDescription": value.propertyTaxDesc,

        }
      ]
}

export function calculateIndexForm(value) {
    console.log("calculateIndexForm: "+JSON.stringify(value));
    var baseRentFixed = 0;
    var interestAdjFixed = 0;
    var totalRentFixed = 0;
    var bookValueScalerFixed = 0;
    var interestRateFixed = 0;
    var interestRateFloating = 0;
    if(value.baseRentFixed != null){
        baseRentFixed = value.baseRentFixed;
    }
    if(value.interestAdjFixed != null) {
        interestAdjFixed = value.interestAdjFixed
    }
    if(value.totalRentFixed != null){
        totalRentFixed = value.totalRentFixed
    }
    if(value.bookValueScalerFixed != null){
        bookValueScalerFixed = value.bookValueScalerFixed
    }
    if(value.interestRateFixed != null){
        interestRateFixed = value.interestRateFixed
    }
    if(value.interestRateFloating != null){
        interestRateFloating = value.interestRateFloating
    }
    return [
        {
          "actionNeeded":value.actionNeeded,
          "areaCode": value.areaCode,
          "baseRent": value.baseRent,
          "baseRentFixed": baseRentFixed,
          "leaseContractId": value.leaseContractId,
          "leaseContractNumber": value.leaseContractNumber,
          "bookValueScaler": value.bookValueScalerFloat,
          "bookValueScalerFixed": bookValueScalerFixed,
          "interestAdjFixed":interestAdjFixed,
          "comments": value.otherSupportingComments,
          "currency": value.currency,
          "customer": value.customer,
          "depreciation": value.depreciation,
          "franchiseName":value.franchiseName,
          "futureValue": value.futureValue,
          "index": value.index,
          "propertyTax": value.propertyTax, 
          "indexAdjustment": value.indexAdjustment,
          "indexBaseDate": value.indexBaseDate,
          "indexBaseNo": value.indexBaseNumber,
          "indexFloor": value.indexFloor,
          "indexName": value.indexName,
          "indexScaling": value.indexScaling,
          "indexType": value.indexType,
          "indexReviewDate": value.indexReviewDate,
          "indexReviewNo": value.indexReviewNumber,
          "interestAdjustment": value.interestAdjustment,
          "interestRateName": value.interestRateName,
          "interestRateReviewDate": value.interestRateReviewDate,
          "interestRateFloor": value.interestRateFloor,
          "invoiceCreatedDate":value.invoiceCreatedDate,
          "invoiceEndDate": value.invoicingEndDate,
          "invoiceFrequency": value.invoicingFrequencyInt,
          "invoicePeriod": value.invoicePeriod,
          "invoiceId": value.invoiceId,
          "invoiceStartDate": value.invoicingStartDate, //"2019-11-19T13:16:13.393Z",
          "invoiceType": value.invoiceType,
          "invoiceUpdatedDate": "2019-12-31T13:16:13.393Z",
          "leaseFee": value.leaseFee,
          "margin": value.margin,
          "numberBpsAdjustment": value.numberBpsAdjustment,
          "pmtTerms": value.pmtTerms,
          "presentValue": value.presentValue,
          "totalRentFixed": totalRentFixed,
          "rentAdjustment": value.rentAdjustment,
          "rentAdjustmentBps": value.rentAdjustmentPerBps,
          "rentRebate": value.rentRebate,
          "spv": value.spv,
          "status": value.status,
          "tlp": value.tlp,
          "totalRent": value.totalRent,
          "vatableProportion": value.vatableProportion,
          "interestRateFixed": interestRateFixed,
          "interestRateFloating": interestRateFloating
        }
      ]
}

export function creditInvoicePayload(value) {
    var newDate = new Date();
    var currentDate =  newDate ; //moment(newDate).format('YYYY-MM-DD');
    console.log("creditInvoicePayload: "+(value.propertyTax + value.baseRent + value.rentRebate + value.rentAdjustment + value.interestAdjustment + value.indexAdjustment)+JSON.stringify(value));
    return [
        {
            "actionNeeded":value.actionNeeded,
            "areaCode": value.areaCode,
            "baseRent": value.baseRent,
            "baseRentFixed": value.baseRentFixed,
            "leaseContractId": value.leaseContractId,
            "leaseContractNumber": value.leaseContractNumber,
            "bookValueScaler": value.bookValueScalerFloat,
            "bookValueScalerFixed": value.bookValueScalerFixed,
            "interestAdjFixed":value.interestAdjFixed,
            "comments": value.otherSupportingComments,
            "currency": value.currency,
            "customer": value.customer,
            "depreciation": value.depreciation,
            "franchiseName":value.franchiseName,
            "futureValue": value.futureValue,
            "index": value.index,
            "propertyTax": value.propertyTax, 
            "indexAdjustment": value.indexAdjustment,
            "indexBaseDate": value.indexBaseDate,
            "indexBaseNo": value.indexBaseNo,
            "indexFloor": value.indexFloor,
            "indexName": value.indexName,
            "indexScaling": value.indexScaling,
            "indexType": value.indexType,
            "indexReviewDate": value.indexReviewDate,
            "indexReviewNo": value.indexReviewNumber,
            "interestAdjustment": value.interestAdjustment,
            "interestRate":value.interestRate,
            "interestRateName": value.interestRateName,
            "interestRateReviewDate": value.interestRateReviewDate,
            "interestRateFloor": value.interestRateFloor,
            "invoiceCreatedDate":value.invoiceCreatedDate,
            "invoiceEndDate": value.invoiceEndDate,
            "invoiceFrequency": value.invoiceFrequency,
            "invoicePeriod": value.invoicePeriod,
            "invoiceStartDate": value.invoiceStartDate, //"2019-11-19T13:16:13.393Z",
            "invoiceType": value.invoiceType,
            "invoiceUpdatedDate": currentDate, //"2019-12-31T13:16:13.393Z",
            "leaseFee": value.leaseFee,
            "margin": value.margin,
            "numberBpsAdjustment": value.numberBpsAdjustment,
            "pmtTerms": value.pmtTerms,
            "presentValue": value.presentValue,
            "rentAdjustment": value.rentAdjustment,
            "rentAdjustmentBps": value.rentAdjustmentPerBps,
            "rentRebate": value.rentRebate,
            "spv": value.spv,
            "status": value.status,
            "tlp": value.tlp,
            "totalRent": (value.propertyTax + value.rentRebate + value.rentAdjustment + value.interestAdjustment + value.indexAdjustment + value.baseRent),//value.totalRent,
            "vatableProportion": value.vatableProportion,
            "invoiceIdParent": value.invoiceId,
            "invoiceId": value.invoiceId,
            "invoiceCreditStatus": "Yes",
            "isCreditNote": "No",
            "approvedDate": null,
            "creditDate": currentDate, 
            "isNewInvoice": 'No', //value.isNewInvoiceValue,
            "bpsAdjValidDate":value.bpsAdjValidDate,
            "invoiceCreditType":"Invoice",
            "indexGradeNumber":""
  
          }, {
          "actionNeeded":value.actionNeeded,
          "areaCode": value.areaCode,
          "baseRent": value.baseRent,
          "baseRentFixed": value.baseRentFixed,
          "leaseContractId": value.leaseContractId,
          "leaseContractNumber": value.leaseContractNumber,
          "bookValueScaler": value.bookValueScalerFloat,
          "bookValueScalerFixed": value.bookValueScalerFixed,
          "interestAdjFixed":value.interestAdjFixed,
          "comments": value.otherSupportingComments,
          "currency": value.currency,
          "customer": value.customer,
          "depreciation": value.depreciation,
          "franchiseName":value.franchiseName,
          "futureValue": value.futureValue,
          "index": value.index,
          "propertyTax": value.propertyTax, 
          "indexAdjustment": value.indexAdjustment,
          "indexBaseDate": value.indexBaseDate,
          "indexBaseNo": value.indexBaseNo,
          "indexFloor": value.indexFloor,
          "indexName": value.indexName,
          "indexScaling": value.indexScaling,
          "indexType": value.indexType,
          "indexReviewDate": value.indexReviewDate,
          "indexReviewNo": value.indexReviewNumber,
          "interestAdjustment": value.interestAdjustment,
          "interestRateName": value.interestRateName,
          "interestRate":value.interestRate,
          "interestRateReviewDate": value.interestRateReviewDate,
          "interestRateFloor": value.interestRateFloor,
          "invoiceCreatedDate":value.invoiceCreatedDate,
          "invoiceEndDate": value.invoiceEndDate,
          "invoiceFrequency": value.invoiceFrequency,
          "invoicePeriod": value.invoicePeriod,
          "invoiceStartDate": value.invoiceStartDate, //"2019-11-19T13:16:13.393Z",
          "invoiceType": value.invoiceType,
          "invoiceUpdatedDate": currentDate, //"2019-12-31T13:16:13.393Z",
          "leaseFee": value.leaseFee,
          "margin": value.margin,
          "numberBpsAdjustment": value.numberBpsAdjustment,
          "pmtTerms": value.pmtTerms,
          "presentValue": value.presentValue,
          "rentAdjustment": value.otherManualAdjustment,
          "rentAdjustmentBps": value.rentAdjustmentPerBps,
          "rentRebate": value.rentRebate,
          "spv": value.spv,
          "status": "In Progress", // value.status,
          "tlp": value.tlp,
          "totalRent": value.totalRent,
          "vatableProportion": value.vatableProportion,
          "invoiceIdParent": value.invoiceId,
          "invoiceCreditStatus": "Pending – Invoiced",
          "isCreditNote": "No",
          "approvedDate": null,
          "creditDate": currentDate, 
          "isNewInvoice": 'No', //value.isNewInvoiceValue,
          "bpsAdjValidDate":value.bpsAdjValidDate,
          "invoiceCreditType":"NewInvoice",
          "indexGradeNumber":""

        },
        {
            "actionNeeded":value.actionNeeded,
            "areaCode": value.areaCode,
            "baseRent": value.baseRent,
            "baseRentFixed": value.baseRentFixed,
            "leaseContractId": value.leaseContractId,
            "leaseContractNumber": value.leaseContractNumber,
            "bookValueScaler": value.bookValueScalerFloat,
            "bookValueScalerFixed": value.bookValueScalerFixed,
            "interestAdjFixed":value.interestAdjFixed,
            "comments": value.otherSupportingComments,
            "currency": value.currency,
            "customer": value.customer,
            "depreciation": value.depreciation,
            "franchiseName":value.franchiseName,
            "futureValue": value.futureValue,
            "index": value.index,
            "propertyTax": value.propertyTax, 
            "indexAdjustment": value.indexAdjustment,
            "indexBaseDate": value.indexBaseDate,
            "indexBaseNo": value.indexBaseNo,
            "indexFloor": value.indexFloor,
            "indexName": value.indexName,
            "indexScaling": value.indexScaling,
            "indexType": value.indexType,
            "indexReviewDate": value.indexReviewDate,
            "indexReviewNo": value.indexReviewNumber,
            "interestAdjustment": value.interestAdjustment,
            "interestRate":value.interestRate,
            "interestRateName": value.interestRateName,
            "interestRateReviewDate": value.interestRateReviewDate,
            "interestRateFloor": value.interestRateFloor,
            "invoiceCreatedDate":value.invoiceCreatedDate,
            "invoiceEndDate": value.invoiceEndDate,
            "invoiceFrequency": value.invoiceFrequency,
            "invoicePeriod": value.invoicePeriod,
            "invoiceIdParent": value.invoiceId,
            "invoiceStartDate": value.invoiceStartDate, //"2019-11-19T13:16:13.393Z",
            "invoiceType": value.invoiceType,
            "invoiceUpdatedDate": currentDate, //"2019-12-31T13:16:13.393Z",
            "leaseFee": value.leaseFee,
            "margin": value.margin,
            "numberBpsAdjustment": value.numberBpsAdjustment,
            "pmtTerms": value.pmtTerms,
            "presentValue": value.presentValue,
            "rentAdjustment": value.otherManualAdjustment,
            "rentAdjustmentBps": value.rentAdjustmentPerBps,
            "rentRebate": value.rentRebate,
            "spv": value.spv,
            "status": "In Progress",
            "tlp": value.tlp,
            "totalRent": value.totalRent,
            "vatableProportion": value.vatableProportion,
           "invoiceCreditStatus": "Pending – Credit Only",
           "isCreditNote": "Yes",
           "approvedDate": null,
          "creditDate": currentDate, 
          "isNewInvoice": 'No',//value.isNewInvoiceValue,
          "bpsAdjValidDate":value.bpsAdjValidDate,
          "invoiceCreditType":"CreditNote",
          "indexGradeNumber":""
          }
      ]
}

export function calculateInterestForm(value) {
    var margin = 0;
    var interestRateFloat =0;
    var futureValue=0;
    var presentValue =0;
    var baseRent =0;
    var interestAdjustment = 0;
    if(value.marginValue!= null){
        margin = value.marginValue
    } 
    if(value.interestRateFloat!= null){
        interestRateFloat = value.interestRateFloat
    } 
    if(value.futureValue!= null){
        futureValue = value.futureValue
    } 
    if(value.presentValue!= null){
        presentValue = value.presentValue
    }
    if(value.baseRent!= null){
        baseRent = value.baseRent
    } 
    if(value.interestAdjustment!= null){
        interestAdjustment = value.interestAdjustment
    } 
    return [
        {
            "actionNeeded":value.actionNeeded,
            "areaCode": value.areaCode,
            "baseRent":baseRent, // value.baseRent,
            "baseRentFixed":0,// value.baseRentFixed,
            "leaseContractId": value.leaseContractId,
            "bookValueScaler": value.bookValueScalerFloat,
            "bookValueScalerFixed": value.bookValueScalerFixed,
            "comments": value.otherSupportingComments,
            "currency": value.currency,
            "customer": value.customer,
            "depreciation": value.depreciation,
            "franchiseName":value.franchiseName,
            "futureValue":futureValue, // value.futureValue,
            "index": value.index,
            "propertyTax": value.propertyTax, 
            "indexAdjustment": value.indexAdjustment,
            "indexBaseDate": value.indexBaseDate,
            "indexBaseNo": value.indexBaseNumber,
            "indexFloor": value.indexFloor,
            "indexName": value.indexName,
            "indexScaling": value.indexScaling,
            "indexType": value.indexType,
            "indexReviewDate": value.indexReviewDate,
            "indexReviewNo": value.indexReviewNumber,
            "interestAdjFixed": 0,//value.interestAdjFixed,
            "interestAdjustment":interestAdjustment, // value.interestAdjustment,
            "interestRateFixed": value.interestRateFixed,
            "interestRateFloating": interestRateFloat, //value.interestRateFloat,
            "interestRateName": value.interestRateName,
            "interestRateReviewDate": value.interestRateReviewDate,
            "interestRateFloor": value.interestRateFloor,
            "invoiceCreatedDate":value.invoiceCreatedDate,
            "invoiceEndDate": value.invoicingEndDate,
            "invoiceFrequency": value.invoicingFrequencyInt,
            "invoicePeriod": value.invoicePeriod,
            "invoiceId": value.invoiceId,
            "invoiceStartDate": value.invoicingStartDate, //"2019-11-19T13:16:13.393Z",
            "invoiceType": value.invoiceType,
            "invoiceUpdatedDate": "2019-12-31T13:16:13.393Z",
            "leaseFee": value.leaseFee,
            "margin":margin, // value.marginValue,
            "numberBpsAdjustment": value.numberBpsAdjustment,
            "pmtTerms": value.pmtTerms,
            "presentValue": presentValue, // value.presentValue,
            "rentAdjustment": value.rentAdjustment,
            "rentAdjustmentBps": value.rentAdjustmentPerBps,
            "rentRebate": value.rentRebate,
            "spv": value.spv,
            "status": value.status,
            "tlp": value.tlpValue,
            "totalRent": value.totalRent,
            "totalRentFixed":0,// value.totalRentFixed,
            "vatableProportion": value.vatableProportion
        }
      ]
}

export function multipleExportApprover(value) {
    
    let filteredData =[];
        console.log(value)
        var invoiceFrequencyCount =0;
    for (var i = 0; i < value.length; i++) {
        if(value[i] != "") {
            if(value[i].invoicingfrequency ==='Monthly' || value[i].invoicingfrequency === 12) {
            invoiceFrequencyCount = 12;
            } else if(value[i].invoicingfrequency ==='Quarterly' || value[i].invoicingfrequency ===4){
            invoiceFrequencyCount =4;
            } else if(value[i].invoicingfrequency ==='Semi-Annual' || value[i].invoicingfrequency ===2){
            invoiceFrequencyCount =2;
            } else if(value[i].invoicingfrequency ==='Annual' || value[i].invoicingfrequency ===1){
            invoiceFrequencyCount =1;
            }
            }
        filteredData.push({
            "actionNeeded": "No",
            "areaCode": value[i].areaCode,
            "baseRent": value[i].baseRent,
            //"bookValueScaler": 0,
            //"comments": "string",
            "currency": value[i].currency,
            "customer": value[i].customer,
            "depreciation": value[i].depreciation,
            "franchiseName": value[i].franchiseName,
            "futureValue": value[i].futureValue,
            "index": value[i].index,
            "indexAdjustment": value[i].indexAdjustment,
            "indexBaseDate": value[i].indexBaseDate,
            "indexBaseNo": value[i].indexBaseNo,
            "indexFloor": value[i].indexFloor,
            "indexName": value[i].indexName,
            "indexReviewDate": value[i].indexReviewDate,
            "indexReviewNo": value[i].indexReviewNo,
            "indexScaling": value[i].indexScaling,
            "indexType": value[i].indexType,
            "interestAdjustment": value[i].interestAdjustment,
            "interestRateFloor": value[i].interestRateFloor,
            "interestRateName": value[i].interestRateName,
            "interestRateReviewDate": value[i].interestRateReviewDate,
            "invoiceCreatedDate": value[i].invoiceCreatedDate,
            "invoiceEndDate": value[i].invoiceEndDate,
            "invoiceFrequency": invoiceFrequencyCount,
            "invoiceId": value[i].ID,
            "invoicePeriod": value[i].invoiceperiod,
            "invoiceStartDate": value[i].invoiceStartDate,
            "invoiceType": value[i].invoicetype,
            "invoiceUpdatedDate": value[i].invoiceUpdatedDate,
            "leaseContractId": value[i].leaseContractId, 
            "leaseContractNumber":value[i].leaseContractNumber,
            "leaseFee": value[i].leasefee,
            "margin": value[i].margin,
            "numberBpsAdjustment": value[i].numberBpsAdjustment,
            "pmtTerms": value[i].pmtterms,
            "presentValue": value[i].presentValue,
            "propertyTax": value[i].propertyTax,
            "rentAdjustment": value[i].rentAdjustment,
            "rentAdjustmentBps": value[i].rentAdjustmentBps,
            "rentRebate": value[i].rentRebate,
            "spv": value[i].spv,
            "status": value[i].status,
            "tlp": value[i].tlp,
            "totalRent": value[i].totalRent,
            "vatableProportion": value[i].vatableProportion,
            "invoiceCreditStatus":value[i].invoiceCreditStatus,
            "bpsAdjValidDate":value[i].bpsAdjValidDate,
            "invoiceCreditType":value[i].invoiceCreditType,
            "indexGradeNumber":value[i].indexGradeNumber,
            "isCreditNote":value[i].isCreditNote,
            "approvedDate":value[i].approvedDate,
            "creditDate":value[i].creditDate,
            "isNewInvoice": value[i].isNewInvoice,
            "requestedBy":value[i].requestedBy,
            "respondedBy":value[i].respondedBy,
            "reasonForRejection":value[i].reasonForRejection,
            "dealCaptain":value[i].dealCaptain,
            
        });
    
}
return filteredData;
}

export function multipleExport(value) {
        let filteredData =[];
        console.log(value)
        var invoiceFrequencyCount =0;
    for (var i = 0; i < value.length; i++) {
        if(value[i] != "") {
            if(value[i].invoicingfrequency ==='Monthly' || value[i].invoicingfrequency === 12) {
            invoiceFrequencyCount = 12;
            } else if(value[i].invoicingfrequency ==='Quarterly' || value[i].invoicingfrequency ===4){
            invoiceFrequencyCount =4;
            } else if(value[i].invoicingfrequency ==='Semi-Annual' || value[i].invoicingfrequency ===2){
            invoiceFrequencyCount =2;
            } else if(value[i].invoicingfrequency ==='Annual' || value[i].invoicingfrequency ===1){
            invoiceFrequencyCount =1;
            }
            } 
            filteredData.push({
                "actionNeeded": value[i].actionneeded,
                "areaCode": value[i].areaCode,
                "baseRent": value[i].baseRent,
                //"bookValueScaler": 0,
                //"comments": "string",
                "currency": value[i].currency,
                "customer": value[i].customer,
                "depreciation": value[i].depreciation,
                "franchiseName": value[i].franchiseName,
                "futureValue": value[i].futureValue,
                "index": value[i].index,
                "indexAdjustment": value[i].indexAdjustment,
                "indexBaseDate": value[i].indexBaseDate,
                "indexBaseNo": value[i].indexBaseNo,
                "indexFloor": value[i].indexFloor,
                "indexName": value[i].indexName,
                "indexReviewDate": value[i].indexReviewDate,
                "indexReviewNo": value[i].indexReviewNo,
                "indexScaling": value[i].indexScaling,
                "indexType": value[i].indexType,
                "interestAdjustment": value[i].interestAdjustment,
                "interestRateFloor": value[i].interestRateFloor,
                "interestRateName": value[i].interestRateName,
                "interestRateReviewDate": value[i].interestRateReviewDate,
                "invoiceCreatedDate": value[i].invoiceCreatedDate,
                "invoiceEndDate": value[i].invoiceEndDate,
                "invoiceFrequency": invoiceFrequencyCount,
                "invoiceId": value[i].ID,
                "invoicePeriod": value[i].invoicePeriod,
                "invoiceStartDate": value[i].invoiceStartDate,
                "invoiceType": value[i].invoicetype,
                "invoiceUpdatedDate": value[i].invoiceUpdatedDate,
                "leaseContractId": value[i].leaseContractId, 
                "leaseContractNumber":value[i].leaseContractNumber,
                "leaseFee": value[i].leasefee,
                "margin": value[i].margin,
                "numberBpsAdjustment": value[i].numberBpsAdjustment,
                "pmtTerms": value[i].pmtterms,
                "presentValue": value[i].presentValue,
                "propertyTax": value[i].propertyTax,
                "rentAdjustment": value[i].rentAdjustment,
                "rentAdjustmentBps": value[i].rentAdjustmentBps,
                "rentRebate": value[i].rentRebate,
                "spv": value[i].spv,
                "status": value[i].status,
                "tlp": value[i].tlp,
                "totalRent": value[i].totalRent,
                "vatableProportion": value[i].vatableProportion,
                "requestedBy":value[i].requestedBy,
                "respondedBy":value[i].respondedBy,
                "reasonForRejection":value[i].reasonForRejection,
                "dealCaptain":value[i].dealCaptain,
                "invoiceCreditStatus":value[i].invoiceCreditStatus,
                "isCreditNote":value[i].isCreditNote,
                "approvedDate":value[i].approvedDate,
                "creditDate":value[i].creditDate,
                "isNewInvoice": value[i].isNewInvoice,
                "bpsAdjValidDate":value[i].bpsAdjValidDate,
                "invoiceCreditType":value[i].invoiceCreditType,
                "indexGradeNumber":value[i].indexGradeNumber
            });
        
    }
    return filteredData;
}
export function deleteApprovalDocument(docData) {
    return {
        "createdOn": docData.createdOn,
        "documentClassification": docData.documentClassification,
        "documentDescription": docData.documentDescription,
        "documentId": docData.documentId,
        "documentIdentifier": docData.documentIdentifier,
        "documentMediaType": docData.documentMediaType,
        "documentName": docData.documentName,
        "ecmDocumentId": docData.ecmDocumentId,
        "ecmVersionNumber": docData.ecmVersionNumber,
        "highRiskRecord": docData.highRiskRecord,
        "isDeleted": 1,
        "isflaggedForDeletion": docData.isflaggedForDeletion,
        "lastUpdatedOn": docData.lastUpdatedOn,
        "leaseContractId": docData.leaseContractId,
        "partyID": docData.partyID,
        "reasonForRejection": docData.reasonForRejection,
        "recordClassCode": docData.recordClassCode,
        "tlpBaseTableReqNo": docData.tlpBaseTableReqNo,
        "uploadedUser": docData.uploadedUser,
        "leaseApprovalDocumentType": docData.leaseApprovalDocumentType,
        "leaseApproverId": docData.leaseApproverId
    }
}

export function uploadApprovalDocuments(name, type, description, ID, ClassificationVal, RecordVal, RiskVal, propertyID, leaseContractID, leaseApprovalDocumentType, leaseApproverId, businessArea) {
    return {
        "documentDescription": description,
        "documentMediaType": type,
        "documentName": name,
        "isflaggedForDeletion": 0,
        "highRiskRecord": RiskVal,
        "documentClassification": ClassificationVal,
        "recordClassCode": RecordVal,
        "uploadedUser": "ECM",
        "partyID": ID,
        "propertyID": propertyID,
        "leaseContractId": leaseContractID,
        "leaseApprovalDocumentType": leaseApprovalDocumentType,
        "leaseApproverId": leaseApproverId,        
        "businessUnit": businessArea
    }
}

export function checkDocumentNamingFormat(format) {
    // var format = "2020-04-12recordsMangementCPBProcessHRV01.01.docx";
    var date = format.slice(0, 10);
    var title = '';
    var version = '';
    var riskType = '';
    var riskStatus = format.lastIndexOf("HR");
    var versionNo;
    var formatStatus = false;
    if (riskStatus != -1) {
        title = format.slice(10, riskStatus);
        riskType = format.slice(riskStatus, riskStatus + 2);
    } else {
        riskStatus = format.lastIndexOf("SR");
        if (riskStatus != -1) {
            title = format.slice(10, riskStatus);
            riskType = format.slice(riskStatus, riskStatus + 2);
        } else {
            riskType = '';
        }

    }
    if (riskStatus == -1) {
        riskStatus = format.lastIndexOf("V");
        if (riskStatus != -1) {
            title = format.slice(10, riskStatus);
            version = format.slice(riskStatus, format.lastIndexOf("."));
            versionNo = format.slice(riskStatus + 1, format.lastIndexOf("."))
        } else {
            version = '';
            versionNo = '';
        }
    } else {
        version = format.slice(riskStatus + 2, format.lastIndexOf("."));
        versionNo = format.slice(riskStatus + 3, format.lastIndexOf("."))
    }
    // var no = parseInt(versionNo);
    // console.log("Document format");
    // console.log("date " ,date);
    // console.log("title " ,title);
    // console.log("riskType " ,riskType);
    // console.log("version " ,version);
    // console.log("versionNo ", versionNo);
    // console.log("Date validity ", moment(moment(date, "YYYY-MM-DD", true)).isValid());
    // console.log("First letter of title ",title[0].toUpperCase() == title[0])
    // console.log("Risk type casing ", riskType.toUpperCase() == riskType)
    // console.log("version casing ", version[0].toUpperCase() == version[0])
    // console.log("Check version type ", isNaN(versionNo));
    if (!moment(moment(date, "YYYY-MM-DD", true)).isValid()) {
        formatStatus = true;
    }
    if (title) {
        if (!(title[0].toUpperCase() == title[0])) {
            formatStatus = true;
        }
    } else {
        formatStatus = true;
    }
    if (riskType) {
        if (!(riskType.toUpperCase() == riskType)) {
            formatStatus = true;
        }
    } else {
        formatStatus = true;
    }
    if (version) {
        if (!(version[0].toUpperCase() == version[0])) {
            formatStatus = true;
        }
    } else {
        formatStatus = true;
    }
    if ((isNaN(versionNo))) {
        formatStatus = true;
    }
    console.log("final result:: ", formatStatus);
    return formatStatus;
}

export function RequestApproval(partydata, ID) {
       
    return {
        "partyName": partydata.userData.partyName,
        "requestedBy": ID,
        "partyID": partydata.partyID,      
    }
}
export function ApproveRejectParty(partydata, ID) {
       
    return {
        "partyName": partydata.userData.partyName,
        "requestedBy": partydata.userData.requestedBy,
        "partyID": partydata.partyID, 
        "userToBeNotified": partydata.userData.requestedBy,
        "respondedBy": ID
        }
}
