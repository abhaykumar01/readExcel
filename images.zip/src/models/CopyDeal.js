import moment from 'moment';
import {roundedDecimal, Comma, removeComma } from '../utils/LeaseUtils.js';
import { Lease_Constants } from './LeaseConstants.js';

export function getformattedDate(date){
    var formattedDate = null;
    if(date !== null && date !== undefined){
        // formattedDate = moment(date).format('DD/MM/YYYY')
        formattedDate = moment(date).format('L');
    }
    return formattedDate;
};

export function nullCheck(temp){
    var result = temp ? temp:'';
    return result;
}

export function getInvoicing(invoicing){

    var invoicefeq = '';
    if(invoicing == 12){
        invoicefeq = 'Monthly';
    } else if(invoicing == 4){
        invoicefeq = 'Quarterly';
    } else if(invoicing == 2){
        invoicefeq = 'Semi-Annually';
    } else if(invoicing == 1){
        invoicefeq = 'Annually';
    }
    return invoicefeq;
}

export function CopyParentModel(leaseParent){
    var reqType = localStorage.getItem('DealRequestType');
    var parentId = '';
    var statusTemp ='';
    var dealNumberTemp ='';
    var dealReferenceNumberTemp ='';
    var currentWorkflowNumberTemp = '';
    var onlineSolutionTemp ='';
    var offlineSolutionTemp ='';
    var dealCaptainRoleIDTemp ='';

    if(reqType !== "COPY_DEAL" && leaseParent !== null || leaseParent !== undefined){
        parentId = leaseParent.leaseParentId;
        statusTemp = leaseParent.status;
        dealNumberTemp = leaseParent.dealNumber;
        dealReferenceNumberTemp = leaseParent.dealReferenceNumber;
        currentWorkflowNumberTemp = leaseParent.currentWorkflowNumber;
        onlineSolutionTemp= leaseParent.onlineSolution;
        offlineSolutionTemp = leaseParent.offlineSolution;
        dealCaptainRoleIDTemp = leaseParent.dealCaptainRoleID;

    }

    var result = {
        leaseParentId :parentId,
        status:statusTemp,
        dealNumber:dealNumberTemp,
        dealReferenceNumber:dealReferenceNumberTemp,
        currentWorkflowNumber : currentWorkflowNumberTemp,
        onlineSolution: onlineSolutionTemp,
        offlineSolution : offlineSolutionTemp,
        dealCaptainRoleID : dealCaptainRoleIDTemp
    };

    return result;
}

export function CopyModelDeal(leaseContract){
    var reqType = localStorage.getItem('DealRequestType');
    // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
    var dType = true;
        if(leaseContract.dealType == "Construction"){
        dType = false;
    }
    var tempPaymentType = '';
    if(leaseContract.paymentTerms == "Advance"){
        tempPaymentType = 'Advanced';
    } else if(leaseContract.paymentTerms == "Arrears"){
        tempPaymentType = 'Arrears';
    }

    var contractId = '';
    // var statusTemp ='';
    // var dealNumberTemp ='';
    // var dealReferenceNumberTemp ='';
    if(reqType == "EDIT_DEAL"){
        contractId = leaseContract.leaseContractId;
        // statusTemp = leaseContract.status;
        // dealNumberTemp = leaseContract.dealNumber;
        // dealReferenceNumberTemp = leaseContract.dealReferenceNumber;
    }

    var isInvoicingTemp = false;
    var isDeprTemp = false;
    if(leaseContract.dealUsability == Lease_Constants.DEAL_USAGE_DEPRECIATION){
        isDeprTemp = true;
    } else if(leaseContract.dealUsability == Lease_Constants.DEAL_USAGE_INVOICING){
        isInvoicingTemp = true;
    }

    var modelState = {
        customerName: leaseContract.customerName || '',
        dealType: dType,
        leaseTenure: leaseContract.tenor,
        currencyName: leaseContract.currency,
        description : leaseContract.contractDescription,
        leaseStartDate: getformattedDate(leaseContract.leaseStartDate),
        leaseEndDate:getformattedDate(leaseContract.leaseEndDate),
        vpvValue:Comma(roundedDecimal(nullCheck(leaseContract.vacantPossesionValue))),
        rvlValue:Comma(roundedDecimal(nullCheck(leaseContract.reLetValue))),
        aquisitioncost:Comma(leaseContract.acquistionCost),
        // corporatetax:leaseContract.customerName,
        faxRate:nullCheck(leaseContract.fxRate),
        // GBP:leaseContract.customerName,
        modeltypeData :leaseContract.modelType,
        paymentterm :tempPaymentType,
        mgs :leaseContract.masterGradingScale,
        leasetype :leaseContract.contractType,
        invoicing :getInvoicing(leaseContract.invoicingFrequencyPerAnnum),
        returnmodel :leaseContract.returnsModel,
        LGD:leaseContract.lossGivenDefault,
        firstPeriodLeaseFeeValue:Comma(roundedDecimal(nullCheck(leaseContract.firstPeriodReleaseFee))),
        residualValue:Comma(roundedDecimal(nullCheck(leaseContract.residualVal))),
        turnover:nullCheck(leaseContract.turnOver),
        maintenance:leaseContract.maintenance,
        upfrontFee:nullCheck(leaseContract.upfrontFeePercentage),
        spv:leaseContract.spv ||'',
        editContractid:contractId,
        // status:statusTemp,
        // dealNumber:dealNumberTemp,
        // dealReferenceNumber:dealReferenceNumberTemp,
        showTenorFrequencyUI:true,
        leaseTenurePeriod:leaseContract.periodTenore,
        tenorFrequencyLable:getInvoicing(leaseContract.invoicingFrequencyPerAnnum),
        isInvoicing:isInvoicingTemp,
        isDepreciation:isDeprTemp,
        areaName:leaseContract.areaName || '',
    };

    // var resultModel = {indexasionState, indexationCount, indexRemainCount};
    return modelState;
}

export function CopyDealIndexation(leaseData){
    // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
    var leaseContract = leaseData;
    // window.alert(JSON.stringify(leaseContract));
    var leaseIndexations = leaseContract.leaseIndexations;
    var indexasionState = [];
    var indexationCount = [];
    var indexRemainCount = [];
    if(leaseIndexations !== undefined && leaseIndexations.length > 0 ){
        for (let j = 0; j < leaseIndexations.length; j++) {
            var indexType = true;
            if(leaseIndexations[j].indexationType == "CPI"){
                indexType = false;
            }
        var indexationobject = {
            editIndexationId :leaseIndexations[j].indexationId,
            indexationDate : getformattedDate(leaseIndexations[j].indexationDate),
            floor:leaseIndexations[j].floorPercentage,
            indexationPercentage:leaseIndexations[j].indexationPercentage,
            franchiseName:leaseIndexations[j].franchiseName,
            indexationName:leaseIndexations[j].indexationName,
            baseIndexName:leaseIndexations[j].baseIndexName,
            baseIndexDate:getformattedDate(leaseIndexations[j].baseIndexDate),
            baseIndexNumber:leaseIndexations[j].baseIndexNumber,
            indexationScaling:leaseIndexations[j].indexationScaling,
            indexationType:indexType,
            indexationPercentageStatus:false,
            indexationDateStatus:false,
            indexationStartDateError :'',
            indexationNameError: false,
            indexationNameErrorMessage: '',
            floorError: false,
            floorErrorMessage: '',
            indexationScalingError: false,
            indexationScalingErrorMessage: '',
            indexationErrorMessage: '',
            baseIndexNumberError: false,
            baseIndexNumberErrorMessage: '',
        };
        indexasionState.push(indexationobject);
        if(j >0){
            indexationCount.push(j+1);
        }
        
        }
    }
    if(leaseIndexations.length < 20){
        for(let j = leaseIndexations.length; j < 40; j++){
            if(j > 0){
                indexRemainCount.push(j+1);
            }
            var indexationobject = {
                editIndexationId:'',
                indexationDate : '',
                floor:'',
                indexationPercentage:'',
                franchiseName:'',
                indexationName:'',
                baseIndexName:'',
                baseIndexDate:'',
                baseIndexNumber:'',
                indexationScaling:100,
                indexationType:true,
                indexationPercentageStatus:false,
                indexationDateStatus:false,
                indexationStartDateError :'',
                indexationNameError: false,
                indexationNameErrorMessage: '',
                floorError: false,
                floorErrorMessage: '',
                indexationScalingError: false,
                indexationScalingErrorMessage: '',
                indexationErrorMessage: '',
                baseIndexNumberError: false,
                baseIndexNumberErrorMessage: '',
            };
            indexasionState.push(indexationobject);
        }
    }
    var resulIndex = {indexasionState, indexationCount, indexRemainCount};
    return resulIndex;
}


export function CopyDealInterestRate(leaseData){
    localStorage.getItem('leaseResponseDataState');
    // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
    var leaseContract = leaseData;
    var leaseInterestRt = leaseContract.leaseInterestRates;
    var interestRtState = [];
    var interestRtCount = [];
    var interestRemainCount = [];
    if(leaseInterestRt.length > 0 && leaseInterestRt !== undefined){
        for (let j = 0; j < leaseInterestRt.length; j++) {
            
            var interestobject = {
                editInterestRtId : leaseInterestRt[j].leaseInterestRateID,
                date: getformattedDate(nullCheck(leaseInterestRt[j].interestRateDate)),
                tlpPeriod: nullCheck(leaseInterestRt[j].tlpPeriodPerc),
                marginPeriod: nullCheck(leaseInterestRt[j].marginPeriodPerc),
                ReferencePeriod: nullCheck(leaseInterestRt[j].refRatePeriodPerc),
                dateErrorField:false,
                tlpPeriodErrorField:false,
                marginPeriodErrorField:false,
                referencePeriodErrorField:false,
                referenceRatePeriodErrorMessage: '',
                marginPeriodErrorMessage: '',
                tlpPeriodErrorMessage: '',
    
            };
        interestRtState.push(interestobject);
        if(j>0){
            interestRtCount.push(j+1);
        }
        }
    }
    if(leaseInterestRt.length < 20){
        for(let j = leaseInterestRt.length; j < 20; j++){
            if(j > 0){
                interestRemainCount.push(j+1);
            }

            var interestobject = {
                date: '',
                tlpPeriod: '',
                marginPeriod: '',
                ReferencePeriod: '',
                dateErrorField:false,
                tlpPeriodErrorField:false,
                marginPeriodErrorField:false,
                referencePeriodErrorField:false,
                referenceRatePeriodErrorMessage: '',
                marginPeriodErrorMessage: '',
                tlpPeriodErrorMessage: '',
                editInterestRtId:'',
    
            };
            interestRtState.push(interestobject);
        }
    }
    var resultInterestRt = {interestRtState, interestRtCount, interestRemainCount};
    return resultInterestRt;
}

export function CopyDealOption(leaseData){
    localStorage.getItem('leaseResponseDataState');
    // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
    var leaseContract = leaseData;
    var leaseOpts = leaseContract.leaseOptions;
    var leaseOptState = [];
    var leaseOptionCount = [];
    var OptionRemainingCount = [];
    var showOptionVar = false;
    if(leaseOpts !== undefined && leaseOpts.length > 0){
        for (let j = 0; j < leaseOpts.length; j++) {
            showOptionVar = true;
            var optionTypevar = true;
            if(leaseOpts[j].optionType == "Put"){
                optionTypevar = false;
            }

            
            let optionApplytoval = "SPV";
            if(leaseOpts[j].applyto == "Property"){
                optionApplytoval = false;
            }

            var optionobject = {
                editOptionId: leaseOpts[j].leaseOptionId,
                applyto: optionApplytoval,
                upfrontPremium: leaseOpts[j].upfrontOptionPremium,
                exercisePremium: leaseOpts[j].premiumPaidOptionExDate,
                optiondate: getformattedDate(leaseOpts[j].optionDate),
                earliernoticedate: getformattedDate(leaseOpts[j].earliestOptionDate),
                latestnoticedate: getformattedDate(leaseOpts[j].latestNoticeDate),
                spvError: false,
                spvErrorMessage: '',
                type: optionTypevar,
                upfrontPremiumError: false,
                upfrontPremiumErrorMessage: '',
                exercisePremiumError: false,
                exercisePremiumErrorMessage: '',
                optiondateError: false,
                optiondateErrorMessage: '',
                optionDateValError: false,
                upfrontPremiumType: leaseOpts[j].upfrontPremiumType,
                exerciseDateType: leaseOpts[j].exerciseDateType,
            };
            leaseOptState.push(optionobject);
            if(j > 0){
                leaseOptionCount.push(j+1);
            }
        }
    }
    if(leaseOpts.length < 20){
        for(let j = leaseOpts.length; j < 40; j++){
            if(j > 0){
                OptionRemainingCount.push(j+1);
            }
            var optionobject = {
                applyto: true,
                spv: '',
                spvError: false,
                spvErrorMessage: '',
                type: true,
                upfrontPremium: '',
                upfrontPremiumError: false,
                upfrontPremiumErrorMessage: '',
                exercisePremium: '',
                exercisePremiumError: false,
                exercisePremiumErrorMessage: '',
                optiondate: '',
                optiondateError: false,
                optiondateErrorMessage: '',
                earliernoticedate: '',
                latestnoticedate: '',
                optionDateValError: false,
                editOptionId:'',
            };
            leaseOptState.push(optionobject);
        }
    }
    var result = {leaseOptState, leaseOptionCount, OptionRemainingCount, showOptionVar};
    return result;
}
