import moment from 'moment';

export const onlineApprovalHeaders = [
    {id : 'businessArea', accessor: 'businessArea', displayName: 'Business Area',minWidth: 120, maxWidth: 450},
    {id : 'description', accessor: 'description', displayName: 'Description', minWidth: 180, maxWidth: 450, style: {color: '#666666'}},
    {id : 'leaseApprovalStatus', accessor: 'leaseApprovalStatus', displayName: 'Status', minWidth: 100, maxWidth: 300},
    {id : 'leaseApprovalActionedBy', accessor: 'leaseApprovalActionedBy', displayName: 'Actioned By', minWidth: 100, maxWidth: 300},
    {id : 'displayStatusDate', accessor: 'displayStatusDate', displayName: 'Date', minWidth: 80, maxWidth: 300},
    {id : 'leaseApprovalComment', accessor: 'leaseApprovalComment', displayName: 'Comments', minWidth: 150, maxWidth: 450},
]

export const offlineApprovalHeaders = [
    {id : 'businessArea', accessor: 'businessArea', displayName: 'Business Area', minWidth: 200},
    {id : 'description', accessor: 'description', displayName: 'Description', minWidth: 300, style: {color: '#666666'}},
    {id : 'leaseApprovalStatus', accessor: 'leaseApprovalStatus', displayName: 'Status', minWidth: 180},
    {id : 'leaseApprovalTeam', accessor: 'leaseApprovalTeam', displayName: 'Team', minWidth: 185},
    {id : 'leaseApprovalActionedBy', accessor: 'leaseApprovalActionedBy', displayName: 'Actioned By', minWidth: 155},
    {id : 'displayStatusDate', accessor: 'displayStatusDate', displayName: 'Date', minWidth: 120},
    {id : 'leaseApprovalComment', accessor: 'leaseApprovalComment', displayName: 'Comments', minWidth: 250},
]

export const onlineSolutionSuggestionData = [
    {id : 'newSolution', value: 'New solution'},
    {id : 'additionalFinancing', value: 'Additional financing'},
    {id : 'additionalLesse', value: 'Additional lessee'},
]

export const offlineSolutionSuggestionData = [
    {id : 'newSolution', value: 'New Solution'},
    {id : 'additionalFinancing', value: 'Additional financing'},
    {id : 'additionalLesse', value: 'Additional lessee'},
]

export const dealApprovalModalMessages = {
    'approveBusinessAreaMsg':'Are you sure you want to approve this business area?',
    'rejectBusinessAreaMsg':'Are you sure you want to reject this business area?',
    'sendAreaApprovalMsg':'Are you sure you want to send this business area for approval?',
    'removeApprovalMsg':'Are you sure you want to remove this offline approval?',
    'saveUpdatesMsg':'Are you sure you want to save these updates?',
    'cancelUpdatesMsg':'Are you sure you want to  cancel ?',
    'dealCaptainSignOffMsg':'Are you sure you want to sign off the deal approval ?',
    'selectDealStatus':'Select a status for deal:',
    'updateStatusToActive':'Are you sure you want to update deal status to active ?',
    'deleteDealMsg':"Are you sure you want to delete the deal? This can't be undone",
    'archiveDealRequestMsg':"Are you sure you want to archive the deal ? A request for approval will be sent",
    'archiveDealConfirmMsg':"Are you sure you want to archive the deal ?",
    'rejectArchiveMsg':"Are you sure you want to reject the deal archive request ?",
    'dealCaptainSignOffErrorMsg':"Please complete below listed fields, then deal captain sign off can be completed",
    'unSavedChangesMsg':"Are you sure you want to navigate away from this page? All your unsaved changes will be lost",
    'selectedDealsReinstateMsg':"This will reinstate the selected deal(s) to the status before they were archived. Are you sure you want to proceed ?",
    'dealReinstateMsg':"This will reinstate the deal to the status before it was archived. Are you sure you want to proceed ?",
}

export const dealNotificationMessages = {
    'sentForApprovalSuccess':'Your deal has been sent for approval',
    'saveUpdatesSuccess':'Your updates have been saved',
    'dealCaptainSignOffSuccess':'The deal captain sign-off has been provided',
    'dealStatusApproved':'Your deal has been approved',
    'setDealCaptainSuccess':'Deal captain has been updated',
    'archiveRequestSuccess': 'Your request for deal archival has been sent for approval',
    'archiveRejectSuccess':'Deal archival request has been rejected',
    'dealActiveSuccess':' has been approved and is now active',
    'reinstateSelectedDealsSuccess':'Selected deals have been reinstated successfully',
    'reinstateDealSuccess':'The deal has been reinstated successfully',
}

export const defaultDealApprovalObject = {
    "documentList": [],
    "dynamicApprover": null,
    "leaseApprovalActionedBy": null,
    "leaseApprovalComment": null,
    "leaseApprovalId": null,
    "leaseApprovalStatus": null,
    "leaseApprovalStatusDate": null,
    "leaseApprovalTeam": null,
    "leaseApprovalType": null,
    "leaseContractId": null,
    "staticApprover": null,
    "staticApproverId": null,
    "isDeleted":0,
}

export const defaultDealAuditObject = {
    "dealAuditUserId": null,
    "leaseAuditId": null,
    "leaseContractId": null,
    "auditHistory" : ''
}

export const dealAuditMsg={
    sendForApproval : " submitted for approval (Online approval)",
    confirmedApproval : " confirmed (Online approval)",
    rejectedApproval : " rejected (Online approval)",
    dealStatusUpdated : "Deal status updated to ",
    reinitiatedWorkflow : "Approval workflow re-initiated with new workflow number",
    dealCaptainSignOff : "All the business area are confirmed. Deal captain sign off submitted"
}

export const Lease_Constants = {    
    LEASE_STATUS_BLANK : "",
    LEASE_STATUS_ACTIVE : "Active",
    LEASE_STATUS_MODELLED : "Modelled",
    LEASE_STATUS_APPROVED : "Approved",
    LEASE_STATUS_AWAITING_APPROVED : "Awaiting approval",
    LEASE_STATUS_SIGNED : "Signed",
    LEASE_STATUS_NA : 'N/A',
    LEASE_STATUS_REJECTED : "Rejected",
    LEASE_STATUS_CONFIRMED :"Confirmed",
    LEASE_STATUS_ARCHIVED :"Archived",

    WORKFOW_NEW_WORKFLOW : "New workflow",
    WORKFLOW_PARTIAL_WORKFLOW :"Partial workflow",
    NO_UPDATE_REQUIRED:"No update required",

    BUSINESS_AREA_TREASURY : 'Treasury confirmation',
    BUSINESS_AREA_DILIGENCE : 'Confirmation of internal and external due diligence carried out',

    DEAL_USAGE_INVOICING:"Invoicing",
    DEAL_USAGE_DEPRECIATION:"Depreciation",
    DEAL_USAGE_INVOICE_AND_DEPRECIATION:"Invoice and Depreciation",
    
}

export const onlineDocumentApprovalHeaders = [
    {id : 'documentName', accessor: 'documentName', displayName: 'Document Name',minWidth: 150, maxWidth: 200},
    {id : 'description', accessor: 'documentDescription', displayName: 'Document Description', minWidth: 220, maxWidth: 350},
    {id : 'uploadedBy', accessor: 'uploadedUser', displayName: 'Uploaded By', minWidth: 150, maxWidth: 200}    
]

export const formatDate = function(dateString, locale){
    if(dateString !== null && dateString !== ''){
        return moment(dateString).toDate().toLocaleDateString(locale, {timezone: 'UTC', dateStyle:'short'});
    } else {
        return '';
    }
}
export const leaseAuditData = [
    {id : 'date', accessor: 'dealAuditTime', displayName: 'Date',minWidth: 30, maxWidth: 250},
    {id : 'auditUserId', accessor: 'dealAuditUserId', displayName: 'User', minWidth: 80, maxWidth: 500, style: {color: '#666666'}},
    {id : 'history', accessor: 'history', displayName: 'History', minWidth: 30, maxWidth: 150}    
]