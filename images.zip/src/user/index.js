import React, { PureComponent } from 'react'
import { Zambezi } from '@zambezi/formidable-components'
import moment from 'moment'
// import { AuthorizationContext } from '../components'


const { InputField } = Zambezi


export default class UserProfile extends PureComponent {
  // static contextType = AuthorizationContext

  render() {
    const { name, age, dateOfBirth, gender, occupation } = this.context
    return (
      <section className="epms-main">
        <header className="zb-card-header zb-card-header-title">
          View Profile
        </header>
        <div className="zb-card-body">
          <div className="zb-control-wrap elements-group">
            <div className="zb-control">
              <InputField label="Name" name="name" disabled value={name} />
            </div>
          </div>

          <div className="zb-control-wrap elements-group">
            <div className="zb-control">
              <InputField label="Age" name="age" disabled value={age} />
            </div>
          </div>

          <div className="zb-control-wrap elements-group">
            <div className="zb-control">
              <InputField
                label="DOB"
                name="DoB"
                disabled
                value={moment(dateOfBirth).format('DD-MMM-YYYY')}
              />
            </div>
          </div>

          <div className="zb-control-wrap elements-group">
            <div className="zb-control">
              <InputField
                label="Gender"
                name="gender"
                disabled
                value={gender}
              />
            </div>
          </div>

          <div className="zb-control-wrap elements-group">
            <div className="zb-control">
              <InputField
                label="Occupation"
                name="occupation"
                disabled
                value={occupation}
              />
            </div>
          </div>
        </div>
      </section>
    )
  }
}