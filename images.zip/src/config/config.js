
 //export const BASE_URL = process.env.REACT_APP_APP_URL;
// export const BASE_URL =  "https://lmsprocessms-dev.edi01-apps.dev-pcf2.lb1.rbsgrp.net/app/";//Development URl
// export const BASE_URL =  "https://lmsprocessms-dev-sandbox.edi01-apps.dev-pcf2.lb1.rbsgrp.net/app/"; //Sandbox URl
// export const BASE_URL =  "https://lmsprocessms-sit.edi01-apps.dev-pcf2.lb1.rbsgrp.net/lmsProcessService-rbs-ms-service/" // SIT URL
 // export const BASE_URL = "https://lmsprocessms-dev1.edi01-apps.dev-pcf2.lb1.rbsgrp.net/lmsProcessService-rbs-ms-service/";
// export const BASE_URL = "https://lmsprocessms-dev3.edi01-apps.dev-pcf2.lb1.rbsgrp.net/lmsProcessService-rbs-ms-service/";

export const  REACT_APP_IAM_CLIENT_ID = process.env.REACT_APP_IAM_CLIENT_ID;
export const REACT_APP_IAM_BASE_URI = process.env.REACT_APP_IAM_BASE_URI;
export const APPLICATION_URL = process.env.REACT_APP_APPLICATION_URL;
 export const BASE_URL =  "https://lmsprocessms-dev1.edi01-apps.dev-pcf2.lb1.rbsgrp.net/lmsProcessService-rbs-ms-service/"; //Sandbox URl
//export const BASE_URL = "https://vstspes05d.server.rbsgrp.mde:6401/lmsProcessService-rbs-ms-service/"; //Development URl
// export const BASE_URL =   "https://partydomainms-dev2.edi01-apps.dev-pcf2.lb1.rbsgrp.net/app/"; //Sandbox URl
//                         //   http://partydomainms-dev2.edi01-apps.dev-pcf2.lb1.rbsgrp.net/app/lms/partyDomainList/0/2/partyID 

export const DEAL_MODEL_TAB = process.env.SHOWLEASETAB;
export const ECM_TOGGLE = process.env.REACT_APP_ECM_TOGGLE; //Toggle notification
console.log("ECM toggle"+APPLICATION_URL+" BASE_URL: "+BASE_URL)

export const API_ENDPOINT = {
    UPLOAD_DOCUMENTS: "lms/ecm",
    CREATE_PARTY: "lms/party",
    PARTY_PROCESS_LIST: "lms/party",
    UPDATE_PARTY: "lms/party",
    // CREATE_PARTY: "lms/partyDomain", //"lms/party",
    // PARTY_PROCESS_LIST: "lms/partyDomainList", //"lms/party",
    GET_PARTY_DETAIL: "lms/party",
    TLP_BASE_GRID: "lms/tlpGrid",
    DOCUMENT: "lms/document",
    SUBMIT_CANCEL_DOCUMENT: "lms/document/user/submitOrCancelDeletionRequest",
    LMS_JWT: "lms/jwt",
    LMS_USERS: "lms/users/current",
    LMS_RBAC_ROLEPERMISSION: "lms/rbac/rolePermissions",
    SUBMIT_DELETION_REQUEST: "lms/document/user/submitDeletionRequest",
    REJECT_DELETION_REQUEST: "lms/document/approver/rejectDeletionRequest",
    LMS_NOTIFICATION: "lms/notification",
    LMS_ECM: "lms/ecm",
    LMS_ECM_DELETE: "lms/ecm/deleteDoc",
    CANCEL_DELETION_REQUEST: "lms/document/user/cancelDeletionRequest",
    DOCUMENT_PROPERTY: "lms/document/property",
    PROPERTY_SUBMIT_DELETION_REQUEST: "lms/document/property/user/submitDeletionRequest",
    PROPERTY_REJECT_DELETION_REQUEST: "lms/document/property/approver/rejectDeletionRequest",
    PROPERTY_CANCEL_DELETION_REQUEST: "lms/document/property/user/cancelDeletionRequest",
    LMS_DOCUMENT_PROPERTY: "lms/document/property",
    LEASE_DOCUMENT: "lms/document/lease/approver/getFlaggedDocumentsForDeletion",
    CREATE_DATAMODEL: "lms/dealModel",
    LEASEDOCUMENT: "lms/document/lease/getDealDocsByLeaseId",
    LMS_ECM_DOWNLOAD:  "lms/ecm",
    SUBMIT_LEASE_DELETION_REQUEST: "lms/document/lease/user/submitDeletionRequest",
    ECM_SUBMIT_LEASE_DELETION_REQUEST: "lms/document/lease/user/submitDeletionRequest",
    ECM_CANCEL_DELETION_REQUEST: "lms/document/lease/user/cancelDeletionRequest",
    ECM_REJECT_DELETION_REQUEST: "lms/document/lease/approver/rejectDeletionRequest",
    DEAL_MODEL_TAB : process.env.SHOWLEASETAB,
    CREATE_ASSET:"lms/spv",
    GET_CUSTOMER_NAME:"lms/party/partyName",
    CHECK_SPV_NUMBER:"lms/spv/validateSpvNumber/",
    ASSET_LIST:"lms/spv",
    ASSET_DETAILS:"lms/spv",
    ASSET_SPV_OPTIONS:"lms/spv/option",
    ASSET_PROPERTY_OPTIONS:"lms/spv/property/option",
    ASSET_SUMMARY:"lms/spv/summary",
    ASSET_BUILDING_LIST:"lms/spv/property/building",
    ASSET_AREA_LIST:"lms/spv/property/building/area",
    REQUEST_ASSET_APPROVAL:"lms/spv/status",
    APPROVE_SPV:"lms/spv/status/approve",
    REJECT_SPV:"lms/spv/status/reject",
    ARCHIVE_SPV: "lms/spv/doArchive",
    GET_CORPORATE_PARENT_LIST:"lms/spv/getAllCorporateParents",
    ADD_NEW_CORPORATE_PARENT:"lms/spv/corporateParent",
    GET_OLD_SPV:"lms/spv/getActiveAsset",
    SAVE_MANUAL_INVOICE: "lease/lms/oic/invoices",
    GET_ALL_INVOICES_WITH_FILTERS: "lease/lms/oic/invoiceGrid",
    MULTIPLE_EXPORT :"lease/lms/oic/invoices",
    REQUEST_APPROVAL :"lease/lms/oic/invoicecalsave",
    RECALCULATION_MANUAL_INVOICE: "lease/lms/oic/invoicecal",
    SAVE_UPDATED_INVOICE: "lease/lms/oic/invoicecalsave",
    GET_INVOICE_BY_ID:"lease/lms/oic/invoice/",
    GET_SINGLE_INVOICE_BY_ID:"lease/lms/oic/invoices/",
    GET_ALL_INVOICES: "lease/lms/oic/invoices",
    LEASE_EXPORT_TO_EXCEL : "lms/dealModel/exportToExcelLease/",
    PERIOD_LIST:"lease/util/periods",
    GET_ALL_USERS: "lms/rbac/users",
    LMS_DOCUMENT_UPLOADSTATUS: "lms/document/uploadStatus",
    LMS_DOCUMENT_PROPERTY_UPLOADSTATUS: "lms/document/property/uploadStatus",
    LMS_DOCUMENT_LEASE_UPLOADSTATUS: "lms/document/lease/uploadStatus",
    LMS_ECM_REJECTDOC:"lms/ecm/rejectDoc",
    GET_SPV_LIST: "lms/spv/spvNumber",
    GET_CUSTOMER_LIST: "lms/party/partyName",
    GET_AREA_LIST:"lms/spv/areaName",
    GET_STATIC_DEAL_APPROVER_LIST:"lease/leaseApproval/getStaticApproversForType",
    SAVE_DEAL_APPROVALS:"lease/leaseApproval/saveLeaseApprovalForDeal/",
    FETCH_DEAL_APPROVALS:"lease/leaseApproval/getLeaseApprovalsForDeal",
    GET_LEASE_APPROVER_DOCUMENT_LIST: "lms/document/lease/getLeaseApproverDocumentList",
    GET_DEAL_BUSINESS_SOLUTION_MAPPING: "lease/leaseApproval/getApproverSolutionConstants/",
    UPDATE_DEAL_STATUS: "lms/dealModel/setDealStatus",
    UPDATE_DEAL_SOLUTION: "lms/dealModel/setSolutionsForDeal",
    SAVE_STATIC_APPROVAL: "lease/leaseApproval/saveStaticLeaseApprovalForDeal/",
    SAVE_APPROVAL_SOLUTION_CONSTANT: "lease/leaseApproval/setApproverSolutionConstants/",
    SAVE_DEAL_AUDIT: "lease/leaseAudit/setAuditDetailsForDeal/",
    GET_AUDIT_DETAILS_FOR_DEAL:"lease/leaseAudit/getAuditDetailsForDeal",	
	GET_DEAL:"lms/dealModel/getLeaseContract",
	GET_DEAL_LIST:"lms/dealModel/getLeaseContractListForUser",
	UPDATE_DEAL:"lms/dealModel/updateLeaseContract/",
    MODEL_A_NEW_DEAL :"lms/dealModel/modelANewDeal/",
    GET_RBAC_USERS_LIST : "lms/rbac/users/",
    SET_DEAL_CAPTAIN : "lease/leaseApproval/setDealCaptain/",
    DELETE_DEAL : "lms/dealModel/setDealDeleteFlag/",
    ARCHIVE_DEAL : "lms/dealModel/setDealArchiveFlag/",
    REQUEST_DEAL_ARCHIVE : "lms/dealModel/setRequestArchiveFlag/",
    GET_ARCHIVED_DEAL_LIST : "lms/dealModel/getArchivedLeaseContractList/",
    VALIDATE_DEAL_DATA : "lms/dealModel/validateDealForDealCaptainSignOff/",
    SET_DEAL_STATUS_ACTIVE : "lms/dealModel/setActiveStatus/",
    GET_SAVED_DEAL_CAPTAIN : "lease/leaseApproval/getDealCaptain/",
    SAVE_CREDIT_INVOICE:"lease/lms/oic/creditinvoice",

    GET_DEAL_PARENT:"lms/dealModel/getLeaseParent",
    SAVE_DEAL_PARENT:"lms/dealModel/saveLeaseParent/",
    UPDATE_DEAL_PARENT:"lms/dealModel/updateLeaseParent/",
    UPDATE_ARCHIVED_DEAL_FLAG:"lms/dealModel/setArchivedDealsParameter/",
    DELETE_PARTY:'lms/party',   
    APPROVAL_REQUEST:'lms/party/approval',
    APPROVE_PARTY:'lms/party/approveParty',
    REJECT_PARTY:'lms/party/rejectParty',
    ARCHIVE_PARTY:'lms/party/archive',
    GET_CUSTOMER_SPV: 'lms/dealModel/getDealNumbersForCustomers'    
}
//Timeout occurence.
export const API_TIMEOUT = 99000;
