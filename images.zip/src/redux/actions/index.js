import { ADD_NOTIFICATION, SELECTED_TAB, SELECTED_DATA_FORMAT } from "../constants/action-types";

export function addNotification(payload) {
    return { type: ADD_NOTIFICATION, payload };
}

export function selectedTab(payload) { 
    return { type: SELECTED_TAB, payload };
}

export function selectedDataFormat(payload){
    return { type: SELECTED_DATA_FORMAT, payload};
}