import store from "./store/index";
import { addNotification, selectedTab } from "./actions/index";

window.store = store;
window.addNotification = addNotification;
window.selectedTab = selectedTab;