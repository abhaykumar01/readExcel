// src/js/reducers/index.js
import { ADD_NOTIFICATION, SELECTED_TAB, SELECTED_DATA_FORMAT } from "../constants/action-types";
const initialState = {
    user: {

    },
    dataFormat:'en-GB'
};
function rootReducer(state = initialState, action) {
    switch (action.type) { 
        case ADD_NOTIFICATION:
            return {
                ...state,
                user: action.payload,
            }
        case SELECTED_TAB:
            return {
                ...state,
                user: action.payload,
            }
        case SELECTED_DATA_FORMAT:
        return {
            ...state,
            dataFormat: action.payload,
        }
        default:
            return state;
    }
}
export default rootReducer;