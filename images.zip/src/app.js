import React, { PureComponent } from 'react'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './components/authContext/index'
import Router from './route';
import ErrorBoundary from './components/errorBoundary/index'
import IdleTimer from 'react-idle-timer'
import { APPLICATION_URL } from './config/config.js'
const PING = process.env.REACT_APP_PING; //Development URl



export default class App extends PureComponent {
    constructor(props) {
        super(props)
        this.idleTimer = null
        this.onAction = this._onAction.bind(this)
        this.onActive = this._onActive.bind(this)
        this.onIdle = this._onIdle.bind(this)
     

      }

    render() {
        return (
            <div>
            <IdleTimer
              ref={ref => { this.idleTimer = ref }}
              element={document}
              onActive={this.onActive}
              onIdle={this.onIdle}
              onAction={this.onAction}
              debounce={250}
               timeout={840000 * 1 * 1} /> 
            { <div>
                {PING == 'true' ? <BrowserRouter>
                    <AuthProvider>
                        <Router />
                    </AuthProvider>
                </BrowserRouter> :
                    <BrowserRouter>
                        {/* <AuthProvider> */}
                        <Router />
                        {/* </AuthProvider> */}
                    </BrowserRouter>
                }
            </div>}
          </div>
           

        )
    }
    _onAction(e) {
        // console.log('user did something', e)
      }
     
      _onActive(e) {
        console.log('user is active', e)
        console.log('time remaining', this.idleTimer.getRemainingTime())
      }
     
      _onIdle(e) {
        console.log('user is idle', e)
        console.log('last active', this.idleTimer.getLastActiveTime());
        alert('Connection expired : click \'OK\' and refresh page to reload');
       console.log('Getting APPLICATION_URL: '+APPLICATION_URL);
        window.open(APPLICATION_URL); // reload
      }
}