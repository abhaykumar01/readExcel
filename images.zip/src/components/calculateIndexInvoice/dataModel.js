export function RegisterParty(partydata, contactCount) {
    let customerType = partydata.customerType;
    let mgs =parseInt(partydata.mgs);
    let userstatus = ''
    let creditrating = [];
    let userAccess = [];
    let userContact = [];
    if (customerType == "Primary") {
        customerType = 200;
    } else if (customerType == "Secondary") {
        customerType = 201;
    } else if (customerType == "Tenant") {
        customerType = 202;
    }
    if (partydata.kycStatus == "Verified") {
        userstatus = 'Active';
    } else if (partydata.kycStatus == "Unverified"){ 
        userstatus = 'Pending';
    }
    for (var i = 0; i < partydata.creditState.length; i++) {
        if (partydata.creditState[i].rating || partydata.creditState[i].source || partydata.creditState[i].webpage) { 
            creditrating.push({
                "creditRating": partydata.creditState[i].rating,
                "creditRatingSource": partydata.creditState[i].source,
                "ratingSourceWebpage": partydata.creditState[i].webpage
            });
        }
    }
    for (var i = 0; i < partydata.userState.length; i++) {
        if (partydata.userState[i].name) {
            userAccess.push({
                "userName": partydata.userState[i].name
            });
        }
    }
    for (var i = 0; i < partydata.contactState.length; i++) {
        if (partydata.contactState[i].email || partydata.contactState[i].city || partydata.contactState[i].name ||
            partydata.contactState[i].role || partydata.contactState[i].name || partydata.contactState[i].moobileno ||
            partydata.contactState[i].officeno || partydata.contactState[i].postcode || partydata.contactState[i].address1 ||
            partydata.contactState[i].address2) {
            let type;
            if (i == 0) {
                type = 1;
            } else { 
                type = 0;
            }
            userContact.push({
                "businessEmailAddress": partydata.contactState[i].email,
                "cityName": partydata.contactState[i].city,
                "contactName": partydata.contactState[i].name,
                "contactRole": partydata.contactState[i].role,
                "countryName": partydata.contactState[i].country,
                "iSPrimaryContact": type,
                "mobileTelephoneNumber": partydata.contactState[i].moobileno,
                "officeTelephoneNumber": partydata.contactState[i].officeno,
                "postCode": partydata.contactState[i].postcode,
                "streetAddressLine1": partydata.contactState[i].address1,
                "streetAddressLine2": partydata.contactState[i].address2
            });
        }
    }
    return {
        "cisCode": partydata.CISCode,
        "companyType": partydata.companytype,
        "competitors": partydata.peers,
        "customerTypeID": customerType,
        "isCustomer": "Y",
        "isSPV": "N",
        "isSeller": "N",
        "isTenant": "N",
        "kycStatus": partydata.kycStatus,
        "masterGradingScale": mgs,
        "organisationNo": partydata.orgNumber,
        "partyContacts": userContact,
        "partyCreditRatings": creditrating,
        "partyName": partydata.customerName,
        "partyStatus": userstatus,
        "partyUsers": userAccess,
        "sector": partydata.customerSector,
        "webPageUrl": partydata.webpage
    }
    
}

export function UpdateParty(partydata) {
    let customerType = partydata.customerType;
    let mgs = parseInt(partydata.mgs);
    let userstatus = ''
    let creditrating = [];
    let userAccess = [];
    let userContact = [];
    if (customerType == "Primary") {
        customerType = 200;
    } else if (customerType == "Secondary") {
        customerType = 201;
    } else if (customerType == "Tenant") {
        customerType = 202;
    }
    if (partydata.kycStatus == "Verified") {
        userstatus = 'Active';
    } else if (partydata.kycStatus == "Unverified") {
        userstatus = 'Pending';
    }
    for (var i = 0; i < partydata.creditState.length; i++) {
        if (partydata.creditState[i].rating || partydata.creditState[i].source || partydata.creditState[i].webpage) {
            creditrating.push({
                "creditRating": partydata.creditState[i].rating,
                "creditRatingSource": partydata.creditState[i].source,
                "ratingSourceWebpage": partydata.creditState[i].webpage,
                "partyID": partydata.partyid,
            });
        }
    }
    for (var i = 0; i < partydata.userState.length; i++) {
        if (partydata.userState[i].name) {
            userAccess.push({
                "userName": partydata.userState[i].name,
                "partyID": partydata.partyid,
                "partyUserId": partydata.userState[i].userID
            });
        }
    }
    for (var i = 0; i < partydata.contactState.length; i++) {
        if (partydata.contactState[i].email || partydata.contactState[i].city || partydata.contactState[i].name ||
            partydata.contactState[i].role || partydata.contactState[i].name || partydata.contactState[i].moobileno ||
            partydata.contactState[i].officeno || partydata.contactState[i].postcode || partydata.contactState[i].address1 ||
            partydata.contactState[i].address2) {
            let type;
            if (i == 0) {
                type = 1;
            } else {
                type = 0;
            }
            userContact.push({
                "businessEmailAddress": partydata.contactState[i].email,
                "cityName": partydata.contactState[i].city,
                "contactName": partydata.contactState[i].name,
                "contactRole": partydata.contactState[i].role,
                "countryName": partydata.contactState[i].country,
                "iSPrimaryContact": type,
                "mobileTelephoneNumber": partydata.contactState[i].moobileno,
                "officeTelephoneNumber": partydata.contactState[i].officeno,
                "postCode": partydata.contactState[i].postcode,
                "streetAddressLine1": partydata.contactState[i].address1,
                "streetAddressLine2": partydata.contactState[i].address2,
                "partyID": partydata.partyid,
                "contactID": partydata.contactState[i].contactID

            });
        }
    }
    return {
        "cisCode": partydata.CISCode,
        "companyType": partydata.companytype,
        "competitors": partydata.peers,
        "customerTypeID": customerType,
        "isCustomer": "Y",
        "isSPV": "N",
        "isSeller": "N",
        "isTenant": "N",
        "kycStatus": partydata.kycStatus,
        "masterGradingScale": mgs,
        "organisationNo": partydata.orgNumber,
        "partyContacts": userContact,
        "partyCreditRatings": creditrating,
        "partyName": partydata.customerName,
        "partyStatus": userstatus,
        "partyUsers": userAccess,
        "sector": partydata.customerSector,
        "webPageUrl": partydata.webpage,
        "partyID": partydata.partyid,
        "createdOn": partydata.createdOn,
    }

}

export function saveApproverGridStatus(requestno, comment) {
    return {
        "comment": comment,
        "ecmDocumentLink": "",
        "tlpBaseGridStatusId": 0,
        "tlpBaseTableRequestNumber": requestno
    }
}



export function uploadDocuments(name, type, description, ID, ClassificationVal, RecordVal, RiskVal, propertyID, leaseContractID) {
    return {
        "documentDescription": description,
        "documentMediaType": type,
        "documentName": name,
        "isflaggedForDeletion": 0,
        "highRiskRecord": RiskVal,
        "documentClassification": ClassificationVal,
        "recordClassCode": RecordVal,
        "uploadedUser": "ECM",
        "partyID": ID,
        "propertyID": propertyID,
        "leaseContractId": leaseContractID
    }
}

export function createNotification(category, desc, group, name, partyID, type, status, userID, leaseContractID, propertyID, tlpBaseTableRequestNo, docID) {
    return [{
        "category": category,
        "description": desc,
        "group": group,
        "leaseContractID": leaseContractID,
        "name": name,
        "partyID": partyID,
        "propertyID": propertyID,
        "tlpBaseTableRequestNo": tlpBaseTableRequestNo,
        "type": type,
        "status": status,
        "userID": userID,
        "hasRead": 0,
        "isActionCompleted": 0,
        "isDeleted": 0,
        "documentID": docID,
    }]
}

export function submitRequest(docID, docName, notificationID, partyID, partyName, reason, leaseContractID, propertyID) { 
    return {
        "documentID": docID,
        "documentName": docName,
        "leaseContractID": leaseContractID,
        "notificationID": notificationID,
        "partyID": partyID,
        "partyName": partyName,
        "reasonForRejection": reason,
        "propertyID": propertyID
    }
}

export function updateNotification(
    category, desc, group, name, partyID, type, status, userID, leaseContractID,
    propertyID, tlpBaseTableRequestNo) {
    return [{
        "category": category,
        "description": desc,
        "group": group,
        "leaseContractID": leaseContractID,
        "name": name,
        "partyID": partyID,
        "propertyID": propertyID,
        "tlpBaseTableRequestNo": tlpBaseTableRequestNo,
        "type": type,
        "status": status,
        "userID": userID,
        "hasRead": 0,
        "isActionCompleted": 1,
        "isDeleted": 0,
    }]
}









export function deleteDocument(docData) {
    return {
        "createdOn": docData.createdOn,
        "documentClassification": docData.documentClassification,
        "documentDescription": docData.documentDescription,
        "documentId": docData.documentId,
        "documentIdentifier": docData.documentIdentifier,
        "documentMediaType": docData.documentMediaType,
        "documentName": docData.documentName,
        "ecmDocumentId": docData.ecmDocumentId,
        "ecmVersionNumber": docData.ecmVersionNumber,
        "highRiskRecord": docData.highRiskRecord,
        "isDeleted": 1,
        "isflaggedForDeletion": docData.isflaggedForDeletion,
        "lastUpdatedOn": docData.lastUpdatedOn,
        "leaseContractId": docData.leaseContractId,
        "partyID": docData.partyID,
        "reasonForRejection": docData.reasonForRejection,
        "recordClassCode": docData.recordClassCode,
        "tlpBaseTableReqNo": docData.tlpBaseTableReqNo,
        "uploadedUser": docData.uploadedUser
    }
}

export function manualInvoiceForm(value) {
    return [
        {
          "areaCode": value.areaCode,
          "baseRent": value.baseRent,
          "bookValueScaler": 0,
          "comments": value.otherSupportingComments,
          "currency": value.currencyName,
          "customer": value.customer,
          "depreciation": 0,
          "franchiseName":"LMS",
          "futureValue": 0,
          "index": value.index,
          "propertyTax": value.propertyTax, 
          "indexAdjustment": value.indexAdjustment,
          "indexBaseDate": value.indexBaseDate,
          "indexBaseNo": value.indexBaseNumber,
          "indexFloor": value.indexFloor,
          "indexName": value.indexName,
          "indexScaling": value.indexScaling,
          "indexType": value.indexType,
          "indexReviewDate": value.indexReviewDate,
          "indexReviewNo": value.indexReviewNumber,
          "interestAdjustment": value.interestAdjustment,
          "interestRateName": null,
          "interestRateReviewDate": "2019-11-19T13:16:13.393Z",
          "interestRateFloor": null,
          "invoiceCreatedDate": "2019-11-19T13:16:13.393Z",
          "invoiceEndDate": value.invoicingEndDate,
          "invoiceFrequency": value.invoicingFrequency,
          "invoicePeriod": 0,
          "invoiceStartDate": value.invoicingStartDate, //"2019-11-19T13:16:13.393Z",
          "invoiceType": value.invoiceType,
          "invoiceUpdatedDate": "2019-11-19T13:16:13.393Z",
          "leaseFee": value.leaseFee,
          "margin": 0,
          "numberBpsAdjustment": value.numberOfBpsAdjustment,
          "pmtTerms": value.pmtTerms,
          "presentValue": 0,
          
          "rentAdjustment": value.rentAdjustment,
          "rentAdjustmentBps": value.rentAdjustmentPerBps,
          "rentRebate": value.rentRebate,
          "spv": value.spv,
          "tlp": 0,
          "totalRent": value.totalRent,
          "vatableProportion": value.vatableProportion
        }
      ]
}


export function intrestManualInvoiceForm(value) {
    return [
        {
          "areaCode": value.areaCode,
          "baseRent": value.baseRent,
          "bookValueScaler": value.bookValueScaler,
          "comments": value.otherSupportingComments,
          "currency": value.currencyName,
          "customer": value.customer,
          "depreciation": value.depreciation,
          "futureValue": value.fv,
          "propertyTax": value.propertyTax, 
          "index": value.index,
          "indexAdjustment": value.indexAdjustment,
          "indexBaseDate": value.indexBaseDate,
          "indexBaseNo": value.indexBaseNumber,
          "indexFloor": value.indexFloor,
          "indexName": value.indexName,
          "indexScaling": value.indexScaling,
          "indexType": value.indexType,
          "indexReviewDate": "",
          "indexReviewNo": 0,
          "interestAdjustment": value.interestAdjustment,
          "interestRateName": value.interestRateName,
          "interestRateReviewDate": value.intrestRateReviewDate,
          "interestRateFloor": value.applyIntrestRateFloor,
          "invoiceCreatedDate": "2019-11-19T13:16:13.393Z",
          "invoiceEndDate": value.invoicingEndDate,
          "invoiceFrequency": value.invoicingFrequency,
          "invoicePeriod": value.invoicePeriodNumberOfDays,
          "invoiceStartDate": value.invoicingStartDate, //"2019-11-19T13:16:13.393Z",
          "invoiceType": value.invoiceType,
          "invoiceUpdatedDate": "2019-11-19T13:16:13.393Z",
          "leaseFee": value.leaseFee,
          "margin": value.margin,
          "numberBpsAdjustment": value.numberOfBpsAdjustment,
          "pmtTerms": value.pmtTerms,
          "presentValue": value.pv,
          "franchiseName":"LMS",
          "rentAdjustment": value.rentAdjustment,
          "rentAdjustmentBps": value.rentAdjustmentPerBps,
          "rentRebate": value.rentRebate,
          "spv": value.spv,
          "tlp": value.tlp,
          "totalRent": value.totalRent,
          "vatableProportion": value.vatableProportion
        }
      ]
}
export function calculateInterestForm(value) {
    return [
        {
          "currentIndexReviewDate": value.currentIndexReviewDate,
          "noOfBpsAdjustment": value.noOfBpsAdjustment,
          "indexReviewNumber": value.indexReviewNumber,
          "rentRebate": value.rentRebate,
          "otherManualAdjustment": value.otherManualAdjustment,
          "vatableProportion": value.vatableProportion,
          "otherSupportingComments": value.otherSupportingComments
        }
      ]
}