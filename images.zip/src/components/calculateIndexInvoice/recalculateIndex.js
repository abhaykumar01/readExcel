import React from 'react';

import GridPage from '../../commonComponents/gridpage';
import '../../index.css';
import './recalculateIndex.css';
import { Tabs, Tab } from 'react-bootstrap-tabs';
// import { Icon } from '@zambezi/sdk/icons';
// import { Select } from '@zambezi/sdk/dropdown-list';

//--
import { calculateIndexForm } from '../../models/dataModel.js';
import Dropdown from '../../commonComponents/dropdown';
import InputfieldCustom from '../../commonComponents/inputInvoiceField';
import Inputfield from '../../commonComponents/inputDealField';
import Calenderinputfield from '../../commonComponents/calenderInputInvoiceRecalculation.js';
import Dropdownfield from '../../commonComponents/DropdownField';
import Dropdownfieldcustom from '../../commonComponents/DropdownFieldCustom';
import TLPGrid from '../../commonComponents/TLPGrid';
import help from '../../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { API_ENDPOINT } from '../../config/config.js';
import { HttpPost, HttpGet, HttpPut } from '../../services/api.js';
//import { validate } from '../../utils/validation.js';
import { validateCalculateInterest } from '../../utils/validation.js';
import moment from 'moment';
import Accordion from '@zambezi/sdk/accordion';
import { Notification } from '@zambezi/sdk/notification';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Icon } from '@zambezi/sdk/icons';
import ButtonGroup from '@zambezi/sdk/button-group';

import { RegisterLeaseModel } from '../../models/LeaseModelRegistry.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Popup from '../../commonComponents/popupMessage';
import InputTextfield from '../../commonComponents/inputField.js';
import ReactTable from 'react-table';
import "react-table/react-table.css";
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;

// import console = require('console');


var baseRentSummary = "";
var currencySummary = "";
var currentDate = new Date();

//        let rentRebateSummary = this.state.summaryData.data[0].rentRebate.toString();
//        let totalRentSummary= this.state.summaryData.data[0].totalRent.toString();
//        let propertyTax= this.state.summaryData.data[0].propertyTax.toString();
//        let interestAdjustmentSummary= this.state.summaryData.data[0].interestAdjustment.toString();
//        let indexAdjustmentSummary=this.state.summaryData.data[0].indexAdjustment.toString();
class recalculateIndex extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        // this.getHeader = this.getHeader.bind(this);
        // this.getRowsData = this.getRowsData.bind(this);
        // this.getKeys = this.getKeys.bind(this);
        this.state = {
            racfData:'',
            bpsAdjValidDate:"",
            permissionData: {},
            memberOfDetail:'',
            baseRent: 0,
            invoiceCreditStatus:"No",
            baseRentError: false,
            baseRentErrorMessage:"",
            indexAdjustment: 0,
            interestAdjustment:0,
            rentRebate:0,
            rentAdjustment:0,
            totalRent: 0,
            propertyTax:0,
            currencyStatus:"",
            currencyName:"",
            //invoiceType:"Index",
            numberBpsAdjustment:0,
            spv: "",
            customer:"",
            areaCode:"",
            pmtTerms: "",
            invoicingFrequency: "",
            invoicingFrequencyInt:0,
            invoicingStartDate: "",
            invoicingEndDate: "",
            invoicingEndDateErrorMessage: "",
            invoicingEndDateError: false,
            leaseFee: 0,
            index: 0,
            indexType: "",
            indexScaling: 0,
            indexName: "",
            indexBaseDate: "",
            indexBaseNo:0,
            //indexReviewDate: "",
            indexReviewNumber:0,
            indexBaseNumber: 0,
            indexFloor: 0,
            indexDateReviewLogic:"",
            currentIndexReviewNumber: "",
            rentAdjustmentPerBps: 0,
            numberOfBpsAdjustment: 0,
           // numberBpsAdjustment:0,
            vatableProportion: 0,
            otherSupportingComments: "",
            partyTypeSelect:false,
            successMessage:"",
            depreciation:0,
            formErrorStatus:true,
            customerNameErrorMessage: "",
            customerNameError: false,
            leaseContractId:"",
            leaseContractNumber:0,
            status:"",
            invoiceId:0,
            bookValueScaler:0,
            invoicePeriod:0,
            actionNeeded:"",
            indexReviewNo:0,
            interestRateFloor:"",
            interestRateName:"",
            interestRateReviewDate:"",
            invoiceCreatedDate:"",
            invoiceEndDate:"",
            invoiceStartDate:"",
            invoiceType:"",
            margin:0,
            presentValue:0,
            rentAdjustmentBps:0,
            indexReviewDate:"",
            tlp:0,
            updatedInvoice:[],
            allInvoicesForSave:[],
            pageSuccessStatus:false,
            serverError:false,
            isLoading:false,
            rows : [
                { id: 0, title: "Task 1", complete: 20 },
                { id: 1, title: "Task 2", complete: 40 },
                { id: 2, title: "Task 3", complete: 60 }
              ],
            periodTableHeader: [{Period:'', 'Rent Adj/bps':'', 'No. of bps Adj':''}],
            periodTableData: this.props.periodTableData || [],
            summaryData:{
                "data": [{
                    "invoiceId": "Loading...",
                    "leaseContractId": "Loading...",
                    "leaseContractNumber":"Loading...",
                    "baseRent": 0,
                    "indexAdjustment": "Loading...",
                    "interestAdjustment": "Loading...",
                    "rentRebate": "Loading...",
                    "rentAdjustment": "Loading...",
                    "totalRent": "Loading...",
                    "invoiceType": "Loading...",
                    "spv": "Loading...",
                    "customer": "Loading...",
                    "areaCode": "Loading...",
                    "currency": "",
                    "pmtTerms": "Loading...",
                    "invoiceFrequency": "Loading...",
                    "invoiceStartDate":  currentDate,
                    "invoiceEndDate": currentDate,
                    "leaseFee": "Loading...",
                    "index": "Loading...",
                    "indexType": "Loading...",
                    "indexScaling": "Loading...",
                    "indexName": "Loading...",
                    "indexBaseDate":currentDate,
                    "indexBaseNo":"Loading...",
                    "indexFloor": "Loading...",
                    "rentAdjustmentBps": "Loading...",
                    "numberBpsAdjustment": "Loading...",
                    "vatableProportion": "Loading...",
                    "comments": "Loading...",
                    "status":"Loading...",
                    "bookValueScaler":"Loading...",
                    "presentValue": "Loading...",
                    "futureValue": "Loading...",
                    "depreciation": "Loading...",
                    "margin": "Loading...",
                    "tlp": "Loading...",
                    "interestRateFloor":"Loading...",
                    "interestRateName": "Loading...",
                    "interestRateReviewDate": "Loading...",
                    "invoicePeriod": "Loading...",
                    "propertyTax": "Loading...",
                    "invoiceCreatedDate":"Loading...",
                    "invoiceUpdatedDate": "Loading...",
                    "franchiseName": "Loading...",
                    "indexReviewDate": "Loading...",
                    "indexReviewNo": "Loading...",
                    "actionNeeded": "Loading...",
                }]
            }
        };
       
       
        this.handleChange = this.handleChange.bind(this);
        this.getCurrentIndexReviewDate = this.getCurrentIndexReviewDate.bind(this);
        this.getBpsAdjValidDate = this.getBpsAdjValidDate.bind(this);
        this.renderEditable = this.renderEditable.bind(this);
        this.renderEditableADJ = this.renderEditableADJ.bind(this);
        
    }

    componentDidMount() {
        this.initForm();  
        
        setTimeout(
            function() {
                this.initInvoiceSummary();
                this.recalculateInvoice();
            }
            .bind(this),
            500
        );
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }

    // componentWillReceiveProps (nextProps) {
    //     this.setState({periodTableData: nextProps.periodTableData || []})
    //   }
    
    

    initForm () {
        

       
        if(this.props.history.location.state != null && this.props.history.location.state != undefined) {
               
                if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Monthly') {
                    this.setState({ invoicingFrequencyInt: 12});
                 } else if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Quarterly'){
                    this.setState({ invoicingFrequencyInt: 4});
                 } else if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Semi-Annually'){
                    this.setState({ invoicingFrequencyInt: 2});
                 } else if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Annually'){
                    this.setState({ invoicingFrequencyInt: 1});
                 }
                    
              
            this.setState({
                actionNeeded: this.props.history.location.state.rowID.original.actionneeded,
                baseRent: this.props.history.location.state.rowID.original.baseRent,
                baseRentError: false,
                baseRentErrorMessage:"",
                indexBaseNo:this.props.history.location.state.rowID.original.indexBaseNo,
                franchiseName:this.props.history.location.state.rowID.original.franchiseName,
                futureValue: this.props.history.location.state.rowID.original.futureValue,
                depreciation:this.props.history.location.state.rowID.original.depreciation,
                indexAdjustment: this.props.history.location.state.rowID.original.indexAdjustment,
                interestAdjustment: this.props.history.location.state.rowID.original.interestAdjustment,
                rentRebate: this.props.history.location.state.rowID.original.rentRebate,
                rentAdjustment: this.props.history.location.state.rowID.original.rentAdjustment,
                totalRent:  this.props.history.location.state.rowID.original.totalRent,
                propertyTax: this.props.history.location.state.rowID.original.propertyTax,
              //currencyStatus: this.props.history.location.state.rowID.original.currencyStatus,
              //currencyName: this.props.history.location.state.rowID.original.currencyName,
                currency:  this.props.history.location.state.rowID.original.currency,
                invoiceType: this.props.history.location.state.rowID.original.invoicetype,
                spv:  this.props.history.location.state.rowID.original.spv,
                customer: this.props.history.location.state.rowID.original.customer,
                areaCode: this.props.history.location.state.rowID.original.areaCode,
                pmtTerms:  this.props.history.location.state.rowID.original.pmtterms,
                invoicingFrequencyInt:  this.props.history.location.state.rowID.original.invoicingFrequencyInt,
                invoicingStartDate:  this.props.history.location.state.rowID.original.invoiceStartDate,
                invoicingEndDate:  this.props.history.location.state.rowID.original.invoiceEndDate,
                invoicingEndDateErrorMessage: "",
                invoicingEndDateError: false,
                invoicePeriod:  this.props.history.location.state.rowID.original.invoicePeriod,
                leaseFee:  this.props.history.location.state.rowID.original.leasefee,
                index:  this.props.history.location.state.rowID.original.index,
                indexType:  this.props.history.location.state.rowID.original.indexType,
                indexScaling:  this.props.history.location.state.rowID.original.indexScaling,
                indexName: this.props.history.location.state.rowID.original.indexName,
                indexBaseDate: this.props.history.location.state.rowID.original.indexBaseDate,
                indexReviewDate:  this.props.history.location.state.rowID.original.indexReviewDate,
                indexReviewNumber: this.props.history.location.state.rowID.original.indexReviewNumber,
                indexBaseNumber:  this.props.history.location.state.rowID.original.indexBaseNumber,
                indexFloor:  this.props.history.location.state.rowID.original.indexFloor,
                rentAdjustmentPerBps:  this.props.history.location.state.rowID.original.rentAdjustmentPerBps,
                //numberBpsAdjustment: this.props.history.location.state.rowID.original.numberBpsAdjustment,
                vatableProportion:  this.props.history.location.state.rowID.original.vatableProportion,
                otherSupportingComments:  this.props.history.location.state.rowID.original.comments,
                status: this.props.history.location.state.rowID.original.status,
                successMessage:"",
                formErrorStatus:true,
                customerNameErrorMessage: "",
                customerNameError: false,
                leaseContractId: this.props.history.location.state.rowID.original.leaseContractId,
                leaseContractNumber: this.props.history.location.state.rowID.original.leaseContractNumber,
                indexReviewNo: this.props.history.location.state.rowID.original.indexReviewNo,
                invoiceId: this.props.history.location.state.rowID.original.invoiceId,
                interestRateFloor: this.props.history.location.state.rowID.original.interestRateFloor,
                interestRateName: this.props.history.location.state.rowID.original.interestRateName,
                interestRateReviewDate: this.props.history.location.state.rowID.original.interestRateReviewDate,
                invoiceCreatedDate: this.props.history.location.state.rowID.original.invoiceCreatedDate,
                invoiceEndDate: this.props.history.location.state.rowID.original.invoiceEndDate,
                invoiceStartDate: this.props.history.location.state.rowID.original.invoiceStartDate,
                numberBpsAdjustment: this.props.history.location.state.rowID.original.numberBpsAdjustment,
                margin: this.props.history.location.state.rowID.original.margin,
                presentValue: this.props.history.location.state.rowID.original.presentValue,
                rentAdjustmentBps: this.props.history.location.state.rowID.original.rentAdjustmentBps,
                tlp: this.props.history.location.state.rowID.original.tlp,
                invoiceCreditStatus: this.props.history.location.state.rowID.original.invoiceCreditStatus,
                bpsAdjValidDate: this.props.history.location.state.rowID.original.bpsAdjValidDate
              
            });
            
        }
        
        console.log("state: "+JSON.stringify(this.props.history.location.state.rowID.original));
        
    }

    handleChange = (e) => {
        if (e) {
            var val = e.target.value;
            var dataVal = val.trimLeft();
            if (e.target.name == "noofbpsadjustment") {
              
                this.setState({ numberBpsAdjustment: dataVal });
            }
            else if (e.target.name == "indexreviewnumber") {
               
                this.setState({ indexReviewNumber: dataVal });
            }
            else if (e.target.name == "currentindexreviewnumber") {
               
                this.setState({ currentIndexReviewNumber: dataVal });
            }
            else if (e.target.name == "indexdatereviewlogic") {
               
                this.setState({ indexDateReviewLogic: dataVal });
            }
            else if (e.target.name == "rentrebate") {
               
                this.setState({ rentRebate: dataVal });
            }
            else if (e.target.name == "othermanualadjustment") {
               
                this.setState({ otherManualAdjustment: dataVal });
            }
            else if (e.target.name == "currentindexreviewdate") {
                
                this.setState({ indexReviewDate: dataVal });
            }
            else if (e.target.name == "bpsAdjValidDate") {
                
                this.setState({ bpsAdjValidDate: dataVal });
            }
            else if (e.target.name == "vatableproportion") {
                
                this.setState({ vatableProportion: dataVal });
            }
            else if (e.target.name == "othersupportingcomments") {
                
                this.setState({ otherSupportingComments: dataVal });
            }
        }
        this.finalCheck();
    }
    finalCheck(){
        let localVariable = localStorage.getItem('errorStatusCalculateInterest');
        if (this.state.currentIndexReviewDateError == true || this.state.noOfBpsAdjustmentError == true
             || this.state.indexReviewNumberError == true || this.state.rentRebateError == true || this.state.otherManualAdjustmentError == true
             || this.state.vatableProportionError == true || this.state.otherSupportingCommentsError) 
        {
            this.setState({ formErrorStatus: true });
        }
        if (this.state.currentIndexReviewDateError == false && this.state.noOfBpsAdjustmentError == false
        && this.state.indexReviewNumberError == false && this.state.rentRebateError == false && this.state.otherManualAdjustmentError == false
            && this.state.vatableProportionError == false && this.state.otherSupportingCommentsError)  
        {  
             this.setState({ formErrorStatus: false });
        }
    }
    validateField(){
        let v = validateCalculateInterest('currentindexreviewdate', this.state.indexReviewDate);
        if (v[0] == null) {
            this.setState({ currentIndexReviewDateError: false, currentIndexReviewDateErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ currentIndexReviewDateError: !v[0], currentIndexReviewDateErrorMessage: v[1] });
        }
        let v1 = validateCalculateInterest('noofbpsadjustment', this.state.numberBpsAdjustment);

        if(v1[0] == null){
            this.setState({ noOfBpsAdjustmentError: false, noOfBpsAdjustmentErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ noOfBpsAdjustmentError: !v1[0], noOfBpsAdjustmentErrorMessage: v1[1] });
        }

        let v2 = validateCalculateInterest('indexreviewnumber', this.state.indexReviewNumber);

        if(v2[0] == null){
            this.setState({ indexReviewNumberError: false, indexReviewNumberErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ indexReviewNumberError: !v2[0], indexReviewNumberErrorMessage: v2[1] });
        }
        let v3 = validateCalculateInterest('rentrebate', this.state.rentRebate);

        if(v3[0] == null){
            this.setState({ rentRebateError: false, rentRebateErrorMessage: v3[1] });
        } else if (v3[0] != null) {
            this.setState({ rentRebateError: !v3[0], rentRebateErrorMessage: v3[1] });
        }
        let v4 = validateCalculateInterest('othermanualadjustment', this.state.otherManualAdjustment);

        if(v4[0] == null){
            this.setState({ otherManualAdjustmentError: false, otherManualAdjustmentErrorMessage: v4[1] });
        } else if (v4[0] != null) {
            this.setState({ otherManualAdjustmentError: !v4[0], otherManualAdjustmentErrorMessage: v4[1] });
        }
        let v5 = validateCalculateInterest('vatableproportion', this.state.vatableProportion);

        if(v5[0] == null){
            this.setState({ vatableProportionError: false, vatableProportionErrorMessage: v5[1] });
        } else if (v5[0] != null) {
            this.setState({ vatableProportionError: !v5[0], vatableProportionErrorMessage: v5[1] });
        }
        let v6 = validateCalculateInterest('othersupportingcomments', this.state.otherSupportingComments);

        if(v6[0] == null){
            this.setState({ otherSupportingCommentsError: false, otherSupportingCommentsErrorMessage: v6[1] });
        } else if (v6[0] != null) {
            this.setState({ otherSupportingCommentsError: !v6[0], otherSupportingCommentsErrorMessage: v6[1] });
        }
       

        
    }
        goToPage(pagename) {
            this.props.history.push({
                pathname: '/lms/' + pagename
            })
            return true;
        }
        
        recalculateInvoice(){
            //this.initForm();
            var currentComponent = this;
            
           // currentComponent.validateField();
           // currentComponent.finalCheck();
           for(var i = 0 ; i < currentComponent.state.periodTableData.length; i ++){
            if(currentComponent.state.periodTableData[i].invoiceId == currentComponent.state.invoiceId) {
                currentComponent.setState({
                    rentAdjustmentBps:currentComponent.state.periodTableData[i].rentAdjustmentBps,
                    numberBpsAdjustment:currentComponent.state.periodTableData[i].numberBpsAdjustment
                });
            }
        }
            let payLoadData = calculateIndexForm(currentComponent.state);
            let allInvoicesData = currentComponent.state.periodTableData;
            console.log("payLoadData= "+JSON.stringify(payLoadData));
            console.log("allInvoicesData= "+JSON.stringify(allInvoicesData));
                let output = HttpPost(currentComponent, payLoadData, API_ENDPOINT.RECALCULATION_MANUAL_INVOICE)
                .then(function (response) {
                    currentComponent.setState({summaryData:response});
                    currentComponent.setState({updatedInvoice:response.data});
                    console.log('1summaryData:'+JSON.stringify(currentComponent.state.summaryData)); 
                    // currentComponent.initForm();  
                })
                .catch(function (error) {
                    window.alert(error);
                });

            return true;
        }

        initInvoiceSummary(){
            // this.initForm();
             var currentComponent = this;
            // currentComponent.validateField();
            // currentComponent.finalCheck();
            console.log("state: "+JSON.stringify(this.state));
             let payLoadData = calculateIndexForm(this.state);
             console.log("payLoadData: "+JSON.stringify(payLoadData));
             var obj = {
                 invoiceId:0,
                 period: 0, 
                 rentAdjPerBps: 0, 
                 noOfBpsAdj: 0
             }
             var leaseContractNumber = payLoadData[0].leaseContractNumber;
             console.log('leaseContractNumber :'+leaseContractNumber);
             if(leaseContractNumber != null){

             
                 let output = HttpGet(currentComponent, API_ENDPOINT.GET_INVOICE_BY_ID+leaseContractNumber)
                 .then(function (response) {
                     currentComponent.setState({summaryData:response, allInvoicesForSave: response.data});
                     console.log("summary response: "+JSON.stringify(response));
                     // console.log("allInvoicesForSave: "+JSON.stringify(currentComponent.state.allInvoicesForSave));
                     var invoiceFrequencySelected = 1;
                     var rentAdjustmentBpsValue = 0;
                     var numberBpsAdjustment = 0;
                     let output = [];
                     for(var i=0;i<response.data.length;i++){
                            if(response.data[i].leaseContractNumber = currentComponent.state.leaseContractNumber)
                            {
                                
                            // obj.invoiceId = response.data[i].invoiceId;
                            // obj.period  = response.data[i].invoiceId; //= 0;
                            // obj.rentAdjPerBps = 0;
                            // obj.noOfBpsAdj = 0;
                            invoiceFrequencySelected = response.data[i].invoiceFrequency;
                            if( response.data[i].rentAdjustmentBps != null){
                                rentAdjustmentBpsValue =response.data[i].rentAdjustmentBps
                            }
                            if(  response.data[i].numberBpsAdjustment != null){
                                numberBpsAdjustment =response.data[i].numberBpsAdjustment
                            }
                            // currentComponent.state.periodTableData.push({
                            //     invoiceId:response.data[i].invoiceId,
                            //      period:  moment(response.data[i].invoiceStartDate).format('DD/MM/YYYY')  +' - '+moment(response.data[i].invoiceEndDate).format('DD/MM/YYYY'), 
                            //      rentAdjPerBps: rentAdjustmentBpsValue, 
                            //      noOfBpsAdj: numberBpsAdjustment
                            //  }); 
                            var newDate = new Date();
                            var currentDate =  newDate; 
                            output.push({
                                "invoiceId":response.data[i].invoiceId,
                                "baseRent":response.data[i].baseRent,
                                "indexAdjustment":response.data[i].indexAdjustment,
                                "interestAdjustment":response.data[i].interestAdjustment,
                                "rentRebate":response.data[i].rentRebate,
                                "rentAdjustment":response.data[i].rentAdjustment,
                                "totalRent":response.data[i].totalRent,
                                "invoiceType":response.data[i].invoiceType,
                                "spv":response.data[i].spv,
                                "customer":response.data[i].customer,
                                "areaCode":response.data[i].areaCode,
                                "currency":response.data[i].currency,
                                "pmtTerms":response.data[i].pmtTerms,
                                "invoiceFrequency":response.data[i].invoiceFrequency,
                                "invoiceStartDate":response.data[i].invoiceStartDate,
                                "invoiceEndDate":response.data[i].invoiceEndDate,
                                "leaseFee":response.data[i].leaseFee,
                                "index":response.data[i].index,
                                "indexType":response.data[i].indexType,
                                "indexScaling":response.data[i].indexScaling,
                                "indexName":response.data[i].indexName,
                                "indexBaseDate":response.data[i].indexBaseDate,
                                "indexBaseNo":response.data[i].indexBaseNo,
                                "indexFloor":response.data[i].indexFloor,
                                "rentAdjustmentBps":response.data[i].rentAdjustmentBps,
                                "numberBpsAdjustment":response.data[i].numberBpsAdjustment,
                                "vatableProportion":response.data[i].vatableProportion,
                                "comments":response.data[i].comments,
                                "status":response.data[i].status,
                                "bookValueScaler":response.data[i].bookValueScaler,
                                "presentValue":response.data[i].presentValue,
                                "futureValue":response.data[i].futureValue,
                                "depreciation":response.data[i].depreciation,
                                "margin":response.data[i].margin,
                                "tlp":response.data[i].tlp,
                                "interestRateFloor":response.data[i].interestRateFloor,
                                "interestRateName":response.data[i].interestRateName,
                                "interestRateReviewDate":response.data[i].interestRateReviewDate,
                                "invoicePeriod":response.data[i].invoicePeriod,
                                "propertyTax":response.data[i].propertyTax,
                                "invoiceCreatedDate":response.data[i].invoiceCreatedDate,
                                "invoiceUpdatedDate":response.data[i].invoiceUpdatedDate,
                                "franchiseName":response.data[i].franchiseName,
                                "indexReviewDate":response.data[i].indexReviewDate,
                                "indexReviewNo":response.data[i].indexReviewNo,
                                "actionNeeded":response.data[i].actionNeeded,
                                "baseRentFixed":response.data[i].baseRentFixed,
                                "interestAdjFixed":response.data[i].interestAdjFixed,
                                "totalRentFixed":response.data[i].totalRentFixed,
                                "bookValueScalerFixed":response.data[i].bookValueScalerFixed,
                                "interestRateFixed":response.data[i].interestRateFixed,
                                "interestRateFloating":response.data[i].interestRateFloating,
                                "baseRentDescription":response.data[i].baseRentDescription,
                                "rentRebateDescription":response.data[i].rentRebateDescription,
                                "indexAdjDescription":response.data[i].indexAdjDescription,
                                "interestAdjDescription":response.data[i].interestAdjDescription,
                                "rentAdjDescription":response.data[i].rentAdjDescription,
                                "propertyTaxDescription":response.data[i].propertyTaxDescription,
                                "leaseContractNumber":response.data[i].leaseContractNumber,
                                "leaseContractId":response.data[i].leaseContractId,
                                "period": moment(response.data[i].invoiceStartDate).format('DD/MM/YYYY') +'-'+moment(response.data[i].invoiceEndDate).format('DD/MM/YYYY'),
                                "invoiceCreditStatus": response.data[i].invoiceCreditStatus,
                               
                                "isCreditNote":  response.data[i].isCreditNote,
                                "approvedDate":  response.data[i].approvedDate,
                                "creditDate": response.data[i].creditDate, 
                                "isNewInvoice": response.data[i].isNewInvoice, //value.isNewInvoiceValue,
                                "bpsAdjValidDate":response.data[i].bpsAdjValidDate,
                                "invoiceCreditType":response.data[i].invoiceCreditType,
                                "indexGradeNumber":response.data[i].indexGradeNumber,
                                
                            });
                            }
                            
                            
                    }
                    currentComponent.setState({periodTableData : output});
                    console.log("periodTableData: "+JSON.stringify(currentComponent.state.periodTableData));
                   
                    
                  
                      currentComponent.initForm();
                 })
                 .catch(function (error) {
                     window.alert(error);
                     console.log(error);
                 });
                }
                else{
                    alert("No valid Deal ID is available, A valid Deal is required to genarate invoice summary. Thanks!");
                    this.props.history.push({
                        // pathname: '/lms/interestInvoicingForm',
                        pathname: '/lms/invoiceList',
                     
                        })
                }
             return true;
         }

         get rows () {
            return this.state.periodTableData
          }
        
          get rowsCount () {
            return this.state.periodTableData.length
          }
        
          rowGetter (i) {
            return this.state.periodTableData[i]
          }
        
          handleGridRowsUpdated ({fromRow, toRow, updated}) {
              console.log(fromRow);
            this.setState(prevState => ({periodTableData: prevState.periodTableData.map(toUpdatedRows)}))
        
            function toUpdatedRows (row, i) {
              if (isOutOfRange(i)) return row
              return Object.assign({}, row, updated)
            }
        
            function isOutOfRange (i) {
              return i < fromRow || i > toRow
            }
          }

        saveInvoice(){
            //this.initForm();
            var currentComponent = this;
           // currentComponent.validateField();
            currentComponent.finalCheck();
            let payLoadData = [];
            if(this.state.updatedInvoice != undefined && this.state.updatedInvoice != null) {
               // payLoadData = this.state.updatedInvoice;
            }   
            console.log("allInvoicesForSave: "+JSON.stringify(currentComponent.state.allInvoicesForSave));
            for(var i = 0 ; i< currentComponent.state.allInvoicesForSave.length;i ++) {
                console.log(currentComponent.state.updatedInvoice[0].invoiceId);
                console.log(currentComponent.state.allInvoicesForSave[i].invoiceId);
                 if(currentComponent.state.allInvoicesForSave[i].invoiceId == currentComponent.state.updatedInvoice[0].invoiceId){
                    console.log("currentComponent.state.allInvoicesForSave[i].invoiceId :"+i+' '+currentComponent.state.allInvoicesForSave[i].invoiceId);
                    // need to pop the previous object and add the updated one from updatedInvoice
                   var updated = currentComponent.state.allInvoicesForSave.slice(0,i);
                   console.log(currentComponent.state.allInvoicesForSave[i].invoiceId);
                   console.log("Split: "+JSON.stringify(updated));
                   
                    }
            }
            currentComponent.state.allInvoicesForSave.push(currentComponent.state.updatedInvoice[0]);
                   console.log('Updated: '+JSON.stringify(currentComponent.state.allInvoicesForSave));
                  
                   payLoadData = currentComponent.state.allInvoicesForSave;
                  var payloadPeriodTable = currentComponent.state.periodTableData;
                   console.log("payLoadData Updated: "+JSON.stringify(payloadPeriodTable));
                // -- hotfix
                  let output = HttpPut(currentComponent, payloadPeriodTable, API_ENDPOINT.SAVE_UPDATED_INVOICE)
                .then(function (response) {
                    window.scrollTo(0, 0);
                    // currentComponent.setState({pageSuccessStatus:true});
                    //  currentComponent.setState({pageSuccessStatus:true});
                      //window.alert(JSON.stringify(response.data));
                      baseRentSummary = currentComponent.state.summaryData.data[0].baseRent.toString();
                      currencySummary = currentComponent.state.summaryData.data[0].currency.toString();
                      //currentComponent.initForm();
                      // -- second call
                         let output = HttpPut(currentComponent, payLoadData, API_ENDPOINT.SAVE_UPDATED_INVOICE)
                .then(function (response) {
                    window.scrollTo(0, 0);
                    currentComponent.setState({pageSuccessStatus:true});
                     currentComponent.setState({pageSuccessStatus:true});
                      //window.alert(JSON.stringify(response.data));
                      baseRentSummary = currentComponent.state.summaryData.data[0].baseRent.toString();
                      currencySummary = currentComponent.state.summaryData.data[0].currency.toString();
                      //currentComponent.initForm();
                      currentComponent.initInvoiceSummary();
                })
                .catch(function (error) {
                    window.alert(error);
                });
                      // -- ends here
                })
                .catch(function (error) {
                    window.alert(error);
                });

                // -- ends
                
                  
            return true;
        }

        cellupdate(val) {

           
            // updatedInvoice
            for(var i = 0 ; i < val.length; i ++){
                if(this.state.leaseContractNumber == val[i].leaseContractNumber && this.state.periodTableData[i].invoiceId == this.state.updatedInvoice[0].invoiceId) {

                    this.setState({
                        rentAdjustmentBps:this.state.periodTableData[i].rentAdjustmentBps,
                        numberBpsAdjustment:this.state.periodTableData[i].numberBpsAdjustment
                    });
                }
            }
            for(var i = 0 ; i < val.length; i ++){
                if(this.state.leaseContractNumber == val[i].leaseContractNumber && this.state.periodTableData[i].invoiceId == this.state.invoiceId) {

                    this.setState({
                        rentRebate: this.state.periodTableData[i].rentRebate,
                        rentAdjustmentBps:this.state.periodTableData[i].rentAdjustmentBps,
                        numberBpsAdjustment:this.state.periodTableData[i].numberBpsAdjustment
                    });
                }
            }
            console.log('cellupdate'+JSON.stringify(val));
            console.log('periodTableData'+JSON.stringify(this.state.periodTableData));
            console.log('updatedInvoice'+JSON.stringify(this.state.updatedInvoice));

        }

        renderEditable(cellInfo) {
            // return (
            //   <div
            //     style={{ backgroundColor: "#fafafa" }}
            //     contentEditable
            //     suppressContentEditableWarning
            //     onBlur={e => {
            //       const data = [...this.state.periodTableData];
            //       data[cellInfo.index][cellInfo.column.id] = e.target.innerHTML;
            //       this.setState({ periodTableData:data });
            //     }}
            //     dangerouslySetInnerHTML={{
            //       __html: this.state.periodTableData[cellInfo.index][cellInfo.column.id]
            //     }}
            //   />
            // );
            return (
                <input type="number"
                    className={"invoice_recal_grid_cell"}
                    placeholder="Enter"
                    key={cellInfo.index}
                    name={"'"+cellInfo.index+"'"}
                    value={this.state.periodTableData[cellInfo.index][cellInfo.column.id]}
                    onChange={e => {
                        let data = [...this.state.periodTableData];
                        data[cellInfo.index][cellInfo.column.id] = e.target.value;
                        this.setState({periodTableData: data });
                        // this.state.tlpRecord = data;
                        this.cellupdate(this.state.periodTableData);
                    }}
                />            
            );
          
          }

          renderEditableADJ(cellInfo) {
            // return (
            //   <div
            //     style={{ backgroundColor: "#fafafa" }}
            //     contentEditable
            //     suppressContentEditableWarning
            //     onBlur={e => {
            //       const data = [...this.state.periodTableData];
            //       data[cellInfo.index][cellInfo.column.id] = e.target.innerHTML;
            //       this.setState({ periodTableData:data });
            //     }}
            //     dangerouslySetInnerHTML={{
            //       __html: this.state.periodTableData[cellInfo.index][cellInfo.column.id]
            //     }}
            //   />
            // );
            return (
                <input type="number"
                    className={"invoice_recal_grid_cell " } //+ (this.state.gbpCellStatus[cellInfo.index] ? 'cell_error' : '')
                    placeholder="Enter"
                    key={cellInfo.index}
                    name={"'"+cellInfo.index+"'"}
                    value={this.state.periodTableData[cellInfo.index][cellInfo.column.id]}
                    onChange={e => {
                        let data = [...this.state.periodTableData];
                        data[cellInfo.index][cellInfo.column.id] = e.target.value;
                        this.setState({ periodTableData: data });
                        // this.state.tlpRecord = data;
                        this.cellupdate(this.state.periodTableData);
                    }}
                />            
            );
          
          }

        getCurrentIndexReviewDate(e) {
            if (e != null) {
                var startDate = Date.parse(e);
                this.state.currentIndexReviewDate = moment(startDate).format('YYYY-MM-DD');
                this.state.indexReviewDate = moment(startDate).format('YYYY-MM-DD');
               // this.validateField();
                this.finalCheck();
            }
            return true;
        } 

        getBpsAdjValidDate(e) {
            if (e != null) {
                var BpsAdjValidDate = Date.parse(e);
            this.state.bpsAdjValidDate = moment(BpsAdjValidDate).format('YYYY-MM-DD');
        }

            return true;
        }
      
        
        
    confirm = () => {
        this.props.history.push({
            pathname: '/lms/viewCustomerDetail',
            state: { rowID: this.state.partyid }
        })
        return true;
    }

    onGridRowsUpdated = ({ fromRow, toRow, updated }) => {
        this.setState(state => {
          const rows = state.rows.slice();
          for (let i = fromRow; i <= toRow; i++) {
            rows[i] = { ...rows[i], ...updated };
          }
          return { rows };
        });
      };

    generateData(type) {
        const data = [];
        if (type == "indexdatereviewlogic") {
            data.push(
                "",
                "WD 5 of preceding month",
                "WD 4 of preceding month",
                "WD 3 of preceding month",
                "WD 2 of preceding month",
                "WD 1 of preceding month"
            );
        }
        return data
    }

    getDropdownItem(event, val, type) {
        if (event == "indexdatereviewlogic") {
            if (type.value != "") {
                this.setState({ indexDateReviewLogic: type.value });
            } else {
                this.setState({ indexDateReviewLogic: type.value });
            }
        }
        return true;
    }

    handleRentAdjPerBpsChange( event, tableData ) {
        
        console.log( tableData);
        console.log(event.rentAdjustmentBps);
      for (var i=0 ; i < this.state.periodTableData.length ; i++){
            if (event.invoiceId == this.state.periodTableData[i].invoiceId) {
                this.state.periodTableData[i].rentAdjustmentBps = event.rentAdjustmentBps;
                this.forceUpdate()
               console.log( this.state.periodTableData[i].rentAdjustmentBps );
            }
        }
        //this.renderTableData()
    }

    handleNoOfBpsAdjChange(event, tableData) {

        for (var i=0 ; i < this.state.periodTableData.length ; i++){
            if (event.invoiceId == this.state.periodTableData[i].invoiceId) {
                this.state.periodTableData[i].numberBpsAdjustment = event.numberBpsAdjustment;
                this.forceUpdate()
               console.log(this.state.periodTableData[i].numberBpsAdjustment );
            }
        }
       
    }

    renderTableData(val) {
        console.log(val);
        var updatedArray = [] ;
       // console.log('tableData: '+JSON.stringify(this.state.periodTableData));
        return this.state.periodTableData.map((key,value,i) => {
         //  var {invoiceId, period, rentAdjPerBps, noOfBpsAdj} = tableData //destructuring
         console.log(key+' '+value+' '+i);
//             for(var j =0 ; j< updatedArray.length; j++) {

//                 if (updatedArray[j].invoiceId == value.invoiceId){
//                     updatedArray[j].rentAdjustmentBps = value.rentAdjustmentBps
//                 }
//             }
// return (
//                  <tr key={value.invoiceId}>
//                    <td><b>{moment(value.invoiceStartDate).format('YYYY-MM-DD')} -  {moment(value.invoiceEndDate).format('YYYY-MM-DD')} </b></td>
//                    <td>{<input id={value.invoiceId} type="text" style={{textAlign: 'center'}} value={this.state.periodTableData[i].rentAdjustmentBps } onChange={this.renderTableData.bind(this,value)} />}</td>
//                    <td>{<input id={value.invoiceId} type="text" style={{textAlign: 'center'}} value={this.state.periodTableData[i].numberBpsAdjustment} onChange={this.renderTableData.bind(this, value)} />}</td>
//                  </tr>
//              )
         
           
        })
        
     }

     renderTableHeader() {
        let header = Object.keys(this.state.periodTableHeader[0])
       // console.log('header: '+header);
        return header.map((value, index) => {
            return <th key={index}>{value}</th>
        })
     }

     tableEventHandler() {
        console.log('Alert');
     }

    

    
    render() {
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btndisable = false;
        //check memberOf
        if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") <= 0){
            console.log("Sfs")
            btndisable = true;
        }
        console.log(btndisable);
        // <div><span className="table_nameprop">Period</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>
        const columns = [{
            key: 'period',
            name: 'period',
            Header: props => <div><span className="">Period</span></div>,
            accessor: 'period', // String-based value accessors!
            headerClassName: 'theader',
            editable: true,
          
            
        },{
            key: 'rentadjbps', 
            name: 'rentadjbps', 
            Header: props => <div><span className="">Rent Adj/bps</span></div>,
            accessor: 'rentAdjustmentBps', 
            headerClassName: 'theader',
            editable: true,
            Cell: this.renderEditable
            
        },
        {
            key: 'noofbpsadj', 
            name: 'noofbpsadj', 
            Header: props => <div><span className="">No. of bps Adj</span></div>,
            accessor: 'numberBpsAdjustment',
            headerClassName: 'theader',
            editable: true,
            Cell: this.renderEditableADJ
            
        }];

        //console.log("New Data: "+JSON.stringify(this.state.summaryData));
        //console.log("Summary Data: "+JSON.stringify(this.state.summaryData));
       
        
        return (
            <div className="background">
               

                <div onClick={this.goToPage.bind(this,'invoiceList')} style={{
                    
                    width: '1244px', marginLeft: '83px'}}>
                    <Icon name="chev-left-xsmall" size="xsmall" className="back_arrow" title=""/>
                        <span className="all_party" >All Invoices</span>
                </div>
                {
                    this.state.serverError ?
                        <Notification status='error' className="Confirmation_header_new" size='medium' title='Server Error'>
                     
                </Notification>
                        : null
                }
                {
                    this.state.pageSuccessStatus ?
                    <Notification className="Confirmation_header_new" style={{ width: '1100px' }} status='success' size='large' title='Invoice updated successfully'>
                        
                </Notification>
                        : null
                }  
                {this.state.isLoading == true ? 
                        <div  style={{ marginLeft: '50px' }}>
                            <div className="zb-loader-block zb-loader-block-inverted">
                            <div className="zb-loader-content">
                                <span className="zb-loader" />
                                <span className="zb-loader-text">
                                Loading...
                                </span>
                            </div>
                            </div>
                    </div> : null } 

                <div className="form-group row" style={{
                    margin: '64px auto 0px 1%',
                    width: '1244px'
                }}>
                    <div className="col-sm-7">
                        <label className="model_title">Re-calculate Invoice {this.state.spv} {this.state.customer}</label>
                    </div>

                </div>
                <div className="row">
                    <div className="col-sm-7">
                    {/* paddingBottom: '616px'  */}
                    <div class="invoice_container" style={{ marginBottom: '24px'}}>
                            <div class="inner_column">
                                <label class="label_title">Invoice calculations</label><br/>
                                <label className="help_label">
                                 Please provide the information below
                                 to re-calculate this invoice. For
                                </label> <br/>
                                <label class="help_label">fields that are irrelevant please type in value '0'.</label>
                                
                                <br/>  <label class="label_title">Index Adjustment</label><br/>
                            </div>
                                <form class="user_form">
                                {/* Index Manual Form */}
                                    <div className="row"> 
                                        <div className="col-sm-8 form_field_adjustment">
                                        <Calenderinputfield fieldTitle="Current index review date" 
                                        value={this.state.indexReviewDate}
                                        inputType="date" name="currentindexreviewdate" 
                                        onChange={this.getCurrentIndexReviewDate} 
                                        placeholder="DD/MM/YYYY" errorStatus={this.state.currentIndexReviewDateError}
                                        errorMessage={this.state.currentIndexReviewDateErrorMessage} />
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>

                                        <div className="row"> 
                                        <div className="col-sm-12 form_field_adjustment">
                                        <Dropdownfieldcustom customLabel="field_label_model_select_recal" 
                                        title="Index date review logic" classname="font_config_custom" 
                                    data={this.generateData('indexdatereviewlogic')} name="indexdatereviewlogic"
                                    errorStatus={this.state.currencyStatus} errorMessage={this.state.dealErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'indexdatereviewlogic')} selectedValue={this.state.indexDateReviewLogic} isDisabled=''/>
                                     </div>
                                        
                                        </div>


                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_recal" fieldTitle="Current index review number " maxlength="30" value={this.state.currentIndexReviewNumber} inputType="text"
                                        name="currentindexreviewnumber" onChange={this.handleChange} placeholder="Enter"
                                        errorStatus={this.state.noOfBpsAdjustmentError}
                                        errorMessage={this.state.noOfBpsAdjustmentErrorMessage} 
                                        />
                                        </div>
                                        </div>
                                     

                                        {/* <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_recal" fieldTitle="Number of bps adjustment" maxlength="30" value={this.state.numberBpsAdjustment} inputType="text"
                                        name="noofbpsadjustment" onChange={this.handleChange} placeholder="Enter"
                                        errorStatus={this.state.noOfBpsAdjustmentError}
                                        errorMessage={this.state.noOfBpsAdjustmentErrorMessage} 
                                        />
                                        </div>
                                        </div> */}

                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Index review number" maxlength="30" value={this.state.indexReviewNumber} inputType="text"
                                        name="indexreviewnumber" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.indexReviewNumberError}
                                        errorMessage={this.state.indexReviewNumberErrorMessage}
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_small"></label>
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_recal" fieldTitle="Rent rebate" maxlength="30" value={this.state.rentRebate} inputType="text"
                                        name="rentrebate" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.rentRebateError}
                                        errorMessage={this.state.rentRebateErrorMessage}
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur"></label>
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_recal" fieldTitle="Other manual adjustment" maxlength="30" value={this.state.otherManualAdjustment} inputType="text"
                                        name="othermanualadjustment" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.otherManualAdjustmentError}
                                        errorMessage={this.state.otherManualAdjustmentErrorMessage}
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur"></label>
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Vatable proportion" maxlength="30" value={this.state.vatableProportion} inputType="text"
                                        name="vatableproportion" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.vatableProportionError}
                                        errorMessage={this.state.vatableProportionErrorMessage}
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_small">%</label>
                                        </div>
                                         <div className="row">
                                    <div className="col-sm-8 form_field_adjustment">
                                    <Inputfield fieldTitle="Other supporting comments" maxlength="30" value={this.state.otherSupportingComments} inputType="text"
                                        name="othersupportingcomments" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.otherSupportingCommentsError}
                                        errorMessage={this.state.otherSupportingCommentsErrorMessage}
                                        />  
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div>


                    <div className="Separator_line"></div>  

                  
            {/* <h1 id='title'></h1>
            <table id='periodtable' >
               <tbody>
                  <tr>{this.renderTableHeader()}</tr>
                  {this.renderTableData(this.state.periodTableData)}
               </tbody>
            </table>
             */}
             
         
            
         
                      
           
                                
            
            <ReactTable
            data={this.state.periodTableData}//{UserData}//{this.state.customerRecord}
            columns={columns}
            rows={this.state.periodTableData}
            loading={this.state.loading}
            // showPagination = {true}
            // showPaginationTop = {false}
            // showPaginationBottom = {true}
            // showPageSizeOptions = {true}
            className= 'griddata'
            //  style = {"border: 1px solid blue"}
            
            onChange={this.tableEventHandler.bind(this)}
            headerClassName= 'theader'
           //  pageSizeOptions = {[5, 10, 20, 25, 50, 100]}
            defaultPageSize = {5}
            // pageSize={this.props.selectedRecord}
            rowGetter={this.rowGetter.bind(this)}
            rowsCount={this.rowsCount}
            enableCellSelect
            onGridRowsUpdated={this.handleGridRowsUpdated.bind(this)}
            // PaginationComponent={Pagination}
            // onFilteredChange = {undefined}
            // defaultSortDesc = {false}
            // // onFilteredChange={(filtered, column) => {... }
            // previousText = 'Previous'
            // nextText = 'Next'
            // loadingText = 'Loading...'
            // noDataText= 'No rows found'
            // pageText= 'Page'
            // ofText= 'of'
            // rowsText= 'rows'
           
        />
        <div className="row"> 
                                        <div className="col-sm-8 form_field_adjustment_valid_date">
                                        <Calenderinputfield fieldTitle="Valid date" 
                                        value={this.state.bpsAdjValidDate}
                                        inputType="date" name="bpsAdjValidDate" 
                                        onChange={this.getBpsAdjValidDate} 
                                        placeholder="DD/MM/YYYY"  />
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>
               <div disabled={this.state.status != 'Not Started'} class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button disabled={this.state.status != 'Not Started' || btndisable} type="button" className="zb-button zb-button-secondary recalc_invoice_btn" data-toggle="modal"  onClick={this.recalculateInvoice.bind(this)}>Re-calculate rent</button>
                </div>
                                </form>
            </div>
            
          
        </div>
        
        <div className="col-sm-4">
        <div class="invoice_container_darker" style={{ marginBottom: '12px' }}>
            <label class="label_title">Invoice summary</label>
            
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Base rent</label>
                <label class="col-sm-8 field_back_label_Black">{this.state == undefined || this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0  || this.state.summaryData.data[0].baseRent == undefined ? "" : Math.round((this.state.summaryData.data[0].baseRent + Number.EPSILON) * 100) / 100 } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index adjustment</label>
                <label class="col-sm-8 field_back_label_Black">{this.state == undefined || this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0  || this.state.summaryData.data[0].baseRent == undefined ? "" :   Math.round(( this.state.summaryData.data[0].indexAdjustment + Number.EPSILON) * 100) / 100  }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest adjustment</label>
                <label class="col-sm-8 field_back_label_Black">{this.state == undefined || this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0  || this.state.summaryData.data[0].baseRent == undefined ? "" :  Math.round(( this.state.summaryData.data[0].interestAdjustment + Number.EPSILON) * 100) / 100 }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Rent adjustment</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0 || this.state.summaryData.data[0].rentAdjustment == null  ? "NA" : Math.round(( this.state.summaryData.data[0].rentAdjustment + Number.EPSILON) * 100) / 100  } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div><div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"> Rent rebate</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0  || this.state.summaryData.data[0].rentRebate == null ? "NA" : Math.round(( this.state.summaryData.data[0].rentRebate + Number.EPSILON) * 100) / 100  } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Property tax</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0 || this.state.summaryData.data[0].propertyTax ==null  ? "0" :  Math.round((  this.state.summaryData.data[0].propertyTax  + Number.EPSILON) * 100) / 100 } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div><div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Total rent</label>
                {/* <label class="col-sm-8 field_back_label_Black"> {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label> */}
                                <label class="col-sm-8 field_back_label_Black">    {Math.round(((this.state.summaryData.data[0].propertyTax == null ? 0: this.state.summaryData.data[0].propertyTax) + (this.state.summaryData.data[0].rentRebate == null ? 0 : this.state.summaryData.data[0].rentRebate) + (this.state.summaryData.data[0].rentAdjustment == null ? 0 : this.state.summaryData.data[0].rentAdjustment) + (this.state.summaryData.data[0].interestAdjustment == null ? 0 : this.state.summaryData.data[0].interestAdjustment) +  (this.state.summaryData.data[0].indexAdjustment == null ? 0 : this.state.summaryData.data[0].indexAdjustment) + (this.state.summaryData.data[0].baseRent == null ? 0 : this.state.summaryData.data[0].baseRent) + Number.EPSILON) * 100) / 100  } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div>
           
            <div className="Separator_line"></div>  
        </div>
        

        <div class="invoice_container_darker" style={{ marginTop: '-2%' }}>
            <label class="label_title">Invoice details</label>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoice type</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].invoiceType }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">SPV</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].spv }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"> Customer</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].customer }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Area code</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].areaCode }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Currency</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">PMT terms</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].pmtTerms }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoicing frequency</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].invoiceFrequency }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoicing period</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : moment(this.state.summaryData.data[0].invoiceStartDate).format('YYYY-MM-DD') +' - ' +moment(this.state.summaryData.data[0].invoiceStartDate).format('YYYY-MM-DD') }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Lease fee</label> 
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : Math.round((this.state.summaryData.data[0].leaseFee + Number.EPSILON) * 100) / 100  } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div>
            <div className="Separator_line"></div>    
        </div>

        <div class="invoice_container_darker" style={{ marginTop: '-2px', marginLeft: '1.2%' }}>
            <label class="label_title">Indexation figures</label>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].index }</label>
                </div>
            </div>
            {/* <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index grade</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div> */}
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"> Index scaling</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].indexScaling } {this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].currency }</label>
                </div>
            </div>
            {/* <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">First index rate</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div> */}
            {/* <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Indexation frequency</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Indexation month</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Floating index?</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div> */}
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index name</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].indexName }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index base date</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0 || this.state.summaryData.data[0].indexBaseDate == null  ? "NA" :  moment(this.state.summaryData.data[0].indexBaseDate).format('YYYY-MM-DD') }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index base number</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].indexBaseNo }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index floor</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].indexFloor }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Rent adjustment per bps</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].rentAdjustmentBps }</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Number of bps adjustment</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].numberBpsAdjustment }</label>
                </div>
            </div>
            {/* <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index apply date 1</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Index apply date 2</label>
                <label class="col-sm-8 field_back_label_Black">3,456.00 EUR</label>
                </div>
            </div> */}

        </div>
        <div class="invoice_container_darker" style={{ marginTop: '-2%' }}>
            <label class="label_title">Interest adjustment</label>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoice type</label>
                <label class="col-sm-8 field_back_label_Black">{this.state.summaryData == undefined || this.state.summaryData == null || this.state.summaryData.length == 0   ? "" : this.state.summaryData.data[0].invoiceType }</label>
                </div>
            </div>
            
            <div className="Separator_line"></div>    
        </div>
                    
        </div>
  </div>
  <div class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button disabled={this.state.status != 'Not Started'} type="button" onClick={this.saveInvoice.bind(this)} className="zb-button zb-button-primary model_invoice_btn">Save updates</button> 
                    {/* onClick={this.saveInvoice.bind(this)} */}
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" data-toggle="modal" data-target="#cancelSave" >Cancel updates</button>
                </div>
</div>
        )
    }
}

export default recalculateIndex;