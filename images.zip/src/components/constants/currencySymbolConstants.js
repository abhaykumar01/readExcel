export const currencySymbols = {
    "Denmark":"DKK",
    "Finland":"EUR",
    "Norway":"NOK",
    "Sweden":"SEK"
}