import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import Home from './home.js';
import Adapter from 'enzyme-adapter-react-16';
import renderer from 'react-test-renderer';
import { BrowserRouter as Router } from 'react-router-dom';

Enzyme.configure({ adapter: new Adapter() });

let wrapper;
beforeEach(() => {
    wrapper = shallow(<Home />);
});

describe('Customer component', () => {
    test('should shallow correctly', () => {
        expect(wrapper).toMatchSnapshot()
    })

    test('should mount correctly', () => {
        expect(mount(
            <Router>
                <Home />
            </Router>
        )).toMatchSnapshot()
    })

    test('should render <button>', () => {
        expect(wrapper.find('button')).toHaveLength(3);
    });
});