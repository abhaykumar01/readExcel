import React from 'react';
import './home.css';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/icons.js';
import { HttpPost, HttpGet } from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { Icon } from '@zambezi/sdk/icons';
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;
// import console = require('console');

class Home extends React.Component {
  static contextType = AuthorizationContext
  constructor(props) {
    super(props);
    this.state = {
      gridCount: 0,
      showPendingNotificationStatus: false,
      permissionData: {},
      memberOfDetail:'',
    }
  }

  componentDidMount() {
    var data;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            memberOf =usersDetails.memberOf;
        } else { 
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            memberOfDetail:memberOf
        });
    // var currentComponent = this;
    // let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/LmsUser/Pending_For_Approval';
    // let output1 = HttpGet(endPoint).then(function (response) {
    //   if (response.data.length > 0) {
    //     currentComponent.setState({ gridCount: 1 });
    //     currentComponent.setState({ showPendingNotificationStatus: true });
    //   } else {
    //     currentComponent.setState({ showPendingNotificationStatus: false });
    //   }
    // })
    //   .catch(function (error) {
    //   })
  }

  goToPage(pagename) {
    // localStorage.setItem('serverDown', 'true');
    // pagename = 'serverDown';
    this.props.history.push({
      pathname: '/lms/' + pagename
    })
    return true;
  }

  render() {
    console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        console.log(this.state.memberOfDetail);
        var btndisable = false;
        //check memberOf
        if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0){
        // if(this.state.memberOfDetail == "rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser"){
            // for (var i = 0; i < datalen; i++) { 
            //     if (perData[i] == "Customer_Edit_Contact") { 
            //         btndisable = true; // test
            //     }
            // }
            btndisable = true;
        }
        var isDisableAssetBtn = true;
        for (var i = 0; i < datalen; i++) { 
          if (perData[i] == "Asset_Add") { 
            isDisableAssetBtn = false;
          }
      }
      var disableModelNewDealBtn = true;

        for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Model_New_Deal") { 
                  disableModelNewDealBtn = false;
                }
            }
        
        console.log("Button disabled");
        console.log(btndisable);
    return (
      <div className="background">
        <div className="home_container" style={{ textAlign: 'center' }}>
          <div className="form-group row" style={{ padding: '20px', marginLeft: '130px' }}>
            <button className='zb-button zb-button-primary home_btn home_btn_text' disabled={disableModelNewDealBtn} onClick={this.goToPage.bind(this, 'modelNewDeal')}>Model a new deal</button>
            <button className='zb-button zb-button-primary home_btn home_btn_text' disabled={btndisable} onClick={this.goToPage.bind(this, 'addCustomer')}>Add a new customer</button>
            <button className='zb-button zb-button-primary home_btn home_btn_text' disabled={isDisableAssetBtn} onClick={this.goToPage.bind(this, 'property')}>Add a new asset</button>
            {/* <button className='zb-button zb-button-primary home_btn home_btn_text' onClick={this.goToPage.bind(this,'addCustomer')}>Add a new party</button>
            <button className='zb-button zb-button-primary home_btn home_btn_text' onClick={this.goToPage.bind(this, 'modelNewDeal')}>Model a new deal</button> */}
          </div>
          {this.state.showPendingNotificationStatus ?
            <button className='zb-feature-button zb-center home_notification_btn' onClick={this.goToPage.bind(this, 'ApproveTLPGrid')}>
              <span className='zb-feature-button-arrowed-content'>
                <Icon name="information-medium" title=""/> <span style={{ marginLeft: '5px' }}>You have {this.state.gridCount} grid pending for approval</span>
              </span>
            </button>
            : null}
        </div>
      </div>

    )
  }
}

export default Home;