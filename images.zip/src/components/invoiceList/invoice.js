import React from 'react';
import './invoice.css';
import { HttpPost, HttpGet, HttpPut} from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { Icon } from '@zambezi/sdk/icons';
import NotificationGrid from '../../commonComponents/notificationGrid';
import InvoiceListGrid from '../../commonComponents/invoiceListGrid';
import { Select } from '@zambezi/sdk/dropdown-list';
import { multipleExport } from '../../models/dataModel.js';
import { Notification } from '@zambezi/sdk/notification';
import Dropdownfieldcustom from '../../commonComponents/DropdownFieldCustom';
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;

var isExportBtnDisabled= true;
var isRequestApprovalBtnDisabled = true;
class invoiceList extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            recordView: 10,
            isExportBtnDisabled:true,
            isRequestApprovalBtnDisabled:true,
            completeData:[],
            invoicaDatastatus: false,
            pageStatus:'',
            isLoading:false,
            languageName:"English", 
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
        }
    }

    HandleSelectChange(event, type, value) {
        this.setState({ recordView: type.value });
    }

    componentDidMount() {
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
        // var currentComponent = this;
        // let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/Anitha/Pending_For_Approval';

        // let output1 = HttpGet(endPoint).then(function (response) {
        //     if (response.data.length > 0) {
        //         currentComponent.setState({ gridCount: 1 });
        //         currentComponent.setState({ showPendingNotificationStatus: true });
        //     } else {
        //         currentComponent.setState({ showPendingNotificationStatus: false });
        //     }
        // })
        //     .catch(function (error) {
        //     })
    }

   

    goToPage(pagename) {
        this.props.history.push({
            pathname: '/lms/' + pagename
        })
        return true;
    }
    
    getGridData(completeData){
        this.setState({completeData: completeData});
    }
    getDropdownItem(event, val, type) {
        if (event == "languagepreference") {
            if (type.value != "") {
                this.setState({ languageName: type.value });
            } else {
                this.setState({ languageName: type.value });
            }
        }
        return true;
    }
    requestApprovalHandle(){
        var filteredData = [];
		if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
		filteredData= this.state.completeData.filter(function(items) {
		return items.isChecked == true && items.actionneeded.toLowerCase() == "no" && (items.status.toLowerCase() =="not started" || items.status.toLowerCase() =="finance review");
			});
        }
        if(filteredData != undefined && filteredData.length > 0){
        filteredData.map((item)=>{
            item.requestedBy = this.state.racfData;
            item.actionneeded = "Yes"; // for demo only
            item.status = "Pending Approval"; //change as per request for approval
        });
    }
    console.log(filteredData)
        var currentComponent = this;
        let endPoint = API_ENDPOINT.REQUEST_APPROVAL;//  + "/0" removed as Sreejith said
        let payLoadData = multipleExport(filteredData);
        console.log(payLoadData)
        currentComponent.setState({ isLoading: true });
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
            //window.alert(JSON.stringify(response.data));
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'requestApprovalSuccess' });
            // currentComponent.setState({isRequestApprovalBtnDisabled:true});
        })
        .catch(function (error) {
            //window.alert(error);
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({ pageStatus: 'requestApprovalError' });
            // currentComponent.setState({isRequestApprovalBtnDisabled:true});
        })
    }
    
    handleExportOracle(){
        var filteredData = [];
		if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
		filteredData= this.state.completeData.filter(function(items) {
		return items.isChecked == true && items.status =="Approved";
			});
        }
        if(filteredData != undefined && filteredData.length > 0){
        filteredData.map((item)=>{
            item.status = "Exported";
        });
    }
        var currentComponent = this;
        let endPoint = API_ENDPOINT.MULTIPLE_EXPORT + "/"+ this.state.languageName; 
        let payLoadData = multipleExport(filteredData);
        
        currentComponent.setState({ isLoading: true });
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
           // window.alert(JSON.stringify(response.data));
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'exportSuccess' });
            // currentComponent.setState({isExportBtnDisabled:true});
        })
        .catch(function (error) {
           // window.alert(error);
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'exportError' });
            // currentComponent.setState({isExportBtnDisabled:true});
        })
}
        exportBtnState(value){
            if(value == true){
                this.setState({ isExportBtnDisabled: true });
            }else {
                this.setState({ isExportBtnDisabled: false });
            }
          
        }
        requestApprovalBtn(value){
            if(value == true){
                this.setState({ isRequestApprovalBtnDisabled: true });
            }else {
                this.setState({ isRequestApprovalBtnDisabled: false });
            }
        }
        goToApproverGrid(){
            localStorage.setItem('visitedFrom', 'invoicelink');
            this.props.history.push({
                pathname: '/lms/invoiceListApprover',
            })
        }
        

    render() {
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btndisable = true;
        var btnCreateInvoice = true;
        var requestApprovalBtn= true;
        for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Invoice_Request_Approval") { 
                    requestApprovalBtn = false;
                }
        }
        for (var i = 0; i < datalen; i++) { 
            if (perData[i] == "Invoice_Add") { 
                btnCreateInvoice = false;
            }
    }
        
        //rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser
        //check memberOf
        //this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0
        //if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") <= 0){
            console.log("Sfs")
        // if(this.state.memberOfDetail == "rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser"){
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Invoice_Export") { 
                    btndisable = false;
                }
            }
            //btndisable = true;
      //  }
        console.log(btndisable);
        // if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
        //     for(var i =0 ; i < this.state.completeData.length ; i++){
        //         if(this.state.completeData[i].ID != undefined && this.state.completeData[i].ID != null){
		// 			if(this.state.completeData[i].isChecked == true && this.state.completeData[i].status.toLowerCase() != "approved"){
        //                 //isExportBtnDisabled=true;
        //                 this.setState({ isExportBtnDisabled: true });
                        
        //                 break;
        //             }
        //             else{
        //                 this.setState({ isExportBtnDisabled: false });
        //                 break;
        //                 //isExportBtnDisabled=false;
        //             }
        //         }
        //     }
        // }
        return (
            <div className="background">
                {this.state.pageStatus == 'exportSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Export to oracle is successful'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'exportError' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='error' size='large' title='Failed due to system down'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'requestApprovalSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Request for approval is successful'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'requestApprovalError' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='error' size='large' title='Request for approval failed'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                <div className="inner_container" style={{
                    width: '91%',
                    margin: '30px -20px 0px 8%'
                }}>

<div class="form-group">
<label className="col-sm-6 invoice_title">Invoicing</label>
<label className="col-sm-6 approverAnchor" onClick={this.goToApproverGrid.bind(this)}>Go to invoice approver list</label>
</div>
<div className="form-group"> 
<div className="col-sm-6" >
                
</div>
<div className="col-sm-6 dropDownLang">
<Dropdownfieldcustom classname="font_config_invoice"  customLabel="font_config" title="Language" 
data={["","English","Swedish","Finnish"]} name="languagepreference" selectedValue="English"
onChange={this.getDropdownItem.bind(this, 'languagepreference')} />
</div>
</div> 
                    {this.state.isLoading == true ? 
                        <div>
                            <div className="zb-loader-block zb-loader-block-inverted">
                            <div className="zb-loader-content">
                                <span className="zb-loader" />
                                <span className="zb-loader-text">
                                Loading...
                                </span>
                            </div>
                            </div>
                    </div>: null }
                   {this.state.invoicaDatastatus ? <InvoiceListGrid  
                    getGridData={this.getGridData.bind(this)} 
                    selectedRecord={parseInt(this.state.recordView)} exportBtnState={this.exportBtnState.bind(this)} 
                    requestApprovalBtn={this.requestApprovalBtn.bind(this)}/>
                    :
                    null
                    }
                    {!this.state.invoicaDatastatus ? <InvoiceListGrid 
                    getGridData={this.getGridData.bind(this)} 
                    selectedRecord={parseInt(this.state.recordView)} exportBtnState={this.exportBtnState.bind(this)}
                    requestApprovalBtn={this.requestApprovalBtn.bind(this)} />
                    :
                    null
                    }
                    <span class="select-wrap -pageSizeOptions select_record">
                        <span className="text_property" style={{
                            marginRight: '18px',
                            color: '#666666'
                        }}>Per page</span>
                        <Select
                            defaultValue={this.state.recordView}
                            suggestions={['5', '10', '15', '20']}
                            className='notification_select_row'
                            isError={false}
                            onChange={this.HandleSelectChange.bind(this)}
                        />
                    </span>
                    

                </div>
                <div class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 8%', paddingLeft:'0%'}}>
                    <button type="button"  className="zb-button zb-button-primary model_invoice_btn" disabled={this.state.isExportBtnDisabled || btndisable} onClick={this.handleExportOracle.bind(this)}>Export to Oracle</button> 
                    {/* onClick={this.goToPage.bind(this,intrestInvoicingForm)} */}
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" disabled={this.state.isRequestApprovalBtnDisabled  || requestApprovalBtn} data-toggle="modal" data-target="#cancelSave" onClick={this.requestApprovalHandle.bind(this)}>Request Approval</button>
                    <button type="button"  className="zb-button zb-button-secondary cancel_invoice_btn"  onClick={this.goToPage.bind(this,'viewInvoicingDetail')}>Create Index Invoices</button> 
                    {/* onClick={this.goToPage.bind(this,intrestInvoicingForm)} */}
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" data-toggle="modal"  data-target="#cancelSave" onClick={this.goToPage.bind(this,'interestInvoicingForm')}>Create Interest Invoices</button>&nbsp;&nbsp;&nbsp;
                    
                </div>
                <div class="modal-footer hide" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button type="button"  className="zb-button zb-button-primary model_invoice_btn" disabled={this.state.isExportBtnDisabled} onClick={this.handleExportOracle.bind(this)}>Export to Oracle</button> 
                    {/* onClick={this.goToPage.bind(this,intrestInvoicingForm)} */}
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" disabled={this.state.isRequestApprovalBtnDisabled} data-toggle="modal" data-target="#cancelSave" onClick={this.requestApprovalHandle.bind(this)}>Request Approval</button>
                </div>
            </div>
        )
    }
}

export default invoiceList;