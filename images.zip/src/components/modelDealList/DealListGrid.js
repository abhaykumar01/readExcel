import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from '../../commonComponents/pagination.js';
import matchSorter from 'match-sorter'
import { HttpPost, HttpGet } from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import moment from 'moment';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import DatePicker from '@zambezi/sdk/date-picker';
import {roundedDecimal, Comma, precise, nullCheck} from '../../utils/LeaseUtils.js';
import {Checkbox}  from '@zambezi/sdk/form-elements';
import { AuthorizationContext } from '../authContext/index.js';
const PING = process.env.REACT_APP_PING;
// const rawData = getPartyCustomer();

class gridPage extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "10",
            customerRecord: [],
            loading: false,
            selected: null,
            permissionData: {},
            racfID: '',
        }
        this.zeroPad = this.zeroPad.bind(this);
    }

     zeroPad(num){
         if(num !== undefined && num !== null && num !== ""){
            return num.toString().padStart(9, "0");
         }
        
    }

    componentWillMount(){
        this.props.updateReinstateCTA(true);
    }

    componentDidMount() {
        var data;
        var racfDetail;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');//"lmsgf";//test1";

        }
        this.setState({
            permissionData: data,
            racfID: racfDetail
        }, function () {
            console.log(this.state.racfID)
            this.forceUpdate();
        });
        let output = [];
        this.setState({ loading: true })
        var currentComponent = this;
        let endPoint = API_ENDPOINT.GET_DEAL_LIST + '/0/100/leaseContractId/' + racfDetail;
        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            for (var i = 0; i < response.data.length; i++) {
                
                var obj = response.data[i].createdOn ? moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ'):'';
                let time = response.data[i].createdOn ? moment(obj).format("DD/MM/YYYY"):''; 
                output.push({
                    
                    createdOn: nullCheck(time),
                    ID: response.data[i].leaseParentId.toString(),
                    customerName: nullCheck(response.data[i].customerName).toString(),
                    spv: nullCheck(response.data[i].spv).toString(),
                    contractDescription: nullCheck(response.data[i].contractDescription).toString(),
                    createdBy: nullCheck(response.data[i].createdBy).toString(),
                    status: nullCheck(response.data[i].status).toString(),
                    openingBalance: nullCheck(Comma(precise(response.data[i].openingBalance))).toString(),
                    residualVal: nullCheck(Comma(precise(response.data[i].residualVal))).toString(),
                    vacantPossesionValue: nullCheck(Comma(precise(response.data[i].vacantPossesionValue))).toString(),
                    rvByVpv: nullCheck(Comma(precise(response.data[i].rvByVpv))).toString(),
                    dealReferenceNumber: nullCheck(currentComponent.zeroPad(response.data[i].dealReferenceNumber)).toString(),
                    ioRwa: nullCheck(Comma(roundedDecimal(response.data[i].ioRwa))).toString(),
                    dealNumber: nullCheck(response.data[i].dealNumber).toString(),
                    isChecked:false,
            
                });
            }

            currentComponent.setState({customerRecord: output});
            currentComponent.setState({ loading: false })
        })
            .catch(function (error) {
                currentComponent.setState({ loading: false })
                console.log("Error received123");
                //window.alert(error);
            })
    }

    // fetchDeal(leaseContractId){
    //     var currentComponent = this;
    //     if(leaseContractId !== null && leaseContractId !== undefined && leaseContractId !== ''){
    //         let endPoint = API_ENDPOINT.GET_DEAL + '/' + leaseContractId;
    //         console.log("Service call");
    //         HttpGet(currentComponent, endPoint).then(function (response) {
    //             console.log("User response received from server");
    //             console.log(response.data);
    //             console.log(response.data.leaseContractId);
    //             //window.alert(JSON.stringify(response.data));
    //             localStorage.setItem('leaseResponseDataState',JSON.stringify(response.data));
    //             currentComponent.props.history.push({
    //                 pathname: '/lms/mainSummaryTabsPage',
    //                  state: { leaseResponseDataState: response.data }
    //             })
                
    //         }).catch(function (error) {
    //             console.log("Error received");
    //             console.log(error);
    //         })
    //     }
    //     }

    render() {
        console.log("Select record::  ");
        console.log(this.props.selectedRecord);
        const columns = [
            {
                id: 'customerName',
                Header: props => <div><span className="table_nameprop">Customer</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'customerName', // String-based value accessors!
                headerClassName: 'theader',
                width: 250,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['customerName'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'dealNumber',
                Header: props => <div><span className="table_nameprop">Deal id</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'dealNumber', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['dealNumber'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'dealReferenceNumber',
                Header: props => <div><span className="table_nameprop">Deal number</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'dealReferenceNumber', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['dealReferenceNumber'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'spv',
                Header: props => <div><span className="table_nameprop">SPV</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'spv', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['spv'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'contractDescription',
                Header: props => <div><span className="table_nameprop">Description</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'contractDescription', // String-based value accessors!
                headerClassName: 'theader',
                width: 255,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['contractDescription'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'createdBy',
                Header: props => <div><span className="table_nameprop">Created by</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'createdBy', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['createdBy'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'status',
                Header: props => <div><span className="table_nameprop">Status</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'status', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['status'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'createdOn',
                Header: props => <div><span className="table_nameprop">Created on</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'createdOn', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['createdOn'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'openingBalance',
                Header: props => <div><span className="table_nameprop">BV</span><Icon name="chev-down-small" size="xsmall" 
				className="arrow_down" title=""/></div>,
                accessor: 'openingBalance', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['openingBalance'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'residualVal',
                Header: props => <div><span className="table_nameprop">RV</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'residualVal', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['residualVal'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'vacantPossesionValue',
                Header: props => <div><span className="table_nameprop">VPV</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'vacantPossesionValue', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['vacantPossesionValue'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            },{
                id: 'rvByVpv',
                Header: props => <div><span className="table_nameprop">RV/VPV</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'rvByVpv', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['rvByVpv'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            // },{
            //     id: 'cname',
            //     Header: props => <div><span className="table_nameprop">Margin</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
            //     accessor: 'name', // String-based value accessors!
            //     headerClassName: 'theader',
            //     filterable: true,
            //     filterMethod: (filter, rows) =>
            //     matchSorter(rows, filter.value, { keys: ["cname"] }),
            },{
                id: 'ioRwa',
                Header: props => <div><span className="table_nameprop">IoRWA</span><Icon name="chev-down-small" size="xsmall" className="arrow_down" title=""/></div>,
                accessor: 'ioRwa', // String-based value accessors!
                headerClassName: 'theader',
                width: 155,
                sortable: true,
                filterable: true,
                filterMethod : (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: ['ioRwa'] }),
                filterAll: true,
                Filter : ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    ),
            }
            
            ]

        return <ReactTable
            data={this.state.customerRecord}
            columns={columns}
            loading={this.state.loading}
            showPagination = {true}
            showPaginationTop = {false}
            showPaginationBottom = {true}
            showPageSizeOptions = {true}
            className= 'tabledata'
            pageSize={this.props.selectedRecord}
            PaginationComponent={Pagination}
            onFilteredChange = {undefined}
            // defaultSortDesc = {false}
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            noDataText= 'No rows found'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
            filterable
            defaultFilterMethod={(filter, row) =>
                String(row[filter.id]) === filter.value}
            getTrProps={(state, rowInfo) => {
                if (rowInfo && rowInfo.row) {
                    return {
                        onClick: (e) => {
                            // this.fetchDeal(rowInfo.original.ID);
                            localStorage.setItem('fromDealURL',"DealView");
                            this.props.history.push({
                                pathname: '/lms/mainSummaryTabsPage',
                                state: { leaseParentId: rowInfo.original.ID,
                                         fromDealURL:"DealView", 
                                        }
                            })
                        },
                    }
                } else {
                    return {}
                }
            }}
            
        />
    }
}

export default withRouter(gridPage);