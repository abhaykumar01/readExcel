import React from 'react';
import './viewModelDealList.css';
import GridPage from '../../components/modelDealList/DealListGrid.js';
import ArchivedDealGrid from '../../components/modelDealList/ArchivedDealGrid.js'
import '../../index.css';
import { Tabs, Tab } from 'react-bootstrap-tabs';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import { AuthorizationContext } from '../authContext/index.js'
import { API_ENDPOINT } from '../../config/config';
import { HttpDelete } from '../../services/api';
import { Notification } from '@zambezi/sdk/notification';
import GeneralDealApprovalModal from '../dealApprovals/dealApprovalModals/generalDealApprovalModal';
import { dealNotificationMessages } from '../../models/LeaseConstants';
const PING = process.env.REACT_APP_PING;

class viewModelDealList extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            searchInput: "",
            recordView: '20',
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            reinstateDisabled: true,
            selectedTab:0,
            selectedRows:[],
        }
        localStorage.setItem("approver", 'false');
    }

    componentWillMount() {
        this.hideNotification();
        // var abj= document.getElementsByClassName('dataTables_filter')[0].innerHTML;
        // console.log(abj);
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }

    handleOnTabChange(index){
        this.hideNotification();
        this.setState({selectedTab : index});
    }

    HandleSelectChange(event, type) {//event, val, type
        console.log("Dropdown change value:: ");
        console.log(event);
        console.log(type);
        this.setState({ recordView: type.value });
    }

    addDeal() {
        console.log("Add deal");
        localStorage.setItem('DealRequestType', 'SAVE_DEAL');
        this.props.history.push('/lms/LeaseModel');
    }

    updateReinstateCTA(flag){
        this.setState({reinstateDisabled :flag});
    }

    updateSelectedData(data){
        this.setState({selectedRows : data},()=>{
            if(this.state.selectedRows.length>0){
                this.updateReinstateCTA(false);
            }else {
                this.updateReinstateCTA(true);
            }
        });
    }

    reinstateDeals(){
        let url = API_ENDPOINT.UPDATE_ARCHIVED_DEAL_FLAG+'0';
        let dealsToReinstate = this.state.selectedRows.map(item => {
            return parseInt(item.ID);
        })
        
        HttpDelete(this, dealsToReinstate, url).then((response)=>{
            this.closeModal('reinstateDeal');
            this.setNotification('success', dealNotificationMessages.reinstateSelectedDealsSuccess);
            this.setState({selectedTab : 0});
        }).catch((error) => {
            console.log(error);
        })
    }

    setNotification(type, notificationMsg){
        window.scrollTo(0, 0);
        let notificationObj = {
            showNotification : true,
            notificationType : type,
            notificationMsg : notificationMsg,
        }
        this.setState({notification : notificationObj});
    }

    hideNotification(){
        let notificationObj = {
            showNotification : false,
            notificationType : '',
            notificationMsg : '',
        }
        this.setState({notification : notificationObj});
    }

    openModal(modalName){
        if(modalName === 'reinstateDeal'){
            this.setState({reinstateModal : true});
        }
    }

    closeModal(modalName){
        if(modalName === 'reinstateDeal'){
            this.setState({reinstateModal : false});
        }
    }


    render() {
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var modelNewDealLabel = true;
        var btnReinstateDisable = true;
        for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Model_New_Deal") { 
                    modelNewDealLabel = false;
                }
            }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Reinstate") { 
                    btnReinstateDisable = false;
                }
                
            }
            
            
        return (
            <div style ={{backgroundcolor: '#eeeeee'}}>
                {this.state.reinstateModal ? 
                    <GeneralDealApprovalModal
                        title="Reinstate deals"
                        confirmText='Yes, reinstate'
                        msgAccessor='selectedDealsReinstateMsg'
                        open={this.state.reinstateModal}
                        onConfirm={this.reinstateDeals.bind(this)}
                        onCancel={this.closeModal.bind(this,'reinstateDeal')} />
                : null}
                
                <div className="inner_container1">
                    {this.state.notification.showNotification ?
                        <div className="DealListNotification"><Notification status={this.state.notification.notificationType} size="medium">{this.state.notification.notificationMsg}</Notification></div>
                        : null
                    }
                    <label className="party_title">Deals</label>

                    <div className="inner_header">
                    
                        <div className={"col-sm-4 new_party_btn " + (modelNewDealLabel ? 'disabledLabel' : '')} onClick={this.addDeal.bind(this)}>
                            <Icon name="plus-xsmall" size='small' title=""/>
                             <label className="uploadDocument" style={{width:'120px', marginRight:'20px'}}> Model new deal</label>
                        </div>
                        <Tabs selected = {this.state.selectedTab} onSelect = {this.handleOnTabChange.bind(this)}
                        style={{ margin: '20px 0 0 0', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }}
                        headerStyle={{ backgroundColor: '#f5f5f5', color: '#ad1982', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'pointer' }}
                        activeHeaderStyle={{ backgroundColor: '#ffffff', color: '#42145f', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'default' }}>
                            <Tab label="Current" >
                                <div className="grid_layout">
                                    <GridPage selectedRecord={parseInt(this.state.recordView)} updateReinstateCTA={this.updateReinstateCTA.bind(this)}/>
                                    <span class="select-wrap -pageSizeOptions select_record">
                                        <span className="select_page">Per page</span>
                                        <Select
                                            defaultValue='20'
                                            suggestions={['20', '40', '60', '80', '100']}
                                            className='select_row_customer'
                                            isError={false}
                                            onChange={this.HandleSelectChange.bind(this)}
                                        />
                                    </span>
                                </div>

                            </Tab>
                            <Tab label="Archived">
                                <div className="grid_layout">
                                        <ArchivedDealGrid selectedRecord={parseInt(this.state.recordView)} 
                                        updateSelectedData={this.updateSelectedData.bind(this)}/>
                                        <span class="select-wrap -pageSizeOptions select_record">
                                            <span className="select_page">Per page</span>
                                            <Select
                                                defaultValue='20'
                                                suggestions={['20', '40', '60', '80', '100']}
                                                className='select_row_customer'
                                                isError={false}
                                                onChange={this.HandleSelectChange.bind(this)}
                                            />
                                        </span>
                                    </div>
                             </Tab>
                        </Tabs>
                    </div>
                    <div className="DealListFooterBtnGroup">
                        <button className='zb-button zb-button-primary DealFooterButton' 
                            disabled={this.state.reinstateDisabled || btnReinstateDisable} onClick={this.openModal.bind(this,'reinstateDeal')}>
                        Reinstate
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

export default viewModelDealList;