import React from 'react';
import '../../index.css';
import './emptyGrid.css';
import TLPGrid from '../../commonComponents/TLPGrid.js';
import Pending from '../../assets/images/pending.png';
import { Notification } from '@zambezi/sdk/notification';
import { AuthorizationContext } from '../authContext/index.js'
import { HttpPost, HttpGet } from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';

const PING = process.env.REACT_APP_PING;
class emptyTLPGrid extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            showConfirmation: false,
            approvalConfirmation: false,
            gridStatus: '',
            showGridStatus: false,
            status: '',
            permissionData: {},
            gridRecordCount: 0,
            approveGridAuthority: false
        }
        //localStorage.setItem('approvalPending', 'true');
    }

    componentDidMount() {
        // const { name, usersDetails } = this.context;
        var notificationStatus = localStorage.getItem('status');
        console.log("Status ", notificationStatus);
        var currentComponent = this;
        var data;
        var roleName = '';
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log("reterive permission data");
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            roleName = usersDetails.memberOf;
        } else {
            let response = localStorage.getItem('permissions');
            console.log("non-ping reterive permission data");
            console.log(response);
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            // console.log(res.length);
            data = JSON.parse(response);
            roleName = localStorage.getItem('roleName');
        }
        this.setState({
            status: notificationStatus,
            permissionData: data
        });
        var username = '';
        if (PING == 'true') {
            let { usersDetails } = this.context;
            username = usersDetails.userID;
        } else {
            username = localStorage.getItem('racfID');
        }
        let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/Pending_For_Approval';
        let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
            console.log("Grid count");
            console.log(response.data);

            var recordCount = response.data.length;
            console.log(recordCount);
            if (recordCount > 0) {
                console.log("Grid count1");
                localStorage.setItem('tlpdata', JSON.stringify(response.data[0]));
                console.log(response.data[0].requestedBy);
                console.log(username);
                currentComponent.setState({ gridRecordCount: recordCount });
                if (response.data[0].requestedBy == username) {
                    localStorage.setItem('approvalPending', 'false');
                    currentComponent.setState({ approveGridAuthority: false });
                } else {
                    localStorage.setItem('approvalPending', 'false');
                    currentComponent.setState({ approveGridAuthority: true });
                }
            } else {
                if (roleName.indexOf('rAppNordiskLMS-GeneralFinanceUser') > -1) {
                    localStorage.setItem('approvalPending', 'true');
                }
                currentComponent.setState({ gridRecordCount: 0 });
            }
        })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
            })
    }

    updateGrid() {
        console.log("Update grid");
        console.log(this.state.gridRecordCount);
        if (this.state.gridRecordCount > 0) {
            if (this.state.approveGridAuthority) {
                this.props.history.push({
                    pathname: '/lms/ApproveTLPGrid'
                })
            } else { }
        } else {
            this.props.history.push({
                pathname: '/lms/updateTLPGrid'
            })
        }
    }

    updateGridStatus(val) {
        if (val == "Pending_For_Approval") {
            this.setState({ gridStatus: 'Pending' });
        } else {
            this.setState({ gridStatus: val });
        }

        if (val != '') {
            this.setState({ showGridStatus: true });
        } else {
            this.setState({ showGridStatus: false });
        }
    }

    back() {
        this.props.history.push({
            pathname: '/lms/modelNewDeal'
        })
    }

    render() {
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else {
            datalen = 0;
        }

        console.log("per data");
        console.log(perData);
        var btndisable = false;
        for (var i = 0; i < datalen; i++) {
            if (perData[i] == "TLP_Update") {
                btndisable = true;
            }
        }
        console.log("Button disabled");
        console.log(btndisable);
        return (
            <div className="background">
                {this.state.status == 'approved' ?
                    <Notification className="Confirmation_header" status='success' size='large' title='Your request to update TLP grid has been approved'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.status == 'rejected' ?
                    <Notification className="Confirmation_header" status='error' size='large' title='Your request to update TLP grid has been rejected'>
                        Reason for rejecting:   {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.status == 'cancel' ?
                    <Notification className="Confirmation_header" status='success' size='large' title='Your updates to the TLP grid were cancelled'>
                        There were no changes made.
                    </Notification>
                    : null
                }
                {this.state.status == 'sendApprove' ?
                    <Notification className="Confirmation_header" status='success' size='large' title='Your request to approve updated TLP grid has been sent'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                <div className="form-group row" style={{
                    margin: '20px auto 0px auto',
                    width: '924px'
                }}>
                    <div className="col-sm-7">
                        <label className="empty_grid_title">TLP grid</label>
                    </div>

                    {this.state.showGridStatus ? <div className="col-sm-5">
                        <label className="empty_grid_status">Status: {this.state.gridStatus == "Pending" ? <img src={Pending} /> : null}<label style={{ marginLeft: '6px' }}>{this.state.gridStatus}</label></label>
                    </div> : null}

                </div>

                <div className="form-group row">
                    <div className="tlp_deal_container_empty">
                        <TLPGrid ref="child" updateGridStatus={this.updateGridStatus.bind(this)} />
                    </div>
                </div>
                <div className="form-group row" style={{
                    margin: '20px auto 0px auto',
                    width: '924px'
                }}>
                    <div className="col-sm-12" >
                        <button type="button" class="btn btn-default updateTLPGrid" disabled={!btndisable} onClick={this.updateGrid.bind(this)}>Update TLP grid</button>
                    </div>
                </div>
            </div>
        )
    }
}

export default emptyTLPGrid;