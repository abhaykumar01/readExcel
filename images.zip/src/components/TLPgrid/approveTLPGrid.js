import React from 'react';
import '../../index.css';
import './emptyGrid.css';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import "react-tabs/style/react-tabs.css";
import TLPGrid from '../../commonComponents/TLPGrid.js';
import { API_ENDPOINT } from '../../config/config.js';
import { HttpPutWithoutBody, HttpPut } from '../../services/api.js';
// import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import { saveApproverGridStatus } from '../../models/dataModel.js'
import { Notification } from '@zambezi/sdk/notification';
import { func } from 'prop-types';
import { AuthorizationContext } from '../authContext/index.js'

const PING = process.env.REACT_APP_PING;

class approveTLPGrid extends React.Component {
    static contextType = AuthorizationContext;
    constructor(props) {
        super(props);
        this.state = {
            rejectReason: true,
            isPopoverOpen: false,
            gridStatus: '',
            approveBtn: true,
            rejectBtn: true,
            status: '',
            key: 0,
            selectClass: 'selectedtlpgridTabPanel',
            showDate: true,
            showwithoutError: true,
            showWithError: false,
            rejectReasonText: "",
            loader: false,
        }
        localStorage.setItem('approvalPending', 'false');
        this.handleSelectTab = this.handleSelectTab.bind(this);
    }

    componentDidMount() {
        // localStorage.setItem('approvalPending', 'false');
    }

    updateGridStatus(val) {
        if (val == 'Pending_For_Approval') {
            localStorage.setItem('status', 'awaitedApproval');
            this.setState({ approveBtn: false });
            this.setState({ rejectBtn: false });
            this.setState({ status: 'awaitedApproval' });
        } else {
            var st = localStorage.getItem('viewRecord');
            if (st == "") {
                this.setState({ showDate: false });
            }
        }
    }
    handleSelectTab(index) {
        if (index === 1) {
            this.setState({ selectClass: 'approvedpgridTabPanel' })
            localStorage.setItem('approvalPending', 'Approved');
        }
        else {
            this.setState({ selectClass: 'selectedtlpgridTabPanel' })
            localStorage.setItem('approvalPending', 'false');
        }
        this.setState({ key: index });
    }
    approveRequest() {
        this.setState({ loader: true });
        let id;
        let requestedByUser = "";
        if (PING == 'true') {
            let { usersDetails } = this.context;
            id = usersDetails.userID;
        } else {
            let racfid = localStorage.getItem('racfID');
            id = racfid;
        }
        let response = localStorage.getItem('Message');
        console.log("non-ping reterive permission data for approve grid");
        // console.log(JSON.parse(response));

        // console.log(data.requestedBy);

        if (response) {
            let data = JSON.parse(response);
            requestedByUser = data.requestedBy;
        } else {
            let data = localStorage.getItem('tlpdata');
            requestedByUser = JSON.parse(data).requestedBy;
        }
        console.log(requestedByUser);
        var requestno = localStorage.getItem('requestNumber');
        if (requestno) {
            var currentComponent = this;
            let payLoadData = saveApproverGridStatus(requestno, "");
            let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/approveOrReject/Approved/' + requestedByUser + '/' + id;
            console.log("payLoadData");
            console.log(payLoadData);
            console.log(endPoint);
            let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
                console.log("Response received from server");
                console.log(response.data);
                localStorage.setItem('approvalPending', 'Approved');
                localStorage.setItem('status', 'approved');
                currentComponent.setState({ status: 'approved' });
                currentComponent.setState({ approveBtn: true });
                currentComponent.setState({ rejectBtn: true });
                currentComponent.setState({ loader: false });
                currentComponent.handleSelectTab(1);

            })
                .catch(function (error) {
                    currentComponent.setState({ loader: false });
                })
        }
    }
    getRejectionReason(value) {
        this.setState({ rejectReasonText: value })
        if (value == "") {
            this.setState({
                rejectReason: true,
                showwithoutError: false,
                showWithError: true
            }, function () {
                this.forceUpdate();
            });
        } else {
            this.setState({
                rejectReason: false,
                showwithoutError: true,
                showWithError: false
            }, function () {
                this.forceUpdate();
            });
        }
    }
    rejectStatus() {
        this.setState({ loader: true });
        let id;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            id = usersDetails.userID;
        } else {
            let racfid = localStorage.getItem('racfID');
            id = racfid;
        }
        let response = localStorage.getItem('Message');
        let requestedByUser = "";
        if (response) {
            let data = JSON.parse(response);
            requestedByUser = data.requestedBy;
        } else {
            let data = localStorage.getItem('tlpdata');
            requestedByUser = JSON.parse(data).requestedBy;
        }
        var requestno = localStorage.getItem('requestNumber');
        if (requestno) {
            var currentComponent = this;
            let payLoadData = saveApproverGridStatus(requestno, this.state.rejectReasonText);
            let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/approveOrReject/Rejected/' + requestedByUser + '/' + id;
            console.log("payLoadData");
            console.log(payLoadData);
            console.log(endPoint);
            let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
                localStorage.setItem('approvalPending', 'Rejected');
                localStorage.setItem('status', 'rejected');
                currentComponent.setState({ status: 'rejected' });
                currentComponent.setState({ approveBtn: true });
                currentComponent.setState({ rejectBtn: true });
                currentComponent.setState({ loader: false });
            })
                .catch(function (error) {
                    currentComponent.setState({ loader: false });
                })
        }
    }
    closeDialog() {
        this.setState({
            rejectReason: true,
            showwithoutError: true,
            showWithError: false
        });
    }


    render() {
        let requestedByUser = '';
        let response = localStorage.getItem('Message');
        if (response) {
            let data = JSON.parse(response);
            requestedByUser = data.requestedBy;
        } else {
            let data = localStorage.getItem('tlpdata');
            requestedByUser = JSON.parse(data).tlp_User;
        }
        console.log("Requested By");
        console.log(requestedByUser);

        return (


            <div className="background">

                {this.state.status == 'awaitedApproval' ?
                    <Notification className="Confirmation_header" status='warning' size='large' title='TLP grid update is awaiting your approval'>
                        {requestedByUser} requested your approval on 11/08/2019.
                        Please review the updates highlighted in yellow and approve/reject accordingly.
                        {/* Please download the supporting document attached to this request.<br /> */}
                        {/* <span style={{ color: '#ad1982', textDecoration: 'underline' }}>AlCoEmail.pdf</span>/ */}
                    </Notification>
                    : null
                }
                {this.state.status == 'approved' ?
                    <Notification className="Confirmation_header" status='success' size='large' title='TLP grid updates have been approved'>
                        Notification email has been sent to {requestedByUser}.
                    </Notification>
                    : null
                }
                {this.state.status == 'rejected' ?
                    <Notification className="Confirmation_header" status='error' size='large' title='TLP grid updates have been rejected'>
                        Notification email has been sent to {requestedByUser}.
                    </Notification>
                    : null
                }

                <div className="form-group row" style={{
                    margin: '20px auto 0px auto',
                    width: '924px'
                }}>
                    <div className="col-sm-8">
                        <label className="update_deal_title">TLP grid</label>
                    </div>
                </div>
                <Tabs selectedIndex={this.state.key} onSelect={this.handleSelectTab}
                    className="tlpGridTab" selectedTabClassName="selectedtlpGridTab">
                    <TabList style={{ border: 'none', margin: '0' }}>
                        <Tab className="headertlpGridTab">Awaiting approval</Tab>
                        <Tab className="headertlpGridTab headertlpGridTab1">Approved</Tab>
                    </TabList>

                    <TabPanel className={this.state.selectClass} >
                        <div className="grid_layout">
                            <TLPGrid ref="child" updateGridStatus={this.updateGridStatus.bind(this)} />
                        </div>
                        <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '15px', marginTop: '-20px' }}>
                            <button type="button" disabled={this.state.approveBtn} data-toggle="modal" data-target="#approve" class="zb-button zb-button-primary deal_approve_btn">Approve TLP updates</button>
                            <button type="button" disabled={this.state.rejectBtn} data-toggle="modal" data-target="#reject" class="zb-button zb-button-secondary deal_approve_cancel_btn">Reject TLP updates</button>
                        </div>


                    </TabPanel >
                    <TabPanel className={this.state.selectClass}>
                        {/* {this.state.showDate ? <label style={{ marginBottom: '12px', marginLeft: '32px', fontSize: '16px', fontWeight: 'normal', color: '#666666', fontFamily: 'RNFontRegularWoff' }}>TLP grid approved on 15/06/2019</label> : null} */}
                        <div className="grid_layout">
                            <TLPGrid ref="child" updateGridStatus={this.updateGridStatus.bind(this)} />
                        </div>
                    </TabPanel>
                </Tabs>

                {this.state.loader ? <div
                    className='zb-loader-block zb-loader-block-inverted zb-loader-block-3rd'
                    style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}
                >
                    <div className='zb-loader-content'>
                        <span className='zb-loader' />
                        <span className='zb-loader-text'>Loading...</span>
                    </div>
                </div> : null}

                <div id="approve" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss='modal'>&times;</button>
                                <h4 class="modal-title header_title">Approve TLP grid update request</h4>
                            </div>
                            <div class="modal-body">
                                <p className="header_body">Are you sure you want to approve TLP grid update request?</p>
                            </div>
                            <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '20px' }}>
                                <button className='zb-button zb-button-primary save_pop_btn approve_grid_btn' data-dismiss="modal" onClick={this.approveRequest.bind(this)}>Yes, approve request</button>
                                <button className='zb-button zb-button-secondary cancel_pop_btn approve_grid_btn' data-dismiss="modal">No, don’t approve request</button>

                            </div>
                        </div>

                    </div>
                </div>

                <div id="reject" class="modal fade" role="dialog" onClick={this.closeDialog.bind(this)}>
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss='modal' onClick={this.closeDialog.bind(this)}>&times;</button>
                                <h4 class="modal-title header_title">Reject TLP grid update request</h4>
                            </div>
                            <div class="modal-body">
                                <p className="header_body">Are you sure you want to reject TLP grid update request?</p>
                                <div className="form-group row">
                                    <div className="col-sm-9">
                                        <span className="header_body">Provide a reason for rejecting</span>
                                    </div>
                                </div>


                                <div className="form-group row">
                                    <div className="col-sm-9">
                                        <input type="text" val={this.state.rejectReasonText}
                                            onChange={e => this.getRejectionReason(e.target.value)}
                                            className="reason_input" placeholder="Input text here..." />

                                    </div>

                                </div>
                                {this.state.showWithError ?
                                    <Notification
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification notification_reason_input"
                                    >
                                        Please provide reason for rejecting
                                        </Notification>
                                    : null}
                            </div>
                            <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '20px', marginTop: '-13px' }}>
                                <button className='zb-button zb-button-primary save_pop_btn approve_grid_btn' disabled={this.state.rejectReason} data-dismiss="modal" onClick={this.rejectStatus.bind(this)}>Yes, reject request</button>
                                <button className='zb-button zb-button-secondary cancel_pop_btn approve_grid_btn' data-dismiss="modal">No, don’t reject request</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}

export default approveTLPGrid;