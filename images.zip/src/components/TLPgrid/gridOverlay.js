import React from 'react';
import '../../index.css';
import './emptyGrid.css';
import TLPGrid from '../../commonComponents/TLPGrid.js';

class emptyTLPGrid extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showConfirmation: false
        }
    }

    componentDidMount() {
        var status = localStorage.getItem('cancelstatus');
        if (status == 'true') {
            this.setState({ showConfirmation: true });
        }
    }

    updateGrid() {
        this.props.history.push({
            pathname: '/lms/updateTLPGrid'
        })
        // React.refs.child.updateTLPGrid();
    }

    back() {
        this.props.history.push({
            pathname: '/lms/modelNewDeal'
        })
    }

    render() {
        return (
            <div className="background">
                {
                    this.state.showConfirmation ? <div className="Confirmation_header">
                        <div style={{ height: '104px', borderBottom: '10px solid #429448' }}>
                            <span className="glyphicon glyphicon-ok-sign ok_btn"></span>
                            <span className="confirmation_msg">Your updates to the TLP grid were cancelled</span>
                            <span className="confirmation_msg1">There were no changes made.</span>
                        </div>
                    </div> : null
                }
                {/* <div className="all_party_deal_tlp">
                    <span class="glyphicon glyphicon-chevron-left">
                        <span className="" onClick={this.back.bind(this)}>Back</span>
                    </span>
                </div> */}
                <div className="form-group row">
                    <div className="col-sm-2"></div>
                    <label className="empty_grid_title">TLP grid</label>
                </div>

                <div className="form-group row">
                    <div className="tlp_deal_container_empty">
                        <TLPGrid ref="child" />
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-12" style={{ width: '100%' }}>
                        <button type="button" class="btn btn-default updateTLPGrid" onClick={this.updateGrid.bind(this)}>Update TLP grid</button>
                    </div>
                </div>
            </div>
        )
    }
}

export default emptyTLPGrid;