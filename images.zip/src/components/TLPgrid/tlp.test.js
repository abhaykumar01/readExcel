import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import EmptyTLPGrid from './emptyTLPGrid.js';
import UpdateTLPGrid from './updateGrid.js';
import Adapter from 'enzyme-adapter-react-16';
import renderer from 'react-test-renderer';
import { create } from "react-test-renderer";
import { BrowserRouter as Router } from 'react-router-dom';

Enzyme.configure({ adapter: new Adapter() });

let wrapper;
beforeEach(() => {
    wrapper = shallow(<EmptyTLPGrid />);
});

describe('TLP component', () => {
    test('should shallow correctly', () => {
        expect(wrapper).toMatchSnapshot()
    })

    test('should mount correctly', () => {
        expect(mount(
            <Router>
                <EmptyTLPGrid />
            </Router>
        )).toMatchSnapshot()
    })
    test('should render correctly', () => {
        expect(render(
            <Router>
                <EmptyTLPGrid />
            </Router>

        )).toMatchSnapshot()
    })
});