
import React from 'react';
import '../../index.css';
import './emptyGrid.css';
import UpdateTLPGrid from '../../commonComponents/updateTLPGrid';
import Popup from '../../commonComponents/popupMessage';
import PopupModal from '../../commonComponents/popupModal';
import help from '../../assets/images/help.png';
import importExcel from '../../assets/images/import.png';
import deleteFile from '../../assets/images/delete.png';
import FileUpload from '../../commonComponents/fileUpload';
import ReactTooltip from 'react-tooltip';
import readXlsxFile from 'read-excel-file';
import { Notification } from '@zambezi/sdk/notification';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import { ECM_TOGGLE } from '../../config/config';
import { Route, withRouter } from 'react-router-dom';
import { AuthorizationContext } from '../authContext/index.js'

const PING = process.env.REACT_APP_PING;
class updateTLPGrid extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            buttonApprove: true,
            buttonSave: true,
            buttonCancel: false,
            selectedFile: null,
            selectedImportFile: null,
            fileUploadStatus: false,
            uploadedFileName: '',
            status: '',
            permissionData: {},
        }
        // this.onClickHandler = this.onClickHandler.bind(this);
        this.inputOpenFileRef = React.createRef();
        this.importOpenFileRef = React.createRef();
        this.deleteAttachment = this.deleteAttachment.bind(this);
        // this.cancelSave = this.cancelSave.bind(this);
    }

    componentDidMount() {
        var data;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log("reterive permission data");
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
        } else {
            let response = localStorage.getItem('permissions');
            console.log("non-ping reterive permission data");
            console.log(response);
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            // console.log(res.length);
            data = JSON.parse(response);
        }
        this.setState({
            permissionData: data
        });
    }

    onClick = () => {
        this.child.saveTLPData(); // do stuff
    }

    sendForApproval = () => {
        this.child.sendForApproval(); // do stuff
    }

    approvalPending = () => {
        localStorage.setItem('status', 'pendingApproval');
        this.setState({ status: 'pendingApproval' });
    }

    cancelSave = () => {
        localStorage.setItem('status', 'cancel');
        this.props.history.push({
            pathname: '/lms/emptyTLPGrid'
        })
    }
    saveConfirmation() {
        localStorage.setItem('status', 'save');
        this.setState({ status: 'save' });
    }
    sendApprovalConfirmation() {
        localStorage.setItem('status', 'sendApprove');
        this.props.history.push({
            pathname: '/lms/emptyTLPGrid'
        })
    }

    deleteAttachment = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.setState({
            uploadedFileName: '',
            selectedFile: [],
            fileUploadStatus: false
        });
    }

    saveGrid() {
        this.setState({
            buttonSave: false,
            // status: '',
            buttonApprove: true,
            buttonCancel: false
        });
    }

    enableApproveButton() {
        if (ECM_TOGGLE == 'false') {
            this.setState({ buttonApprove: false });
        } else {
            this.setState({ buttonApprove: true });
        }
    }

    disableSaveButton() {
        this.setState({
            buttonSave: true
        });
        if (ECM_TOGGLE == 'false') {
            this.setState({ buttonApprove: false });
        } else {
            this.setState({ buttonApprove: true });
        }
    }

    onChangeHandler = event => {
        if (event.target.files[0]) {
            this.setState({
                uploadedFileName: event.target.files[0].name,
                selectedFile: event.target.files[0],
                loaded: 0,
                fileUploadStatus: true
            });
        }
    }

    onChangeImportHandler = event => {
        // this.setState({ selectedImportFile: null });
        if (event.target.files[0]) {
            var fileSize = (event.target.files[0].size / 1024);
            var output = [];
            if (event.target.files[0] && fileSize <= 300) {
                this.setState({
                    selectedImportFile: event.target.files[0],
                    status: ''
                });
                readXlsxFile(event.target.files[0]).then((rows) => {
                    this.child.importFromExcel(rows); // do stuff
                })
            } else {
                this.setState({ status: 'importFailed' });
            }
        }
    }

    importFileFailed() {
        this.setState({ status: 'importExcelFailed' });
    }

    importFileValueFailed() {
        this.setState({ status: 'importExcelValueFailed' });
    }

    pageError() {
        this.setState({ status: 'genericError' });
    }

    noStatus() {
        this.setState({ status: '' });
    }


    onClickHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.inputOpenFileRef.current.click();
    }

    importFileHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        // // this.setState({ selectedImportFile: '' });
        // if (this.state.selectedImportFile) { 
        //     this.state.selectedImportFile = null;
        // }
        this.importOpenFileRef.current.click();
    }

    render() {
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else {
            datalen = 0;
        }

        console.log("per data");
        console.log(perData);
        var btndisable = false;
        var saveBtnDisable = false;
        for (var i = 0; i < datalen; i++) {
            if (perData[i] == "TLP_Import") {
                btndisable = true;
            }
            if (perData[i] == "TLP_Add") {
                saveBtnDisable = true;
            }
        }
        console.log("Button disabled");
        console.log(btndisable);
        return (
            <div className="background">
                {this.state.status == 'save' ?
                    <Notification className="Confirmation_header" status='success' size='large' title='Your updates to the TLP grid were saved'>
                        Please request update approval to publish an updated TLP grid.
                    </Notification>
                    : null
                }
                {this.state.status == 'pendingApproval' ?
                    <Notification className="Confirmation_header" status='info' size='large' title='Please request update approval'>
                        You have to request update approval before the updated TLP grid can be published.
                    </Notification>
                    : null
                }
                {this.state.status == 'importFailed' ?
                    <Notification className="Confirmation_header" status='error' size='large' title='Import failed'>
                        Please ensure you import an excel file no larger than 300KB.
                    </Notification>
                    : null
                }
                {this.state.status == 'importExcelFailed' ?
                    <Notification className="Confirmation_header" status='error' size='large' title='Import failed'>
                        Please import valid excel file.
                    </Notification>
                    : null
                }
                {this.state.status == 'importExcelValueFailed' ?
                    <Notification className="Confirmation_header" status='error' size='large' title='Import failed'>
                        Import failed due to invalid values
                    </Notification>
                    : null
                }
                {this.state.status == 'genericError' ?
                    <Notification className="Confirmation_header" status='error' size='large' title='Import failed'>
                        Some error occurred. Please make sure you have input valid data.
                    </Notification>
                    : null
                }

                <div className="form-group row" style={{
                    margin: '20px auto 0px auto',
                    width: '924px'
                }}>
                    <div className="col-sm-7">
                        <label className="update_deal_title">Update TLP grid</label>
                    </div>
                    <div className="col-sm-5 " className={!btndisable ? "disabledbutton" : ""}>
                        <input type="file" style={{ display: 'none' }} ref={this.importOpenFileRef}
                            class="form-control file_upload_hide" accept=".xlsx"
                            onChange={this.onChangeImportHandler.bind(this)}
                            onClick={(event) => {
                                event.target.value = null
                            }} />
                        <span className="excel_import" onClick={this.importFileHandler.bind(this)}><img src={importExcel} style={{ marginRight: '10px' }} />import from excel</span>
                    </div>
                </div>

                <div className="form-group row">
                    <div className="col-sm-12">
                        <div className="tlp_deal_container">
                            <UpdateTLPGrid onRef={ref => (this.child = ref)} importFileFailed={this.importFileFailed.bind(this)}
                                enableApproveButton={this.enableApproveButton.bind(this)}
                                approvalPending={this.approvalPending.bind(this)}
                                approvalConfirmation={this.sendApprovalConfirmation.bind(this)}
                                approve={this.state.buttonApprove} save={this.saveGrid.bind(this)}
                                disableSave={this.disableSaveButton.bind(this)} cancel={this.state.buttonCancel}
                                saveConfirm={this.saveConfirmation.bind(this)}
                                pageError={this.pageError.bind(this)}
                                noStatus={this.noStatus.bind(this)} importFileValueFailed={this.importFileValueFailed.bind(this)}
                            />
                        </div>
                    </div>
                </div>

                <div className="form-group row footer_btn">
                    <div className="col-sm-2">
                        {/* <button className='zb-button zb-button-primary approval_btn' data-toggle="modal" data-target="#myModal2" disabled={this.state.buttonApprove}>Request approval</button> */}
                        <button className='zb-button zb-button-primary approval_btn' data-toggle="modal" data-target="#myModal2" disabled={saveBtnDisable ? this.state.buttonApprove : true}>Request approval</button>
                    </div>
                    <div className="col-sm-3 ">
                        <button className='zb-button zb-button-secondary update_save_btn' data-toggle="modal" data-target="#myModal" disabled={saveBtnDisable ? this.state.buttonSave : true}>Save updates</button>
                        {/* <button type="button" class="btn btn-default update_save_btn" data-toggle="modal" data-target="#myModal" disabled={this.state.buttonSave}>Save updates</button> */}
                    </div>
                    <div className="col-sm-3">
                        <button className='zb-button zb-button-secondary cancel_btn' data-toggle="modal" data-target="#myModal1" disabled={saveBtnDisable ? this.state.buttonCancel : true}>Cancel updates</button>
                        {/* <button type="button" class="btn btn-default cancel_btn" data-toggle="modal" data-target="#myModal1" disabled={this.state.buttonCancel}>Cancel updates</button> */}
                    </div>
                </div>

                {/* {this.state.openDialog ?
                    <PopupModal headerTitle="Save updates"
                        headerbody="Are you sure you want to save the updates to the TLP grid?"
                        buttontext1="Yes, save updates" buttontext2="No, don't save update"
                        datatarget="myModal" onClick={this.onClick} toggleDialog={this.toggleDialog.bind(this)}
                        openDialog={this.state.openDialog}
                    /> : null
                } */}

                <Popup headerTitle="Save updates" headerbody="Are you sure you want to save the updates to the TLP grid?" buttontext1="Yes, save updates" buttontext2="No, don't save update"
                    datatarget="myModal" onClick={this.onClick} />
                <Popup headerTitle="Cancel updates" headerbody="Are you sure you want to cancel the updates to the TLP grid?" buttontext1="Yes, cancel updates" buttontext2="No, don't cancel update" datatarget="myModal1" onClick={this.cancelSave.bind(this)} />
                <div id="myModal2" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss='modal'>&times;</button>
                                <h4 class="modal-title header_title">Request update approval</h4>
                            </div>

                            {this.state.fileUploadStatus ? <div class="modal-body">
                                <p className="header_body">Are you sure you want to request update approval?</p>
                                <div className="form-group row">
                                    <div className="col-sm-1">
                                        <div style={{ backgroundColor: '#6F2C91', width: '16px', height: '16px', marginLeft: '21px', marginTop: '5px', textAlign: 'center' }}>
                                            <span style={{ color: '#fff', fontSize: '7px' }}>MSG</span></div>
                                    </div>
                                    <div className="col-sm-9">
                                        <span className="header_body" style={{ marginLeft: '-7px' }}>{this.state.uploadedFileName}</span>
                                    </div>

                                    <div className="col-sm-2" onClick={this.onClickHandler.bind(this)}>
                                        <img src={deleteFile} style={{ float: 'right', marginRight: '21px' }} onClick={this.deleteAttachment.bind(this)} />
                                    </div>
                                </div>
                            </div> : null}
                            {!this.state.fileUploadStatus ? <div class="modal-body">
                                <p className="header_body">Are you sure you want to request update approval?</p>
                                <div className="form-group row">
                                    <div className="col-sm-9">
                                        <span className="header_body">Upload supporting document, up to 2GB (optional)</span>

                                        <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Please attach the supporting document for the updated TLP grid
                                                        </Flyout>
                                            }>
                                            <img src={help} data-tip data-for='help' style={{ marginLeft: '4px', marginTop: '-5px' }} />
                                            {/* <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" /> */}
                                        </FlyoutTrigger>
                                    </div>
                                    <div className="col-sm-3" onClick={this.onClickHandler.bind(this)}>
                                        <div style={{
                                            textDecoration: 'underline',
                                            color: '#ad1982',
                                            marginLeft: '41px',
                                            fontSize: '16px'
                                        }} >Browse</div>
                                    </div>
                                </div>
                                <FileUpload onChange={this.onChangeHandler.bind(this)} reference={this.inputOpenFileRef} />
                            </div> : null}
                            <div class="modal-footer" style={{ display: 'table', border: 'none', marginLeft: '17px', marginTop: '-13px' }}>
                                <button className='zb-button zb-button-primary save_pop_btn' style={{ width: '260px' }} data-dismiss="modal" onClick={this.sendForApproval}>Yes, request approval</button>
                                <button className='zb-button zb-button-secondary cancel_pop_btn' style={{ width: '260px' }} data-dismiss="modal">No, don’t request approval</button>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )
    }
}

export default withRouter(updateTLPGrid);
