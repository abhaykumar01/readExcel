import React from 'react';
import './invoiceApprover.css';
import { HttpPost, HttpGet, HttpPut} from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { Icon } from '@zambezi/sdk/icons';
import NotificationGrid from '../../commonComponents/notificationGrid';
import InvoiceListApproverGrid from '../../commonComponents/invoiceListApproverGrid';
import { Select } from '@zambezi/sdk/dropdown-list';
import { multipleExportApprover } from '../../models/dataModel.js';
import { Notification } from '@zambezi/sdk/notification';
import Dropdownfieldcustom from '../../commonComponents/DropdownFieldCustom';
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;
//import console = require('console');


var isExportBtnDisabled= true;
var isRequestApprovalBtnDisabled = true;
class invoiceListApprover extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            latestNotification :{},
            notificationData:{},
            recordView: 10,
            isExportBtnDisabled:true,
            isRequestApprovalBtnDisabled:true,
            completeData:[],
            invoicaDatastatus: false,
            pageStatus:'',
            isLoading:false,
            languageName:"English", 
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
        }
    }

    HandleSelectChange(event, type, value) {
        this.setState({ recordView: type.value });
    }

    componentDidMount() {
        var filteredData;
        console.log(localStorage.getItem('visitedFrom'));
        console.log(localStorage.getItem('nObject'));
        console.log(localStorage.getItem('allNotifications'));
        console.log(JSON.parse(localStorage.getItem('allNotifications')));
        var jsonForNotification = JSON.parse(localStorage.getItem('allNotifications'));
        if(jsonForNotification != undefined){
            filteredData= jsonForNotification.filter(function(items) {
            return items.isActionCompleted == 0 
                && items.group.toLowerCase() == "invoice"
                && items.name.toLowerCase()== "invoice_request_approval"
                && items.type.toLowerCase() == "action"
                && items.description.indexOf("pending for your review") > 0
             });
        }
        //console.log(filteredData[0])
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf,
            latestNotification:filteredData[0]
        });
        this.initForm();
        // var currentComponent = this;
        // let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/Anitha/Pending_For_Approval';

        // let output1 = HttpGet(endPoint).then(function (response) {
        //     if (response.data.length > 0) {
        //         currentComponent.setState({ gridCount: 1 });
        //         currentComponent.setState({ showPendingNotificationStatus: true });
        //     } else {
        //         currentComponent.setState({ showPendingNotificationStatus: false });
        //     }
        // })
        //     .catch(function (error) {
        //     })
    }
    initForm(){
        if (this.props.location.state != undefined) {
            this.setState({ notificationData : this.props.location.state.notificationData});
            
            console.log(this.state.notificationData)
        }
        // if(this.props.history.location.state != null 
        //     && this.props.history.location.state != undefined) {
        //         console.log(this.props.history.location.state);
        //     }
        
    }
   

    goToPage(pagename) {
        this.props.history.push({
            pathname: '/lms/' + pagename
        })
        return true;
    }
    
    getGridData(completeData){
        this.setState({completeData: completeData});
    }
    getDropdownItem(event, val, type) {
        if (event == "languagepreference") {
            if (type.value != "") {
                this.setState({ languageName: type.value });
            } else {
                this.setState({ languageName: type.value });
            }
        }
        return true;
    }
    requestApprovalHandle(){
        var filteredData = [];
		if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
		filteredData= this.state.completeData.filter(function(items) {
		return items.isChecked == true && items.actionneeded.toLowerCase() == "yes" && (items.status.toLowerCase() =="pending approval");
			});
        }
        if(filteredData != undefined && filteredData.length > 0){
        filteredData.map((item)=>{
            console.log(item)
            item.reasonForRejection = "";
            item.respondedBy = this.state.racfData;
            item.status = "Approved"; //change as per request for approval
            item.actionneeded = "No";
        });
    }   
    console.log(filteredData)
        var currentComponent = this;
        console.log(currentComponent.state.notificationData)
        var endPoint;
        if(localStorage.getItem('visitedFrom') == "notification"){
             endPoint = API_ENDPOINT.REQUEST_APPROVAL + "/" + currentComponent.state.notificationData.notificationID;
        }
        else{
            endPoint = API_ENDPOINT.REQUEST_APPROVAL + "/" + currentComponent.state.latestNotification.notificationID;
        }
        //let endPoint = API_ENDPOINT.REQUEST_APPROVAL + "/" + currentComponent.state.notificationData.notificationID;
        let payLoadData = multipleExportApprover(filteredData);
        currentComponent.setState({ isLoading: true });
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
            //window.alert(JSON.stringify(response.data));
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'requestApprovalSuccess' });
        })
        .catch(function (error) {
            //window.alert(error);
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({ pageStatus: 'requestApprovalError' });
        })
    }

    requestRejectionHandle(){
        var filteredData = [];
		if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
		filteredData= this.state.completeData.filter(function(items) {
		return items.isChecked == true && items.actionneeded.toLowerCase() == "yes" && (items.status.toLowerCase() =="pending approval");
			});
        }
        if(filteredData != undefined && filteredData.length > 0){
        filteredData.map((item)=>{
            item.reasonForRejection = "";
            item.respondedBy = this.state.racfData;
            item.actionneeded = "No";
            item.status = "Rejected"; //change as per request for approval
        });
    }   
        var currentComponent = this;
        var endPoint;
        if(localStorage.getItem('visitedFrom') == "notification"){
             endPoint = API_ENDPOINT.REQUEST_APPROVAL + "/" + currentComponent.state.notificationData.notificationID;
        }
        else{
            endPoint = API_ENDPOINT.REQUEST_APPROVAL + "/" + currentComponent.state.latestNotification.notificationID;
        }
        //let endPoint = API_ENDPOINT.REQUEST_APPROVAL + "/" + currentComponent.state.notificationData.notificationID;
        let payLoadData = multipleExportApprover(filteredData);
        currentComponent.setState({ isLoading: true });
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
            //window.alert(JSON.stringify(response.data));
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'requestRejected' });
        })
        .catch(function (error) {
            //window.alert(error);
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({ pageStatus: 'requestApprovalError' });
        })
    }
    
    handleExportOracle(){
        var filteredData = [];
		if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
		filteredData= this.state.completeData.filter(function(items) {
		return items.isChecked == true && items.status =="Approved";
			});
        }
        if(filteredData != undefined && filteredData.length > 0){
        filteredData.map((item)=>{
            item.status = "Approved";
        });
    }
        var currentComponent = this;
        let endPoint = API_ENDPOINT.MULTIPLE_EXPORT + "/"+ this.state.languageName; 
        let payLoadData = multipleExportApprover(filteredData);
        
        currentComponent.setState({ isLoading: true });
        let output1 = HttpPut(currentComponent, payLoadData, endPoint).then(function (response) {
           // window.alert(JSON.stringify(response.data));
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'exportSuccess' });
        })
        .catch(function (error) {
           // window.alert(error);
            currentComponent.setState({ isLoading: false });
            currentComponent.setState({invoicaDatastatus: !currentComponent.state.invoicaDatastatus});
            currentComponent.setState({ pageStatus: 'exportError' });
        })
}
        exportBtnState(value){
            if(value == true){
                this.setState({ isExportBtnDisabled: true });
            }else {
                this.setState({ isExportBtnDisabled: false });
            }
          
        }
        requestApprovalBtn(value){
            if(value == true){
                this.setState({ isRequestApprovalBtnDisabled: true });
            }else {
                this.setState({ isRequestApprovalBtnDisabled: false });
            }
        }
        

    render() {
        console.log(this.state.isRequestApprovalBtnDisabled);
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var approveBtnDisable = true;
        var rejectBtnDisable = true;
        var btndisable= true;
        // for(var i= 0 ;i<datalen ; i++){
        //     if (perData[i] == "Invoice_Request_Approval") { 
        //         btndisable = false;
        //     }
        // }
          if(this.state.memberOfDetail.indexOf("BusinessUser") > 0){
            for(var i= 0 ;i<datalen ; i++){
                if (perData[i] == "Invoice_First_Approval") { 
                    btndisable = false;
                }
            }
          }      
          for(var i= 0 ;i<datalen ; i++){
            if (perData[i] == "Invoice_Further_Approval") { 
                btndisable = false;
            }
        }
        console.log(btndisable);
        // if(this.state.completeData != undefined && this.state.completeData.length > 0 && this.state.completeData != null){
        //     for(var i =0 ; i < this.state.completeData.length ; i++){
        //         if(this.state.completeData[i].ID != undefined && this.state.completeData[i].ID != null){
		// 			if(this.state.completeData[i].isChecked == true && this.state.completeData[i].status.toLowerCase() != "approved"){
        //                 //isExportBtnDisabled=true;
        //                 this.setState({ isExportBtnDisabled: true });
                        
        //                 break;
        //             }
        //             else{
        //                 this.setState({ isExportBtnDisabled: false });
        //                 break;
        //                 //isExportBtnDisabled=false;
        //             }
        //         }
        //     }
        // }
        return (
            <div className="background">
                {this.state.pageStatus == 'exportSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Export to oracle is successful'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'exportError' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='error' size='large' title='Failed due to system down'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'requestApprovalSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Request approved'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'requestRejected' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Request rejected'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'requestApprovalError' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='error' size='large' title='Action failed, Please try again'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }
                <div className="inner_container" style={{
                    width: '91%',
                    margin: '30px -20px 0px 8%'
                }}>

<div class="form-group">
<label className="invoice_title">Invoicing Approver</label>
</div>
<div className="row form-group"> 
<div className="col-sm-6" ></div>
<div className="col-sm-6 dropDownLang">
<Dropdownfieldcustom classname="font_config_invoice"  customLabel="font_config" title="Language" 
data={["","English","Norwegian","Swedish","Finnish"]} name="languagepreference" selectedValue="English"
onChange={this.getDropdownItem.bind(this, 'languagepreference')} />
</div>
</div> 
                    {this.state.isLoading == true ? 
                        <div>
                            <div className="zb-loader-block zb-loader-block-inverted">
                            <div className="zb-loader-content">
                                <span className="zb-loader" />
                                <span className="zb-loader-text">
                                Loading...
                                </span>
                            </div>
                            </div>
                    </div>: null }
                   {this.state.invoicaDatastatus ? <InvoiceListApproverGrid  
                    getGridData={this.getGridData.bind(this)} 
                    selectedRecord={parseInt(this.state.recordView)} exportBtnState={this.exportBtnState.bind(this)} 
                    requestApprovalBtn={this.requestApprovalBtn.bind(this)}/>
                    :
                    null
                    }
                    {!this.state.invoicaDatastatus ? <InvoiceListApproverGrid 
                    getGridData={this.getGridData.bind(this)} 
                    selectedRecord={parseInt(this.state.recordView)} exportBtnState={this.exportBtnState.bind(this)}
                    requestApprovalBtn={this.requestApprovalBtn.bind(this)} />
                    :
                    null
                    }
                    <span class="select-wrap -pageSizeOptions select_record">
                        <span className="text_property" style={{
                            marginRight: '18px',
                            color: '#666666'
                        }}>Per page</span>
                        <Select
                            defaultValue={this.state.recordView}
                            suggestions={['5', '10', '15', '20']}
                            className='notification_select_row'
                            isError={false}
                            onChange={this.HandleSelectChange.bind(this)}
                        />
                    </span>
                    

                </div>
                <div class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 8%', paddingLeft:'0%'}}>
                    {/* <button type="button"  className="zb-button zb-button-primary model_invoice_btn" onClick={this.goToPage.bind(this,'viewInvoicingDetail')}>Create Index Invoices</button>  */}
                    {/* onClick={this.goToPage.bind(this,intrestInvoicingForm)} */}
                    {/* <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" data-toggle="modal" data-target="#cancelSave" onClick={this.goToPage.bind(this,'interestInvoicingForm')}>Create Interest Invoices</button>&nbsp;&nbsp;&nbsp; */}
                    {/* <button type="button"  className="zb-button zb-button-primary model_invoice_btn" disabled={this.state.isExportBtnDisabled} onClick={this.handleExportOracle.bind(this)}>Export to Oracle</button>  */}
                    {/* onClick={this.goToPage.bind(this,intrestInvoicingForm)} */}
                    <button type="button"  className="zb-button zb-button-primary model_invoice_btn" disabled={this.state.isRequestApprovalBtnDisabled} data-toggle="modal" data-target="#cancelSave" onClick={this.requestApprovalHandle.bind(this)}>Approve</button>
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" disabled={this.state.isRequestApprovalBtnDisabled } data-toggle="modal" data-target="#cancelSave" onClick={this.requestRejectionHandle.bind(this)}>Reject</button>
                </div>
                {/* <div class="modal-footer hide" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button type="button"  className="zb-button zb-button-primary model_invoice_btn" disabled={this.state.isExportBtnDisabled} onClick={this.handleExportOracle.bind(this)}>Export to Oracle</button> 
                    {/* onClick={this.goToPage.bind(this,intrestInvoicingForm)} 
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" disabled={this.state.isRequestApprovalBtnDisabled} data-toggle="modal" data-target="#cancelSave" onClick={this.requestApprovalHandle.bind(this)}>Request Approval</button>
                </div> */}
            </div>
        )
    }
}

export default invoiceListApprover;