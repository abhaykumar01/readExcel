import React, { PureComponent } from 'react';
import { Notification } from '@zambezi/sdk/notification';
import './login.css';
import { AuthorizationContext } from '../../components/authContext/index';
// import logo from '../assets/images/logo.png';
import logo from '../../assets/images/logo.png'
import { Link } from 'react-router-dom';

// import { AuthorizationContext } from '../../'

class loginError extends PureComponent {
    static contextType = AuthorizationContext;
    constructor(props) {
        document.execCommand('Stop');
        super(props);
        this.state = {
            hasError: false
        }        
    }

    componentDidCatch() {
        // Display fallback UI
        this.setState({ hasError: true }, function () { 
            document.execCommand('Stop');
        });
    }

    render() { 
        var errorCode = localStorage.getItem('errorCode');
        var message = 'Please refresh after some time and if the issue persists';
        var heading = 'Internal Server Error';

        if (parseInt(errorCode)  === 400 || parseInt(errorCode)  === 405 || parseInt(errorCode)  === 404 || parseInt(errorCode)  === 409){
            heading = 'Internal Server Error'
            message = 'Please refresh after some time and if the issue persists'
        } else if (parseInt(errorCode)  === 401){
            heading = 'Access Denied'
            message = 'You do not have permission to access the Lease Management System. To request access'
        } else if (parseInt(errorCode)  === 403){
            heading =  'Forbidden'
            message = 'You do not have permission to access the Lease Management System. To request access'
            
        } 
        else if (parseInt(errorCode)  === 500){
            heading = 'Internal Server Error'
            message = 'There is an internal server error'
        }

      
            return (
                <div>
                    <nav className="navbar navbar-inverse header_container">
                        <div className="header_top">
                            <div className="navbar-header header_up" style={{ marginBottom: '32px'}}>
                                <img src={logo} className="logo" />
                            </div>
                        </div>
                    </nav>
                    <div className="background" >
                        <Notification className="Confirmation_header" status='warning' size='large' title=''>
                           <h2> {heading} </h2>
                          {message}, Please raise a <a href="#" className="serviceLink">ServiceLine express</a> request.
                    </Notification>
                    </div>
                </div>
            )
    }
}

export default loginError;
