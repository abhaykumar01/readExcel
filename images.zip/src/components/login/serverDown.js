import React, { PureComponent } from 'react';
import { Notification } from '@zambezi/sdk/notification';
import './login.css';
import logo from '../../assets/images/logo.png'
import { Link } from 'react-router-dom';

var message = "We’re sorry, the server is down. We’re working on fixing the problem ASAP.";
class serverDown extends PureComponent {
    constructor(props) {
        // document.execCommand('Stop');
        super(props);
        this.state = {
            hasError: false
        }
        message = localStorage.getItem('ServerErrorMessage');
        localStorage.setItem('serverDown', 'false');
    }

    componentDidCatch() {
        // Display fallback UI
        console.log("Server down Error received::: ")
    }

    render() {
        return (
            <div>
                {/* <nav className="navbar navbar-inverse header_container">
                    <div className="header_top">
                        <div className="navbar-header header_up" style={{ marginBottom: '32px' }}>
                            <img src={logo} className="logo" />
                        </div>
                    </div>
                </nav> */}
                <div className="background" >
                    <Notification className="Confirmation_header" status='warning' size='large' title='Problem with the server'>
                        {message} {/* We’re sorry, the server is down. We’re working on fixing the problem ASAP. */}
                    </Notification>
                </div>
            </div>
        )
    }
}

export default serverDown;
