import React from 'react';
import { withRouter } from 'react-router-dom';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Icon } from '@zambezi/sdk/icons';
import { HttpPost, HttpGet } from '../../../services/api';
import { API_ENDPOINT } from '../../../config/config';
import AddOfflineApprovalModal from '../dealApprovalModals/addOfflineApprovalModal';
import OfflineApprovalGrid from './offlineApprovalGrid';
import GeneralDealApprovalModal from './../dealApprovalModals/generalDealApprovalModal';
// import { offlineSolutionSuggestionData, defaultDealApprovalObject, dealNotificationMessages,formatDate } from '../dealApprovalsConstants';
import { businessAreaTeamMapping } from './../dealBusinessTeamMapping'
import { AuthorizationContext } from '../../authContext/index.js'
import { offlineSolutionSuggestionData, defaultDealApprovalObject, dealNotificationMessages, formatDate } from '../../../models/LeaseConstants';
const PING = process.env.REACT_APP_PING;

class OfflineApprovalTab extends React.Component{
    static contextType = AuthorizationContext
    constructor(props){
        super(props);
        this.state = {
            isAddApprovalModalOpen : false,
            solutionSuggestions : offlineSolutionSuggestionData,
            offlineApprovalGridData : this.formatAllDates(props.data, props.locale),
            dealId : props.dealId,
            newSolutionTeamMapping : [],
            additionalFinancingTeamMapping : [],
            additionalLesseTeamMapping : [],
            // solution : '',
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            solution : props.offlineSolution !=='null' ? props.offlineSolution : '',
        }
    }
    componentDidMount(){
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        }); 
    }
    componentWillReceiveProps(props){
        this.setState({
            offlineApprovalGridData : this.formatAllDates(props.data, props.locale),
            dealId : props.dealId,
            solution : props.offlineSolution !=='null' ? props.offlineSolution : '',
        })
    }

    componentWillMount(){
        this.props.hideNotification();
        this.getBusinessAreaTeamMappings();
    }

    addNewOfflineApproval(newApproval){
        let newDealApprovalObj = {...defaultDealApprovalObject};

        this.saveOfflineApproval(newApproval).then((response) => {
            if(response && response.data && response.data[0].staticApproverId){
                let savedApproval = response.data[0];
                this.saveBusinessSolutionTeamMapping(newApproval,savedApproval.staticApproverId);
                newDealApprovalObj.leaseApprovalType = 'offline';
                newDealApprovalObj.leaseContractId = this.state.dealId;
                newDealApprovalObj.staticApprover = { ...savedApproval };
                newDealApprovalObj.staticApproverId = savedApproval.staticApproverId;
                newDealApprovalObj.businessArea = savedApproval.businessArea;
                newDealApprovalObj.description = savedApproval.staticApproverDescription;
                newDealApprovalObj.workflowNumber = this.props.selectedWorkflow;
                newDealApprovalObj.tempApprovalId = this.state.offlineApprovalGridData.length; // To set key of the select component in react table

                if (this.state.solution.toLowerCase() === 'new solution') {
                    newDealApprovalObj.leaseApprovalTeam = newApproval.newSolution;
                } else if (this.state.solution.toLowerCase() === 'additional financing') {
                    newDealApprovalObj.leaseApprovalTeam = newApproval.additionalFinancing;
                } else if (this.state.solution.toLowerCase() === 'additional lessee') {
                    newDealApprovalObj.leaseApprovalTeam = newApproval.additionalLease;
                }

                this.state.offlineApprovalGridData.unshift(newDealApprovalObj);
                this.setState({ offlineApprovalGridData: this.state.offlineApprovalGridData }, this.saveUpdates);
                this.closeModal('addApproval');
            }
        }).finally(()=>{
            this.closeModal('addApproval');
        });
    }

    saveOfflineApproval(newApproval){
        let offlineApproval =[];
        let url = API_ENDPOINT.SAVE_STATIC_APPROVAL;
        let newOfflineApproval = {
            "approvalType": "offline",
            "businessArea": newApproval.businessArea,
            "staticApproverDescription": newApproval.staticApproverDescription,
            "staticApproverId": null
        }
        
        offlineApproval.push(newOfflineApproval);
        
        return HttpPost(this,offlineApproval,url).catch((error)=>{
            console.log(error);
        })
    }

    saveBusinessSolutionTeamMapping(newApproval, staticApproverId){
        let mappingConstant = [];
        let url = API_ENDPOINT.SAVE_APPROVAL_SOLUTION_CONSTANT;
        let newSolutionConstant ={
            "businessArea": newApproval.businessArea,
            "dealSolutionConstantId": null,
            "solutionType": "New solution",
            "staticApproverId": staticApproverId,
            "value": newApproval.newSolution,
        }
        mappingConstant.push(newSolutionConstant);

        let additionalFinancingConstant ={
            "businessArea": newApproval.businessArea,
            "dealSolutionConstantId": null,
            "solutionType": "Additional financing",
            "staticApproverId": staticApproverId,
            "value": newApproval.additionalFinancing
        }
        mappingConstant.push(additionalFinancingConstant);

        let additionalLesseConstant ={
            "businessArea": newApproval.businessArea,
            "dealSolutionConstantId": null,
            "solutionType": "Additional lessee",
            "staticApproverId": staticApproverId,
            "value": newApproval.additionalLease,
        }
        mappingConstant.push(additionalLesseConstant);

        return HttpPost(this, mappingConstant, url).then((response)=>{
            this.getBusinessAreaTeamMappings();
        }).catch((error)=> {
            console.log(error);
        })

    }

    onRemoveApproval(approvalObj){
        this.state.removeApprovalObj = approvalObj;
        this.openModal('removeApproval');
    }

    removeOfflineApproval(){
        let approvalObj=this.state.removeApprovalObj;
        if(approvalObj){
            this.deleteOfflineApproval(approvalObj.staticApprover).then((response)=>{
                let updatedData = this.state.offlineApprovalGridData.map((item)=>{
                    if(item.leaseApprovalId === approvalObj.leaseApprovalId){
                        item.isDeleted = 1;
                    }
                    return item;
                })
                this.setState({ offlineApprovalGridData: updatedData }, this.saveUpdates);
            }).finally(()=>{
                this.closeModal('removeApproval');
            })
        } else {
            this.closeModal('removeApproval');
        }
    }

    deleteOfflineApproval(staticApprover){
        let offlineApproval =[];
        let url = API_ENDPOINT.SAVE_STATIC_APPROVAL;
        
        staticApprover.isDeleted = 1;
        offlineApproval.push(staticApprover);
        
        return HttpPost(this,offlineApproval,url).catch((error)=>{
            console.log(error);
        })
    }

    saveUpdates(){
        let data = this.state.offlineApprovalGridData;

        HttpPost(this, data, API_ENDPOINT.SAVE_DEAL_APPROVALS).then((response)=>{
            this.props.updateDealCaptainBtn();
            if(this.state.solution && this.state.solution !== ''){
                this.props.updateDealSolutions(undefined, this.state.solution);
            }

            if(response.data && response.data.length>0){
                let savedData = response.data.map((item, index)=>{
                    if(item.staticApprover && item.staticApprover.staticApproverId){
                        item.businessArea=item.staticApprover.businessArea;
                        item.description=item.staticApprover.staticApproverDescription;
                    }
                    item.displayStatusDate= formatDate(item.leaseApprovalStatusDate, this.props.locale);
                    return item;
                });
                savedData = savedData.filter((item) => {
                    return item.isDeleted !== 1;
                })

                this.props.updateOfflineApprovalData(savedData);
                this.closeModal('saveUpdates');

                let notification={
                    showNotification: true,
                    notificationType: 'success',
                    notificationMsg: dealNotificationMessages.saveUpdatesSuccess,
                }
                this.props.setNotification(notification);
            }
        }).catch((error)=>{
            console.log(error);
        })
    }

    handleWorkflowChange(event, target){
        this.setState({solution : ''});
        this.props.updateWorkflow(target.value);
    }

    handleSolutionChange(event, obj){
        let solution = obj.value;
        let updatedData = this.updateBusinessAreaTeam(solution.toLowerCase());
        this.props.setDealApprovalSolutions(undefined, solution);
        this.setState({
            offlineApprovalGridData : updatedData,
            solution : solution,
        });
    }

    getBusinessAreaTeamMappings(){
        let newSolutionMapping=[];
        let additionalFinancingMapping=[];
        let additionalLesseMapping=[];
        let url = API_ENDPOINT.GET_DEAL_BUSINESS_SOLUTION_MAPPING;

        HttpGet(this, url).then((response) => {
            let businessAreaTeamMapping = response.data;

            businessAreaTeamMapping.forEach((item)=>{
                if(item.solutionType.toLowerCase()==='new solution'){
                    newSolutionMapping.push(item);
                } else if(item.solutionType.toLowerCase() ==='additional financing'){
                    additionalFinancingMapping.push(item);
                }else if(item.solutionType.toLowerCase() ==='additional lessee'){
                    additionalLesseMapping.push(item);
                }
            })
    
            this.setState({
                newSolutionTeamMapping : newSolutionMapping,
                additionalFinancingTeamMapping : additionalFinancingMapping,
                additionalLesseTeamMapping : additionalLesseMapping,
            })
        })
    }

    updateBusinessAreaTeam(solution){
        let data = this.state.offlineApprovalGridData;
        return data.map((item) => {
            if(item.staticApprover && item.staticApprover.staticApproverId != null){
                item.leaseApprovalTeam = this.getTeamForBusinessArea(item.staticApproverId, solution);
            } 
            // else if(item.dynamicApprover){
            //     let team = '';
            //     if(solution === 'new solution'){
            //         team = item.dynamicApprover.newSolution;
            //     } else if(solution === 'additional financing'){
            //         team = item.dynamicApprover.additionalFinancing;
            //     }else if(solution === 'additional lessee'){
            //         team = item.dynamicApprover.additionalLease;
            //     }
            //     item.leaseApprovalTeam = team;
            // }
            return item;
        })
    }

    getTeamForBusinessArea(approverId, solution){
        let teamMapping = [];
        let teamName = '';
        solution = solution.toLowerCase();

        if(solution ==='new solution'){
            teamMapping = this.state.newSolutionTeamMapping;
        } else if(solution ==='additional financing'){
            teamMapping = this.state.additionalFinancingTeamMapping;
        }else if(solution ==='additional lessee'){
            teamMapping = this.state.additionalLesseTeamMapping;
        }

        for(let i=0; i<teamMapping.length; i++){
            if(teamMapping[i].staticApproverId===approverId){
                teamName = teamMapping[i].value;
                break;
            }
        }
        
        return teamName;
    }

    cancelUpdates(){
        this.props.history.push({
            pathname: '/lms/mainSummaryTabsPage',
            state: { leaseParentId: this.state.dealId }
        });
    }

    openModal(modalName){
        if(modalName === 'addApproval'){
            this.setState({addApprovalModalOpen : true});
        } else if(modalName === 'removeApproval'){
            this.setState({removeApprovalModalOpen : true});
        } else if(modalName === 'saveUpdates'){
            this.setState({saveUpdatesModalOpen : true});
        } else if(modalName === 'cancelUpdates'){
            this.setState({cancelUpdatesModalOpen : true});
        }
    }

    closeModal(modalName){
        if(modalName === 'addApproval'){
            this.setState({addApprovalModalOpen : false});
        } else if(modalName === 'removeApproval'){
            this.setState({removeApprovalModalOpen : false});
        } else if(modalName === 'saveUpdates'){
            this.setState({saveUpdatesModalOpen : false});
        } else if(modalName === 'cancelUpdates'){
            this.setState({cancelUpdatesModalOpen : false});
        }
    }

    formatAllDates(data, locale){
        return data.map((item)=> {
            item.displayStatusDate=formatDate(item.leaseApprovalStatusDate, locale);
            return item;
        })
    }

    documentsChange(response){
        var currentComponent = this;
        for(var i=0; i<currentComponent.state.offlineApprovalGridData.length; i++){
            if(currentComponent.state.offlineApprovalGridData[i].businessArea === response.businessUnit){
                currentComponent.state.offlineApprovalGridData[i].documentList.push(response);         
            }
        }
        currentComponent.forceUpdate();
    }
    
    deleteDealDoc(deletedDocDetails){
        var currentComponent = this;
        this.state.offlineApprovalGridData.forEach((item,i)=>{ 
           item.documentList.forEach((items,j)=>{ 
            if (items.documentId === deletedDocDetails.documentId){
                currentComponent.state.offlineApprovalGridData[i].documentList.splice(j);
            }               
        })});
        currentComponent.forceUpdate();
    }

    render(){
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btnOfflineSave = true;
        var labelAddOfflineApproval = true;
        var labelRemoveOfflineApproval = true;

            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Offline_Save") { 
                    btnOfflineSave = false;
                }
                if (perData[i] == "Deal_Add_Offline_Approval") { 
                    labelAddOfflineApproval = false;
                }
                if (perData[i] == "Deal_Remove_Offline_Approval") { 
                    labelRemoveOfflineApproval = false;
                }
            }
        return (
            <div>
                {this.state.addApprovalModalOpen ? 
                    <AddOfflineApprovalModal
                        open={this.state.addApprovalModalOpen}
                        onCancel={this.closeModal.bind(this, 'addApproval')}
                        onConfirm={this.addNewOfflineApproval.bind(this)}
                        data={this.state}
                    /> 
                : null}
                {this.state.removeApprovalModalOpen ? 
                    <GeneralDealApprovalModal
                        title="Remove offline approval"
                        confirmText='Yes, remove approval'
                        msgAccessor='removeApprovalMsg'
                        open={this.state.removeApprovalModalOpen}
                        onConfirm={this.removeOfflineApproval.bind(this)}
                        onCancel={this.closeModal.bind(this,'removeApproval')} />
                : null}
                {this.state.saveUpdatesModalOpen ? 
                    <GeneralDealApprovalModal
                        title="Save updates"
                        confirmText='Yes, save updates'
                        msgAccessor='saveUpdatesMsg'
                        open={this.state.saveUpdatesModalOpen}
                        onConfirm={this.saveUpdates.bind(this)}
                        onCancel={this.closeModal.bind(this,'saveUpdates')} />
                : null}
                {this.state.cancelUpdatesModalOpen ? 
                    <GeneralDealApprovalModal
                        title="Cancel updates"
                        confirmText='Yes, cancel updates'
                        msgAccessor='cancelUpdatesMsg'
                        cancelText="No, don't cancel"
                        open={this.state.cancelUpdatesModalOpen}
                        onConfirm={this.cancelUpdates.bind(this)}
                        onCancel={this.closeModal.bind(this,'cancelUpdates')} />
                : null}

                <div className = "row tabDropdownGroup">
                
                    <div className={"col-sm-2 addApproval " + (labelAddOfflineApproval ? 'disabledLabel' : '')}>
                        <Icon name="plus-xsmall" size='small' title="Add offline approval"/> 
                        <label onClick={this.openModal.bind(this, 'addApproval')}>Offline approval</label>
                    </div>
                    <div className="col-sm-2 col-sm-offset-6">
                        <label className="row">Solution</label>
                        <div className="row tabDropdown">
                            <Select 
                                placeholder='Select' 
                                suggestions={this.state.solutionSuggestions.map(d => d.value)}
                                onChange={this.handleSolutionChange.bind(this)}
                                value={this.state.solution}
                            />
                        </div>
                    </div>
                    <div className="col-sm-2">
                    <label className="row">View workflow</label>
                        <div className="row tabDropdown">
                            <Select 
                                placeholder='Select' 
                                suggestions={this.props.workflowSuggestions}
                                defaultValue={this.props.selectedWorkflow}
                                onChange={this.handleWorkflowChange.bind(this)}/>
                        </div>
                    </div>
                </div>

                <OfflineApprovalGrid data={this.state.offlineApprovalGridData} dealId={this.state.dealId} locale={this.props.locale} userName={this.props.userName}
                documentsChange = {this.documentsChange.bind(this)} dealApprovalDocDeleted={this.deleteDealDoc.bind(this)}
                removeOfflineApproval = {this.onRemoveApproval.bind(this)}/>

                <div className="form-group approveBtnGroup">
                    <button className='zb-button zb-button-primary footerButton' disabled={btnOfflineSave} onClick={this.openModal.bind(this, 'saveUpdates')} >Save</button>
                    <button className='zb-button zb-button-secondary footerButton transparent' onClick={this.openModal.bind(this, 'cancelUpdates')} >Cancel</button>
                </div>
            </div>
        )
    }
}

export default withRouter(OfflineApprovalTab);
