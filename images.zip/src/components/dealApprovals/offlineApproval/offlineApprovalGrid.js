import React from 'react';
import ReactTable from 'react-table';
import withFixedColumns from "react-table-hoc-fixed-columns";
import moment from 'moment';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import Pagination from '../../../commonComponents/pagination';
import { offlineApprovalHeaders, formatDate, Lease_Constants } from '../../../models/LeaseConstants';
import OnlineOfflineApprovalDocumentsTab from '../dealDocuments/OnlineOfflineApprovalDocumentsTab';

const ReactTableFixedColumns = withFixedColumns(ReactTable);

class OfflineApprovalGrid extends React.Component{
    constructor(props){
        super(props);
        this.state={
            columns : [],
            pageSize : 10,
        };
    }

    componentWillMount(){
        this.setState({columns : this.generateColumns()});
    }

    toggleAll(){
        console.log('toggle all');
    }

    changePageSize(event, type){
        this.setState({pageSize : parseInt(type.value)});
    }

    generateStatusCell(row){
        let key = row.index;

        if(row.original.staticApproverId){
            key = row.original.staticApproverId;
        } else if(row.original.dynamicApprover && row.original.dynamicApprover.dynamicApproverId){
            key = row.original.dynamicApprover.dynamicApproverId;
        } else if(row.original.tempApprovalId){
            key = row.original.tempApprovalId;
        }
        return (
            <div>
                <Select 
                key={key}
                suggestions={[Lease_Constants.LEASE_STATUS_NA, Lease_Constants.LEASE_STATUS_CONFIRMED]}
                value= {row.original.leaseApprovalStatus}
                onChange={(event, { value, method }) => {
                    let leaseStatusDate=moment(new Date()).format('YYYY-MM-DD');
                    let displayStatusDate=formatDate(new Date(), this.props.locale);
                    row.original.leaseApprovalStatus=value;
                    row.original.leaseApprovalActionedBy=this.props.userName ?  this.props.userName : "Joe Doe";
                    row.original.leaseApprovalStatusDate=leaseStatusDate;
                    row.original.displayStatusDate=displayStatusDate;
                    this.forceUpdate();
                }}
                />
            </div>
        )
    }

    generateCommentsCell(row){
        let key = row.index;
        if(row.original.staticApproverId){
            key = row.original.staticApproverId;
        } else if(row.original.dynamicApprover && row.original.dynamicApprover.dynamicApproverId){
            key = row.original.dynamicApprover.dynamicApproverId;
        } else if(row.original.tempApprovalId){
            key = row.original.tempApprovalId;
        }
        return(
            <div>
                <textarea key={key} className="form-control inputFields" type='textarea' 
                        maxLength={255} value={row.original.leaseApprovalComment}
                        onChange={(e)=>{row.original.leaseApprovalComment=e.target.value}} 
                        rows={2} style={{resize:"none", borderRadius:"0px"}}
                        placeholder="Input text here"/>
            </div>
        )
    }

    generateColumns(){
        let columns = [];
        let expanderColumn = {
            expander: true,
            width: 50,
            className: 'rowExpandArrow',
            Expander: ({ isExpanded, ...rest }) => {
                return (
                    <div>{isExpanded ? <span><Icon name="chev-up-xsmall" size="xsmall" title="" /></span> : <span><Icon name="chev-down-xsmall" size="xsmall" title="" /></span>}</div>
                );
            }
        };
        
        columns.push(expanderColumn);

        for(var i=0; i<offlineApprovalHeaders.length; i++){
            let tempColumn={};
            let currentHeader=offlineApprovalHeaders[i];

            tempColumn.id=currentHeader.id;
            tempColumn.accessor=currentHeader.accessor;
            tempColumn.Header=currentHeader.displayName;
            tempColumn.filterable=false;
            tempColumn.filterable=false;
            tempColumn.minWidth=currentHeader.minWidth;

            if(currentHeader.id === 'leaseApprovalStatus'){
                tempColumn.Cell = this.generateStatusCell.bind(this);
            }
            if(currentHeader.id === 'leaseApprovalComment'){
                tempColumn.Cell = this.generateCommentsCell.bind(this);
            }
            if(currentHeader.style){
                tempColumn.style= currentHeader.style ;
            }

            columns.push(tempColumn);
        }

        return columns;
    }

    updateDocumentsData(response) {
        this.props.documentsChange(response);
    }

    deletedDealDoc(docDetails) {
        this.props.dealApprovalDocDeleted(docDetails);
    }

    removeApproval(data){
        this.props.removeOfflineApproval(data);
    }

    render(){
        return (
            <div>
                <ReactTableFixedColumns
                    columns={this.state.columns}
                    data={this.props.data}
                    className='approvalGrid'
                    showPagination={true}
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    PaginationComponent={Pagination}
                    showPageSizeOptions = {true}
                    freezeWhenExpanded={false}
                    pageSize={this.state.pageSize}
                    minRows={1}
                    SubComponent={(row) => {
                        return (
                            <div>
                               <OnlineOfflineApprovalDocumentsTab approvalType={"offline"} leaseApproverId={row.original.staticApproverId} dealId={this.props.dealId} key={row.original.staticApproverId} data={row.original.documentList} businessArea={row.original.businessArea} 
                               documentsModified={this.updateDocumentsData.bind(this)} documentsDeleted={this.deletedDealDoc.bind(this)} removeApproval={this.removeApproval.bind(this, row.original)}></OnlineOfflineApprovalDocumentsTab>
                            </div>
                        )
                    }}
                />
                
                <span class="select-wrap -pageSizeOptions selectRecord">
                    <span className="text_property" style={{
                        marginRight: '18px',
                        color: '#666666',
                        position: 'relative',
                    }}>Per page</span>
                    <Select
                        defaultValue={this.state.pageSize}
                        suggestions={[5,10,15,20]}
                        className='notification_select_row'
                        isError={false}
                        onChange={this.changePageSize.bind(this)}/>
                </span>
            </div>
        )
    }
}

export default OfflineApprovalGrid;