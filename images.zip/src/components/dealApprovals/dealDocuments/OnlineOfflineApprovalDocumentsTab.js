import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { onlineDocumentApprovalHeaders } from '../../../models/LeaseConstants';
import DocumentUpload from '../../../commonComponents/documentsUpload';
import { HttpPostDocuments, HttpDownloadFile, HttpDelete } from '../../../services/api.js';
import { API_ENDPOINT } from '../../../config/config.js';
import { validate } from '../../../utils/validation.js';
import { Icon } from '@zambezi/sdk/icons';
import { uploadApprovalDocuments, deleteApprovalDocument } from '../../../models/dataModel.js';
import { withRouter } from 'react-router-dom';
import { AuthorizationContext } from '../../authContext/index.js'
const PING = process.env.REACT_APP_PING;

class OnlineOfflineApprovalDocumentsTab extends React.Component{
    static contextType = AuthorizationContext
    constructor(props){
        super(props);
            this.state = this.getInitialState();
            this.inputOpenFileRef = React.createRef();
            this.state = {
                columns : [],
                selectedDoc: {},
                data : [...props.data],
                racfData:'',
                permissionData: {},
                memberOfDetail:'',    
                leaseApproverId : props.leaseApproverId,   
            }
        }
        componentDidMount(){
            var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        }); 
        }
        componentWillMount(){
            this.setState({
                columns : this.generateColumns(),
                data : [...this.props.data],
                leaseApproverId : this.props.leaseApproverId,
            });
        }
        componentWillReceiveProps(props){
            this.setState({
                data : [...props.data],
                leaseApproverId : props.leaseApproverId,
            })
        }
        getInitialState = () => {
            const initialState = {
                documentUploadStatus: true,
                uploadedFileName: '',
                documentDescription: '',
                selectedFile: '',
                textErrorStatus: false,
                textErrorMessage: '',
                dialogDismiss: '',
                docType: '',
                docLengthStatus: false,              
                rbsClassificationVal: '',
                rbsRecordVal: '',
                rbsRiskVal: '',
                rbsClassificationValErrorStatus: '',
                rbsRecordValErrorStatus: '',
                rbsRiskValErrorStatus: '',
                rbsClassificationValErrorMessage: '',
                rbsRecordValErrorMessage: '',
                rbsRiskValErrorMessage: ''
              
            };
            return initialState;
        }
        downloadData(row){
            return (<div>
                <div style={{display:'flex'}}>
                    <Icon name="download-small" size="small" title="" />
                    <label style={{margin: '0 0 0 10px'}} className="doc_download" onClick={this.downloadDocument.bind(this, row.row.documentName, row.row._original.ecmDocumentId)}>Download doc</label>
                </div>
            </div>
            )
        }
        deleteData(row){
            return (<div>
                <div style={{display:'flex'}}>
                <Icon name="trash-small" size="small" style={{}} title="" />
                    <label style={{margin: '0 0 0 10px'}} className="doc_download" data-toggle="modal" data-target="#deleted" onClick={this.getDeleteDocument.bind(this, row.row._original)}>
                        Delete doc
                    </label>
                </div>
        <div id="deleted" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content" style={{ borderRadius: '0px' }}>
                                        <div class="modal-header">
                                            <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Request deletion</h4>
                                        </div>
                                        <div class="modal-body" style={{ textAlign: 'left' }}>
                                            <p className="header_body">Are you sure you want to delete the document?</p>
                                        </div>
                                        <div class="modal-footer" style={{
                                            display: 'table',
                                            border: 'none',
                                            marginLeft: '34px',
                                            marginBottom: '20px',
                                            marginTop: '20px'
                                        }}>
                                            <button className='zb-button zb-button-primary save_pop_btn ' data-dismiss="modal"  onClick={this.deleteDealDocument.bind(this)}>Delete</button>
                                            <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss="modal">Cancel</button>
                                        </div>
                                    </div>

                                </div>
                            </div></div>
            )
        }
        downloadDocument(dName, dID) {
            let currentComponent = this;
            let name = dName.replace(/\s/g, '');
            let endPoint = API_ENDPOINT.LMS_ECM + '/' + dID + '/' + name;
            let output1 = HttpDownloadFile(currentComponent, endPoint).then(function (response) {                
                if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                    // var fileName = escapeHtml(dName);
                    window.navigator.msSaveOrOpenBlob(response.data, dName);
                } else {
                    const url = window.URL.createObjectURL(new Blob([response.data]));
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', dName); //or any other extension
                    document.body.appendChild(link);
                    link.click();
    
                }                  
               
            })
            .catch(function (error) {
            })
        }
    
        generateColumns(){
            let columns = [];  
    
            for(var i=0; i<onlineDocumentApprovalHeaders.length; i++){
                let tempColumn={};
                let currentHeader=onlineDocumentApprovalHeaders[i];
    
                tempColumn.id=currentHeader.id;
                tempColumn.accessor=currentHeader.accessor;
                tempColumn.Header=currentHeader.displayName;
                tempColumn.minWidth=currentHeader.minWidth;
                tempColumn.maxWidth=currentHeader.maxWidth;
                tempColumn.filterable=false;
    
                if(currentHeader.style){
                    tempColumn.style= currentHeader.style ;
                }
    
                columns.push(tempColumn);
            }
            let downloadDocumentColumn={
                id: 'download',
                // headerClassName: 'theader',
                minWidth: 120,
                maxWidth: 180,
                Cell: this.downloadData.bind(this),
                filterable: false,
                sortable: false
            }
            columns.push(downloadDocumentColumn);
            let deleteDocumentColumn={
                id: 'delete',
                // headerClassName: 'theader',
                minWidth: 120,
                maxWidth: 180,
                Cell: this.deleteData.bind(this),
                filterable: false,
                sortable: false
            }
            columns.push(deleteDocumentColumn);
    
            return columns;
        }
    
        deleteDocument() { 
            this.setState({
                uploadedFileName: '',
                selectedFile: '',
                fileUploadStatus: false,
                documentUploadStatus: true,
                rbsClassificationVal: '',
                rbsRecordVal: '',
                rbsRiskVal: '',
                rbsClassificationValErrorStatus: '',
                rbsRecordValErrorStatus: '',
                rbsRiskValErrorStatus: '',
                rbsClassificationValErrorMessage: '',
                rbsRecordValErrorMessage: '',
                rbsRiskValErrorMessage: '',
                documentDescription: ''                
            });
            return true;
        }
   
    getDropdownItem(event, ID, type) {
        if (event == "Classification") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
                
            } else if (v[0] != null) {
                this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
            }
            this.setState({ rbsClassificationVal: type.value }, function () { 
                this.fieldValidation();
            });
        } else if (event == "Record") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRecordValErrorStatus: !v[0], rbsRecordValErrorMessage: v[1] });
            }
            this.setState({ rbsRecordVal: type.value }, function () { 
                this.fieldValidation();
            });
        } else if (event == "Risk") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRiskValErrorStatus: !v[0], rbsRiskValErrorMessage: v[1] });
            }
            this.setState({ rbsRiskVal: type.value }, function () { 
                this.fieldValidation();
            });
        }
    }

    onChangeCheckBox = (e, isChecked) => {
        this.setState({ checkboxStatus: isChecked }, function () { 
            this.fieldValidation();
        });
        return true;
    }

    uploadDocuments = (e)=> {
        this.validateField();
        var currentComponent = this;
        if (this.state.rbsClassificationVal && this.state.rbsRecordVal && this.state.rbsRiskVal && this.state.documentDescription) {       
                this.setState({
                    dialogDismiss: 'modal',
                });
            let id = parseInt(localStorage.getItem('userID'));
            let doctype = ''
            if (this.state.docType == "") {
                doctype = "MSG";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || 
                this.state.docType == "application/vnd.ms-excel") { 
                doctype = "EXCEL";
            } else if (this.state.docType == "application/pdf") {
                doctype = "PDF";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                doctype = "DOC";
            } else if (this.state.docType == "application/msword") {
                doctype = "doc";
            } else if (this.state.docType == "image/png") {
                doctype = "PNG";
            } else if (this.state.docType == "image/jpeg") {
                doctype = "JPG";
            }
            else if (this.state.docType == "text/plain") {
                doctype = "TXT";
            }
            //pdf, doc,xls,png, jpg, msg, txt
            // leaseContractID should be updated and it should be received from the parent component
            var dealID = this.props.dealId;
            var filename = this.state.uploadedFileName;
            var file = filename.split('.');
            var extension = '.'+filename.split('.').pop().toUpperCase();
            var formattedFileName = file[0]+'.'+file[1].toUpperCase();
            var riskValue = this.state.rbsRiskVal.split(' ');
            var formattedRiskValue = riskValue[0]+' '+riskValue[1].toLowerCase();
            let payLoadData = uploadApprovalDocuments(formattedFileName, doctype, 
                this.state.documentDescription, null,
                this.state.rbsClassificationVal, this.state.rbsRecordVal, formattedRiskValue, null,dealID,
                'static', this.props.leaseApproverId, this.props.businessArea);
                let endPoint = API_ENDPOINT.UPLOAD_DOCUMENTS  + '/uploadDoc/lease';
                const formData = new FormData();
                formData.append('file', this.state.selectedFile);
            formData.append('documentDetails', JSON.stringify(payLoadData));
            HttpPostDocuments(currentComponent, formData, endPoint)
                .then(function(response) {
                    if (response.status == 200) {                                                 
                        currentComponent.props.documentsModified(response.data[0]);                         
                    }
                })                
                .catch(function (error) {                    
                })                
            }
        
        return true;
    }
    validateField() {
        let v = validate('dropdown', this.state.rbsClassificationVal);
        if (v[0] == null) {
            this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
        }
        let v1 = validate('dropdown', this.state.rbsRecordVal);
        if (v1[0] == null) {
            this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ rbsRecordValErrorStatus: !v1[0], rbsRecordValErrorMessage: v1[1] });
        }

        let v2 = validate('dropdown', this.state.rbsRiskVal);
        if (v2[0] == null) {
            this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ rbsRiskValErrorStatus: !v2[0], rbsRiskValErrorMessage: v2[1] });
        }

        let v3 = validate('documentDescription', this.state.documentDescription);
        if (v3[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v3[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v3[0], textErrorMessage: v3[1] });
        }

        return true;
    }

    onClickHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.inputOpenFileRef.current.click();
        const formData = new FormData();
        formData.append('file', this.state.selectedFile);
        return true;
    }

    onChangeHandler = event => {
        var fileSize = (event.target.files[0].size / (1024 * 1024 * 1024));
        console.log(fileSize);
        if (event.target.files.length > 1) {
            this.setState({
                docLengthStatus: true,
                errorMessage: 'Max 1 file can be uploaded in one go. Please select a file and try again.'
            });
        } else { 
            if (event.target.files[0] && fileSize <= 2) {
                this.setState({
                    uploadedFileName: event.target.files[0].name,
                    docType: event.target.files[0].type,
                    selectedFile: event.target.files[0],
                    fileUploadStatus: true,
                    // documentUploadStatus: false,
                    docLengthStatus: false
                });
            } else {
                this.setState({
                    docLengthStatus: true,
                    errorMessage: 'File size should be less then 2GB. Please select a file and try again.'
                });
            }
        }
        return true;
    }

    onChangeDocumentDescription = (e) => {
        let v = validate('documentDescription', e.target.value);
        if (v[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v[0], textErrorMessage: v[1] });
        }
        this.setState({
            documentDescription: e.target.value,
        }, function () { 
                this.fieldValidation();
        })
        return true;
    }

    fieldValidation() {
        // CPBNRP-1328 fixed
        var docDescription = this.state.documentDescription.split(" ").join("");
        var descriptionValid;
        if(docDescription === "" || docDescription === null){
        // alert("At least 8 characters are required!");
        descriptionValid = false
        }
        else{
            descriptionValid = true;
        }
        

        if (this.state.rbsClassificationVal && this.state.rbsRecordVal
            && this.state.rbsRiskVal && this.state.documentDescription && this.state.checkboxStatus) {
            this.setState({
                dialogDismiss: 'modal',
                documentUploadStatus: false
            });
        } else { 
            this.setState({
                dialogDismiss: '',
                documentUploadStatus: true
            });
        }
        return true;
    }

    resetData() {
        this.setState(this.resetState(), function () {
        });
        return true;
    }
    resetState = () => {
        const initialState = {
            documentUploadStatus: true,
            uploadedFileName: '',
            documentDescription: '',
            selectedFile: '',
            textErrorStatus: false,
            dialogDismiss: '',
            docType: '',
            docLengthStatus: false,
            errorMessage: '',
            checkboxStatus: false,
            partyID: 0,
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            recordView: '10',
            pageStatus: '',
            leaseApprovalDocumentType: 'default',
            // leaseApproverId: 0
        };
        return initialState;
     }
     getDeleteDocument(document) { 
        this.setState({selectedDoc: document});
    }
    deleteDealDocument() {
        let endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/lease';
        let deletePayLoadData = deleteApprovalDocument(this.state.selectedDoc);
        let output1 = HttpDelete(this, deletePayLoadData, endPoint).then((response) => {                   
                if (response.status == 200) {                                                 
                    this.props.documentsDeleted(this.state.selectedDoc);                               
                }
        })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
            })
    }
    removeApproval(){
        console.log("Remove approval");
        this.props.removeApproval();
    }

    render(){
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var removeOfflineApproval = true;

            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Remove_Offline_Approval") { 
                    removeOfflineApproval = false;
                }
            }
        return (<div className="subcomponentBorder">
            {this.state.data.length > 0 ? <ReactTable style={{ margin: '0px 0px 0px 50px' }}
                data={this.state.data}
                columns={this.state.columns}
                className='documentdata'
                showPagination={false}
                minRows={0}
            /> : null}
            <div className="row subcomponentBorder" style={{margin:'0px'}}>
            <div className="col-sm-2" onClick={this.resetData.bind(this)}>
                <div style={{ backgroundColor: '#ffffff', padding: '15px 25px 15px 35px' }} >
                    <div data-toggle="modal" data-target="#upload" style={{ width: '175px' }}>
                        <Icon name="plus-xsmall" size='small' /><label className="uploadDocument" style={{whiteSpace:'nowrap'}} >Upload documents</label>
                    </div>
                </div>
            </div>
            { 
                this.props.approvalType === "offline" ? 
                <div className={"col-sm-2 " + (removeOfflineApproval ? 'disabledLabel' : '')} style={{padding:'15px 25px 15px 20px'}} onClick={this.removeApproval.bind(this)}>
                    <Icon name="trash-small" size="small"/><label className="uploadDocument">Remove offline approval</label>
                </div> : null
            }
            </div>

            <DocumentUpload onClick={this.onClickHandler.bind(this)}
                onChangeDoc={this.onChangeHandler.bind(this)} reference={this.inputOpenFileRef}
                id="upload" uploadStatus={this.state.documentUploadStatus} fileName={this.state.uploadedFileName}
                value={this.state.documentDescription} onChange={this.onChangeDocumentDescription.bind(this)}
                deleteDoc={this.deleteDocument.bind(this)} onUpload={this.uploadDocuments.bind(this)}
                errorStatus={this.state.textErrorStatus} textErrorMessage={this.state.textErrorMessage} dialogDismiss={this.state.dialogDismiss}
                docType={this.state.docType} docLengthStatus={this.state.docLengthStatus}
                errorMessage={this.state.errorMessage} onCheckboxChange={this.onChangeCheckBox.bind(this)}
                rbsClassificationVal={this.state.rbsClassificationVal} rbsRecordVal={this.state.rbsRecordVal}
                rbsRiskVal={this.state.rbsRiskVal} getDropdownItem={this.getDropdownItem.bind(this)}
                rbsClassificationValErrorStatus={this.state.rbsClassificationValErrorStatus} rbsClassificationValErrorMessage={this.state.rbsClassificationValErrorMessage}
                rbsRecordValErrorStatus={this.state.rbsRecordValErrorStatus} rbsRecordValErrorMessage={this.state.rbsRecordValErrorMessage}
                rbsRiskValErrorStatus={this.state.rbsRiskValErrorStatus} rbsRiskValErrorMessage={this.state.rbsRiskValErrorMessage} actionType="deal"
            />
        </div>
        )
    }
}

export default withRouter (OnlineOfflineApprovalDocumentsTab);

