import React, { forwardRef } from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from '../../../commonComponents/pagination.js';
import matchSorter from 'match-sorter'
import { HttpGet, HttpDownloadFile, HttpPut, HttpDelete } from '../../../services/api.js';
import { API_ENDPOINT } from '../../../config/config.js';
import moment from 'moment';
import { withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import DatePicker from '@zambezi/sdk/date-picker';
import { Select, DropdownList } from '@zambezi/sdk/dropdown-list';
import { object } from 'prop-types';
import { submitRequest, deleteApprovalDocument } from '../../../models/dataModel';
import { connect } from "react-redux";
import { addNotification } from "../../../redux/actions/index";
import { ECM_TOGGLE } from '../../../config/config';
import { Notification } from '@zambezi/sdk/notification';

class DealApprovalDocument extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            selected: null,
            documentRecord: {},
            expanded: {},
            selectedDoc: '',
            requestedDocDeleted: [],
            rangeStartDate: '',
            rangeEndDate: '',
            showDateRange: false,
            dateFilterApply: true,
            selectedClass: '',
            notificationData: [],
            selectedDocData: null,
            startDateError: false,
            endDateError: false,
            isDocDeleted: true
        }
        this.renderDocName = this.renderDocName.bind(this);
        this.getRangeEndDate = this.getRangeEndDate.bind(this);
        this.getInputRangeEndDate = this.getInputRangeEndDate.bind(this);
        this.getRangeStartDate = this.getRangeStartDate.bind(this);
        this.getInputRangeStartDate = this.getInputRangeStartDate.bind(this);

    }

    componentDidMount() {
        let output = [];
        this.setState({ notificationData: this.props.notifications });
        
        this.props.onRef(this);
        this.fetchDealApprovalDocuments();
    }

    fetchDealApprovalDocuments() {
        this.state.isDocDeleted = true;
        let output = [];
        this.setState({ loading: true });
        let currentComponent = this;
        this.setState({ customerRecord: output });
        // let id = parseInt(localStorage.getItem('leaseContractId'));
        let id = this.props.dealId;
        let endPoint = API_ENDPOINT.GET_LEASE_APPROVER_DOCUMENT_LIST + '/' + id;
        let output1 = HttpGet(currentComponent, endPoint).then(function(response) {
            currentComponent.setState({ documentRecord: response.data });
            for (var i = 0; i < response.data.length; i++) {
                var obj = moment(response.data[i].createdOn).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
                let time = moment(obj).format('DD/MM/YYYY');
                if (response.data[i].isflaggedForDeletion == 1) {
                    var joined = currentComponent.state.requestedDocDeleted.concat(response.data[i].documentId);
                    currentComponent.setState({
                        requestedDocDeleted: joined,
                    })
                }
                var img_class_obj = '';
                var img_name = '';
                let mediaType = response.data[i].documentMediaType.toLowerCase();
                console.log("mediaType");
                console.log(mediaType);
                if (mediaType == 'pdf') {
                    img_class_obj = 'pdf_img';
                    img_name = 'PDF';
                } else if (mediaType == 'doc') {
                    img_class_obj = 'doc_img';
                    img_name = 'W'
                } else if (mediaType == 'png') {
                    img_class_obj = 'png_img';
                    img_name = 'PNG'
                } else if (mediaType == 'jpg') {
                    img_class_obj = 'jpg_img';
                    img_name = 'JPG'
                } else if (mediaType == 'excel' || mediaType == 'xls') {
                    img_class_obj = 'xcel_img';
                    img_name = 'X'
                } else if (mediaType == 'txt') {
                    img_class_obj = 'msg_img';
                    img_name = ''
                } else if (mediaType == 'msg') {
                    img_class_obj = 'msg_img';
                    img_name = 'MSG'
                } else if (mediaType == 'ppt') {
                    img_class_obj = 'ppt_img';
                    img_name = 'PPT'
                }
                output.push({
                    name: response.data[i].documentName,
                    description: response.data[i].documentDescription,
                    uploadedBy: response.data[i].uploadedUser,
                    created: time,
                    ID: response.data[i].documentId,
                    img_name: img_name,
                    imgClass: img_class_obj,
                    date: response.data[i].createdOn,
                    ecmDocID: response.data[i].ecmDocumentId,
                    docData: response.data[i],
                    businessArea: response.data[i].businessUnit
                });
            }

            currentComponent.setState({ customerRecord: output }, function () {
                currentComponent.forceUpdate();
            });
            currentComponent.setState({ loading: false })
        })
            .catch(function (error) {
                currentComponent.setState({ loading: false })
            })
    }


    componentWillReceiveProps(newProps) {
        this.setState({ notificationData: newProps.notifications });
    }

    deleteApprovalDocument() { 
            let endPoint = API_ENDPOINT.LMS_ECM_DELETE + '/lease';
            let deletePayLoadData = deleteApprovalDocument(this.state.selectedDocData);
            let output1 = HttpDelete(this, deletePayLoadData, endPoint).then((response) =>{                                                      
                this.props.documentDeleted();
                this.fetchDealApprovalDocuments();                
        this.state.isDocDeleted = false;
            })
                .catch(function (error) {
                    console.log("Error received");
                    console.log(error);
                })        
    }

    getDeleteDocumentID(e, ID) {
        localStorage.setItem('selectDocID', e._original.ID);    
        this.state.isDocDeleted = true;     
    }

    downloadDocument(dName, dID) {
        var currentComponent = this;
        let name = dName.replace(/\s/g, '');
        let endPoint = API_ENDPOINT.LMS_ECM + '/' + dID + '/' + name;
        let output1 = HttpDownloadFile(currentComponent, endPoint).then(function (response) {           
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {                             
                window.navigator.msSaveOrOpenBlob(response.data, dName);
            } else {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                console.log(url);
                const link = document.createElement('a');
                console.log("Link:: ", link);
                link.href = url;
                console.log("Link1:: ", link);
                link.setAttribute('download', dName); //or any other extension
                console.log("Link2:: ", link);
                document.body.appendChild(link);
                console.log("Link3:: ", link);
                link.click();
            }
        })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
            })
    }

    setDocName(name, ID, data) {
        this.setState({
            selectedDoc: name,
            selectedDocData: data
        });
        localStorage.setItem('selectDocID', ID);
        this.setState({ selectedDoc: name });  
    }

    getRangeStartDate(e) {
        this.setState({ rangeStartDate: e });
        if (e != "" && this.state.rangeEndDate != "") {
            if (moment(e).isAfter(this.state.rangeEndDate)) {
                this.setState({
                    dateFilterApply: false,
                    endDateError: false,
                    startDateError: false,
                });
            } else {
                this.setState({
                    endDateError: true,
                    dateFilterApply: true,
                });
            }
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getInputRangeStartDate(value) { 
        this.setState({ rangeStartDate: value });
        if (value != "" && this.state.rangeEndDate != "") {
            if (moment(value).isAfter(this.state.rangeEndDate)) {
                this.setState({
                    dateFilterApply: false,
                    startDateError: false,
                    endDateError: false,
                });
            } else {
                this.setState({  endDateError: true, dateFilterApply: true  });
            }
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getInputRangeEndDate(value) {
        this.setState({ rangeEndDate: value });
        if (value != "" && this.state.rangeStartDate != "") {           
            if (moment(this.state.rangeStartDate).isAfter(value)) {
                this.setState({
                    dateFilterApply: false,
                    startDateError: false,
                    endDateError: false,
                });
            } else {
                this.setState({
                    startDateError: true,
                    dateFilterApply: true,
                });
            }

        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getRangeEndDate(e) {
        this.setState({ rangeEndDate: e });
        if (e != "" && this.state.rangeStartDate != "") {
            if (moment(this.state.rangeStartDate).isAfter(e)) {
                this.setState({
                    dateFilterApply: false,
                    startDateError: false,
                    endDateError: false,
                });
            } else {
                this.setState({
                    startDateError: true,
                    dateFilterApply: true,
                });
            }
        } else {
            this.setState({ dateFilterApply: true });
        }
        return true;
    }

    getRangeData() { 
        this.setState({ showDateRange: false });
    }

    setRangeData(e) {
        this.setState({ filtered: { id: e.filtered[0].id, value: e.filtered[0].value } });
    }

    expand_row(row) {
        var expanded = { ...this.state.expanded };
        if (row) { 
            if (expanded[row.index]) {
                expanded[row.index] = !expanded[row.index];
            } else {
                expanded[row.index] = true;
            }
        }

        this.setState({
            expanded: expanded
        }, function () { 
                this.forceUpdate();
        });

    }

    renderDocName(cellInfo) {
        return (
            <div className="form-group row ">
                <div className="col-sm-1">
                    <div className={cellInfo.original.imgClass}><label style={{
                        color: '#fff',
                        fontSize: '8px',
                        marginTop: '-9px',
                        verticalAlign: 'middle'
                    }}>{cellInfo.original.img_name}</label></div>
                </div>
                <div className="col-sm-2">
                    <span style={{ marginLeft: '-5px' }}>{cellInfo.original.name}</span>
                </div>
            </div>
        );
    }

    generateData(type) {
        const data = [];
        if (type == "date") {
            data.push(
                "All",
                "Today",
                "This week",
                "This month",
                "Last month",
                "Last 3 months",
                "Date range"
            );
        }
        return data
    }

    getWeekDates() {
        let now = new Date();
        let dayOfWeek = now.getDay(); //0-6
        let numDay = now.getDate();
        let start = new Date(now); //copy
        start.setDate(numDay - dayOfWeek);
        start.setHours(0, 0, 0, 0);
        let end = new Date(now); //copy
        end.setDate(numDay + (7 - dayOfWeek));
        end.setHours(0, 0, 0, 0);
        return [start, end];
    }
    getCurrentMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        var firstDay = new Date(y, m, 1);
        var lastDay = new Date(y, m + 1, 0);
        return [firstDay, lastDay];
    }
    getLastMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 1;
        var firstDay = new Date(y, m, 1);
        var lastDay = new Date(y, m + 1, 0);
        return [firstDay, lastDay];
    }
    getLastThreeMonth() {
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 3;
        var lastDay = moment(date).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        date.setMonth(date.getMonth() - 3);
        var firstDay = moment(date).utc().format('YYYY-MM-DDTHH:mm:ssZZ');
        console.log("First day:: ", firstDay);
        console.log("Last day::: ", lastDay);
        return [firstDay, lastDay];
    }
    cancelDateFilter() {
        this.setState({
            showDateRange: false,
            rangeStartDate: "",
            rangeEndDate: "",
            startDateError: false,
            endDateError: false,
        }, function () {
            this.forceUpdate();
        });
    }
    render() {
        const columns = [{
            expander: true,
            width: 42,
            className: 'arrow_cell',
            Expander: ({ isExpanded, ...rest }) => {
                return (
                    <div>{isExpanded ? <span><Icon name="chev-up-xsmall" size="xsmall" title="" /></span> : <span><Icon name="chev-down-xsmall" size="xsmall" title="" /></span>}</div>
                );                
            }
        },
        {
            id: 'cname',
            Header: <div style={{
                textAlign: 'left',
                color: '#AD1982',
                textDecoration: 'underline',

            }}><span class="table_columnprop">Document name</span><Icon name="sort-down-xsmall" style={{ marginLeft: '10px' }} />                
            </div>,
            accessor: 'name', // String-based value accessors!
            headerClassName: 'theader_docname',
            filterable: true,
            Cell: this.renderDocName,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'cname'}] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search" style={{ marginLeft: '-16px' }}>
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            right: '5px'
                        }} title="" />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
            width: 250,
            className: 'docheader'
        }, {
            id: 'description',
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '16px',
            }}>Description</div>,
            accessor: 'description',
            headerClassName: 'theader_docname',
            sortable: false,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'description'}] }),
            filterAll: true,
            filterable: true,
            width: 350,
            className: 'des_cell',
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search">
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            right: '5px'
                        }} title="" />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
        },
        {
            id: 'businessArea', // Required because our accessor is not a string
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '20px'
            }}><span class="table_columnprop">Business Area</span></div>,
            accessor: 'businessArea',
            headerClassName: 'theader_docname',
            style: { 'whiteSpace': 'unset' }, //Add this line to the column definition
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'businessArea'}] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search" style={{ marginLeft: '-16px' }}>
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            right: '5px'
                        }} title="" />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            )
        }, 
        {
            id: 'uploadedBy', // Required because our accessor is not a string
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '20px'
            }}><span class="table_columnprop">Uploaded by</span><Icon name="sort-down-xsmall" style={{ marginLeft: '10px' }} /></div>,
            accessor: 'uploadedBy',
            headerClassName: 'theader_docname',
            filterable: true,
            sortable: true,
            filterMethod: (filter, rows) =>
            matchSorter(rows, filter.value, { keys: [{threshold: matchSorter.rankings.CONTAINS, key: 'uploadedBy'}] }),
            filterAll: true,
            Filter: ({ filter, onChange }) => (
                <div class="form-group col-xs-12 view_search">
                    <div class="inner-addon right-addon table_input_search">
                        <Icon name="search-small" size='small' style={{
                            marginTop: '11px',
                            position: 'absolute',
                            right: '5px'
                        }} title="" />
                        <input type="text"
                            onChange={event => onChange(event.target.value)} class="form-control" placeholder="All"
                            value={filter ? filter.value : ''}
                            style={{
                                width: '100%',
                                height: '44px',
                                border: '1px solid #c9c6c6',
                                borderRadius: '0px'
                            }} />
                    </div>
                </div>
            ),
        }, {
            id: 'cdate',
            Header: <div style={{
                textAlign: 'left',
                marginLeft: '16px',
            }}>Uploaded on</div>,//props => <span>Friend Age</span>, // Custom header components!
            accessor: 'created',
            headerClassName: 'theader_docname',
            filterable: true,
            sortable: false,
            filterMethod: (filter, row) => {
                if (typeof (filter.value) == 'object' && !this.state.showDateRange) { 
                    filter.value = "All"
                }
                if (filter.value === "All") {
                    return true;
                }
                if (filter.value === "Today") {
                    var today = new Date();
                    var date = moment(today).format('DD/MM/YYYY')
                    return row[filter.id] == date;
                }
                if (filter.value === "This week") {
                    let [start, end] = this.getWeekDates();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "This month") {
                    let [start, end] = this.getCurrentMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Last month") {
                    let [start, end] = this.getLastMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Last 3 months") {
                    let [start, end] = this.getLastThreeMonth();
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(start).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(start);
                    var isBefore = moment(row._original.date).isAfter(end);
                    var isSameEnd = moment(end).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }
                if (filter.value === "Date range") {
                    this.setState({
                        showDateRange: true,
                        rangeStartDate: "",
                        rangeEndDate: ""
                    });
                    return row[filter.id] == filter.value;
                }
                console.log("show date range");
                console.log(this.state.showDateRange);
                if (typeof (filter.value) == 'object' && this.state.showDateRange) {
                    var date = moment(row._original.date).format('DD/MM/YYYY')
                    var isSameStart = moment(this.state.rangeStartDate).format('DD/MM/YYYY')
                    var isAfter = moment(row._original.date).isAfter(this.state.rangeEndDate);
                    var isBefore = moment(row._original.date).isAfter(this.state.rangeStartDate);
                    var isSameEnd = moment(this.state.rangeEndDate).format('DD/MM/YYYY')
                    return isSameStart == date || isSameEnd == date || (isAfter == true && isBefore == false);
                }

            },
            // Custom cell components!
            Filter: ({ filter, onChange }) =>
                <div>
                    {!this.state.showDateRange ?
                        <Select
                            defaultValue='All'
                            suggestions={this.generateData('date')}
                            className='dropdown_date_selection'
                            isError={false}
                            value={filter ? filter.value : "All"}
                            onChange={(event, { value, method }) => onChange(value)}
                        />
                        : null}

                    {this.state.showDateRange ?
                        <div>
                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                        From
                                                        </label>
                                    <div className="col-sm-4" style={{ marginLeft: '10px' }}>
                                        <DatePicker
                                            date={this.state.rangeEndDate}
                                            keepDateInRange
                                            onChange={this.getRangeEndDate}
                                            onUserChange={this.getInputRangeEndDate}
                                            placeholder='DD/MM/YYYY'
                                            error={this.state.startDateError}
                                            dateFormat='DD/MM/YYYY'
                                        />
                                    </div>

                                </div>
                            </div>

                            {this.state.startDateError ? <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                    </label>
                                    <div className="col-sm-4" style={{ marginLeft: '38px', width: '429px' }}>
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            <span>The ‘From’ date must occur before the ‘To’ date.</span>
                                        </Notification>
                                    </div>

                                </div>
                            </div> : null}

                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property">
                                        To
                                                        </label>
                                    <div className="col-sm-4" style={{ marginLeft: '10px' }}>
                                        <DatePicker
                                            date={this.state.rangeStartDate}
                                            keepDateInRange
                                            onChange={this.getRangeStartDate}
                                            onUserChange={this.getInputRangeStartDate}
                                            placeholder='DD/MM/YYYY'
                                            error={this.state.endDateError}
                                            dateFormat='DD/MM/YYYY'
                                        />
                                    </div>
                                  
                                </div>
                            </div>

                            {this.state.endDateError ? <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <label className="col-sm-1 text_property" >
                                    </label>
                                    <div className="col-sm-4" style={{ marginLeft: '38px', width: '429px' }}>
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            <span>The ‘To’ date must occur after the ‘From’ date.</span>
                                        </Notification>
                                    </div>

                                </div>
                            </div> : null}

                            <div className="form-group row">
                                <div className="col-sm-12 ">
                                    <button type="button" style={{
                                        minWidth: '50px',
                                        width: '85px',
                                        marginLeft: '15px',
                                    }} id="Apply" disabled={this.state.dateFilterApply}
                                        class="zb-button zb-button-primary" onClick={event => onChange(event)}>
                                        Apply
                                                </button>
                                    <button type="button" style={{
                                        minWidth: '50px',
                                        width: '85px',
                                        marginLeft: '5px',
                                    }} id="Cancel" class="zb-button zb-button-primary"
                                        onClick={this.cancelDateFilter.bind(this)}>
                                        Cancel
                                                </button>
                                </div>
                            </div>
                        </div> : null}


                </div>
            , Cell: props => <span style={{ marginLeft: '10px' }}>{props.value}</span>,
        }]
        return (
            <div>
                <ReactTable
                    data={this.state.customerRecord}//{UserData}//{this.state.customerRecord}
                    columns={columns}
                    loading={this.state.loading}
                    showPagination={true}
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    showPageSizeOptions={true}
                    className='documentdata'
                    freezeWhenExpanded={ this.state.isDocDeleted== true? true: false}
                    defaultPageSize={10}
                    pageSize={this.props.selectedRecord}
                    PaginationComponent={Pagination}
                    previousText='Previous'
                    nextText='Next'
                    loadingText='Loading...'
                    noDataText='There are no search results'
                    pageText='Page'
                    ofText='of'
                    rowsText='rows'
                    filterable                    
                    getTrProps={(state, rowInfo) => {
                      
                        if (rowInfo && rowInfo.row) {
                            return {
                                onClick: (e) => {
                                    this.state.selected = rowInfo.index;                                    
                                },
                                style: {                                    
                                    background: rowInfo.index == this.state.selected ? (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'rgb(77,170,233, 0.1)')
                                        : (this.state.requestedDocDeleted.indexOf(rowInfo.original.ID) > -1 ? 'rgb(251, 186, 32, 0.1)' : 'white'),
                                    color: rowInfo.index === this.state.selected ? '#000000' : 'black',
                                    textAlign: 'left'
                                }
                            }
                        } else {
                            return {}
                        }
                    }}
                    SubComponent={({ row, nestingPath, toggleRowSubComponent }) => {
                        console.log("row expanded")
                        console.log(toggleRowSubComponent);
                        console.log(nestingPath);
                        console.log(this.state.requestedDocDeleted);
                        console.log(row._original.ID);
                        console.log(this.state.requestedDocDeleted.indexOf(row._original.ID) > -1);
                        console.log(row);
                        console.log(row.cname);

                        console.log(row._index);

                        localStorage.setItem('selectDocID', row._original.ID);
                        return (                           
                            <div className={this.state.requestedDocDeleted.indexOf(row._original.ID) > -1 ? 'deleted_row_style' : 'selected_row_style'}>
                                   <div className="expand_doc_row">
                                {this.state.documentRecord[row._index].documentDescription}<br></br>
                                <label className="expand_doc_row_detail">RBS classification</label>
                                <span className="expand_doc_row_value">
                                    {this.state.documentRecord[row._index].documentClassification}
                                </span><br></br>
                                <label className="expand_doc_row_detail">RBS record class code</label>
                                <span className="expand_doc_row_value">
                                    {this.state.documentRecord[row._index].recordClassCode}
                                </span><br></br>
                                <label className="expand_doc_row_detail">High risk record</label>
                                <span className="expand_doc_row_value">
                                    {this.state.documentRecord[row._index].highRiskRecord}
                                </span>
                            </div>

                                <div className="expand_line"></div>

                                {!(this.state.requestedDocDeleted.indexOf(row._original.ID) > -1) ? <div className="form-group row" >
                                    <div className="col-sm-1">
                                        <Icon name="download-small" size="small" style={{ marginTop: '16px', marginLeft: '54px' }} title="" />
                                    </div>
                                    <div className="col-sm-2">
                                        <label className="doc_download" onClick={this.downloadDocument.bind(this, row.cname, row._original.ecmDocID)}>Download document</label>
                                    </div>
                                    <div className="col-sm-1" style={{ marginLeft: '-92px' }}>
                                        <Icon name="trash-small" size="small" style={{ marginTop: '16px' }} title="" />
                                    </div>
                                    <div className="col-sm-2" style={{ marginLeft: '-93px' }} onClick={this.setDocName.bind(this, row.cname, row._original.ID, row._original.docData)}>
                                        <label className="doc_download" data-toggle="modal" data-target="#delete" onClick={this.getDeleteDocumentID.bind(this, row)}>
                                           Delete
                                </label>
                                    </div>
                                </div> : null}
                                
                                <div id="delete" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">                                               
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Delete</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to delete {this.state.selectedDoc} ?</p>
                                            </div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn' data-dismiss="modal" onClick={this.deleteApprovalDocument.bind(this)}>Delete</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                             
                            </div>
                        );
                    }}
                />
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        notifications: state.user,
    }
};

function mapDispatchToProps(dispatch) {
    return {
        addNotification: article => dispatch(addNotification(article))
    };
}
const documentLeaseGridValue = connect(mapStateToProps, mapDispatchToProps)(DealApprovalDocument);

export default withRouter(documentLeaseGridValue);