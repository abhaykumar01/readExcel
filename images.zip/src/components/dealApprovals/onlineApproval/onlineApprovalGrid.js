import React from 'react';
import ReactTable from 'react-table';
import { Icon } from '@zambezi/sdk/icons';
import { Checkbox } from '@zambezi/sdk/form-elements'
import { onlineApprovalHeaders } from '../../../models/LeaseConstants';
import OnlineOfflineApprovalDocumentsTab from '../dealDocuments/OnlineOfflineApprovalDocumentsTab';
import { AuthorizationContext } from '../../authContext/index.js';
const PING = process.env.REACT_APP_PING;

class OnlineApprovalGrid extends React.Component{
    static contextType = AuthorizationContext;
    constructor(props){
        super(props);
        this.state={
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            columns : []
        };
    }

    componentWillMount(){
        this.setState({columns : this.generateColumns()});
    }
    componentDidMount(){
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        }); 
    }

    toggleAll(){
        console.log('toggle all');
    }

    selectApproval(row){
        var disableCheckboxIfApproverSame=false;
        console.log(row)
        if(row.original.leaseApprovalActionedBy == this.state.racfData){
            disableCheckboxIfApproverSame = true;
        }
        return (
            <div style={{paddingTop : '10%'}}>
                <Checkbox
                    key={row.original.staticApproverId}
                    defaultChecked={false}
                    checked={row.original.isSelected}
                    disabled={row.original.leaseApprovalStatus === 'N/A' || disableCheckboxIfApproverSame}
                    onChange={(e, isChecked)=>{
                        row.original.isSelected = isChecked;
                        this.props.updateOnlineTabCTAs();
                        this.props.getRowData(row);
                    }} />
            </div>
        )
    }

    generateColumns(){
        let columns = [];
        let expanderColumn = {
            expander: true,
            width: 50,
            className: 'rowExpandArrow',
            Expander: ({ isExpanded, ...rest }) => {
              return (
                  <div>{isExpanded ? <span><Icon name="chev-up-xsmall" size="xsmall" title="" /></span> : <span><Icon name="chev-down-xsmall" size="xsmall" title=""/></span>}</div>
              );
            }
          };
        
        columns.push(expanderColumn);

        let checkBoxColumn={
            id: '_select',
            width: 50,
            Cell: this.selectApproval.bind(this),
            filterable: false,
            sortable: false
        }
        columns.push(checkBoxColumn);

        for(var i=0; i<onlineApprovalHeaders.length; i++){
            let tempColumn={};
            let currentHeader=onlineApprovalHeaders[i];

            tempColumn.id=currentHeader.id;
            tempColumn.accessor=currentHeader.accessor;
            tempColumn.Header=currentHeader.displayName;
            tempColumn.minWidth=currentHeader.minWidth;
            tempColumn.maxWidth=currentHeader.maxWidth;
            tempColumn.filterable=false;

            if(currentHeader.style){
                tempColumn.style= currentHeader.style ;
            }

            columns.push(tempColumn);
        }

        return columns;
    }
    
    updateDocumentsData(response) {
        this.props.documentsChange(response);
    }   
    deletedDealDoc(docDetails) {
        this.props.dealApprovalDocDeleted(docDetails);
    }   
    render(){
        return (
            <ReactTable
                columns={this.state.columns}
                data={this.props.data}
                className='approvalGrid'
                showPagination={false}
                freezeWhenExpanded={false}
                minRows={4}
                SubComponent={(row) => {
                    return (
                        <div>
                        <OnlineOfflineApprovalDocumentsTab key={row.original.staticApproverId} leaseApproverId={row.original.staticApproverId} dealId={this.props.dealId} data={row.original.documentList} businessArea={row.original.businessArea} documentsModified={this.updateDocumentsData.bind(this)} documentsDeleted={this.deletedDealDoc.bind(this)}></OnlineOfflineApprovalDocumentsTab>
                        </div>
                    )
                }}
            >
            </ReactTable>
        )
    }
}

export default OnlineApprovalGrid;