import React from 'react';
import { withRouter } from 'react-router-dom';
import moment from 'moment';
import { Select } from '@zambezi/sdk/dropdown-list';
import { HttpPost } from '../../../services/api';
import { API_ENDPOINT } from '../../../config/config';
import OnlineApprovalGrid from './onlineApprovalGrid';
import SendForApprovalModal from '../dealApprovalModals/sendForApprovalModal';
import ApproveBusinessAreaModal from '../dealApprovalModals/approveBusinessAreaModal';
import RejectBusinessAreaModal from '../dealApprovalModals/rejectBusinessAreaModal';
// import { onlineSolutionSuggestionData, Lease_Constants, dealNotificationMessages, formatDate } from '../dealApprovalsConstants';
import { AuthorizationContext } from '../../authContext/index.js'
import { onlineSolutionSuggestionData, Lease_Constants, dealNotificationMessages, dealAuditMsg, formatDate } from '../../../models/LeaseConstants';
const PING = process.env.REACT_APP_PING;

class OnlineApprovalTab extends React.Component{
    static contextType = AuthorizationContext
    constructor(props){
        super(props);
        this.state = {
            onlineApprovalGridData : this.formatAllDates(props.data, props.locale),
            solutionSuggestions : onlineSolutionSuggestionData,
            isSendForApprovalModalOpen : false,
            isApproveBusinessAreaModalOpen : false,
            isRejectBusinessAreaModalOpen : false,
            sendApprovalBtnDisable : true,
            approveBtnDisable : true,
            rejectBtnDisable : true,
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            onlineSolution : props.onlineSolution !== 'null' ? props.onlineSolution : '',
        }
    }
    componentDidMount(){
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        }); 
    }
    componentWillReceiveProps(props){
        this.setState({
            onlineApprovalGridData : this.formatAllDates(props.data, props.locale),
            onlineSolution : props.onlineSolution !== 'null' ? props.onlineSolution : '',
        });
    }

    componentWillMount(){
        this.props.hideNotification();
        this.updateOnlineTabCTAs();
    }

    handleWorkflowChange(event, target){
        this.setState({
            onlineSolution : '',
            sendApprovalBtnDisable : true,
            approveBtnDisable : true,
            rejectBtnDisable : true,
        });
        this.props.updateWorkflow(target.value);
    }

    handleSolutionChange(event, target){
        this.setState({onlineSolution : target.value});
        this.props.setDealApprovalSolutions(target.value);
        this.selectSolution(target.value);
        this.props.updateDealCaptainBtn();
    }
    getRowData(row){
        console.log(row)
    }
    // selectSolution(event, target){

    selectSolution(solutionName){
        let solutionId= '';
        this.state.solutionSuggestions.forEach((item)=>{
            if(item.value === solutionName){
                solutionId=item.id;
            }
        })
        this.resetApprovalNAStatus();

        if(solutionId==='additionalLesse'){
            this.updateApprovalStatus(Lease_Constants.BUSINESS_AREA_TREASURY, Lease_Constants.LEASE_STATUS_NA);
        }
        if(solutionId==='additionalLesse' || solutionId==='additionalFinancing'){
            this.updateApprovalStatus(Lease_Constants.BUSINESS_AREA_DILIGENCE, Lease_Constants.LEASE_STATUS_NA);
        }
    }

    updateApprovalStatus(businessArea, status){
        let updatedData = this.state.onlineApprovalGridData.map((item,index) => {
            if(businessArea==='ALL' || item.staticApprover.businessArea===businessArea){
                item.leaseApprovalStatus=status
            }
            if(status === Lease_Constants.LEASE_STATUS_NA){
                item.isSelected = false;
            }
            return item;
        })

        this.props.updateOnlineApprovalData(updatedData);
        this.setState({onlineApprovalGridData : updatedData},()=>{
            this.updateOnlineTabCTAs();
        })
    }

    resetApprovalNAStatus(){
        let updatedData = this.state.onlineApprovalGridData.map((item,index) => {
            if(item.leaseApprovalStatus===Lease_Constants.LEASE_STATUS_NA){
                item.isSelected = false;
                item.leaseApprovalStatus=null;
            }
            return item;
        })

        this.props.updateOnlineApprovalData(updatedData);
        this.setState({onlineApprovalGridData : updatedData},()=>{
            this.updateOnlineTabCTAs();
        })
    }

    sendForApproval(){
        let updatedData = this.updateSelectedRowsStatus(Lease_Constants.LEASE_STATUS_AWAITING_APPROVED);
        this.saveOnlineApprovalsData(updatedData).then(()=>{
            let notification={
                showNotification: true,
                notificationType: 'success',
                notificationMsg: dealNotificationMessages.sentForApprovalSuccess,
            }
            this.saveAuditData(updatedData, Lease_Constants.LEASE_STATUS_AWAITING_APPROVED);
            this.props.setNotification(notification);
            this.props.updateDealStatus(Lease_Constants.LEASE_STATUS_AWAITING_APPROVED);
            this.closeModal('sendForApproval');
        });
    }

    approveBusinessArea(approveComment){
        let updatedData = this.updateSelectedRowsStatus(Lease_Constants.LEASE_STATUS_CONFIRMED, approveComment);
        this.saveOnlineApprovalsData(updatedData).then(()=> {
            this.saveAuditData(updatedData, Lease_Constants.LEASE_STATUS_CONFIRMED);
            this.closeModal('approveBusinessArea');
        });
    }

    rejectBusinessArea(rejectComment){
        let updatedData = this.updateSelectedRowsStatus(Lease_Constants.LEASE_STATUS_REJECTED, rejectComment);
        this.saveOnlineApprovalsData(updatedData).then( () => {
            this.saveAuditData(updatedData, Lease_Constants.LEASE_STATUS_REJECTED);
            this.closeModal('rejectBusinessArea');
        });
    }

    saveOnlineApprovalsData(data){
        console.log(data)
        return HttpPost(this, data, API_ENDPOINT.SAVE_DEAL_APPROVALS).then((response)=>{
            this.props.updateDealCaptainBtn();
            if(this.state.onlineSolution && this.state.onlineSolution!==''){
                this.props.updateDealSolutions(this.state.onlineSolution);
            }

            if(response.data && response.data.length>0){
                let savedData = response.data.map((item, index)=>{
                    if(item.staticApprover && item.staticApprover.staticApproverId){
                        item.businessArea=item.staticApprover.businessArea;
                        item.description=item.staticApprover.staticApproverDescription;
                    }
                    item.displayStatusDate= formatDate(item.leaseApprovalStatusDate, this.props.locale);
                    item.isSelected = false;
                    return item;
                });
                this.props.updateOnlineApprovalData(savedData);
                this.setState({onlineApprovalGridData : savedData},()=>{
                    this.updateOnlineTabCTAs();
                });
            }
        }).catch((error)=>{
            console.log(error);
        })
    }

    updateSelectedRowsStatus(status, comment){
        let tempData = this.state.onlineApprovalGridData.map((item) => {
            if(item.isSelected != null && item.isSelected === true){
                item.leaseApprovalRequestedBy= this.state.racfData;
                item.isNotificationRequired =1;
                item.leaseApprovalStatus = status;
                item.leaseApprovalActionedBy = this.props.userName ?  this.props.userName : "Joe Doe"; //logged in user name will come here, once we have user details
                item.leaseApprovalStatusDate=moment(new Date()).format('YYYY-MM-DD'); 
                item.displayStatusDate=formatDate(new Date(), this.props.locale);
                if(comment){
                    item.leaseApprovalComment = comment;
                }
            }
            return item;
        })
        return tempData;
    }

    updateOnlineTabCTAs(){
        let sendApprovalBtn=false;
        let approveBtn=false;
        let rejectBtn=false;
        let isSelectedRowsPresent=false;

        this.props.hideNotification();

        if(this.state.onlineApprovalGridData && this.state.onlineApprovalGridData.length > 0){
            this.state.onlineApprovalGridData.forEach((item)=>{
                if(null != item.isSelected && item.isSelected === true){
                    isSelectedRowsPresent = true;
                    if(item.leaseApprovalStatus === Lease_Constants.LEASE_STATUS_NA || 
                        item.leaseApprovalStatus === Lease_Constants.LEASE_STATUS_AWAITING_APPROVED){
                        sendApprovalBtn = true;
                    } else if(item.leaseApprovalStatus !== Lease_Constants.LEASE_STATUS_AWAITING_APPROVED){
                        approveBtn = true;
                        rejectBtn = true;
                    }
                     if(item.leaseApprovalStatus === Lease_Constants.LEASE_STATUS_AWAITING_APPROVED
                        && item.leaseApprovalRequestedBy == this.state.racfData){
                        approveBtn = true;
                        rejectBtn = true;
                    }
                }
            })
        }

        this.setState({
            sendApprovalBtnDisable : isSelectedRowsPresent ? sendApprovalBtn : true,
            approveBtnDisable : isSelectedRowsPresent ? approveBtn : true,
            rejectBtnDisable : isSelectedRowsPresent ? rejectBtn : true,
        });
    }

    formatAllDates(data, locale){
        return data.map((item)=> {
            item.displayStatusDate=formatDate(item.leaseApprovalStatusDate, locale);
            return item;
        })
    }

    openModal(modalName){
        if(modalName === 'sendForApproval'){
            this.setState({isSendForApprovalModalOpen : true});
        } else if(modalName === 'approveBusinessArea'){
            this.setState({isApproveBusinessAreaModalOpen : true});
        } else if(modalName === 'rejectBusinessArea'){
            this.setState({isRejectBusinessAreaModalOpen : true});
        }
    }

    closeModal(modalName){
        if(modalName === 'sendForApproval'){
            this.setState({isSendForApprovalModalOpen : false});
        } else if(modalName === 'approveBusinessArea'){
            this.setState({isApproveBusinessAreaModalOpen : false});
        } else if(modalName === 'rejectBusinessArea'){
            this.setState({isRejectBusinessAreaModalOpen : false});
        }
    }

    documentsChange(response){
        var currentComponent = this;
        for(var i=0; i<currentComponent.state.onlineApprovalGridData.length; i++){
            if(currentComponent.state.onlineApprovalGridData[i].staticApproverId === response.leaseApproverId){
                currentComponent.state.onlineApprovalGridData[i].documentList.push(response);         
            }
        }
        currentComponent.forceUpdate();
    }
    
    deleteDealDoc(deletedDocDetails){
        var currentComponent = this;
        this.state.onlineApprovalGridData.forEach((item,i)=>{ 
           item.documentList.forEach((items,j)=>{ 
            if (items.documentId === deletedDocDetails.documentId){
                currentComponent.state.onlineApprovalGridData[i].documentList.splice(j);
            }               
        })});
        currentComponent.forceUpdate();
    }    

    saveAuditData(data, status){
        let auditData = [];
        if(data && data.length > 0){
            data.forEach((item) => {
                if(item.isSelected){
                    let businessArea = '"'+item.businessArea+'" ';
                    let auditInfo='';

                    if(status === Lease_Constants.LEASE_STATUS_AWAITING_APPROVED){
                        auditInfo += businessArea + dealAuditMsg.sendForApproval;
                    } else if(status === Lease_Constants.LEASE_STATUS_CONFIRMED){
                        auditInfo += Lease_Constants.LEASE_STATUS_CONFIRMED+":"+businessArea+dealAuditMsg.confirmedApproval;
                    } else if(status === Lease_Constants.LEASE_STATUS_REJECTED){
                        auditInfo += Lease_Constants.LEASE_STATUS_REJECTED+":"+businessArea+dealAuditMsg.rejectedApproval;
                    }
                    auditData.push(auditInfo);
                }
            })
            this.props.saveDealAudit(auditData);
        }
    }

    render(){
         console.log(this.state.racfData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btnApproveOnline = true;
        var btnRejectOnline = true;

            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Online_Approve") { 
                    btnApproveOnline = false;
                }
                if (perData[i] == "Deal_Online_Reject") { 
                    btnRejectOnline = false;
                }
            }
        return (
            <div>
                {
                    this.state.isSendForApprovalModalOpen ? 
                        <SendForApprovalModal
                            open={this.state.isSendForApprovalModalOpen}
                            onCancel={this.closeModal.bind(this, 'sendForApproval')}
                            onConfirm={this.sendForApproval.bind(this)}
                        /> : null
                }

                {
                    this.state.isApproveBusinessAreaModalOpen ?
                        <ApproveBusinessAreaModal
                            open={this.state.isApproveBusinessAreaModalOpen}
                            onCancel={this.closeModal.bind(this, 'approveBusinessArea')}
                            onConfirm={this.approveBusinessArea.bind(this)}
                        /> : null
                }

                {
                    this.state.isRejectBusinessAreaModalOpen ?
                        <RejectBusinessAreaModal
                            open={this.state.isRejectBusinessAreaModalOpen}
                            onCancel={this.closeModal.bind(this, 'rejectBusinessArea')}
                            onConfirm={this.rejectBusinessArea.bind(this)}
                        /> : null
                }

                <div className = "row tabDropdownGroup">
                    <div className="col-sm-2 col-sm-offset-8">
                        <label className="row">Solution</label>
                        <div className="row tabDropdown">
                            <Select 
                            placeholder='Select' 
                            suggestions={this.state.solutionSuggestions.map(d => d.value)}
                            value={this.state.onlineSolution}
                            onChange={this.handleSolutionChange.bind(this)} />
                        </div>
                    </div>
                    <div className="col-sm-2">
                    <label className="row">View workflow</label>
                        <div className="row tabDropdown">
                            <Select 
                            placeholder='Select' 
                            suggestions={this.props.workflowSuggestions}
                            value={this.props.selectedWorkflow}
                            onChange={this.handleWorkflowChange.bind(this)}/>
                        </div>
                    </div>
                </div>
                
                <OnlineApprovalGrid data={this.state.onlineApprovalGridData} dealId={this.props.dealId} documentsChange = {this.documentsChange.bind(this)} getRowData={this.getRowData.bind(this)} updateOnlineTabCTAs={this.updateOnlineTabCTAs.bind(this)} dealApprovalDocDeleted={this.deleteDealDoc.bind(this)}/>
                
                <div className="form-group approveBtnGroup">
                    <button className='zb-button zb-button-primary footerButton' disabled={this.state.sendApprovalBtnDisable || this.props.btnSendForApprovalOnline} onClick={this.openModal.bind(this,'sendForApproval')}>Send for approval</button>
                    <button className='zb-button zb-button-secondary footerButton transparent' disabled={this.state.approveBtnDisable || btnApproveOnline} onClick={this.openModal.bind(this,'approveBusinessArea')}>Approve</button>
                    <button className='zb-button zb-button-secondary footerButton transparent' disabled={this.state.rejectBtnDisable || btnRejectOnline} onClick={this.openModal.bind(this,'rejectBusinessArea')}>Reject</button>
                </div>
            </div>
        )
    }
}

export default withRouter(OnlineApprovalTab);
