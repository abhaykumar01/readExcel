export const businessAreaTeamMapping = [
    {
      "staticApproverId": 459,
      "businessArea": "Information to Treasury",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Finance & Treasury"
    },
    {
      "staticApproverId": 452,
      "businessArea": "Customer meeting",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 453,
      "businessArea": "Customer insight",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 454,
      "businessArea": "Initial customer solution",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 455,
      "businessArea": "Deal-team set up",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 456,
      "businessArea": "One-pager",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 457,
      "businessArea": "Deal logging with Control Room",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 458,
      "businessArea": "Information to Credit",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 460,
      "businessArea": "Structured customer solution",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 461,
      "businessArea": "Principal agreement with customer",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination (with assistance from Legal)"
    },
    {
      "staticApproverId": 462,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination (with assistance from Poland)"
    },
    {
      "staticApproverId": 463,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination (with assistance from Poland)"
    },
    {
      "staticApproverId": 464,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 465,
      "businessArea": "New Transaction Proposal (NTP)",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 466,
      "businessArea": "Investigate insurance solution",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Resource"
    },
    {
      "staticApproverId": 467,
      "businessArea": "SPV approval process initiated",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 468,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 469,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 470,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 471,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 472,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 473,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 474,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 478,
      "businessArea": "Internal loan documentation",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal/Finance &Treasury"
    },
    {
      "staticApproverId": 501,
      "businessArea": "First draft of agreements",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 479,
      "businessArea": "Construction company; KYC completed",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 480,
      "businessArea": "Negotiations",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination/Legal"
    },
    {
      "staticApproverId": 481,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 482,
      "businessArea": "Formation of new legal entity (SPV); tax registration of SPV",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 483,
      "businessArea": "SPV post incorporation form",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 484,
      "businessArea": "Business approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 485,
      "businessArea": "Credit Approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 486,
      "businessArea": "Board approval (or CEO approval)",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal/Origination"
    },
    {
      "staticApproverId": 487,
      "businessArea": "ESE approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 488,
      "businessArea": "CPC approval",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 489,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 490,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 491,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Finance & Treasury"
    },
    {
      "staticApproverId": 492,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 493,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 494,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 495,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 496,
      "businessArea": "Initiate PRiSM update",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 497,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 498,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 499,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Legal"
    },
    {
      "staticApproverId": 500,
      "businessArea": "Deal metrics",
      "dealSolutionConstant": null,
      "solutionType": "New solution",
      "value": "Origination"
    },
    {
      "staticApproverId": 459,
      "businessArea": "Information to Treasury",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Finance & Treasury"
    },
    {
      "staticApproverId": 452,
      "businessArea": "Customer meeting",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 453,
      "businessArea": "Customer insight",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 454,
      "businessArea": "Initial customer solution",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 455,
      "businessArea": "Deal-team set up",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 456,
      "businessArea": "One-pager",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 457,
      "businessArea": "Deal logging with Control Room",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 458,
      "businessArea": "Information to Credit",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 460,
      "businessArea": "Structured customer solution",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 461,
      "businessArea": "Principal agreement with customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio, with assistance from Legal"
    },
    {
      "staticApproverId": 462,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 463,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 464,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 465,
      "businessArea": "New Transaction Proposal (NTP)",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 466,
      "businessArea": "Investigate insurance solution",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 467,
      "businessArea": "SPV approval process initiated",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 468,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 469,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 470,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 471,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 472,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 473,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 474,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 478,
      "businessArea": "Internal loan documentation",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal/Finance &Treasury"
    },
    {
      "staticApproverId": 501,
      "businessArea": "First draft of agreements",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal"
    },
    {
      "staticApproverId": 479,
      "businessArea": "Construction company; KYC completed",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal"
    },
    {
      "staticApproverId": 480,
      "businessArea": "Negotiations",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio/Legal"
    },
    {
      "staticApproverId": 481,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 482,
      "businessArea": "Formation of new legal entity (SPV); tax registration of SPV",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 483,
      "businessArea": "SPV post incorporation form",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 484,
      "businessArea": "Business approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 485,
      "businessArea": "Credit Approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 486,
      "businessArea": "Board approval (or CEO approval)",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal/Portfolio"
    },
    {
      "staticApproverId": 487,
      "businessArea": "ESE approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 488,
      "businessArea": "CPC approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 489,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 490,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal"
    },
    {
      "staticApproverId": 491,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Finance & Treasury"
    },
    {
      "staticApproverId": 492,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal"
    },
    {
      "staticApproverId": 493,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 494,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 495,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "N/A"
    },
    {
      "staticApproverId": 496,
      "businessArea": "Initiate PRiSM update",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 497,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 498,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal"
    },
    {
      "staticApproverId": 499,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Legal"
    },
    {
      "staticApproverId": 500,
      "businessArea": "Deal metrics",
      "dealSolutionConstant": null,
      "solutionType": "Additional financing",
      "value": "Origination"
    },
    {
      "staticApproverId": 459,
      "businessArea": "Information to Treasury",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 452,
      "businessArea": "Customer meeting",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 453,
      "businessArea": "Customer insight",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 454,
      "businessArea": "Initial customer solution",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 455,
      "businessArea": "Deal-team set up",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 456,
      "businessArea": "One-pager",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 457,
      "businessArea": "Deal logging with Control Room",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 458,
      "businessArea": "Information to Credit",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 460,
      "businessArea": "Structured customer solution",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 461,
      "businessArea": "Principal agreement with customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio, with assistance from Legal"
    },
    {
      "staticApproverId": 462,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio, with assistance from Poland"
    },
    {
      "staticApproverId": 463,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio, with assistance from Poland"
    },
    {
      "staticApproverId": 464,
      "businessArea": "On-boarding of customer",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 465,
      "businessArea": "New Transaction Proposal (NTP)",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 466,
      "businessArea": "Investigate insurance solution",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 467,
      "businessArea": "SPV approval process initiated",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 468,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 469,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 470,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 471,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 472,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 473,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 474,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 478,
      "businessArea": "Internal loan documentation",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 501,
      "businessArea": "First draft of agreements",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Legal-Update VAT registration"
    },
    {
      "staticApproverId": 479,
      "businessArea": "Construction company; KYC completed",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "legal"
    },
    {
      "staticApproverId": 480,
      "businessArea": "Negotiations",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio/Legal"
    },
    {
      "staticApproverId": 481,
      "businessArea": "SPV approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 482,
      "businessArea": "Formation of new legal entity (SPV); tax registration of SPV",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 483,
      "businessArea": "SPV post incorporation form",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 484,
      "businessArea": "Business approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 485,
      "businessArea": "Credit Approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 486,
      "businessArea": "Board approval (or CEO approval)",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Legal/Portfolio"
    },
    {
      "staticApproverId": 487,
      "businessArea": "ESE approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": ""
    },
    {
      "staticApproverId": 488,
      "businessArea": "CPC approval",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": ""
    },
    {
      "staticApproverId": 489,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 490,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Legal"
    },
    {
      "staticApproverId": 491,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Finance & Treasury"
    },
    {
      "staticApproverId": 492,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Legal"
    },
    {
      "staticApproverId": 493,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 494,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 495,
      "businessArea": "Confirmation of internal and external due diligence carried out",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "N/A"
    },
    {
      "staticApproverId": 496,
      "businessArea": "Initiate PRiSM update",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 497,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Portfolio"
    },
    {
      "staticApproverId": 498,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Legal"
    },
    {
      "staticApproverId": 499,
      "businessArea": "Internal go ahead",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Legal"
    },
    {
      "staticApproverId": 500,
      "businessArea": "Deal metrics",
      "dealSolutionConstant": null,
      "solutionType": "Additional lessee",
      "value": "Origination"
    }
  ];