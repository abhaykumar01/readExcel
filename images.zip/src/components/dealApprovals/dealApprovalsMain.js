import React from 'react';
import { connect } from "react-redux";
import './dealApprovals.css';
import { Tabs, Tab } from 'react-bootstrap-tabs';
import { Icon } from '@zambezi/sdk/icons';
import { Notification } from '@zambezi/sdk/notification';
import { ComboBox } from '@zambezi/sdk/dropdown-list';
import { API_ENDPOINT } from '../../config/config';
import { HttpGet, HttpPutWithoutBody, HttpPost, HttpPut } from '../../services/api.js';
import { AuthorizationContext } from '../authContext/index';
import DealDocumentsTab from './dealDocuments/dealDocumentsTab';
import OnlineApprovalTab from './onlineApproval/onlineApprovalTab';
import OfflineApprovalTab from './offlineApproval/offlineApprovalTab';
import GeneralDealApprovalModal from './dealApprovalModals/generalDealApprovalModal';
import DealCaptainSignOffErrorModal from './dealApprovalModals/dealCaptainSignOffErrorModal';
import { defaultDealApprovalObject, defaultDealAuditObject, Lease_Constants, dealAuditMsg, formatDate, dealNotificationMessages } from '../../models/LeaseConstants';
const PING = process.env.REACT_APP_PING;

class DealApprovalsMain extends React.Component{
    static contextType = AuthorizationContext;
    constructor(props){
        super(props);
        this.state = {
            pageStatus:'',
            confirmMessage:'',
            customerName : '',
            spvName : '',
            dealId : '',
            dealNumber : '',
            dealDescription : '',
            onlineApprovalData : [],
            offlineApprovalData : [],
            selectedTab : 0,
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            workflowSuggestions : [],
            isDealCaptainBtnDisabled : true,
            dealCaptainSuggestions : [],
            dealCaptain : '',
            dealCaptainErrorFields : [],
        }
    }

    componentWillMount(){
        this.hideNotification();
        this.setState({locale : this.props.locale});
        this.getDealCaptainData();

        if (this.props.location.state != undefined) {
            let dealData = this.props.location.state.dealData;
            this.setState(dealData, () => {
                if(this.state.workflowType && this.state.workflowType === Lease_Constants.WORKFOW_NEW_WORKFLOW){
                    this.reinitiateWorkflow();
                } else{
                    this.generateWorkflowSuggestions(this.state.workflowNumber);
                    this.fetchSavedDealData(this.state.workflowNumber);
                }

                if(this.state.dealCaptainId !== null && this.state.dealCaptainId !==''){
                    this.getSavedDealCaptain(this.state.dealCaptainId)
                }
            });
        } else{
            this.props.history.push({
                pathname: '/lms/viewDealList'
            })
        }
    }
    componentDidMount(){
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        }); 
    }
    
    componentWillReceiveProps(props){
        this.setState({locale : props.locale}); 
    }

    handleOnTabChange(index){
        this.setState({selectedTab : index});
    }

    fetchSavedDealData(workflowNumber){
        let url = API_ENDPOINT.FETCH_DEAL_APPROVALS+'/'+this.state.dealId+'/'+workflowNumber;

        HttpGet(this, url).then((response)=>{
            let dealApprovalData = response.data.map((item, index)=>{
                if(item.staticApprover && item.staticApprover.staticApproverId){
                    item.businessArea=item.staticApprover.businessArea;
                    item.description=item.staticApprover.staticApproverDescription;
                }
                item.displayStatusDate= formatDate(item.leaseApprovalStatusDate, this.state.locale);
                item.isSelected = false;
                return item;
            });

            let tempOnlineData= dealApprovalData.filter((item) => {
                return item.leaseApprovalType==='online';
            })
            if(tempOnlineData && tempOnlineData.length>0){
                this.setState({onlineApprovalData : tempOnlineData}, this.updateDealCaptainSignOffBtn);
            } else {
                this.generateOnlineStaticApprovals(workflowNumber);
            }

            let tempOfflineData= dealApprovalData.filter((item) => {
                return item.leaseApprovalType==='offline';
            })
            if(tempOfflineData && tempOfflineData.length>0){
                let offlineData = tempOfflineData.map((item,index)=>{
                    if(item.dynamicApprover && item.dynamicApprover.dynamicApproverId){
                        item.businessArea=item.dynamicApprover.businessArea;
                        item.description=item.dynamicApprover.dynamicApproverDescription;
                        if( item.documentList[index] !== undefined && item.documentList[index].length > 0 ) {
                            item.documentList[index].documentName = item.documentList[index].documentName;
                            item.documentList[index].documentDescription = item.documentList[index].documentDescription;
                            item.documentList[index].uploadedUser = item.documentList[index].uploadedUser;   
                        }
                    }
                    return item;
                })
                this.setState({offlineApprovalData : offlineData}, this.updateDealCaptainSignOffBtn);
            } else {
                this.generateOfflineStaticApprovals(workflowNumber);
            }
        })
    }

    generateNewStaticApprovalData(workflowNumber){
        this.generateOnlineStaticApprovals(workflowNumber);
        this.generateOfflineStaticApprovals(workflowNumber);
    }

    generateOnlineStaticApprovals(workflowNumber){
        this.setState({isDealCaptainBtnDisabled : true});

        let fetchApproval=this.getStaticApprovals('online');
        let tempOnlineData = [];
        fetchApproval.then((response) => {
            let approvalRawData = response.data;
            tempOnlineData = this.formatApprovalsData('online', workflowNumber, approvalRawData);
            this.setState({onlineApprovalData : tempOnlineData});
        })
    }

    generateOfflineStaticApprovals(workflowNumber){
        this.setState({isDealCaptainBtnDisabled : true});

        let fetchApproval=this.getStaticApprovals('offline');
        let tempOfflineData = [];
        fetchApproval.then((response) => {
            let approvalRawData = response.data;
            this.sortResponse(approvalRawData, 'staticApproverId');
            tempOfflineData = this.formatApprovalsData('offline', workflowNumber, approvalRawData);
            this.setState({offlineApprovalData : tempOfflineData});
        })
    }

    formatApprovalsData(approvalType, workflowNumber, data){
        let formattedData= [];
        if(data && data.length>0){
            formattedData= data.map((item, index)=>{
                let tempObj= {...defaultDealApprovalObject};
                tempObj.leaseContractId=this.state.dealId;
                tempObj.leaseApprovalType=approvalType;
                tempObj.staticApprover={...item};
                tempObj.businessArea=item.businessArea;
                tempObj.description=item.staticApproverDescription;
                tempObj.staticApproverId=item.staticApproverId;
                tempObj.workflowNumber=workflowNumber;
                tempObj.isSelected = false;
                tempObj.leaseApprovalStatus='';
                tempObj.documentList=[];
                
                return tempObj;
            })
        }
        return formattedData;
    }

    getStaticApprovals(approvalType){
        let url = API_ENDPOINT.GET_STATIC_DEAL_APPROVER_LIST+'/'+approvalType;
        return HttpGet(this, url);
    }

    sortResponse(data, prop) {
        data.sort((a, b) => {
            if (a[prop] < b[prop]) {
                return -1;
            }
            if (b[prop] < a[prop]) {
                return 1;
            }
            return 0;
        });
    }

    setNotification(notificationObj){
        window.scrollTo(0, 0);
        this.setState({notification : notificationObj});
    }

    hideNotification(){
        let notificationObj = {
            showNotification : false,
            notificationType : '',
            notificationMsg : '',
        }
        this.setState({notification : notificationObj});
    }

    goBackToDeal(){
        this.props.history.push({
            pathname: '/lms/mainSummaryTabsPage',
            state: { leaseParentId: this.state.dealId }
        })
    }

    updateOnlineApprovalData(data){
        this.setState({onlineApprovalData : data})
    }

    updateOfflineApprovalData(data){
        this.setState({offlineApprovalData : data})
    }

    updateDealSolutions(onlineSolution, offlineSolution){
        if(!onlineSolution){
            onlineSolution = this.state.onlineSolution !== "" ? this.state.onlineSolution : null;
        }
        if(!offlineSolution){
            offlineSolution = this.state.offlineSolution !== "" ? this.state.offlineSolution : null;
        }

        let url = API_ENDPOINT.UPDATE_DEAL_SOLUTION+'/'+this.state.dealId+'/'+onlineSolution+'/'+offlineSolution;

        HttpPutWithoutBody(this, url).then(()=>{
            this.setDealApprovalSolutions(onlineSolution, offlineSolution);
        }).catch((error)=> {
            console.log(error);
        })
    }

    setDealApprovalSolutions(onlineSolution, offlineSolution){
        let newOnlineSolution = onlineSolution ? onlineSolution : this.state.onlineSolution;
        let newOfflineSolution = offlineSolution ? offlineSolution : this.state.offlineSolution;
        this.setState({
            onlineSolution: newOnlineSolution,
            offlineSolution: newOfflineSolution,
        })
    }

    updateDealStatus(newStatus){
        let url = API_ENDPOINT.UPDATE_DEAL_STATUS+'/'+this.state.dealId+'/'+newStatus;

        HttpPutWithoutBody(this, url).then((response) => {
            let dealAuditInfo = newStatus+":"+dealAuditMsg.dealStatusUpdated+newStatus;
            let dealAuditData = [dealAuditInfo];
            if(newStatus !== this.state.dealStatus){
                this.saveDealAudit(dealAuditData);
            }
            this.setState({dealStatus : newStatus});
        }).catch((error)=>{
            console.log(error);
        });
    }

    updateStatus(status) {
        this.setState({pageStatus: status});     
    }

    saveDealAudit(auditInfo){
        let dealAuditData = [];
        let url = API_ENDPOINT.SAVE_DEAL_AUDIT;
        let userName = this.state.racfData;
        if(!userName){
            userName = "";
        }

        for (let i = 0; i < auditInfo.length; i++) {
            let auditObj = { ...defaultDealAuditObject };

            auditObj.leaseContractId = this.state.dealId;
            auditObj.dealAuditUserId = userName;
            auditObj.auditHistory = auditInfo[i];

            dealAuditData.push(auditObj);
        }

        HttpPost(this, dealAuditData, url).then(

        ).catch((error) => {
            console.log(error);
        })
    }

    reinitiateWorkflow(){
        let newWorkflowNumber = parseInt(this.state.workflowNumber) + 1;
        let dealAuditInfo = dealAuditMsg.reinitiatedWorkflow;
        let dealAuditData = [dealAuditInfo];

        this.saveDealAudit(dealAuditData);
        this.updateDealStatus(Lease_Constants.LEASE_STATUS_MODELLED);
        this.generateNewStaticApprovalData(newWorkflowNumber);
        this.generateWorkflowSuggestions(newWorkflowNumber);
        this.setState({
            workflowNumber : newWorkflowNumber,
            onlineSolution : '',
            offlineSolution : '',
        });
    }

    updateWorkflow(workflowNumber){
        this.setState({workflowNumber : workflowNumber});
        this.fetchSavedDealData(workflowNumber);
    }

    generateWorkflowSuggestions(workflowNumber){
        let tempWorkflowSuggestions=[]
        for(let i=workflowNumber; i > 0; i--){
            tempWorkflowSuggestions.push(i);
        }
        this.setState({workflowSuggestions : tempWorkflowSuggestions});
    }

    getDealCaptainData(){
        let url= API_ENDPOINT.GET_RBAC_USERS_LIST;

        HttpGet(this, url).then((response) => {
            if(response.data && response.data.length > 0){
                this.setState({dealCaptainSuggestions : response.data});
            }
        })
    }

    onDealCaptainSelected(e, selection){
        let selectedData=selection.suggestion;
        let user ={
            userID : selectedData.userID,
            userName : selectedData.userName,
            restrictedRoleCreatedOn: null,
            restrictedRoleUpdatedOn: null,
        }
        let url = API_ENDPOINT.SET_DEAL_CAPTAIN+this.state.dealId;

        this.state.dealCaptain=selectedData.userName;

        HttpPut(this, user, url).then((response)=>{
            let notificationObj;
            if(response.data){
                notificationObj = {
                    showNotification : true,
                    notificationType : 'success',
                    notificationMsg : dealNotificationMessages.setDealCaptainSuccess,
                }
                this.setNotification(notificationObj);
            }
        }).catch((error) => {
            console.log(error);
        })
    }

    onDealCaptainSignOff(){
        // Add validations of complete model deal information
        let url =API_ENDPOINT.VALIDATE_DEAL_DATA+this.state.dealId+'/';

        HttpPutWithoutBody(this, url).then((response) => {
            if(response.data && response.data.length > 0){
                this.setState({dealCaptainErrorFields : response.data},
                    this.openModal.bind(this,'dealCaptainSignOffError'));
                this.closeModal('dealCaptainSignOff');
            } else if(response.data && response.data.length === 0) {
                let dealAuditInfo = dealAuditMsg.dealCaptainSignOff;
                let dealAuditData = [dealAuditInfo];

                this.saveDealAudit(dealAuditData);
                this.updateDealStatus(Lease_Constants.LEASE_STATUS_APPROVED);
                let notificationObj = {
                    showNotification: true,
                    notificationType: 'success',
                    notificationMsg: dealNotificationMessages.dealCaptainSignOffSuccess,
                }
                this.setNotification(notificationObj);
                this.closeModal('dealCaptainSignOff');
            }
            this.closeModal('dealCaptainSignOff');
        }).catch((error) => {
            console.log(error);
        })
    }

    updateDealCaptainSignOffBtn(){
        let isDealCaptainBtnDisabled = true;
        if(this.isAllApprovalConfirmed(this.state.onlineApprovalData) &&
            this.isAllApprovalConfirmed(this.state.offlineApprovalData)){
                isDealCaptainBtnDisabled = false;
        }

        this.setState({isDealCaptainBtnDisabled : isDealCaptainBtnDisabled});
    }

    getSavedDealCaptain(dealCaptainId){
        let url = API_ENDPOINT.GET_SAVED_DEAL_CAPTAIN+dealCaptainId;

        HttpGet(this, url).then((response) => {
            if(response && response.data){
                this.setState({dealCaptain : response.data.userName,
                    dealCaptainRacfID: response.data.userID
                });
            }
        }).catch((error) => {
            console.log(error);
        })
    }

    isAllApprovalConfirmed(data){
        let result = true;

        if(data && data.length > 0){
            for(let i =0; i<data.length; i++){
                let item = data[i];
                if(item.leaseApprovalStatus !== Lease_Constants.LEASE_STATUS_CONFIRMED &&
                    item.leaseApprovalStatus !== Lease_Constants.LEASE_STATUS_NA){
                        result = false;
                        break;
                }
            }
        } else {
            result = false;
        }

        return result;
    }

    openModal(modalName){
        if(modalName === 'dealCaptainSignOff'){
            this.setState({dealCaptainSignOffModal : true});
        } else if(modalName === 'dealCaptainSignOffError'){
            this.setState({dealCaptainSignOffErrorModal : true});
        }
    }

    closeModal(modalName){
        if(modalName === 'dealCaptainSignOff'){
            this.setState({dealCaptainSignOffModal : false});
        } else if(modalName === 'dealCaptainSignOffError'){
            this.setState({dealCaptainSignOffErrorModal : false});
        }
    }

    render(){
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        console.log(this.state.dealCaptain)
        console.log(perData);
        var btnSendForApprovalOnline = true;
        var dealCaptainSignOffBtn = true;
        var reInitiateBtn = true;
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Online_Request_For_Approval") { 
                    btnSendForApprovalOnline = false;
                    if(this.state.memberOfDetail.indexOf("BusinessUser") > 0){
                        if(this.state.dealCaptainRacfID != undefined && this.state.dealCaptainRacfID != null){
                            if(this.state.dealCaptainRacfID ==  this.state.racfData){
                                btnSendForApprovalOnline = true;
                            }
                            else{
                                btnSendForApprovalOnline =false;
                            }
                        }
                    }
                }
                if (perData[i] == "Deal_ReInitiate_Approval_WorkFlow") { 
                    reInitiateBtn = false;
                }
            }
            if(this.state.dealCaptainRacfID != undefined && this.state.dealCaptainRacfID != null){
                if(this.state.dealCaptainRacfID ==  this.state.racfData){
                    // check whether current deal captain == logged in racf
                // for (var i = 0; i < datalen; i++) { 
                //     if (perData[i] == "Deal_Captain_Sign_off") { 
                        dealCaptainSignOffBtn = false;
                //     }
                // }
            }
            }
            
        let isDealApproved = false;

        if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_APPROVED ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_SIGNED ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_ACTIVE){
            isDealApproved = true;
        }

        return (
        <div className="dealApprovalsPage container-fluid">
            <div className="dealBackButton">
                <Icon name="chev-left-xsmall" size='xsmall' title="Back to deal"/>
                <span onClick={this.goBackToDeal.bind(this)} > Back to deal</span>
            </div>
            
            <div className="innerHeader">
                {this.state.notification.showNotification ?
                    <div className="dealSuccessMessage"><Notification status={this.state.notification.notificationType} size="medium">{this.state.notification.notificationMsg}</Notification></div>
                    : null
                }
                {this.state.pageStatus == 'docUploadSuccess' ?
                    <Notification className="Confirmation_header_new" style={{width: '1244px'}} status='success' size='large' title='Your document has been uploaded'>                       
                    </Notification>
                    : null
                }
                  {this.state.pageStatus == 'docDeletedSuccess1' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Your document has been deleted'>
                        {this.state.confirmMessage}
                    </Notification>
                    : null
                }
                {this.state.dealCaptainSignOffModal ? 
                    <GeneralDealApprovalModal
                        title="Deal captain sign off"
                        confirmText='Yes, sign off'
                        msgAccessor='dealCaptainSignOffMsg'
                        open={this.state.dealCaptainSignOffModal}
                        onConfirm={this.onDealCaptainSignOff.bind(this)}
                        onCancel={this.closeModal.bind(this,'dealCaptainSignOff')} />
                : null}
                {this.state.dealCaptainSignOffErrorModal ? 
                    <DealCaptainSignOffErrorModal
                        open={this.state.dealCaptainSignOffErrorModal}
                        onConfirm={this.closeModal.bind(this,'dealCaptainSignOffError')}
                        fieldsList={this.state.dealCaptainErrorFields}
                        />
                :null}

                <div className="dealTitleHeader">
                    <div><label className="modelTitle">{'Deal - '+this.state.dealNumber}</label></div>
                    {this.state.customerName ? <div><label className="modelTitle customerName">{this.state.customerName}</label></div> : null}
                    {this.state.spvName ? <div><label className="modelTitle spvName">{this.state.spvName}</label></div> : null}
                    <div><label className="modelTitle dealDetails">{'Deal number '+ this.state.dealRefNumber + (this.state.dealDescription ? ' | '+this.state.dealDescription : '')}</label></div>
                </div>

                <div className="col-sm-2 dealCaptainDropdown">
                    <label className="row">Deal captain</label>
                    <div className="row tabDropdown">
                        <ComboBox placeholder='Search' 
                        suggestions={this.state.dealCaptainSuggestions}
                        value={this.state.dealCaptain} // this should be the user name
                        getSuggestionValue={item => item.userName}
                        renderSuggestion={(suggestion) => {
                            return (<div>{suggestion.userName}</div>)
                        }}
                        onSuggestionSelected={this.onDealCaptainSelected.bind(this)}
                        />
                    </div>
                </div>

                <Tabs selected = {this.state.selectedTab} onSelect = {this.handleOnTabChange.bind(this)}
                    style={{ margin: '20px 0 0 0', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }}
                    headerStyle={{ backgroundColor: '#f5f5f5', color: '#ad1982', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'pointer' }}
                    activeHeaderStyle={{ backgroundColor: '#ffffff', color: '#42145f', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'default' }}>
                    <Tab label="Online">
                        <div className='innerTab'>
                            <OnlineApprovalTab data={this.state.onlineApprovalData} btnSendForApprovalOnline={btnSendForApprovalOnline} updateOnlineApprovalData={this.updateOnlineApprovalData.bind(this)} dealId={this.state.dealId}
                            setNotification={this.setNotification.bind(this)} hideNotification={this.hideNotification.bind(this)} locale={this.state.locale} 
                            userName={this.context.name} onlineSolution={this.state.onlineSolution} selectedWorkflow={this.state.workflowNumber} 
                            workflowSuggestions={this.state.workflowSuggestions} updateWorkflow={this.updateWorkflow.bind(this)}
                            updateDealStatus={this.updateDealStatus.bind(this)} updateDealSolutions={this.updateDealSolutions.bind(this)}
                            updateDealCaptainBtn={this.updateDealCaptainSignOffBtn.bind(this)} 
                            saveDealAudit={this.saveDealAudit.bind(this)} setDealApprovalSolutions={this.setDealApprovalSolutions.bind(this)}></OnlineApprovalTab>
                        </div>
                    </Tab>
                    <Tab label="Offline">
                        <div className='innerTab'>
                            <OfflineApprovalTab data={this.state.offlineApprovalData} updateOfflineApprovalData={this.updateOfflineApprovalData.bind(this)} dealId={this.state.dealId} 
                            setNotification={this.setNotification.bind(this)} hideNotification={this.hideNotification.bind(this)} locale={this.state.locale} 
                            userName={this.context.name} offlineSolution={this.state.offlineSolution} selectedWorkflow={this.state.workflowNumber} 
                            workflowSuggestions={this.state.workflowSuggestions} updateWorkflow={this.updateWorkflow.bind(this)}
                            updateDealStatus={this.updateDealStatus.bind(this)} updateDealSolutions={this.updateDealSolutions.bind(this)}
                            updateDealCaptainBtn={this.updateDealCaptainSignOffBtn.bind(this)} 
                            saveDealAudit={this.saveDealAudit.bind(this)} setDealApprovalSolutions={this.setDealApprovalSolutions.bind(this)}></OfflineApprovalTab>
                        </div>
                    </Tab>
                    <Tab label="Documents">
                        <div className='innerTab'>
                            <DealDocumentsTab dealId={this.state.dealId} updateStatus = {this.updateStatus.bind(this)}></DealDocumentsTab>
                        </div>
                    </Tab>
                </Tabs>

                <div className="form-group">
                        <button className='zb-button zb-button-primary footerButton' disabled={this.state.isDealCaptainBtnDisabled || isDealApproved || dealCaptainSignOffBtn} onClick={this.openModal.bind(this,'dealCaptainSignOff')}>Deal captain sign off</button>
                        <button className='zb-button zb-button-secondary footerButton transparent' disabled={isDealApproved || reInitiateBtn} onClick={this.reinitiateWorkflow.bind(this)}>Re-initiate approval workflow</button>
                </div>
            </div>
        </div>
        )
    } 
}

const mapStateToProps = state => {
    return {
         locale: state.dataFormat,
    }
   
};

export default connect(mapStateToProps)(DealApprovalsMain);
