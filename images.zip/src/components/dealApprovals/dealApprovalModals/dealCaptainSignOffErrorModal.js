import React from 'react';
import Modal from '@zambezi/sdk/modal';
import { dealApprovalModalMessages } from '../../../models/LeaseConstants';

class DealCaptainSignOffErrorModal extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return (
            <Modal 
                title='Deal captain sign off' 
                className='dealApprovalModal' 
                confirm='Close'
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={() => { this.props.onConfirm() }}>
                <div className="form-group row noMargin">
                    <label className="fieldLabel msgLabel" >{ dealApprovalModalMessages.dealCaptainSignOffErrorMsg }</label>
                    <div>
                        {this.props.fieldsList.map((item, index)=>{
                            return <lable key={index} className="fieldLabel">{'- '+item}</lable>
                        })}
                    </div>
                </div>   
            </Modal>
        )
    }
}

export default DealCaptainSignOffErrorModal;