import React from 'react';
import Modal from '@zambezi/sdk/modal';
import { dealApprovalModalMessages } from '../../../models/LeaseConstants';

class SendForApprovalModal extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return (
            <Modal 
                title="Send for approval" 
                className='dealApprovalModal' 
                confirm='Yes, send for approval' 
                cancel='Cancel'
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={() => { this.props.onConfirm() }}
                onCancel={() => { this.props.onCancel() }}
                >
                <div className="form-group row noMargin">
                    <label className="fieldLabel msgLabel" >{ dealApprovalModalMessages['sendAreaApprovalMsg'] }</label>
                </div>   
            </Modal>
        )
    }
}

export default SendForApprovalModal;