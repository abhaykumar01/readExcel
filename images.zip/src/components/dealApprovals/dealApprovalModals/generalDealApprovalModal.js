import React from 'react';
import Modal from '@zambezi/sdk/modal';
import { dealApprovalModalMessages } from '../../../models/LeaseConstants';

class GeneralDealApprovalModal extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return (
            <Modal 
                title={this.props.title} 
                className='dealApprovalModal' 
                confirm={this.props.confirmText} 
                cancel={this.props.cancelText ? this.props.cancelText : 'Cancel'}
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={() => { this.props.onConfirm() }}
                onCancel={() => { this.props.onCancel() }}
                >
                <div className="form-group row noMargin">
                    <label className="fieldLabel msgLabel" >{ dealApprovalModalMessages[this.props.msgAccessor] }</label>
                </div>   
            </Modal>
        )
    }
}

export default GeneralDealApprovalModal;