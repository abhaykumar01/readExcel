import React from 'react';
import Modal from '@zambezi/sdk/modal';

class AddOfflineApprovalModal extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            data : {
                businessArea: '',
                staticApproverDescription: '',
                additionalLease: '',
                newSolution: '',
                additionalFinancing: '',
            },
            isSaveDisabled : true
        }
    }

    handleOnChange(e) {
        const name = e.target.name;
        const value = e.target.value;
        let tempData = this.state.data;
        tempData[name] = value

        this.setState({
            data : tempData
        }, () => {
            this.setState({isSaveDisabled : !this.validateAllRequiredFields()});
            this.props.data[name] = this.state.data[name];
        })
    }

    validateAllRequiredFields(){
        for(let property in this.state.data){
            if(this.state.data.hasOwnProperty(property)){
                if(null === this.state.data[property] || this.state.data[property]===''){
                    return false;
                }
            }
        }
        return true;
    }

    saveNewApproval(){
        this.props.onConfirm(this.state.data);
    }

    render(){
        return (
            <Modal 
                title="Add offline approval" 
                className='dealApprovalModal addDealApprovalModal' 
                confirm='Save' 
                cancel='Cancel'
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={this.saveNewApproval.bind(this)}
                onCancel={() => { this.props.onCancel() }}
                renderFooter={(onConfirm, onCancel) => {
                    return (
                        <div className="form-group">
                            <button className='zb-button zb-button-primary footerButton' disabled={this.state.isSaveDisabled} onClick={onConfirm}>Save</button>
                            <button className='zb-button zb-button-secondary footerButton transparent' onClick={onCancel}>Cancel</button>
                        </div>
                    )
                }}
                >
                <div>
                    <div className="form-group row noMargin">
                        <div className="row noMargin">
                            <label htmlFor="businessArea" className="col-sm-6 col-form-label fieldLabel" >Business area</label>
                            <label className="col-sm-6 col-form-label fieldLabel fieldInfo" >max 250 characters</label>
                        </div>
                        <div className="row noMargin">
                            <input type='text' className="form-control inputFields" name="businessArea" onChange={this.handleOnChange.bind(this)} maxLength={250} placeholder="Enter"/>
                        </div>
                    </div>
                    <div className="form-group row noMargin">
                        <div className="row noMargin">
                            <label htmlFor="staticApproverDescription" className="col-sm-6 col-form-label fieldLabel" >Description</label>
                            <label className="col-sm-6 col-form-label fieldLabel fieldInfo" >max 350 characters</label>
                        </div>
                        <div className="row noMargin">
                            <input type='text' className="form-control inputFields" name="staticApproverDescription" onChange={this.handleOnChange.bind(this)} maxLength={350} placeholder="Enter"/>
                        </div>
                    </div>
                    <div className="form-group row noMargin">
                        <div className="row noMargin">
                            <label htmlFor="additionalLease" className="col-sm-6 col-form-label fieldLabel" >Additional lessee</label>
                            <label className="col-sm-6 col-form-label fieldLabel fieldInfo" >max 50 characters</label>
                        </div>
                        <div className="row noMargin">
                            <input type='text' className="form-control inputFields" name="additionalLease" onChange={this.handleOnChange.bind(this)} maxLength={50} placeholder="Enter"/>
                        </div>
                    </div>
                    <div className="form-group row noMargin">
                        <div className="row noMargin">
                            <label htmlFor="newSolution" className="col-sm-6 col-form-label fieldLabel" >New solution</label>
                            <label className="col-sm-6 col-form-label fieldLabel fieldInfo" >max 50 characters</label>
                        </div>
                        <div className="row noMargin">
                            <input type='text' className="form-control inputFields" name="newSolution" onChange={this.handleOnChange.bind(this)} maxLength={50} placeholder="Enter"/>
                        </div>
                    </div>
                    <div className="form-group row noMargin">
                        <div className="row noMargin">
                            <label htmlFor="additionalFinancing" className="col-sm-6 col-form-label fieldLabel" >Additional financing</label>
                            <label className="col-sm-6 col-form-label fieldLabel fieldInfo" >max 50 characters</label>
                        </div>
                        <div className="row noMargin">
                            <input type='text' className="form-control inputFields" name="additionalFinancing" onChange={this.handleOnChange.bind(this)} maxLength={50} placeholder="Enter"/>
                        </div>
                    </div>
                </div>
            </Modal>
        )
    }
}

export default AddOfflineApprovalModal;