import React from 'react';
import Modal from '@zambezi/sdk/modal';
import { dealApprovalModalMessages } from '../../../models/LeaseConstants';


class RejectBusinessAreaModal extends React.Component{
    constructor(props){
        super(props);

        this.state={
            rejectComment : '',
            isConfirmDisabled : true,
        }
    }

    handleOnChange(e){
        const name = e.target.name;
        const value = e.target.value;

        this.setState({[name] : value},() => {
            this.setState({isConfirmDisabled : !this.validateAllRequiredFields()});
        });
    }

    validateAllRequiredFields(){
        if(null === this.state.rejectComment || this.state.rejectComment===''){
            return false;
        }
        return true;
    }

    render(){
        return (
            <Modal 
                title="Reject business area" 
                className='dealApprovalModal' 
                confirm='Yes, reject'
                cancel='Cancel'
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={() => { this.props.onConfirm(this.state.rejectComment) }}
                onCancel={() => { this.props.onCancel() }}
                renderFooter={(onConfirm, onCancel) => {
                    return (
                        <div className="form-group">
                            <button className='zb-button zb-button-primary footerButton' disabled={this.state.isConfirmDisabled} onClick={onConfirm}>{'Yes, reject'}</button>
                            <button className='zb-button zb-button-secondary footerButton transparent' onClick={onCancel}>{'Cancel'}</button>
                        </div>
                    )
                }}
                >
                <div className="form-group row noMargin">
                    <div className="row noMargin">
                        <label className="fieldLabel msgLabel" >{ dealApprovalModalMessages['rejectBusinessAreaMsg'] }</label>
                    </div>
                    <div className="row noMargin">
                        <label htmlFor="newBusinessArea" className="col-sm-6 col-form-label fieldLabel" >Leave a comment</label>
                        <label className="col-sm-6 col-form-label fieldLabel fieldInfo" >max 255 characters</label>
                    </div>
                    <div className="row noMargin">
                        <textarea className="form-control inputFields" name="rejectComment" type='textarea' 
                        maxLength={255} onChange={this.handleOnChange.bind(this)} rows={3} style={{resize:"none"}}
                        placeholder="Input text here"/>
                    </div>
                </div>   
            </Modal>
        )
    }
}

export default RejectBusinessAreaModal;