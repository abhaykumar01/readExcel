import React from 'react';
import './notification.css';
import { HttpPost, HttpGet } from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { Icon } from '@zambezi/sdk/icons';
import NotificationGrid from '../../commonComponents/notificationGrid';
import { Select } from '@zambezi/sdk/dropdown-list';

class Notification extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            recordView: 10,
        }
    }

    HandleSelectChange(event, type, value) {
        this.setState({ recordView: type.value });
    }

    componentDidMount() {
        // var currentComponent = this;
        // let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/Anitha/Pending_For_Approval';

        // let output1 = HttpGet(endPoint).then(function (response) {
        //     if (response.data.length > 0) {
        //         currentComponent.setState({ gridCount: 1 });
        //         currentComponent.setState({ showPendingNotificationStatus: true });
        //     } else {
        //         currentComponent.setState({ showPendingNotificationStatus: false });
        //     }
        // })
        //     .catch(function (error) {
        //     })
    }

    goToPage(pagename) {
        this.props.history.push({
            pathname: '/lms/' + pagename
        })
        return true;
    }

    render() {
        return (
            <div className="background">
                <div className="inner_container" style={{
                    width: '1244px',
                    margin: '30px auto 0px auto'
                }}>

                    <div class="form-group">
                        <label className="customer_title">Notifications</label>
                    </div>
                    <NotificationGrid selectedRecord={parseInt(this.state.recordView)} />
                    <span class="select-wrap -pageSizeOptions select_record">
                        <span className="text_property" style={{
                            marginRight: '18px',
                            color: '#666666'
                        }}>Per page1</span>
                        <Select
                            defaultValue={this.state.recordView}
                            suggestions={['5', '10', '15', '20']}
                            className='notification_select_row'
                            isError={false}
                            onChange={this.HandleSelectChange.bind(this)}
                        />
                    </span>

                </div>
            </div>
        )
    }
}

export default Notification;