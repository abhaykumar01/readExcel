import React, { Component, createContext } from 'react'
import qs from 'qs'
import axios from 'axios';
import SetupInterceptor from '../../utils/axiosInterceptor';
import {BASE_URL, API_ENDPOINT, REACT_APP_IAM_BASE_URI, REACT_APP_IAM_CLIENT_ID} from '../../config/config.js';
import { HttpGet } from '../../services/api.js';

// Context lets us pass a value deep into the component tree
// without explicitly threading it through every component.
// Create a context for the defaults values.
const defaults = {
  isAdmin: false
, isLoggedIn: false
, dateOfBirth: ''
, name: ''
, role: ''
, cin: ''
, age: ''
, gender: ''
  , occupation: ''
  , serviceStatus: false
}
const AuthorizationContext = createContext({ ...defaults })



class AuthProvider extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      serviceStatus: false,
      // serviceCall: true,
      count: 1,
       hasError: false,
    }
      this.initState();
    // localStorage.setItem('serviceCount', 1);
  } 

  componentDidMount() {
      this.getCurrentUser();
    
  }

  componentDidCatch(error, info) {
    // Display fallback UI
    this.setState({ hasError: true });
  }

  set authData(data) {
    localStorage.setItem('userData', JSON.stringify(data))
  }

  get authData() {
    return JSON.parse(localStorage.getItem('userData'))
  }

  async getCurrentUser() {
    
    // var currentComponent = this;
    // const response = await Promise.all([
    //   axios.get(BASE_URL + API_ENDPOINT.LMS_JWT),
    //   axios.get(BASE_URL + API_ENDPOINT.LMS_USERS)
    // ])
    // if (response[1].data) { 
    //   const name = response[1].data.firstName + " " + response[1].data.lastName;
    //   const usersDetails = response[1].data;
    //   const cin = "";
    //   const role = 'Admin';
    //   const isAdmin = role === 'Admin'

    //   // this.userStatus = this.getUserStatus();
    //   currentComponent.authData = { ...currentComponent.userStatus, isAdmin }
    //   currentComponent.setState({
    //     name
    //     , role
    //     , isAdmin
    //     , cin
    //     , usersDetails
    //   })

    // }

    // const serviceStatus = true;
    // this.setState({
    //   serviceStatus
    // })
    

var currentComponent = this;
    // let output = HttpGet(API_ENDPOINT.LMS_JWT)
    //   .then(function (response) {
    //     currentComponent.setState({serviceStatus: true});
    //   })
    //   .catch(function (error) {
    //   })
    HttpGet(currentComponent, API_ENDPOINT.LMS_USERS)
      .then(function (response) {
        // currentComponent.setState({serviceStatus: true}); updated
        localStorage.setItem('timeout', "true");
        if (response.data) {
          console.log("response data");
          console.log(response.data);
          console.log(response.data.memberOf);
          console.log(response.data.permissions);
          let groupName = API_ENDPOINT.LMS_RBAC_ROLEPERMISSION + '/' + 'General_Finance_Users'; //response.data.memberOf
         
          console.log(response.data);
          const name = response.data.userName;
          const usersDetails = response.data;
          const cin = "";
          const role = 'Admin';
          const isAdmin = role === 'Admin'
          // const errorFlag = false;
          
          currentComponent.authData = { ...currentComponent.userStatus, isAdmin }
          currentComponent.setState({
            name
            , role
            , isAdmin
            , cin
            , usersDetails
          }) 
  
          localStorage.setItem('errorPage', false);
          //  HttpGet(currentComponent, groupName)
          //   .then(function (response) { 
          //     console.log("Permissions received from LMS user");
          //     console.log(response);
          //   }).catch(function (error) {
          //     console.log("Error received from Permission user");
          //     console.log(error);
          //    })
        }
        
      })
      .catch(function (error) {
        const serviceStatus = true;
        let count = localStorage.getItem('serviceCount');
        if (count == null) {
          localStorage.setItem('serviceCount', 1);
        } else if (parseInt(count) == 1) { 
          localStorage.setItem('serviceCount', 2);
        }

        if (error.response.status === 400) {
          localStorage.setItem('errorCode', '400');
        } else if (error.response.status === 401) {
          localStorage.setItem('errorCode', '401');
        } else if (error.response.status === 403) {
          localStorage.setItem('errorCode', '403');
        } else if (error.response.status === 404) {
          localStorage.setItem('errorCode', '404');
        } else if (error.response.status === 405) {
          localStorage.setItem('errorCode', '405');
        } else if (error.response.status === 409) {
          localStorage.setItem('errorCode', '409');
        } else if (error.response.status === 500) {
          localStorage.setItem('errorCode', '500');
        }
        
      })

  }

  getUserStatus = () => {
    const { href, hash } = window.location
    let userData = {}
    localStorage.clear(); 
    
    
    if (href.indexOf('access_token') !== -1) {

      const token = hash.split('=')[1].replace('&token_type', '');
      // const token = '';
      userData = {
        token
      , isAdmin: false
      }
      this.authData = { token }
      
    } else { 
        userData = this.authData || {}
        
        if (!userData.token) {
          localStorage.clear(); 
          this.clearAuthData()
        }
    }
    return userData
  }

  logoutUser = e => {
    e.preventDefault()
    const data = {
      client_id: REACT_APP_IAM_CLIENT_ID
    , token: this.userStatus.token
    }
    axios({
      method: 'post'
    , url: REACT_APP_IAM_BASE_URI + '/as/revoke_token.oauth2'
    , headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    , data: qs.stringify(data)
    }).then(this.clearAuthData)
  }

  clearAuthData = () => {
    localStorage.removeItem('userData');
    // localStorage.clear();
    this.redirectToIAMAuthScreen()
  }

  handleError = () => { 
    localStorage.removeItem('userData');
    // localStorage.clear();
    // window.location = 'https://lmsui-dev.apps.dev-pcf.lb1.rbsgrp.net/lms/Error';
  }

  redirectToIAMAuthScreen = () => {
    
    /*  Make sure to put the right CLIENT ID, based upon client mentioned on OAuth Server on IAM PingFederate page, in our case it's "channels_demo"  */
    const IAMEnv =  REACT_APP_IAM_BASE_URI+'/as/authorization.oauth2?client_id='+REACT_APP_IAM_CLIENT_ID+'&response_type=token&redirect_uri'
      , { origin } = window.location
    window.location = `${IAMEnv}=${origin}/`
    
  }

  initState() {
    
      this.userStatus = this.getUserStatus()
    
    let userData = {}
    const { token, isAdmin } = this.userStatus
    // token = '';
    if (token) {
      userData = {
        isLoggedIn: !!token
      , isAdmin
      }

      // const temperedToken = token + '1234';
       SetupInterceptor(token, this.handleError);
      //  var currentComp = this;
      //  var myVar = setInterval(function(){
      //     let time =  localStorage.getItem('timeout');
      //     if(time == "false"){
      //       currentComp.getCurrentUser();
      //     }else {
      //       clearInterval(myVar);
      //     }
      //   },
      //      4000);

          //  if(currentComp.state.serviceStatus == true){
          //     clearInterval(myVar);
          //  }

       //clearInterval(myVar);
 
    }
    this.state = {
      ...defaults
    , ...userData
    }
  }

  render() {
    // Use a Provider to pass the defaults, onLogout and logoutUser methods, to the tree below.
    // Any component can read it, no matter how deep it is.
    // In this code, we're passing this.state with spread operator, onLogout & logoutUser() methods as the current value.

    const { children } = this.props
        , { isLoggedIn } = this.state

    return (
      
      <AuthorizationContext.Provider
        value={{
          ...this.state
        , token: this.userStatus.token
        , onLogout: this.clearAuthData
        , logoutUser: this.logoutUser
        }}
      >
        {children}
      </AuthorizationContext.Provider>
    )
  }
}

export { AuthorizationContext, AuthProvider }