import React, { Fragment } from 'react';
import { API_ENDPOINT} from '../../config/config';
import { HttpGet, HttpPut, HttpPutWithoutBody } from '../../services/api';
import { Icon } from '@zambezi/sdk/icons';
import { Notification } from '@zambezi/sdk/notification';
import AssetDetailsTableMode from './assetDetailsTableMode';
import AssetDetailsListMode from './assetDetailsList';
import {modalMessage, spvstatusArray, objectToSkip} from './assetConstants';
import ModalPopup from './modal';
import MultilineModalPopup from './multilineModal';
import { withRouter } from 'react-router-dom';
import { AuthorizationContext } from '../authContext/index.js';
const PING = process.env.REACT_APP_PING;

class AssetDetails extends React.Component{
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            displayMode : 'table',
            isNewAsset : false,
            isError : true,
            errorMessage : '',
            newSpvExists: false,
            requestApproval:false,
            approveSPV:false, 
            rejectSPV:false,
            requestApprovalModalOpen:false,
            resonforRejection:"",
            archiveAsset:false,
            archiveAssetModal: false,
            isSentForApproval: false,
        };
    }
  
    componentDidMount(){
        var spvID ;
        var isNewAsset;
        if (this.props.location.state != undefined) {
            spvID = this.props.location.state.spvID;
            isNewAsset = this.props.location.state.isNewAsset;
            this.setState({spvID : spvID, isNewAsset : isNewAsset});
        }
        this.fetchSpvData(spvID);
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }

    fetchSpvData(spvID){
        var url = API_ENDPOINT.ASSET_DETAILS+'/'+ spvID;
        var currentComponent = this;

        HttpGet(currentComponent, url).then( (response)=> {
            localStorage.setItem('jurisdiction', response.data.jurisdiction);
            this.setState({
                isError : false,
                errorMessage : '',
                spvName : response.data.spvName,
                spvNumber : response.data.spvNumber,
                spvStatus : response.data.spvStatus,
                assetData : response.data,
                newSpvExists: response.data.newSpvExists,
                oldObj:{}
               
            }, () =>{
                this.closemodal();
                this.setrequestApproval();
                this.getOldSPVData();
            });
        })
        .catch((error) => {
            localStorage.setItem('jurisdiction','');
            console.log(error);
            this.setState({
                isError : true,
                errorMessage : 'Server error while fetching asset details, Please try again later !'
            })
        });
    }

    getOldSPVData (){
        if(this.state.newSpvExists && (this.state.spvStatus === "In Progress" || this.state.spvStatus.toLowerCase() === "pending approval")){
            const api = API_ENDPOINT.GET_OLD_SPV +"/"+ this.state.spvNumber;
            var currentComponent = this;
            HttpGet(currentComponent, api).then((response) => {
                if (response.data !== null) {
                     this.setState({'oldObj' : response.data})
                } 
            }).catch((error) => {
                    new Error(error);
                })
        }
        
    }
    setrequestApproval = () =>{
        let _toreturn = true;
        const data = this.state.assetData;
        const objectToSkip= ["corporateParentID", "mrec","reasonForRejection","optionCategory","managementFee","optionCategory","areaEffectiveDate","areaLocation","bookValue","dealStatus","leaseContractID","leaseEndDate","leaseStartDate","loRWA","marginAmount","residualValue","tenor","totalRWA","subAreaType","leaseFee", "supportingComments","versionNumber", "createdBy", "updatedBy", "requestedBy"];
        const optionalProps=['addressLineTwo','mvValue','constructionYear','lettableArea','areaSize'];
        // remove "createdBy", "updatedBy", "requestedBy" from above
        function chckNullObject(data){
            if(!_toreturn ) {return};
            for( const obj in data){
                if(objectToSkip.indexOf(obj) < 0 && optionalProps.indexOf(obj) < 0 ){
                    if(data[obj] === null){
                        _toreturn = false;
                        //alert("All feilds are mandatory. Please complete them")
                        break;
                    }
                }
            }
        }
        chckNullObject(data);
        data.propertyList.forEach(elem => {
            chckNullObject(elem);
            elem.buildingList.forEach(elem => {
                chckNullObject(elem);
                elem.areaEOList.forEach(item => {
                    chckNullObject(item);
                    item.areaTaxList.forEach(itemchild => {
                        chckNullObject(itemchild);
                    })
                    item.subAreaList.forEach(itemchild => {
                        chckNullObject(itemchild);
                    })
                })
            });
            elem.propertyOptionList.forEach(elem => {
                chckNullObject(elem);
            });
        })

        if(!_toreturn){
            this.setState({requestApproval : true})
        }
    }
    toggleDisplayMode(mode){
        this.setState({displayMode : mode});
    }

    formatResponseData(data){
    }
    setSPVContext(){
        localStorage.setItem('spvId', this.state.spvID);
        this.props.history.push('/lms/editasset');
    }
    goToAssetsList(){
        this.props.history.push('/lms/viewAssetDetail');
    }
    openRequestApprovalModal(){
        this.hideNotifications();
        this.setState({requestApprovalModalOpen : true});
    }
    sendRequestForApproval(){
        var racfDetail;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            racfDetail = usersDetails.userID;//racfID;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            racfDetail = "test";
        }
        this.hideNotifications();
        window.scrollTo(0, 0);
        const url = API_ENDPOINT.REQUEST_ASSET_APPROVAL +"/"+ parseInt(this.state.spvID)+"/"+"Pending Approval"+"/"+racfDetail
        var currentComponent = this;
        HttpPutWithoutBody(currentComponent, url).then( (response)=> {
            this.fetchSpvData(this.state.spvID);
            this.setState({isSentForApproval: true});
            
        })
    }
    approveSPV= ()=>{
        this.hideNotifications();
        if(!this.state.approveSPV){
            this.setState({approveSPV:true})
        }else {
            const url = API_ENDPOINT.APPROVE_SPV +"/"+ parseInt(this.state.spvID)+"/"+this.state.spvNumber+"/"+"Active"
            var currentComponent= this;
            HttpPutWithoutBody(currentComponent, url).then( (response)=> {
                this.props.history.push('/lms/viewAssetDetail');
            })
        }   
    }
    archiveAsset(){
        if(!this.state.archiveAsset){
            let dealstatus = false;
            const dealtype = ['Approved', 'Signed', 'Active']
            this.state.assetData.propertyList.forEach(elem => {
                elem.buildingList.forEach( item => {
                    item.areaEOList.forEach( itemchild => {
                        if(dealtype.indexOf(itemchild.dealstatus) >= 0){
                            dealstatus = true;
                        }
                    })
                })
            });
            if(dealstatus){
                    this.setState({archiveAsset:true})
                }else{
                    const url = API_ENDPOINT.ARCHIVE_SPV +"/"+parseInt(this.state.spvID)
                    var currentComponent = this;
                    HttpPutWithoutBody(currentComponent, url).then( (response)=> {
                        this.props.history.push('/lms/viewAssetDetail');
                    })
                }
        }else{
            const url = API_ENDPOINT.ARCHIVE_SPV +"/"+parseInt(this.state.spvID)
            var currentComponent = this;
            HttpPutWithoutBody(currentComponent, url).then( (response)=> {
                        this.props.history.push('/lms/viewAssetDetail');
                    })
        }   
    }
    
    openArchiveAssetModal(){
        this.hideNotifications();
        let dealstatus = false;
        const dealtype = ['Approved', 'Signed', 'Active']
        this.state.assetData.propertyList.forEach(elem => {
            elem.buildingList.forEach( item => {
                item.areaEOList.forEach( itemchild => {
                    if(dealtype.indexOf(itemchild.dealstatus) >= 0){
                        dealstatus = itemchild.dealstatus;
                    }
                })
            })
        });
        this.setState({"archiveAssetModal" : true, "dealstatus" : dealstatus});
    }

    confirmArchiveAsset(){
        const url = API_ENDPOINT.ARCHIVE_SPV + "/" + parseInt(this.state.spvID)
        var currentComponent = this;
        window.scrollTo(0, 0);
        HttpPutWithoutBody(currentComponent, url).then((response) => {
            // this.props.history.push('/lms/viewAssetDetail');
            this.fetchSpvData(this.state.spvID);
        })
    }

    handleOnChange (e){
        const name = e.target.name;
        const value = e.target.value;
        this.setState({
            [name]: value
        })
    }
    rejectSPV= ()=>{
        this.hideNotifications();
        if(!this.state.rejectSPV){
            this.setState({ rejectSPV:true})
        }else{
            let rejectReason = (this.state.resonforRejection && this.state.resonforRejection.length > 0) ? this.state.resonforRejection : 'NA';
            let newStatus = (this.state.newSpvExists ? 'Archived' : 'In Progress');
            const url = API_ENDPOINT.REJECT_SPV +"/"+ parseInt(this.state.spvID)+"/"+newStatus+"/"+rejectReason;
            var currentComponent = this;
            HttpPutWithoutBody(currentComponent, url).then( (response)=> {
                this.props.history.push('/lms/viewAssetDetail');
            })
        }
    }
    closemodal(){
        this.setState({
            approveSPV:false,
            rejectSPV:false,
            archiveAsset:false,
            requestApprovalModalOpen:false,
            archiveAssetModal : false,
        });
    }
    hideNotifications(){
        this.setState({
            isSentForApproval: false,
            isNewAsset: false
        })
    }
    fndisableEditBtn =()=>{
        let disabledEditBtn = true;
        if(this.state.spvStatus === "Active" && !this.state.newSpvExists){
           disabledEditBtn = false;
        }
        if(this.state.spvStatus === "In Progress"){
           disabledEditBtn = false;
        }
        return disabledEditBtn
    }
    render(){
        console.log(this.state);
        var requestedByFlag=false;
        if(this.state.assetData != undefined && this.state.assetData != null){
            if(this.state.racfData == this.state.assetData.requestedBy || 
                this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0){
                    console.log("if")
                    requestedByFlag = true;
            }
            else{
                requestedByFlag = false;
            }
        }
        
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var fucntDisable = true;
        
        for(var i = 0 ; i < datalen ; i++){
            if(perData[i] == "Asset_Archive"){
                fucntDisable = false; // general finance user can only remove subarea and property tax, he/she cannot archive asset
            }
        }
        console.log(fucntDisable)
              
    const rejectModalBody = <div className="form-group row">
                                <label htmlFor="spvName" className="col-sm-12 col-form-label field_label" style={{ marginTop: '0px', textAlign: "left", color: '#000000' }}>Are you sure you want to reject this asset ?</label>
                                <div className="col-sm-12">
                                <textarea className="form-control" name="resonforRejection" onChange={this.handleOnChange.bind(this)} placeholder="Please provide the reason of rejection" maxLength={255} rows={3} style={{ marginTop: '20px', resize: "none", borderRadius: "0px" }} />
                                </div>
                            </div>
     const spvstatusBol = spvstatusArray.indexOf(this.state.spvStatus) >= 0 ? true : false;
     const archiveAssetMsg = this.state.dealstatus ? `This asset has a linked deal to it in "${this.state.dealstatus}" status, please remove the link before proceeding` : modalMessage["archiveMsg"];
     const disabledEditBtn = this.fndisableEditBtn();
     console.log(spvstatusBol)
        return(
            <div className="assetpage container-fluid">
            {this.state.approveSPV ?
                <ModalPopup headerTitle="Approve Asset" open={true} className={'assetpageModal'} confirm={this.approveSPV} confirmBtnText="Yes, approve asset" close={this.closemodal.bind(this)} modalbody={modalMessage["approveAssetMsg"]} /> : null}
                
                {this.state.rejectSPV ? <ModalPopup headerTitle="Reject asset" className={'assetpageModal'} confirmBtnText='Yes, reject asset' cancel='Cancel' withSectioning={false} open={true} confirm={this.rejectSPV.bind(this)} close={this.closemodal.bind(this)}  modalbody={rejectModalBody} /> : null}
                
                {this.state.archiveAssetModal ? <ModalPopup headerTitle="Archive asset" className={'assetpageModal'} confirmBtnText={this.state.dealstatus?'':'Yes, archive asset'} cancelBtnText={this.state.dealstatus?'OK':"No, don't archive asset"} withSectioning={false} open={true} confirm={this.confirmArchiveAsset.bind(this)} close={this.closemodal.bind(this)}   modalbody={archiveAssetMsg} /> : null}

                {this.state.requestApprovalModalOpen ? <MultilineModalPopup headerTitle="Request approval" className={'assetpageModal'} confirmBtnText="Yes, request approval" cancelBtnText="Cancel" open={true} confirm={this.sendRequestForApproval.bind(this)} close={this.closemodal.bind(this)} modalbody={modalMessage['requestApprovalMsg']}/> : null}

                <div className="allAssetsButton">
                    <Icon name="chev-left-xsmall" title="Go to assets list" size='xsmall' />
                    <span onClick={this.goToAssetsList.bind(this)}> All assets</span>
                </div>
                {this.state.isError ? 
                // <div className="errorMessage"><Notification status="error" size="small">{this.state.errorMessage ? this.state.errorMessage : 'Server error. Please try again later !'}</Notification></div>
                null
                :
                <div className="inner_header">
                    {this.state.isNewAsset ? 
                    <div className="saveAssetSuccessMessage"><Notification status="success" size="medium">{'Your asset has been saved.'}</Notification></div>
                    : null
                    }
                    {this.state.isSentForApproval ? 
                    <div className="saveAssetSuccessMessage"><Notification status="success" size="medium">{'Your asset has been send for approval.'}</Notification></div>
                    : null
                    }
                    <label className="details_title model_title">{this.state.spvNumber+' '+this.state.spvName}</label>
                    <div className="form-group row">
                        <div className="col-sm-8">
                            <div className="approvalSelectBtn_grp">
                                <div className="btn-group">
                                    <button type="button" style = {{fontFamily : 'RNFontRegularWoff', fontSize : '17px'}} onClick = {this.toggleDisplayMode.bind(this, 'table')} className={"btn btn-primary selectBtn " + (this.state.displayMode === 'table' ? 'dealtype_selected' : 'dealtype_notselected')} >Table Mode</button>
                                    <button type="button" style = {{fontFamily : 'RNFontRegularWoff', fontSize : '17px'}} onClick = {this.toggleDisplayMode.bind(this, 'list')} className={"btn btn-primary selectBtn " + (this.state.displayMode === 'list' ? 'dealtype_selected' : 'dealtype_notselected')} >List Mode</button>
                                </div>
                            </div>
                        </div>
                        <label className="col-sm-4 col-form-label field_label" style={{paddingRight: '35px'}}>
                        <p>Status : <b>{this.state.spvStatus}</b></p>
                        </label>
                    </div>
                    <div className="col-sm-4 exportButtonGroup">
                        <div className="col-sm-6">
                            <Icon name="export-small" size='small' /> <label className="uploadDocument"> Export to Excel</label>
                        </div>
                        <div className="col-sm-6">
                            <Icon name="download-small" size='small' /> <label className="uploadDocument"> Download PDF</label>
                        </div>
                    </div>
                    {
                        this.state.displayMode === 'table' ? 
                                <AssetDetailsTableMode data={{ spvID: this.state.spvID }} assetData={this.state.assetData}></AssetDetailsTableMode> :
                        <AssetDetailsListMode prevData= {this.state.oldObj} data={this.state.assetData}></AssetDetailsListMode>
                    }
                    <div className="form-group"> 
                    {this.state.spvStatus === "Pending Approval" ? 
                         <Fragment>
                            <button disabled={requestedByFlag} className='zb-button zb-button-primary footerButton'onClick={this.approveSPV.bind(this)}>Approve</button>
                            <button disabled={requestedByFlag} className="zb-button zb-button-secondary footerButton transparent" onClick={this.rejectSPV.bind(this)}>Reject</button>
                        </Fragment>
                        : 
                       <Fragment>
                             <button disabled={ (this.state.requestApproval && this.state.spvStatus === "In Progress") || (this.state.spvStatus === "Active" || this.state.spvStatus === "Archived") ? true : false} className='zb-button zb-button-primary footerButton' onClick={this.openRequestApprovalModal.bind(this)}>Request approval</button> 
                            <button disabled ={disabledEditBtn} className="zb-button zb-button-secondary footerButton transparent" onClick={this.setSPVContext.bind(this)}>Edit asset</button>
                           </Fragment> 
                    } 
                        {spvstatusBol ? 
                        
                            <div className={"col-sm-4 archiveButtonFooter " + (fucntDisable  ? 'disabledLabel' : '')} >
                                <Icon name="trash-small" size='small' /><label className="uploadDocument"onClick={this.openArchiveAssetModal.bind(this)}>Archive asset</label>
                            </div>
                                : 
                            <div className="col-sm-4 archiveButtonFooterDisable">
                                <Icon name="trash-small" size='small' /><label className="uploadDocument">Archive asset</label>
                            </div> } 
                        </div>
                </div>
                }
            </div>
        )
    }
}

export default withRouter(AssetDetails);
