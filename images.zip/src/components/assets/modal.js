import React from 'react';
import Modal from '@zambezi/sdk/modal';


export const ModalPopup = (props) =>{
  // const modaltitle = <label style={{ "fontSize":"22px", "padding":"0px", "margin":"0px", "fontWeight":"normal"}}>{props.headerTitle}</label>
  return <Modal
                title= {props.headerTitle}
                className={props.className ? props.className : 'example-simple'}
                confirm={props.confirmBtnText}
                cancel={props.cancelBtnText ? props.cancelBtnText : 'Cancel'}
                withSectioning={false}
                withPadding
                isClosable
                open={props.open}
                onConfirm={() => {
                    console.info('You confirmed')
                    props.confirm();
                }}
                onCancel={() => {
                    console.info('You closed the modal or cancelled')
                    props.close()
                }}>
                { (typeof props.modalbody !== "object") ? 
                  <label className='col-form-label field_label' style={{color:'#000000', textAlign:'left'}}>{props.modalbody}</label> 
                : props.modalbody
                }
      </Modal>
}

export default ModalPopup;