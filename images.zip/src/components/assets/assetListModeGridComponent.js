import React, { Fragment } from 'react';

class AssetListModeGridComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            displayData : props.data,
        };
    }

    componentWillReceiveProps(props){
        this.setState({ displayData : props.data });
    }

    render(){
        let accordianCustomClass = '';
        let editText = '';
        if (this.props.editFlag == 1) {
            accordianCustomClass = 'deletedGridComponent';
            editText = ' - Removed'
        } else if (this.props.editFlag == 2) {
            accordianCustomClass = 'addedGridComponent';
            editText = ' - New'
        } 
        // else if (this.props.editFlag == 3) {
        //     accordianCustomClass = 'editedGridComponent';
        //     editText = ' - Edited'
        // }
        return(
            <div className={(this.props.isList ? 'col-sm-4':'col-sm-7')+" assetListModeGrid "+accordianCustomClass}>
                {this.props.heading ?
                    <div className={this.props.bigHeading ? 'big_header' : 'header'}>
                        {this.props.heading+editText}
                    </div>
                    : null
                }
                {
                    this.state.displayData.map((rowData, index) => {
                        return (
                            <div key={index} className="form-group removeMargin row">
                                <label className={(this.props.isList ? ' col-sm-7':'col-sm-4')+" col-form-label field_label"}>
                                    {rowData ? rowData.key : ''}
                                </label>
                                <label className={(this.props.isList ? ' col-sm-5':'col-sm-8')+ " col-form-label field_label field_value"}>
                        {rowData.isEdited ? 
                            <Fragment>
                                <div className="highlighted">{rowData.value}</div>
                                <div className="oldText">{rowData.oldValue !== '' ? '( '+rowData.oldValue+' )' : ''}</div>
                            </Fragment> 
                        : rowData.value}
                                </label>
                            </div>
                        )
                    })
                }
            </div>
        )
    }
}

export default AssetListModeGridComponent;