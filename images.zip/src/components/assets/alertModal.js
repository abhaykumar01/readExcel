import React from 'react';
import Modal from '@zambezi/sdk/modal';


export const AlertModalPopup = (props) =>{

  return <Modal
                title= {props.headerTitle}
                className={props.className ? props.className : 'example-simple'}
                confirm={props.confirmBtnText}
                withSectioning={false}
                withPadding
                isClosable = {false}
                open={props.open}
                onConfirm={() => {
                    console.info('You confirmed')
                    props.confirm();
                }}>
                { (props.modalbody && props.modalbody.length > 0) ? 
                  props.modalbody.map((item, index) => {
                    return <label key={index} className='col-form-label field_label' style={{color:'#000000', textAlign:'left'}}>{item}</label> 
                  })
                : props.modalbody
                }
      </Modal>
}

export default AlertModalPopup;