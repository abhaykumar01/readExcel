import React from 'react';

class assetSummaryComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            displayData : [],
        };
    }

    componentWillReceiveProps(props){
        let displayData =[];
        for(let i=0; i<props.data.length; ){
            let tempDataArray = [];
            for(let j=0; j<4; j++){
                if(props.data[i] && props.data[i].id=='customerNameList'){
                    this.setState({secondDisplayData : props.data[i]});
                    j--;
                    i++;
                    continue;
                }
                tempDataArray.push(props.data[i]);
                i++;
            }
            displayData.push(tempDataArray);
        }
        this.setState({displayData : displayData});
    }

    render(){
        return(
            <div className="spvSummaryGrid">
                {
                    this.state.displayData.map((rowData,index) => {
                        return (
                            <div key={index} className="row" style={{marginRight : '30px'}}>
                             {rowData.map((columnData, cIndex) =>{
                                 return (
                                    <div key={index*10 + cIndex} className="col-sm-3">
                                        <div className="form-group removeMargin row">
                                            <label className="col-sm-8 col-form-label field_label">{columnData ? columnData.key : ''}</label>
                                            <label className="col-sm-4 col-form-label field_label field_value">{columnData ? columnData.value : ''}</label>
                                        </div>
                                    </div>
                                 )
                             })}
                            </div>
                        )
                    })
                }
                {this.state.secondDisplayData ? 
                    <div className="form-group row optioncontainer" style={{marginLeft:'25px'}}>
                        <label className="col-sm-2 col-form-label field_label">{this.state.secondDisplayData.key}</label>
                        <label className="col-sm-10 col-form-label field_label field_value">{this.state.secondDisplayData.value}</label>
                    </div>
                    : null
                }
            </div>
        )
    }
}

export default assetSummaryComponent;