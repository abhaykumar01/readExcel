export const spvLabelsListMode = [
    {key : 'spvName' , value : 'SPV name', type : 'name'},
    {key : 'spvNumber' , value : 'SPV number', type : 'number'},
    {key : 'jurisdiction' , value : 'Jurisdiction', type : 'name'},
    {key : 'registrationForm' , value : 'Registration form', type : 'name'},
    {key : 'mrec' , value : 'MREC', type : 'boolean'},
    {key : 'registrationNumber' , value : 'Registration number', type : 'number'},
    {key : 'corporateParent' , value : 'Corporate parent', type : 'name'},
    {key : 'spvApproval' , value : 'SPV approval received?', type : 'boolean'},
]

export const optionLabelsListMode = [
    {key : 'optionType' , value : 'Option type', type : 'optionType'},
    {key : 'optionStrikePrice' , value : 'Option strike price', type : 'currency'},
    {key : 'upfrontOptionPremium' , value : 'Upfront option premium', type : 'currency'},
    {key : 'paidPremium' , value : 'Premium paid at option exercise date', type : 'currency'},
    {key : 'optionDate' , value : 'Option date', type : 'date'},
    {key : 'earliestNoticeDate' , value : 'Earliest notice date', type : 'date'},
    {key : 'latestNoticeDate' , value : 'Latest notice date', type : 'date'},
]

export const propertyLabelsListMode = [
    {key : 'propertyName', value : 'Property name', type : 'name'},
    {key : 'addressLineOne' , value : 'Address line 1', type : 'name'},
    {key : 'addressLineTwo' , value : 'Address line 2', type : 'name'},
    {key : 'city' , value : 'City', type : 'name'},
    {key : 'postCode' , value : 'Postcode', type : 'number'},
    {key : 'country' , value : 'Country', type : 'name'},
    {key : 'registrationNumber' , value : 'Registration number', type : 'number'},
    {key : 'propertyStatus' , value : 'Status', type : 'name'},
]

export const buildingLabelsListMode = [
    {key : 'buildingName' , value : 'Building name', type : 'name'},
    {key : 'buildingType' , value : 'Building type', type : 'name'},
    {key : 'assetClassification' , value : 'Asset classification', type : 'name'},
    {key : 'isConstructionWorkPlanned' , value : 'Construction work planned?', type : 'boolean'},
    {key : 'valuationDate' , value : 'Valuation date', type : 'date'},
    {key : 'valuationDateUntil' , value : 'Valuation valid until', type : 'date'},
    {key : 'mvValue' , value : 'MV', type : 'currency'},
    {key : 'reLetValue' , value : 'RLV', type : 'currency'},
    {key : 'vacantPossessionValue' , value : 'VPV', type : 'currency'},
    {key : 'constructionYear' , value : 'Construction year', type : 'number'},
    {key : 'lettableArea' , value : 'Lettable area', type : 'number'},
]

export const areaLabelsListMode = [
    {key : 'areaName' , value : 'Unique area name', type : 'name'},
    {key : 'customerName' , value : 'Customer name', type : 'name'},
    {key : 'areaByUse' , value : 'Area by use', type : 'number'},
    {key : 'areaSize' , value : 'Square metres', type : 'number'},
    {key : 'tenor' , value : 'Tenor', type : 'number'},
    {key : 'leaseStartDate' , value : 'Lease start date', type : 'date'},
    {key : 'leaseEndDate' , value : 'Lease end date', type : 'date'},
    {key : 'bookValue' , value : 'Book value', type : 'currency'},
    {key : 'totalRWA' , value : 'RWA', type : 'currency'},
    {key : 'marginAmount' , value : 'Margin amount', type : 'currency'},
    {key : 'loRWA' , value : 'loRWA', type : 'number'},
    {key : 'residualValue' , value : 'Residual value', type : 'currency'},
    {key : 'vacantPossesionValue' , value : 'VPV', type : 'currency'},
    {key : 'reLetValue' , value : 'RLV', type : 'currency'},
    {key : 'extensionPeriod' , value : 'Extension period', type : 'number'},
    {key : 'leaseFee' , value : 'Lease Fee', type : 'currency'},
    // {key : 'totalServiceCharge' , value : 'Service charge', type : 'currency'},
]

export const subAreaLabelsListMode = [
    {key : 'subAreaPercent' , value : 'Area percent', type : 'percent'},
]

const areaTaxLablesListMode = [
    {key : 'propTaxValue' , value : 'Property tax', type : 'currency'},
    {key : 'taxationValue' , value : 'Taxation value', type : 'currency'},
    {key : 'propTaxationValueInPercent' , value : 'Proportion of taxation value %', type : 'percent'},
    {key : 'propTaxationValue' , value : 'Proportion of taxation value', type : 'currency'},
    {key : 'propTaxPercent' , value : 'Property tax %', type : 'percent'},
    {key : 'effectiveDate' , value : 'Effective from', type : 'date'},
    {key : 'supportingComments' , value : 'Supporting comments', type : 'name'},
]

const serviceChargeListMode = [
    {key : 'serviceChargeAmount' , value : 'Amount', type : 'currency'},
]

export function getAreaTaxLables(taxType){
    if(taxType === "Property tax"){
        return areaTaxLablesListMode;
    } else {
        return serviceChargeListMode;
    }
}