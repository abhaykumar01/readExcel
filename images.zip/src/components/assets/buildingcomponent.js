import React, { Fragment } from 'react';
import Dropdown from '../../commonComponents/dropdown';
import Accordion from '@zambezi/sdk/accordion';
import { Icon } from '@zambezi/sdk/icons';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import { generatedataType, getCurrencySymbol, areaLimit, defaultArea, modalMessage, dealstatusArray, spvstatusArray } from './assetConstants';
import AreaComponent from './areacomponent';
import ModalPopup from './modal';
import MultilineModalPopup from './multilineModal';
import moment from 'moment';

class BuildingComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = props.data;
        this.state.spvstatusBol = props.parentData.spvstatusBol;
        this.state.buildingRemoval = false;
        this.getValuationDate = this.getValuationDate.bind(this, 'valuationDate');
        this.getValuationUntilDate = this.getValuationUntilDate.bind(this, 'valuationDateUntil');
    }
    componentWillMount() {
        /* this case will work only when in edit mode data is already preset
           so as to add id which is required for deletion while adding new    
        */
        if (this.state.areaEOList.length > 0) {
            const areaList = this.state.areaEOList
            for (var i = 0; i < areaList.length; i++) {
                areaList[i].spvareaID = i + 1;
            }
        }
    }
    getValuationDate(type, e) {
        var startDate = moment(Date.parse(e)).format('YYYY-MM-DD');
        this.setState({ [type]: startDate }, () => {
            this.props.data[type] = this.state[type];
        })
    }
    getValuationUntilDate(type, e) {
        var startDate = moment(Date.parse(e)).format('YYYY-MM-DD');
        this.setState({ [type]: startDate }, () => {
            this.props.data[type] = this.state[type];
        })
    }
    componentWillReceiveProps(props) {
        let _updatedData = Object.assign(this.state, props.data)
        this.setState({ _updatedData })
    }

    handleDropDownChange(event, val, type) {
        // const spvstatusBol = typeof this.state.buildingID != "undefined" ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.buildingFlag && this.state.buildingFlag !== 2)) ? 3 : this.state.buildingFlag;
        this.setState({ buildingFlag: optnflag, [event]: type.value }, () => {
            this.props.data.buildingFlag = this.state.buildingFlag
            this.props.data[event] = this.state[event];
        })
    }

    handleOnChange(e) {
        const name = e.target.name;
        //const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        // const spvstatusBol = typeof this.state.buildingID != "undefined" ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.buildingFlag && this.state.buildingFlag !== 2)) ? 3 : this.state.buildingFlag;
        let value = e.target.value;
        let newVal =""; 
        if(name ==="lettableArea" || name ==="constructionYear" ||  name ==="vacantPossessionValue" || name==="reLetValue" || name==="mvValue" ){
            var regex= (name ==="constructionYear") ?  /^[0-9,]{0,3}.[0-9]{0,1}$/ : /^[0-9,]{0,23}.[0-9]{0,2}$/;
            if(!regex.test(value) ){
                if(value === ""){
                    value ="";
                }else {
                    return ;
                }
            }

        } else {
            if (value.length > e.target.maxLength) {
                value = value.substring(value.length - 1, value);
            }
        }

        this.setState({ buildingFlag: optnflag, [name]: value }, () => {
            this.props.data.buildingFlag = this.state.buildingFlag
            this.props.data[name] = this.state[name]
        });


        if (name === 'lettableArea' || name === 'reLetValue' || name === 'vacantPossessionValue') {
            var buildingSquareMetres;
            var buildingRlv;
            var buildingVpv;
            if (name === 'lettableArea') {
                buildingSquareMetres = value;
            } else {
                buildingSquareMetres = this.state.lettableArea;
            }

            if (name === 'reLetValue') {
                buildingRlv = value;
            } else {
                buildingRlv = this.state.reLetValue;
            }

            if (name === 'vacantPossessionValue') {
                buildingVpv = value;
            } else {
                buildingVpv = this.state.vacantPossessionValue;
            }

            this.state.areaEOList.map((areaEO) => {
                if (buildingSquareMetres && areaEO.squareMetres) {
                    if (buildingSquareMetres > 0 && areaEO.squareMetres > 0) {
                        areaEO.reLetValue = (areaEO.squareMetres / buildingSquareMetres) * buildingRlv;
                        areaEO.vacantPossesionValue = (areaEO.squareMetres / buildingSquareMetres) * buildingVpv;
                    } else {
                        areaEO.reLetValue = buildingRlv;
                        areaEO.vacantPossesionValue = buildingVpv;
                    }
                } else {
                    areaEO.reLetValue = buildingRlv;
                    areaEO.vacantPossesionValue = buildingVpv;
                }
            })
            this.setState({ areaEOList: this.state.areaEOList });
        }
    }

    checkApprovalStatus(status) {
        this.setState({ 'isConstructionWorkPlanned': status }, () => {
            this.props.data.isConstructionWorkPlanned = this.state.isConstructionWorkPlanned;
        })
    }
    addArea() {
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if (typeof this.state.areaCount !== "undefined" && this.state.areaCount == areaLimit) { return }
        if (typeof this.state.areaCount !== 'undefined') {
            this.state.areaCount = this.state.areaCount + 1
        } else {
            this.state.areaCount = this.state.areaEOList.length > 0 ? this.state.areaEOList.length + 1 : 1
        }
        if (this.state.areaCount <= areaLimit) {
            let newArea = { ...defaultArea };
            newArea.spvareaID = this.state.areaCount;
            newArea.areaFlag = (this.state.spvstatusBol) ? 2 : 0;
            newArea.vacantPossesionValue = this.state.vacantPossessionValue;
            newArea.reLetValue = this.state.reLetValue;
            const modfiedState = this.state.areaEOList.concat({ ...newArea, 'totalSubAreaPercentage': 0, 'totalSubAreaError': false, "uniqueNameError": false, });
            this.setState({
                areaEOList: modfiedState
            }, () => {
                this.props.data.areaEOList = this.state.areaEOList;
                this.props.data.areaCount = this.state.areaCount;
            })
        }

    }
    removeArea = (param) => {
        // event.stopPropagation();
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        let dealLinked = false;
        if (!this.state.spvstatusBol || (param.state.areaFlag && param.state.areaFlag === 2)) {
            const newState = this.state.areaEOList.filter((item) => {
                return param.props.data.spvareaID != item.spvareaID
            })
            this.setState({
                areaEOList: newState
            }, () => {
                this.props.data.areaEOList = this.state.areaEOList;
                this.props.data.areaCount = this.state.areaCount;
            })
        } else {
            this.state.removedArea = typeof this.state.removedArea != "undefined" ? this.state.removedArea : []
            // this.state.areaEOList.forEach( item =>{
            //     if(item.dealStatus !== null && dealstatusArray.indexOf(item.dealStatus) >=0){
            //         dealLinked = item.dealStatus;
            //     }
            // })
            const removeObj = this.state.areaEOList.filter((item) => {
                if (param.props.data.spvareaID === item.spvareaID) {
                    item.areaFlag = 1;
                    return item;
                }
            })
            // this.state.removedArea.push(removeObj[0])
            // this.setState({"arearemoval":true, "dealLinked":dealLinked})
            this.forceUpdate();
        }
    }
    confirmremoveArea = () => {
        const newState = this.state.areaEOList.filter((item) => {
            return item.areaFlag != 1
        })
        this.setState({
            "arearemoval": false,
            "areaEOList": newState
        }, () => {
            this.props.data.areaEOList = this.state.areaEOList
        });
    }

    removeBuilding() {
        let dealLinked = false;
        this.state.areaEOList.forEach(itemchild => {
            if (itemchild.dealStatus !== null && dealstatusArray.indexOf(itemchild.dealStatus) >= 0) {
                dealLinked = itemchild.dealStatus;
            }
        });
        this.setState({ "buildingRemoval": true, "dealLinked": dealLinked });
    }

    onConfirmBuildingRemoval() {
        this.setState({ buildingRemoval: false }, () => {
            this.props.removebuilding(this);
        })
    }

    closemodal = () => {
        const closeObj = {
            "arearemoval": false,
            "buildingRemoval": false,
        }
        this.setState(closeObj);
    }
    render() {
        console.log(this.props.fucntDisable);
        const country = this.props.parentData.country.toString().toLowerCase();
        const area = this.state.areaEOList.map((item, index) => {
            if (item.areaFlag != 1) {
                return <AreaComponent fucntDisable={this.props.fucntDisable} key={item.spvareaID} index={index + 1} data={item} parentData={this.state} removearea={this.removeArea} />
            }
        })


        const dealLinkedMsgBuilding = dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? [`The Building you are trying to remove has a linked deal to it in ${this.state.dealLinked} status, please remove the link before proceeding`] : modalMessage["buildingMsg"];

        return (
            <Fragment>
                {/* { this.state.arearemoval ?
                <ModalPopup headerTitle="Remove Area" className={'assetpageModal'} open={true} confirmBtnText={dealstatusArray.indexOf(this.state.dealLinked) >=0 ? "" : "Yes, remove this area" } confirm={this.confirmremoveArea} close = {this.closemodal} data= {this.state} modalbody= {dealLinkedMsg} />  : null} */}
                {this.state.buildingRemoval ?
                    <MultilineModalPopup headerTitle="Remove building" className={'assetpageModal'} open={this.state.buildingRemoval} confirmBtnText={dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? "" : "Yes, remove this building"} confirm={this.onConfirmBuildingRemoval.bind(this)} close={this.closemodal} data={this.state} modalbody={dealLinkedMsgBuilding} /> : null}

                <Accordion className="buildingComponent" withPadding={false}>
                    <dt open={true} >Building {this.props.index} <span className="accordianRightlabel" onClick={this.removeBuilding.bind(this)}><Icon name="trash-small" size="small" />Remove building</span></dt>
                    <div className="">
                        <div className="form-group row">
                            <label htmlFor="buildingName" className="col-sm-4 col-form-label field_label" >Building name  </label>
                            <div className="col-sm-6">
                                <input type="text" maxLength="50" onChange={this.handleOnChange.bind(this)} name="buildingName" value={this.state.buildingName}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                        </div>
                        <Dropdown title="Building type" selectedValue={this.state.buildingType} onChange={this.handleDropDownChange.bind(this, 'buildingType')}
                            classname="font_config_custom" data={generatedataType['buildingType']} errorStatus={false} />
                        <Dropdown title="Asset classification" selectedValue={this.state.assetClassification} onChange={this.handleDropDownChange.bind(this, 'assetClassification')} classname="font_config_custom" data={generatedataType[country]} errorStatus={false} />
                        <div className="form-group row">
                            <label className="col-sm-4 col-form-label field_label">Construction work planned</label>
                            <div className="col-sm-8">
                                <div className="approvalSelectBtn_grp">
                                    <div className="btn-group">
                                        <button type="button" onClick={this.checkApprovalStatus.bind(this, 0)} className={"btn btn-primary selectBtn " + (this.state.isConstructionWorkPlanned === 0 ? 'dealtype_selected' : 'dealtype_notselected')} >No</button>
                                        <button type="button" onClick={this.checkApprovalStatus.bind(this, 1)} className={"btn btn-primary selectBtn " + (this.state.isConstructionWorkPlanned === 1 ? 'dealtype_selected' : 'dealtype_notselected')} >Yes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <Calenderinputfield fieldTitle="Valuation date" value={this.state.valuationDate} onChange={this.getValuationDate} inputType="date" name="valuationDate" placeholder="DD/MM/YYYY" />
                        <Calenderinputfield fieldTitle="Valuation valid until" value={this.state.valuationDateUntil} onChange={this.getValuationUntilDate} inputType="date" name="valuationDateUntil" placeholder="DD/MM/YYYY" />
                        <div className="form-group row">
                            <label htmlFor="mvValue" className="col-sm-4 col-form-label field_label" >MV (optional)</label>
                            <div className="col-sm-6">
                                <input type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="mvValue" value={this.state.mvValue}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="reLetValue" className="col-sm-4 col-form-label field_label" >RLV</label>
                            <div className="col-sm-6">
                                <input type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="reLetValue" value={this.state.reLetValue}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="vacantPossessionValue" className="col-sm-4 col-form-label field_label" >VPV</label>
                            <div className="col-sm-6">
                                <input type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="vacantPossessionValue" value={this.state.vacantPossessionValue}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="constructionYear" className="col-sm-4 col-form-label field_label" >Construction year (optional)</label>
                            <div className="col-sm-6">
                                <input type="text" maxLength="4" onChange={this.handleOnChange.bind(this)} name="constructionYear" value={this.state.constructionYear}
                                    className="form-control input_Fields" placeholder="YYYY" />
                            </div>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="lettableArea" className="col-sm-4 col-form-label field_label" >Lettable Area (optional)</label>
                            <div className="col-sm-3">
                                <input type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="lettableArea" value={this.state.lettableArea}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label className="col-sm-3 col-form-label field_label currencySymbol" >square meters</label>

                        </div>
                        {area}
                        <div className="form-group row" style={{ 'marginBottom': '0px' }}>
                            <label className="col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor" onClick={this.addArea.bind(this)}> <span><Icon name="plus-xsmall" size="small" /> {this.state.areaEOList.length > 0 ? <span>Add another area</span> : <span>Add area</span>} </span></label>
                        </div>
                    </div>
                </Accordion>
            </Fragment>
        )
    }
}
export default BuildingComponent;