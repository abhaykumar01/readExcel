import React from 'react';
import '../../index.css';

import SPVFormContainer from './spvformcontainer';
import { defaultAsset } from './assetConstants';

class addAsset extends React.Component {
    constructor(props) {
        super(props);
        const notification = {"isSucess":false, "isUniqueAreaNameError" : false, "isErrorOnSave":false}
        this.state = {...defaultAsset , ...notification};
        
    }
    render() {
        return (
            <div className="assetpage container-fluid">
                <SPVFormContainer data= {this.state}/>
            </div>
        )
    }
}
export default addAsset;

