import { getCurrencySymbol } from './assetConstants';
import moment from 'moment';

export const formatDate = function(dateString, locale){
    if(dateString !== null && dateString !== ''){
        return moment(dateString).toDate().toLocaleDateString(locale, {timezone: 'UTC', dateStyle:'short'});
    } else {
        return '';
    }
}

export const formatCurrencyValue = function(value, locale){
    if(null != value && value !== ''){
        return getCurrencySymbol()+" "+value.toLocaleString(locale, {maximumFractionDigits : 2});
    }else {
        return '';
    }
}

export const getCommaSeperatedStringFromArray = function(list){
    var result ='';
    if(list && list.length > 0){
        list.forEach((element) => {
            if(element){
                result += (element + ', ');
            }
        })
        return result.slice(0, -2);  
    } else {
        return result;
    }
}


export const getDateFormat = function(date, locale){
    if( date != null){
        const date= moment(date).toDate();
        return date.toLocaleString(locale, {timezone: 'UTC', timeStyle:'short', dateStyle:'medium'})
    }else {
        return  '';
    }
    
}