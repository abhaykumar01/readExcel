import React, { Fragment } from 'react';
import Dropdown from '../../commonComponents/dropdown';
import Accordion from '@zambezi/sdk/accordion';
import { Icon } from '@zambezi/sdk/icons';
import {generatedataType,  modalMessage, spvstatusArray, dealstatusArray} from './assetConstants';
import PropertyOptionComponent from './propertyoptioncomponent';
import BuildingComponent from './buildingcomponent';
import  ModalPopup from './modal';
import MultilineModalPopup from './multilineModal';
import AlertModalPopup from './alertModal';
import { propertyOptionLimit , buildingLimit, propertyoption, deafaultBuilding} from './assetConstants'

class PropertyContainer extends React.Component {
    constructor(props){
        super(props);
        this.state = props.data
        this.state.propertyOptionModal = false;
        this.state.spvstatusBol = props.parentData.spvstatusBol;
    }
    componentWillReceiveProps(props){
         let _updatedData = Object.assign(this.state, props.optiondata)
         this.setState({_updatedData})
     }
     componentWillMount(){
        /* this case will work only when in edit mode data is already preset
           so as to add id which is required for deletion while adding new    
        */
        if(this.state.propertyOptionList.length > 0){
            const optnList = this.state.propertyOptionList
            for( var i=0; i<optnList.length; i++){
                optnList[i].propertyoptionID = i+1;
            }

        }

        if(this.state.buildingList.length > 0){
            const buldList = this.state.buildingList;
            for( var j=0; j<buldList.length; j++){
                buldList[j].spvbuildingID = j+1;
            }
        }
        
    }
    handleDropDownChange(event, val, type){
        //const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        // const spvstatusBol = (typeof this.state.propertyID != "undefined") ? true : false;
        const flagVal = (this.state.spvstatusBol && (null != this.state.propertyFlag && this.state.propertyFlag !== 2)) ? 3 : this.state.propertyFlag;
        this.setState({ propertyFlag : flagVal, [event]: type.value}, () => {
            this.props.data.propertyFlag = this.state.propertyFlag
            this.props.data[event] = this.state[event];
        }) 
    } 
    handleOnChange (e) {
        const name = e.target.name;
        // const spvstatusBol = (typeof this.state.propertyID != "undefined") ? true : false;
        const flagVal = (this.state.spvstatusBol && (null != this.state.propertyFlag && this.state.propertyFlag !== 2)) ? 3 : this.state.propertyFlag;
        let value = e.target.value;
        let newVal =""; 
        if(name ==="postCode"){
            var regex= /^[0-9\b]+$/;
            if(value !==""){
                if(value.length > e.target.maxLength){
                    newVal = value.substring(value.length-1, value);
                }
                if(!regex.test(value)){
                    newVal =  value.substring(value.length-1, value);
                    value = newVal;
                }
            }else {
                // TODO for blank case
            }
        }else {
            if(value !==""){
                if(value.length > e.target.maxLength){
                    newVal = value.substring(value.length-1, value);
                }
            }else {
                // TODO for blank case
            }
        }
        
        this.setState({propertyFlag : flagVal,  [name]:value}, () => {
            this.props.data.propertyFlag = this.state.propertyFlag
            this.props.data[name] = this.state[name]
        });
    }
    checkSPVOptionAdded = () =>{
        let optionAdded = false;
        if(this.props.parentData.spvOptionsList.length > 0){ optionAdded = true}
        return optionAdded ;
    }
    addPropertyOption(){
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if (this.checkSPVOptionAdded()) {
            this.setState({propertyOptionModal: true}); 
            return;
        }
        if (typeof  this.state.propertyoptionCount !== "undefined"  && this.state.propertyoptionCount == propertyOptionLimit) {return}
            if (typeof  this.state.propertyoptionCount !== "undefined") {
                this.state.propertyoptionCount = this.state.propertyoptionCount + 1
           } else {
               this.state.propertyoptionCount = this.state.propertyOptionList.length > 0 ? this.state.propertyOptionList.length+1 : 1
               }  
        if(this.state.propertyoptionCount <= propertyOptionLimit) {  
            const newPropertyOption = {...propertyoption};
            newPropertyOption.dealOptionFlag = (this.state.spvstatusBol) ? 2 : 0
            newPropertyOption.propertyoptionID = this.state.propertyoptionCount;
            // this.state.propertyOptionList.push(newPropertyOption);
            const modfiedState = this.state.propertyOptionList.concat(newPropertyOption);
             this.setState({
                 propertyOptionList: modfiedState
             }, () =>{
                this.props.data.propertyOptionList = this.state.propertyOptionList
             });
            }
     }
    removePropertyOption = (param) =>{
         //console.log("removePropertyOption", this.state);
         this.state.removedpropertyOption = typeof this.state.removedpropertyOption != "undefined" ? this.state.removedpropertyOption : [] ;
        //  const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if(this.state.spvstatusBol && param.props.optiondata.dealOptionFlag !==2 ){
            const newState = this.state.propertyOptionList.map( (item ) =>{
                if(param.props.optiondata.propertyoptionID === item.propertyoptionID){
                    item.dealOptionFlag= 1 ;
                }
                return item;
            })
            this.setState({
                   propertyOptionList: newState                 
            },() =>{
               this.props.data.propertyOptionList = this.state.propertyOptionList
            });
        }else{
            const newState = this.state.propertyOptionList.filter( (item ) =>{
                return param.props.optiondata.propertyoptionID != item.propertyoptionID
            })
            this.setState({
                   propertyOptionList: newState                 
            },() =>{
               this.props.data.propertyOptionList = this.state.propertyOptionList
            });
        }
     }
     addBuilding(){
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if (typeof this.state.buildingCount !== 'undefined' && this.state.buildingCount == buildingLimit) { return }
        if (typeof this.state.buildingCount !== 'undefined') {
            this.state.buildingCount = this.state.buildingCount + 1
        } else {
            this.state.buildingCount = this.state.buildingList.length > 0 ? this.state.buildingList.length+1 : 1
        }

        if (this.state.buildingCount <= buildingLimit) {
            const building = {...deafaultBuilding};
            building.buildingFlag = (this.state.spvstatusBol) ? 2 : 0
            building.spvbuildingID = this.state.buildingCount;
            const modfiedState = this.state.buildingList.concat(building)
             this.setState({
                buildingList: modfiedState
             }, () =>{
                //this.props.parentData.propertyList[0].buildingList = this.state.buildingList
                this.props.data.buildingList = this.state.buildingList
             })
        };
     }

     removeBuilding= (param) => {
        // event.stopPropagation();
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        let dealLinked = false;
        if(!this.state.spvstatusBol || (param.state.buildingFlag && param.state.buildingFlag===2)){
            const newState = this.state.buildingList.filter( (item ) =>{
                return param.props.data.spvbuildingID != item.spvbuildingID
            })
            this.setState({
                buildingList: newState                 
            },() =>{
               this.props.data.buildingList = this.state.buildingList
            });
        }else {
            this.state.removedbuilding = typeof this.state.removedbuilding != "undefined" ? this.state.removedbuilding : []
            // this.state.buildingList.forEach(elem => {
            //     elem.areaEOList.forEach( item =>{
            //             if(item.dealStatus !== null && dealstatusArray.indexOf(item.dealStatus) >=0){
            //                 dealLinked = item.dealStatus;
            //             }
            //     })
            // })
            const removeObj = this.state.buildingList.filter( (item ) =>{
                if(param.props.data.spvbuildingID === item.spvbuildingID)
                {
                    item.buildingFlag = 1;
                    return item;
                }
            })
            this.forceUpdate();
            // this.state.removedbuilding.push(removeObj[0])
            // this.setState({"buildingremoval":true, "dealLinked":dealLinked})
        }
        
    }
    // confirmremoveBuilding = () =>{
    //     const newState = this.state.buildingList.filter( (item ) =>{
    //         return item.buildingFlag != 1
    //     })
    //     this.setState({
    //         "buildingremoval":false,
    //         "buildingList": newState                 
    //     },() =>{
    //        this.props.data.buildingList = this.state.buildingList
    //     });
    // }

    removeProperty(){
        let dealLinked = false;
        this.state.buildingList.forEach( item =>{
            item.areaEOList.forEach( itemchild =>{
                if(itemchild.dealStatus !== null && dealstatusArray.indexOf(itemchild.dealStatus) >=0){
                    dealLinked = itemchild.dealStatus;
                }
            })
        })
        this.setState({ "propertyremoval": true , "dealLinked":dealLinked});
    }

    onConfirmPropertyRemoval(){
        this.setState({propertyremoval: false}, ()=>{
            this.props.removeproperty(this.state);
        })
    }

    closemodal = () => {
        //console.log(this.state);
        const closeObj = {
            "buildingremoval":false,
            "propertyOptionModal":false,
            "propertyremoval": false,
        }
        this.setState(closeObj);
    }
    render() {
        const isEditMode = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
    //console.log("from:propertycontainerrender", this.state, this.props.parentData);
    // const dealLinkedMsg = dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? `The Building you are trying to remove has a linked deal to it in ${this.state.dealLinked} status, please remove the link before proceeding` : modalMessage["buildingMsg"];
    const dealLinkedPropMsg = dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? [`The Property you are trying to remove has a linked deal to it in ${this.state.dealLinked} status, please remove the link before proceeding`] : modalMessage["propertyMsg"];

    const child = this.state.propertyOptionList.map((item, index) => {
        if (item.dealOptionFlag != 1) {
            return <PropertyOptionComponent key={item.propertyoptionID} index={index + 1} fucntDisable={this.props.fucntDisable} spvstatusBol={this.state.spvstatusBol} optiondata={item} removeOption={this.removePropertyOption.bind(this)} />
        }
    });

    const building = this.state.buildingList.map((item, index) => {
        if (item.buildingFlag !== 1) {
            return <BuildingComponent key={item.spvbuildingID} index={index + 1} data={item} fucntDisable={this.props.fucntDisable} parentData={this.state} removebuilding={this.removeBuilding.bind(this)} />
        }
    }) 
    return (
        <div className="clearfix">
            {/* { this.state.buildingremoval ?
                <ModalPopup headerTitle="Remove Building" className={'assetpageModal'} open={true} confirmBtnText={dealstatusArray.indexOf(this.state.dealLinked) >=0 ? "" : "Yes, remove this building"} confirm={this.confirmremoveBuilding}  close = {this.closemodal} data= {this.state} modalbody={dealLinkedMsg}/>  : null} */}
        
        {this.state.propertyOptionModal ?
                <AlertModalPopup headerTitle="Property option" open={true} className={'assetpageModal'} confirmBtnText="OK" confirm={this.closemodal.bind(this)} modalbody={modalMessage["propertyOptionMsg"]}/> : null
        }

        {this.state.propertyremoval ?
                <MultilineModalPopup headerTitle="Remove property" className={'assetpageModal'} open={true} confirm={this.onConfirmPropertyRemoval.bind(this)} confirmBtnText={dealstatusArray.indexOf(this.state.dealLinked) >=0 ? "" : "Yes, remove this property"} close={this.closemodal} modalbody={dealLinkedPropMsg} /> : null
        }

        <Accordion className="accordion_header " withPadding={false}>
        <dt open={false} className="genetal_tab"> Property {this.props.index} <span className={"accordianRightlabel " + (this.props.fucntDisable && isEditMode ? 'disabledLabel' : '')} onClick ={this.removeProperty.bind(this)}><Icon name="trash-small" size="small" />Remove property</span></dt>
        <div className="propertyContainer">
        <Accordion className="propertyOption">
                <dt open={true} >Property details</dt>
                <div className="">
                    <div className="form-group row">
                        <label htmlFor="propertyName" className="col-sm-4 col-form-label field_label" >Property name</label>
                        <div className="col-sm-6">
                            <input type="text" disabled={this.props.fucntDisable} maxLength="50" onChange={this.handleOnChange.bind(this)} name="propertyName" value={this.state.propertyName}
                                className="form-control input_Fields" placeholder="Enter" />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label htmlFor="addressLineOne" className="col-sm-4 col-form-label field_label" >Address line 1</label>
                        <div className="col-sm-6">
                            <input disabled={this.props.fucntDisable} type="text" maxLength="50" onChange={this.handleOnChange.bind(this)}  name="addressLineOne" value={ this.state.addressLineOne}
                                className="form-control input_Fields" placeholder="Enter" />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label htmlFor="addressLineTwo" className="col-sm-4 col-form-label field_label" >Address line 2 (optional)</label>
                        <div className="col-sm-6">
                            <input disabled={this.props.fucntDisable} type="text" maxLength="50" onChange={this.handleOnChange.bind(this)}  name="addressLineTwo" value={ this.state.addressLineTwo}
                                className="form-control input_Fields" placeholder="Enter" />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label htmlFor="city" className="col-sm-4 col-form-label field_label" >City</label>
                        <div className="col-sm-6">
                            <input disabled={this.props.fucntDisable} type="text" maxLength="25" onChange={this.handleOnChange.bind(this)}  name="city" value={ this.state.city}
                                className="form-control input_Fields" placeholder="Enter" />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label htmlFor="postCode" className="col-sm-4 col-form-label field_label" >Postcode</label>
                        <div className="col-sm-6">
                            <input disabled={this.props.fucntDisable} type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="postCode" value={ this.state.postCode}
                                className="form-control input_Fields" placeholder="Enter" />
                        </div>
                    </div>
                    <Dropdown  isDisabled={this.props.fucntDisable} title="Country" selectedValue={this.state.country} onChange={this.handleDropDownChange.bind(this, 'country')} classname="font_config_custom" data={generatedataType['country']} errorStatus={false} />
                    <div className="form-group row">
                        <label htmlFor="registrationNumber" className="col-sm-4 col-form-label field_label" >Registration number</label>
                        <div className="col-sm-6">
                            <input disabled={this.props.fucntDisable} type="text" maxLength="25" name="registrationNumber" onChange={this.handleOnChange.bind(this)}  value={ this.state.registrationNumber}
                                className="form-control input_Fields" placeholder="Enter" />
                        </div>
                    </div>
                    <Dropdown isDisabled={this.props.fucntDisable} title="Status" selectedValue={this.state.propertyStatus} onChange={this.handleDropDownChange.bind(this, 'propertyStatus')} classname="font_config_custom" data={generatedataType['status']} errorStatus={false} />
                    {child}
                    <div className="form-group row"  style= {{'marginBottom':'0px'}}>
                        <label className={"col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor " + (this.props.fucntDisable ? 'disabledLabel' : '')} ><span onClick={ this.addPropertyOption.bind(this)}><Icon name="plus-xsmall" size="small" /> {this.state.propertyOptionList.length > 0 ? <span>Add another option</span> : <span>Add option</span>}</span></label>
                </div>
                </div>
            </Accordion>
            {building}
                <div className="form-group row" style= {{'marginBottom':'0px', 'paddingLeft':'10px', 'paddingBottom':'10px'}}>
                        <label className="col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor" > <span onClick= {this.addBuilding.bind(this)}><Icon name="plus-xsmall" size="small" />{this.state.buildingList.length > 0 ? <span>Add another building</span> : <span>Add building</span>}</span></label>
            </div>
        </div>
    </Accordion>
    </div>
    )
    }
}



export default PropertyContainer;