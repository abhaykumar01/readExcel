import { currencySymbols } from '../constants/currencySymbolConstants';


export const spvOptionLimit = 40 ;
export const propertyOptionLimit = 40 ;
export const propertyLimit = 15 ;
export const buildingLimit = 5 ;
export const areaLimit = 10;
export const subareaLimit = 10;
export const taxchargeLimit = 10;

export const defaultAsset= {
    "issuperuser":true,
    "corporateParent": null,
    "createdBy": null, 
    "jurisdiction": "Sweden",
    "propertyList": [
    
    ],
    "registrationForm": null,
    "registrationNumber": null,
    "spvApproval": 0,
    "spvID": null,
    "spvName": null,
    "spvNumber": null,
    "franchiseName": "LMS",
    "spvStatus": null,
    "spvFlag": 0,
    "spvOptionsList": [
        
    ]
    }

export const defaultArea = {
    "areaByUse": null,
    "spvareaID": null,
    "areaName": null,	
    "areaSize": null,
    "partyID": null,
    "createdBy": null,
    "extensionPeriod": 0,
    "franchiseName": "LMS",
    "vacantPossesionValue": null,
    "areaFlag" : 0,
    "areaTaxList": [
        
    ],
    "reLetValue": null,
    "subAreaList": [
        
    ]              
   
}

export const defaultTax = {
    "taxType": null,			// Service Charge / Property Tax
    "serviceChargeAmount": 0,
    "taxationValue": 0,
    "propTaxationValueInPercent": 0,  	
    "propTaxationValue": 0,				
    "propTaxPercent": 0,				
    "propTaxValue": 0,					
    "effectiveDate": null,				
    "supportingComments": null,
    "createdBy": null,					//======= User RacfID
    "franchiseName": "LMS" ,
    "areaTaxFlag": 0
}

export const defaultsubarea = {
    "subAreaPercent": 0,
    "subAreaType": null,
    "createdBy": null,					//======= User RacfID
    "franchiseName": "LMS",				//======= By Default set
    "subAreaFlag": 0,
}

export const propertyoption = {
    "createdBy": null,
    "earliestNoticeDate": null,
    "franchiseName": "LMS",
    "latestNoticeDate": null,
    "optionCategory": "",
    "optionDate": null,
    "propertyoptionID": null,
    "optionStrikePrice": 0,
    "optionType": "0",
    "paidPremium": 0,                 
    "upfrontOptionPremium": 0,
    "dealOptionFlag": 0
  }

export const deafaultBuilding = {
    "areaEOList": [                      
    ],
    "assetClassification": null,
    "spvbuildingID": null,
    "buildingName": null,
    "buildingType": null,
    "isConstructionWorkPlanned": 0,
    "constructionYear": null,
    "createdBy": null,
    "lettableArea": 0,
    "mvValue": 0,
    "franchiseName": "LMS",
    "reLetValue": 0,
    "valuationDate": null,
    "valuationDateUntil": null,
    "vacantPossessionValue": 0,
    "buildingFlag": 0,
}

export const defaultSpvOption = {
    "optionType": "0",
    "createdBy": null,
    "earliestNoticeDate": null,
    "franchiseName": "LMS",
    "latestNoticeDate": null,
    "optionDate": null,
    "spvoptionID": null,
    "optionStrikePrice": 0,
    "paidPremium": 0,
    "upfrontOptionPremium": 0,
    "dealOptionFlag": 0,
}

export const defaultProperty = {   
    "addressLineOne": null,
    "addressLineTwo": null,
    "buildingList": [                    
    ],
    "country": "Sweden",
    "franchiseName": "LMS",
    "postCode": null,
    "spvpropertyID": null,
    "propertyName": null,
    "propertyOptionList": [               
    ],
    "propertyStatus": null,
    "registrationNumber": null,
    "createdBy": null,
    "propertyFlag": 0,
}

    
export const generatedataType = {
    "jurisdiction": ["Finland", "Norway", "Denmark", "Sweden"],
    "registrationform": ["", "AB", "HB", "KB", "OY", "AS(Norway)", "As(Denmark)", "Ks(Denmark)"],
    "corporateparent": ["", "Nordisk Renting AB", "Nordisk Renting Oy", "Nordisk Renting AS (Norway)", "Nordisk Renting A/S (Denmark)", "Nordisk a Strategifastigheter Holding AB", "Svenskt Fastighetskapital Holding AB", "Svenskt Energikapital AB", "IR IndustriRenting AB",
    "Bil Fastigheter i Sverige AB", "Ursvik Entré Holding AB", "Airside Properties AB"],
    "country" : ["Sweden","Denmark", "Finland","Norway"],
    "status":["Active", "Inactive"],
    "buildingType":["","Office","Industrial","Retail","Logistics","Hotel","Transportation infrastructure","Utilities infrastructure","Social infrastructure","Telecommunications infrastructure","Other"]   ,
    "assetClassification":["","For Sweden", "For Finland", "For Norway", "For Denmark"],
    "areabyUse":["", "Office","Industrial","Retail", "Logistics","Hotel","Transportation infrastructure","Utilities infrastructure","Social infrastructure","Telecommunications infrastructure","Common","Other","Vacant "],
    "taxType":["Property tax", "Service charge"],
    "sweden":["Hyreshus (2%)", "Specialfastighet (3%)","Parkeringshus, Varuhus, Hotell- och restaurangbyggnader (3%)", "Industrienhet (4%)", "Värmekraftverk (4%)", "other"],
    "norway":["Forretningsbygg (2%)","Bygg og anlegg (4%)", "Anlegg for overføring og distribusjon av elektrisk kraft (5%)"],
    "denmark":["other"],
    "finland":["Kontorsbyggnad (4%)", "Industribyggnad (7%)", "other"]

}
export const getCurrencySymbol = () =>{
   return  currencySymbols[localStorage.getItem('jurisdiction')] ;
} 
export const modalMessage = {
    "editassetMsg": "You'll be able to view these asset details from the Asset page within the 'In progress tab'",
    "propertyMsg": ["If you remove this property, it will remove all the associated options, buildings and areas linked with it.", "Are you sure you want to remove this property ?"],
    "buildingMsg" : ["If you remove this building, it will remove all the areas linked with to it.", "Are you sure you want to remove this building ?"],
    "areaMsg" : "Are you sure you want to remove this area ?",
    "areadealLinkedMSG" : "The area you are trying to remove has a linked deal to it in Approved/Signed/Active status, please remove the link before proceeding",
    "approveAssetMsg": "Are you sure  you want to approve this asset ?",
    "archiveMsg": "Are you sure you want to archive the asset ?",
    "requestApprovalMsg": ["Are you sure you want to request approval for this asset ?","You won't be able to make changes until it's either been approved or rejected."],
    "spvOptionMsg":["Option(s) already added under property level."],
    "propertyOptionMsg":["Option(s) already added under the SPV."],
    "cancelAssetMsg": "Are you sure you want to cancel? All the information you've entered will be lost." 
}
export const dealstatusArray = ["Approved", "Signed", "Active"]
export const spvstatusArray = ["Active", "In Progress"]
export const LocaleCode = {
  "Denmark": "da-Dk",
  "Finland": "fi-FI",
  "Norway": "no-NO",
  "Sweden": "sv-SE"
}
export const notificationTitleMsg ={
    'defaultMsg' : 'Error while uploading document',
    'docUploadSuccess': 'Your document has been uploaded',
    'docDeleteSuccess': 'Your request for deletion has been sent',
    'docDeleteCancel': 'Your request for deletion has been cancelled',
    'saveSuccess' : 'Your customer has been saved',
    'changeSuccess' : 'Your customer changes have been saved',
    'docDeletedSuccess' : 'Your request for deletion has been approved',
    'docDeletedFailed' : 'Your request for deletion has been rejected',
    'approverDocDeleted' : 'Deletion request has been approved',
    'docPendingApproval' : ' Document deletion request pending your approval',
    'docDeleteRejected': 'Deletion request has been rejected',
    'docUploadApproved': 'Document upload request has been approved.',
    'docUploadRejected': 'Your request for document upload has been rejected'
}