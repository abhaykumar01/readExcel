import React, { Fragment } from 'react';
// import { Tabs, Tab } from 'react-bootstrap-tabs';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import { Icon } from '@zambezi/sdk/icons';
import AssetOptionDetailsTab from './assetOptionDetails';
import AssetBuildingDetailsTab from './assetBuildingDetails';
import { notificationTitleMsg } from './assetConstants';
import ApproverAssetDocumentGrid from '../../commonComponents/approverAssetDocumentGrid';
import AssetDocumentGrid from '../../commonComponents/assetDocumentsGrid';
import { Select } from '@zambezi/sdk/dropdown-list';
import DocumentUpload from '../../commonComponents/documentsUpload';
import { HttpPostDocuments } from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { validate } from '../../utils/validation.js';
import { Notification } from '@zambezi/sdk/notification';
import { withRouter } from 'react-router-dom';
import { AuthorizationContext } from '../authContext/index.js'
import { uploadDocuments, deleteDocument,  checkDocumentNamingFormat} from '../../models/dataModel.js';

const PING = process.env.REACT_APP_PING;
class AssetDetailsTableMode extends React.Component{
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        const state = this.getInitialState();
        this.state = { ...props.data, ...state, "selectedTab": 0 };
        this.inputOpenFileRef = React.createRef();
    }
    getInitialState = () => {
        const initialState = {
            userData: {},
            documentUploadStatus: true,
            uploadedFileName: '',
            documentDescription: '',
            selectedFile: '',
            textErrorStatus: false,
            textErrorMessage: '',
            dialogDismiss: '',
            docType: '',
            docLengthStatus: false,
            errorMessage: '',
            checkboxStatus: false,
            // docUploadSuccess: false,
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            showData: false,
            recordView: 10,
            showCustomerDocuments: true,
            pageStatus: null,
            deleteStatus: '',
            deletedDocName: '',
            docUserName: '',
            retrieveDoc: false,
            showDocData: true,
            confirmMessage: '',
            failureMessage: '',
            rejectionReason: '',
            racfID: '',
            permissionData: {},
            roleName: '',
            highRiskStatus: false
        };
        return initialState;
    }
    resetState = () => {
        const initialState = {
            documentUploadStatus: true,
            uploadedFileName: '',
            documentDescription: '',
            selectedFile: '',
            textErrorStatus: false,
            dialogDismiss: '',
            docType: '',
            docLengthStatus: false,
            errorMessage: '',
            checkboxStatus: false,
            partyID: 0,
            showData: false,
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            recordView: '10',
            showCustomerDocuments: true,
            pendingCount: 0,
            deleteStatus: '',
            deletedDocName: '',
            docUserName: '',
            retrieveDoc: false,
            pageStatus: null,
            showDocData: true,
            confirmMessage: '',
            failureMessage: '',
            rejectionReason: '',
            racfID: '',
            highRiskStatus: false
        };
        return initialState;
    }
    componentWillReceiveProps(props) {
        this.setState(props.data);
    }
    
    componentDidMount() {
        console.log("Asset data");
        console.log(this.props.assetData);
        window.scrollTo(0, 0);
        var userID = '';
        var data;
        var roleName = '';
        if (PING == 'true') {
            let { usersDetails } = this.context;
            userID = usersDetails.userID;
            data = usersDetails.permissions;
            roleName = usersDetails.memberOf;
        } else {
            userID = localStorage.getItem('racfID');
            let response = localStorage.getItem('permissions');
            data = JSON.parse(response);
            roleName = localStorage.getItem('roleName');
        }

        this.setState({
            racfID: userID,
            permissionData: data,
            roleName: roleName
        });
        
            localStorage.setItem("docUpload", "userDocUpload1");
            let message = localStorage.getItem("Message");
            console.log("Message")
            console.log(message)
            if (message) {
                var obj = JSON.parse(message);
                console.log("Reason for rejection");
                console.log(obj.reasonForRejection);
                if (obj.status == "Approved") {
                    this.setState({
                        pageStatus: "docDeletedSuccess",
                        confirmMessage: obj.description
                    });
                } else if (obj.status == "Rejected") {
                    this.setState({
                        pageStatus: "docDeletedFailed",
                        failureMessage: obj.description,
                        rejectionReason: obj.reasonForRejection
                    });
                }
            }
        // }
        var saveStatus = localStorage.getItem('datasave');
        var changeStatus = localStorage.getItem('datachange');
        if (saveStatus == 'true') {
            this.setState({ pageStatus: 'saveSuccess' });
        }
        if (changeStatus == 'true') {
            this.setState({ pageStatus: 'changeSuccess' });
        } else {
        }
        // this.fetchCustomerDocuments();
    }

    resetData() {
        console.log("get initial state");
        this.setState(this.resetState(), function () {
        });
        return true;
    }

    DocumentDeleteRequestSent () { 
        console.log("Document deleted")
        this.setState({ pageStatus: 'docDeleteSuccess' });
    }
    DocumentDeleteCancelRequestSent() {
        console.log("Document deleted")
        this.setState({ pageStatus: 'docDeleteCancel' }); 
    }

    deletionStatus(count, docName, cname) {
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pendingCount: count,
            deleteStatus: 'approverDocDeleted',
            pageStatus: 'docPendingApproval',
            deletedDocName: docName,
            docUserName: cname,
        }, function () {
            this.forceUpdate();
        })
        return true;
    }

    rejectStatus(docName) {
        // /docDeleteRejected
        // console.log("Pending count:: " + count);
        console.log("docName:: " + docName);
        this.setState({
            pageStatus: 'docDeleteRejected',
            deletedDocName: docName,
        })
        return true;
    }

    pendingCount(count) {
        console.log("Pending count:: " + count);
        this.setState({
            pendingCount: count,
            pageStatus: 'docPendingApproval',
        }, function () {
        })
        return true;
    }

    HandleSelectChange(event, type, value) {
        localStorage.setItem('recordview', type.value);
        this.setState({ recordView: type.value });
    }
    // onClickHandler = (e) => {
       
    //     this.inputOpenFileRef.current.click();
    //     const formData = new FormData();
    //     formData.append('file', this.state.selectedFile);
    //     return true;
    // }

    onClickHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        console.log("on click");
        this.inputOpenFileRef.current.click();
        console.log("Select file");
        console.log(this.state.selectedFile);
        const formData = new FormData();
        formData.append('file', this.state.selectedFile);
        console.log("uploaded files");
        console.log(formData);
        return true;
    }
    onChangeHandler = event => {
        console.log("Selected file");
        console.log(event.target.files);
        if (event.target.files[0]) {
            var status = checkDocumentNamingFormat(event.target.files[0].name);
            if (!status) {
                var fileSize = (event.target.files[0].size / (1024 * 1024 * 1024));
                console.log("RIght file selected");

                if (event.target.files.length > 1) {
                    this.setState({
                        docLengthStatus: true,
                        errorMessage: 'Max 1 file can be uploaded in one go. Please select a file and try again.'
                    });
                } else {
                    console.log("RIght file selected1");
                    if (event.target.files[0] && fileSize <= 2) {
                        if (event.target.files[0].type == 'application/pdf' || event.target.files[0].type == 'image/png' ||
                            event.target.files[0].type == 'image/jpeg' ||
                            event.target.files[0].type == 'application/msword' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
                            event.target.files[0].type == 'application/vnd.ms-excel' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
                            console.log("RIght file selected2");
                            this.setState({
                                uploadedFileName: event.target.files[0].name,
                                docType: event.target.files[0].type,
                                selectedFile: event.target.files[0],
                                fileUploadStatus: true,
                                // documentUploadStatus: false,
                                docLengthStatus: false
                            });
                        } else {
                            this.setState({
                                docLengthStatus: true,
                                errorMessage: 'Invalid document type.'
                            });
                        }

                    } else {
                        this.setState({
                            docLengthStatus: true,
                            errorMessage: 'File size should be less then 2GB. Please select a file and try again.'
                        });
                    }
                }
            } else {
                this.setState({
                    docLengthStatus: true,
                    errorMessage: 'Please make sure that the document name is compliant with the naming convention'
                });
            }
        }
        return true;
    }

    onChangeDocumentDescription = (e) => {
        console.log("Value change");
        console.log(e.target.value);//textErrorMessage
        var val = e.target.value;
        var dataVal = val.trimLeft();
        let v = validate('documentDescription', dataVal);
        if (v[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v[0], textErrorMessage: v[1] });
        }
        this.setState({
            documentDescription: dataVal,
        }, function () {
            this.fieldValidation();
        })
        return true;
    }

    fieldValidation() {
        console.log("Field validation");
        console.log(this.state.rbsClassificationVal);
        console.log(this.state.rbsRecordVal);
        console.log(this.state.rbsRiskVal);
        console.log(this.state.documentDescription);
        console.log(this.state.checkboxStatus);
        // CPBNRP-1328 fixed
        var docDescription = this.state.documentDescription.split(" ").join("");
        var descriptionValid;
        if (docDescription === "" || docDescription === null) {
            console.log("At least 8 characters are required!");
            console.log(docDescription);
            descriptionValid = false
        }
        else {
            descriptionValid = true;
        }


        if (this.state.rbsClassificationVal && this.state.rbsRecordVal
            && this.state.rbsRiskVal && descriptionValid && this.state.checkboxStatus) {
            // CPBNRP-1328 changes in if condition
            this.setState({
                dialogDismiss: 'modal',
                documentUploadStatus: false
            });
        } else {
            this.setState({
                dialogDismiss: '',
                documentUploadStatus: true
            });
        }
        this.validateField();
        return true;
    }

    deleteDocument() {
        this.setState({
            uploadedFileName: '',
            selectedFile: '',
            fileUploadStatus: false,
            documentUploadStatus: true,
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            documentDescription: ''
        });
        return true;
    }

    validateField() {
        let v = validate('dropdown', this.state.rbsClassificationVal);
        if (v[0] == null) {
            this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
        }
        let v1 = validate('dropdown', this.state.rbsRecordVal);
        if (v1[0] == null) {
            this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ rbsRecordValErrorStatus: !v1[0], rbsRecordValErrorMessage: v1[1] });
        }

        let v2 = validate('dropdown', this.state.rbsRiskVal);
        if (v2[0] == null) {
            this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ rbsRiskValErrorStatus: !v2[0], rbsRiskValErrorMessage: v2[1] });
        }

        let v3 = validate('documentDescription', this.state.documentDescription);
        if (v3[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v3[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v3[0], textErrorMessage: v3[1] });
        }

        return true;
    }

    uploadDocuments() {
        this.validateField();
        var obj = localStorage.getItem('errorStatus');
        console.log("Error status::: " + obj);
        if (this.state.rbsClassificationVal && this.state.rbsRecordVal && this.state.rbsRiskVal && this.state.documentDescription) {
            var currentComponent = this;
            this.setState({
                dialogDismiss: 'modal',
            });
            var userID = '';
            var roleName = '';
            var userName = '';
            if (PING == 'true') {
                let { usersDetails, name } = this.context;
                userID = usersDetails.userID;
                roleName = usersDetails.memberOf;
                userName = name;
            } else {
                userID = localStorage.getItem('racfID');
                roleName = localStorage.getItem('roleName');
                userName = 'Joe Doe';
            }
            // console.log(localStorage.getItem('userID'));
            // console.log(this.state.docType);
            // let id = parseInt(localStorage.getItem('userID'));
            let doctype = ''
            let id = parseInt(localStorage.getItem('userID'));
            if (this.state.docType == "") {
                doctype = "msg";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
                this.state.docType == "application/vnd.ms-excel") {
                doctype = "excel";
            } else if (this.state.docType == "application/pdf") {
                doctype = "pdf";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                doctype = "doc";
            } else if (this.state.docType == "application/msword") {
                doctype = "doc";
            } else if (this.state.docType == "image/png") {
                doctype = "png";
            } else if (this.state.docType == "image/jpeg") {
                doctype = "jpg";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
                doctype = "ppt";
            }
            doctype = doctype.toUpperCase();
            let isApprovalrequired = 0;
            let isHighRisk = 0;
            let isApproved = "Approved";
            let riskVal = '';
            if (this.state.rbsRiskVal == "High Risk") {
                riskVal = 'High risk';
                isHighRisk = 1;
                if (roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1) {
                    isApprovalrequired = 0;
                    isApproved = "Approved";
                } else {
                    isApprovalrequired = 1;
                    isApproved = "PendingApproval";
                }
            } else if (this.state.rbsRiskVal == "Secondary Risk") {
                riskVal = 'Secondary risk';
            } else if (this.state.rbsRiskVal == "Historical") {
                riskVal = 'Historical';
            }
            console.log("racfID:: ", localStorage.getItem('racfID'));
            console.log("spvID:: " + this.props.location.state.spvID);
            let payLoadData = uploadDocuments(this.state.uploadedFileName, doctype, this.state.documentDescription, null,
                this.state.rbsClassificationVal, this.state.rbsRecordVal, riskVal, null, null, userID,
                this.props.location.state.spvID, isApproved, isApprovalrequired, isHighRisk, userName);
            let endPoint = API_ENDPOINT.UPLOAD_DOCUMENTS + '/uploadDoc/asset';
            console.log("payLoadData:: ");
            console.log(payLoadData);
            console.log(endPoint);
            const formData = new FormData();
            formData.append('file', this.state.selectedFile);
            formData.append('documentDetails', JSON.stringify(payLoadData));
            this.setState({ showData: true });
            let output = HttpPostDocuments(currentComponent, formData, endPoint)
                .then(function (response) {
                    console.log("response received from server for asset documents");
                    console.log(response);
                    console.log(response.status);
                    if (response.status == 200 || response.status == 201) {
                        console.log("success response");
                            let docUpload = localStorage.getItem("docUpload");
                            console.log("docUpload");
                            console.log(docUpload);
                            if (docUpload == "userDocUpload") {
                                localStorage.setItem("docUpload", "userDocUpload1");
                            } else if (docUpload == "userDocUpload1") {
                                localStorage.setItem("docUpload", "userDocUpload");
                            }
                        currentComponent.setState({
                            dialogDismiss: 'modal',
                            docUploadSuccess: true,
                            pageStatus: 'docUploadSuccess',
                            showDocData: false,
                            // key: 3,
                        }, function () {
                            // currentComponent.handleSelectTab();
                            currentComponent.forceUpdate();
                        });
                    } else {
                        console.log("Error received");
                        currentComponent.setState({
                            // docUploadSuccess: false,
                            pageStatus: '',
                        });
                    }
                })
                .catch(function (error) {
                    console.log("Error received");
                    console.log(error);
                    currentComponent.setState({
                        // docUploadSuccess: false
                        pageStatus: '',
                    });
                })
        }

        return true;
    }
    onChangeCheckBox = (e, isChecked) => {
        this.setState({ checkboxStatus: isChecked }, function () {
            this.fieldValidation();
        });
        return true;
    }
    getDropdownItem(event, ID, type) {
        console.log("Dropdowntype");
        if (event == "Classification") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });

            } else if (v[0] != null) {
                this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
            }
            this.setState({ rbsClassificationVal: type.value }, function () {
                this.fieldValidation();
            });
        } else if (event == "Record") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRecordValErrorStatus: !v[0], rbsRecordValErrorMessage: v[1] });
            }
            this.setState({ rbsRecordVal: type.value }, function () {
                this.fieldValidation();
            });
        } else if (event == "Risk") {
            var isSeniorApprover = this.state.roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1
            console.log(!isSeniorApprover);
            if ((type.value).toLowerCase() == "high risk" && (!isSeniorApprover)) { 
                console.log("Inside hIgh risk");
                this.setState({ highRiskStatus: true });
            } else {
                this.setState({ highRiskStatus: false });
            }
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRiskValErrorStatus: !v[0], rbsRiskValErrorMessage: v[1] });
            }
            this.setState({ rbsRiskVal: type.value }, function () {
                this.fieldValidation();
            });
        }
    }

    documentDeleted() {
        let docUpload = localStorage.getItem("docUpload");
        console.log("docUpload");
        console.log(docUpload);
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({ pageStatus: 'docDeletedSuccess1' });
    }

    uploadApprovalStatus(docName, cname) {
        console.log("uploadApprovalStatus");
        console.log(docName);
        console.log(cname);
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pageStatus: 'docUploadApproved',
            deletedDocName: docName,
            docUserName: cname,
        }, function () {
            this.forceUpdate();
        })
        return true;
    }

    uploadRejectStatus(docName, reason, approverName) {
        // /docDeleteRejected
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pageStatus: 'docUploadRejected',
            deletedDocName: docName,
            rejectionReason: reason,
            approverName: approverName
        }, function () {
            this.forceUpdate();
        })
        return true;
    }

    changeTab(datum, index) {
        console.log("Tab changed::");
        var record = localStorage.getItem('recordview');
        if (record) {
            this.setState({ recordView: record });
        } else {
            this.setState({ recordView: 10 });
        }

    }

    setTabKey(index){
        this.setState({'selectedTab':index, 'pageStatus': null})
    }
    getTitleMsg = () => {
        if (this.state.pageStatus === '') {
            return notificationTitleMsg['defaultMsg'];
        } else if (this.state.pageStatus == 'docPendingApproval' && this.state.pendingCount > 0) {
            return `${this.state.pendingCount} + ${notificationTitleMsg['docPendingApproval']}`
        } else {
            return notificationTitleMsg[this.state.pageStatus];
        }

    }
    setdocumentMsg = () => {
        let pagestatus = this.state.pageStatus;
        let _toreturn;
        if (pagestatus === 'docDeletedSuccess') {
            _toreturn = this.state.confirmMessage
        } else if (pagestatus === 'docDeletedFailed') {
            _toreturn = <span style={{ wordBreak: 'break-all'}}> {this.state.failureMessage} {this.state.rejectionReason ? `Reason for rejection:${this.state.rejectionReason}` : null}</span>;
        } else if (pagestatus === 'approverDocDeleted') {
            _toreturn = `The document ${this.state.deletedDocName} has been deleted. Notification email has been sent to ${this.state.docUserName}`
        } else if (this.state.pageStatus === 'docPendingApproval') {
            _toreturn = 'Please review the documents highlighted in yellow and approve/reject deletion request accordingly.'
        } else if (this.state.pageStatus === 'docDeleteRejected') {
            _toreturn = `The document ${this.state.deletedDocName} has not been deleted.`
        } else if (this.state.pageStatus === 'docUploadApproved') {
            _toreturn = ` The upload of document ${this.state.deletedDocName} has been approved. A notification email has been sent to ${this.state.docUserName}.`
        } else if (this.state.pageStatus === 'docUploadRejected') {
            _toreturn = <span style={{ wordBreak: 'break-all' }}>{`The request to upload document ${this.state.deletedDocName} has been rejected by ${this.state.approverName}.
                        Reason for rejection: ${this.state.rejectionReason}`}</span>
        }

        return _toreturn;
    }
    render() {
        let docUpload = localStorage.getItem("docUpload");
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else {
            datalen = 0;
        }
        var uploadDocumentEnable = false;
        for (var i = 0; i < datalen; i++) {
            if (perData[i] == "Asset_Doc_Request_Upload_High_Risk") {
                uploadDocumentEnable = true;
            }
        }

        console.log("Asset data::")
        console.log(this.props.assetData);
        return(
            <Fragment>

                {typeof this.state.pageStatus !== 'undefined' && this.state.pageStatus !== null ?
                    <div className="form-group row">
                        <Notification className="assetPage_Notification" status='success' size='large' title={this.getTitleMsg()} >{this.setdocumentMsg()}</Notification>
                    </div>
                    : null
                }
                
            <div>

                    <Tabs selectedIndex={this.state.key}
                        className="assetDocGridTab" selectedTabClassName="selectedtlpGridTab"
                        style={{ marginBottom: '85px' }}
                        onSelect={this.changeTab.bind(this)}>
                        <TabList style={{ border: 'none', margin: '0', marginLeft: '-6px' }}>
                            <Tab className="headertlpGridTab">Assets</Tab>
                            <Tab className="headertlpGridTab">Options</Tab>
                            <Tab className="headertlpGridTab">Documents</Tab>
                        </TabList>

                        <TabPanel className="selectedtlpgridTabPanel" >
                            <div style={{ marginBottom: '20px' }}>
                                <AssetBuildingDetailsTab data={this.state}></AssetBuildingDetailsTab>
                            </div>
                    </TabPanel >
                        <TabPanel>
                            <div style={{ marginBottom: '20px' }}>
                                <AssetOptionDetailsTab data={this.state}></AssetOptionDetailsTab>
                            </div>
                    </TabPanel>

                        <TabPanel style={{ backgroundColor: '#ffffff', marginBottom: '85px' }}>

                            {!uploadDocumentEnable ? <div>
                                <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                                    <div data-toggle="modal" style={{ width: '175px' }}>
                                        <Icon name="plus-xsmall" size='small' title="" /><label className="uploadDocument" >Upload documents</label>
                                    </div>
                                </div>
                            </div> : null}
                            {uploadDocumentEnable ? <div onClick={this.resetData.bind(this)}>
                                <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                                    <div data-toggle="modal" data-target="#upload" style={{ width: '175px' }}>
                                        <Icon name="plus-xsmall" size='small' title="" /><label className="uploadDocument" >Upload documents</label>
                                    </div>
                                </div>
                            </div> : null}
                            {docUpload == "approverDocUpload" ? <div><ApproverAssetDocumentGrid
                                DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                                DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                                selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                                userData={this.props.assetData} deletionStatus={this.deletionStatus.bind(this)}
                                rejectStatus={this.rejectStatus.bind(this)} />
                                <span class="select-wrap -pageSizeOptions select_record">
                                    <span className="select_page">Per page</span>
                                    <Select
                                        defaultValue={this.state.recordView}
                                        suggestions={['5', '10', '15', '20']}
                                        className='select_row'
                                        isError={false}
                                        onChange={this.HandleSelectChange.bind(this)}
                                    />
                                </span> </div> : null}
                            {docUpload == "approverDocUpload1" ? <div><ApproverAssetDocumentGrid
                                DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                                DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                                selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                                userData={this.props.assetData} deletionStatus={this.deletionStatus.bind(this)}
                                rejectStatus={this.rejectStatus.bind(this)} />
                                <span class="select-wrap -pageSizeOptions select_record">
                                    <span className="select_page">Per page</span>
                                    <Select
                                        defaultValue={this.state.recordView}
                                        suggestions={['5', '10', '15', '20']}
                                        className='select_row'
                                        isError={false}
                                        onChange={this.HandleSelectChange.bind(this)}
                                    />
                                </span> </div> : null}
                            {docUpload == "userDocUpload" ? <div><AssetDocumentGrid
                                DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                                DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                                userData={this.props.assetData}
                                deletionStatus={this.deletionStatus.bind(this)}
                                selectedRecord={parseInt(this.state.recordView)}
                                rejectStatus={this.rejectStatus.bind(this)}
                                documentDeleted={this.documentDeleted.bind(this)}
                                uploadApprovalStatus={this.uploadApprovalStatus.bind(this)}
                                uploadRejectStatus={this.uploadRejectStatus.bind(this)}/>
                                <span class="select_record_doc">
                                    <label className="select_page_doc">Per page</label>
                                    <Select
                                        defaultValue={this.state.recordView}
                                        suggestions={['5', '10', '15', '20']}
                                        className='select_page_size'
                                        isError={false}
                                        onChange={this.HandleSelectChange.bind(this)}
                                    />
                                </span> </div> : null}
                            {docUpload == "userDocUpload1" ? <div><AssetDocumentGrid
                                DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                                DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                                selectedRecord={parseInt(this.state.recordView)}
                                userData={this.props.assetData}
                                rejectStatus={this.rejectStatus.bind(this)}
                                deletionStatus={this.deletionStatus.bind(this)}
                                documentDeleted={this.documentDeleted.bind(this)} 
                                uploadApprovalStatus={this.uploadApprovalStatus.bind(this)}
                                uploadRejectStatus={this.uploadRejectStatus.bind(this)}/>
                                <span class="select_record_doc">
                                    <label className="select_page_doc">Per page</label>
                                    <Select
                                        defaultValue={this.state.recordView}
                                        suggestions={['5', '10', '15', '20']}
                                        className='select_page_size'
                                        isError={false}
                                        onChange={this.HandleSelectChange.bind(this)}
                                    />
                                </span> </div> : null}
                        </TabPanel>
                    </Tabs>
               
                {/* <Tabs
                    style={{ margin: '20px 0 0 0', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }}
                    headerStyle={{ backgroundColor: '#f5f5f5', color: '#ad1982', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'pointer' }}
                        activeHeaderStyle={{ backgroundColor: '#ffffff', color: '#42145f', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'default' }}
                        selected={this.state.selectedTab}
                        // onSelect={(index) => this.setTabKey(index)}
                        onSelect={this.changeTab.bind(this)}>
                    <Tab  label="Assets">
                        <div style={{marginBottom : '20px'}}>
                            <AssetBuildingDetailsTab data={this.state}></AssetBuildingDetailsTab>
                        </div>
                    </Tab>
                    <Tab  label="Options">
                        <div style={{marginBottom : '20px'}}>
                            <AssetOptionDetailsTab data={this.state}></AssetOptionDetailsTab>
                        </div>
                    </Tab>
                    <Tab  label="Documents">
                     <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                                    <div data-toggle="modal" data-target="#upload" style={{ width: '175px' }}>
                                        <Icon name="plus-xsmall" size='small' /><label className="uploadDocument" onClick={this.resetState.bind(this)}>Upload documents</label>
                                    </div>
                       </div>
                       {docUpload == "approverDocUpload" ? <div><ApproverAssetDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                            userData={this.state.userData} deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)} pageStatus = {this.state.pageStatus} />
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per page</span>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_row'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "approverDocUpload1" ? <div><ApproverAssetDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                            userData={this.state.userData} deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)} pageStatus = {this.state.pageStatus} />
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per page</span>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_row'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "userDocUpload" ? <div><AssetDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)}
                            documentDeleted={this.documentDeleted.bind(this)} pageStatus = {this.state.pageStatus}/>
                            <span class="select_record_doc">
                                <label className="select_page_doc">Per page</label>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_page_size'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "userDocUpload1" ? <div><AssetDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)}
                            documentDeleted={this.documentDeleted.bind(this)} pageStatus = {this.state.pageStatus} />
                            <span class="select_record_doc">
                                <label className="select_page_doc">Per page</label>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_page_size'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                    </Tab>
                </Tabs> */}
                <DocumentUpload onClick={this.onClickHandler.bind(this)}
                    onChangeDoc={this.onChangeHandler.bind(this)} reference={this.inputOpenFileRef}
                    id="upload" uploadStatus={this.state.documentUploadStatus} fileName={this.state.uploadedFileName}
                    onChange={this.onChangeDocumentDescription.bind(this)}
                    deleteDoc={this.deleteDocument.bind(this)} onUpload={this.uploadDocuments.bind(this)}
                    errorStatus={this.state.textErrorStatus} textErrorMessage={this.state.textErrorMessage} dialogDismiss={this.state.dialogDismiss}
                    docType={this.state.docType} docLengthStatus={this.state.docLengthStatus}
                    errorMessage={this.state.errorMessage} onCheckboxChange={this.onChangeCheckBox.bind(this)}
                    rbsClassificationVal={this.state.rbsClassificationVal} rbsRecordVal={this.state.rbsRecordVal}
                    rbsRiskVal={this.state.rbsRiskVal} getDropdownItem={this.getDropdownItem.bind(this)}
                    rbsClassificationValErrorStatus={this.state.rbsClassificationValErrorStatus}
                    rbsClassificationValErrorMessage={this.state.rbsClassificationValErrorMessage}
                    rbsRecordValErrorStatus={this.state.rbsRecordValErrorStatus} rbsRecordValErrorMessage={this.state.rbsRecordValErrorMessage}
                    rbsRiskValErrorStatus={this.state.rbsRiskValErrorStatus} rbsRiskValErrorMessage={this.state.rbsRiskValErrorMessage}
                        actionType="asset"
                        highRiskStatus={this.state.highRiskStatus}
                />
            </div>
            </Fragment>
        )
    }
}

export default withRouter(AssetDetailsTableMode);
