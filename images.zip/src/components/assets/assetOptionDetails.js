import React from 'react';
import { connect } from "react-redux";
import { API_ENDPOINT } from '../../config/config';
import { HttpGet } from '../../services/api';
import VerticalGridComponent from './verticalGridComponent';
import { formatDate, formatCurrencyValue } from './commonUtilityFunctions';
import { withRouter } from 'react-router-dom';


class assetOptionDetails extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            displayMode : 'spv',
            rowHeaders : this.getOptionRowHeaders(),
            spvOptionsData :[],
            spvOptionsRawData : [],
            spvOptionHeaders :[],
            propertyOptionsData : [],
            propertyOptionsRawData : [],
            allPropertiesOptionsData : [],
            allPropertiesOptionsRawData : [],
            propertyOptionHeaders : [],
            propertyDropdownData : [],
            selectedProperty : null,
        }
    }

    componentWillMount(){
        var getSpvOptionsUrl = API_ENDPOINT.ASSET_SPV_OPTIONS+'/'+ this.props.data.spvID;
        var getPropertyOptionsUrl = API_ENDPOINT.ASSET_PROPERTY_OPTIONS+'/'+ this.props.data.spvID;
        var locale = this.props.locale;
        var currentComponent = this;

        HttpGet(currentComponent, getSpvOptionsUrl).then( (response)=> {
            if(response.data.length > 0){
                let spvOptionsData = this.formatOptionsData(response.data, locale);
                this.setState({
                    spvOptionsRawData : response.data,
                    spvOptionsData : spvOptionsData,
                    spvOptionHeaders : this.generateOptionColumnHeaders(spvOptionsData)
                })
            }
        });

        HttpGet(currentComponent, getPropertyOptionsUrl).then( (response)=> {
            if(response.data.length > 0){
                let allPropertiesOptionsData = this.getPropertyOptionsList(response.data, locale);
                this.setState({
                    allPropertiesOptionsRawData : response.data,
                    allPropertiesOptionsData : allPropertiesOptionsData,
                    propertyOptionsData : allPropertiesOptionsData[0].optionsList,
                    propertyOptionsRawData : response.data[0].propertyOptionList,
                    propertyOptionHeaders : this.generateOptionColumnHeaders(allPropertiesOptionsData[0].optionsList)
                })
            }
        });
    }

    componentWillReceiveProps(props){
        var locale = props.locale;
        this.updateDataFormat(locale);
    }

    getOptionRowHeaders(){
        return [
            {key : 'optionType', value :'Option type'},
            {key : 'optionStrikePrice', value :'Option strike price'},
            {key : 'upfrontOptionPremium', value :'Upfront option premium'},
            {key : 'paidPremium', value :'Premium paid at option exercise date'},
            {key : 'optionDate', value :'Option date'},
            {key : 'earliestNoticeDate', value :'Earliest notice date'},
            {key : 'latestNoticeDate', value :'Latest notice date'},
        ]
    }

    formatOptionsData(data, locale){
        let optionsData = [];

        for(let i=0; i<data.length ; i++){
            let tempObj = {...data[i]};

            if(tempObj.optionType == 1){
                tempObj.optionType = 'Put';
            } else if(tempObj.optionType == 0){
                tempObj.optionType = 'Call';
            }
            
            tempObj.optionDate = formatDate(tempObj.optionDate, locale);
            tempObj.earliestNoticeDate = formatDate(tempObj.earliestNoticeDate, locale);
            tempObj.latestNoticeDate = formatDate(tempObj.latestNoticeDate, locale);
            tempObj.createdOn = formatDate(tempObj.createdOn, locale);
            tempObj.updatedOn = formatDate(tempObj.updatedOn, locale);

            tempObj.upfrontOptionPremium = formatCurrencyValue(tempObj.upfrontOptionPremium, locale);
            tempObj.optionStrikePrice = formatCurrencyValue(tempObj.optionStrikePrice, locale);
            tempObj.paidPremium = formatCurrencyValue(tempObj.paidPremium, locale);

            optionsData.push(tempObj);
        }
        return optionsData;
    }

    generateOptionColumnHeaders(optionsData){
        let optionColumnHeaders = [];
        for(let i=0; i<optionsData.length ; i++){
            optionColumnHeaders.push('Option '+ (i+1));
        }
        return optionColumnHeaders;
    }

    getPropertyOptionsList(allPropertyData, locale){
        let tempAllPropertiesOptionsData = [];
        let tempPropertiesDropDownData = [];

        for(let i=0; i<allPropertyData.length; i++){
            let tempPropertyOptionObj = {};
            tempPropertyOptionObj.propertyId = allPropertyData[i].propertyID;
            tempPropertyOptionObj.propertyName = allPropertyData[i].propertyName;
            tempPropertyOptionObj.optionsList = this.formatOptionsData(allPropertyData[i].propertyOptionList, locale);

            tempAllPropertiesOptionsData.push(tempPropertyOptionObj);

            let tempPropertyDropdownObj = {};
            tempPropertyDropdownObj.id=allPropertyData[i].propertyID.toString();
            tempPropertyDropdownObj.value='Property ' + (i+1);
            tempPropertyDropdownObj.name=allPropertyData[i].propertyName;
            tempPropertiesDropDownData.push(tempPropertyDropdownObj);
        }

        this.setState({propertyDropdownData : tempPropertiesDropDownData})
        return tempAllPropertiesOptionsData;
    }

    onPropertyChange(propertyID){
        for(let i=0; i<this.state.allPropertiesOptionsData.length; i++){
            if(this.state.allPropertiesOptionsData[i].propertyId.toString() == propertyID.toString()){
                let propertyOptionsData = this.state.allPropertiesOptionsData[i].optionsList;
                this.setState({
                    selectedProperty : propertyID,
                    propertyOptionsData : propertyOptionsData,
                    propertyOptionHeaders : this.generateOptionColumnHeaders(propertyOptionsData)
                });
            }
            if(this.state.allPropertiesOptionsRawData[i].propertyID.toString() == propertyID.toString()){
                let propertyOptionsRawData = this.state.allPropertiesOptionsRawData[i].propertyOptionList;
                this.setState({
                    propertyOptionsRawData : propertyOptionsRawData,
                });
            }
        }
    }

    updateDataFormat(locale){
        if(this.state.spvOptionsRawData && this.state.spvOptionsRawData.length>0){
            this.setState({
                spvOptionsData : this.formatOptionsData(this.state.spvOptionsRawData, locale),
                spvOptionHeaders : this.generateOptionColumnHeaders(this.state.spvOptionsRawData)
            })
        }

        if(this.state.allPropertiesOptionsRawData && this.state.allPropertiesOptionsRawData.length>0){
            let tempAllPropertiesOptionsData = this.getPropertyOptionsList(this.state.allPropertiesOptionsRawData, locale);
            this.setState({
                allPropertiesOptionsData : tempAllPropertiesOptionsData,
                propertyOptionsData : this.formatOptionsData(this.state.propertyOptionsRawData, locale),
                propertyOptionHeaders : this.generateOptionColumnHeaders(this.state.propertyOptionsRawData)
            })
        }
    }

    toggleMode(mode){
        this.setState({displayMode : mode});
    }

    render(){

        return (
        <div className="optionDetails">
            <div className="leftMargin form-group row">
                <div className="col-sm-8">
                    <div className="approvalSelectBtn_grp">
                        <div className="btn-group">
                            <button type="button" onClick={this.toggleMode.bind(this, 'spv')} className={"btn btn-primary selectBtn labelFont " + (this.state.displayMode === 'spv' ? 'dealtype_selected' : 'dealtype_notselected')} >SPV</button>
                            <button type="button" onClick={this.toggleMode.bind(this, 'property')} className={"btn btn-primary selectBtn labelFont " + (this.state.displayMode === 'property' ? 'dealtype_selected' : 'dealtype_notselected')} >Property</button>
                        </div>
                    </div>
                </div>
            </div>
            {
                this.state.displayMode==='spv' ? 
                <VerticalGridComponent rowHeaders={this.state.rowHeaders} columnHeaders={this.state.spvOptionHeaders} data={this.state.spvOptionsData}></VerticalGridComponent> :
                <VerticalGridComponent rowHeaders={this.state.rowHeaders} columnHeaders={this.state.propertyOptionHeaders} data={this.state.propertyOptionsData} filterRowData={this.state.propertyDropdownData} filterOnChange={this.onPropertyChange.bind(this)} selectedProperty={this.state.selectedProperty}></VerticalGridComponent>
            }
        </div>
        )
    }
}

const mapStateToProps = state => {
    return {
         locale: state.dataFormat,
    }
    
};

const assetOptionDetailsTab = connect(mapStateToProps)(assetOptionDetails);

export default withRouter(assetOptionDetailsTab);