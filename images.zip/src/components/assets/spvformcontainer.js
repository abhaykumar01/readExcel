import React, { Fragment } from 'react';
import Dropdown from '../../commonComponents/dropdown';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Icon } from '@zambezi/sdk/icons';
import SPVOptionComponent from './spvoptoncomponent';
import { generatedataType, modalMessage , dealstatusArray } from './assetConstants';
import { spvOptionLimit, defaultSpvOption, defaultProperty, spvstatusArray, LocaleCode, propertyLimit } from './assetConstants';
import { API_ENDPOINT } from '../../config/config';
import { HttpGet, HttpPost, HttpPut } from '../../services/api.js';
import PropertyContainer from './propertycontainer';
import Accordion from '@zambezi/sdk/accordion';
import { Notification } from '@zambezi/sdk/notification';
import ModalPopup from './modal';
import Modal from '@zambezi/sdk/modal';
import { withRouter } from 'react-router-dom';
import { buildFailureTestResult } from '@jest/test-result';
import { getDateFormat } from './commonUtilityFunctions';
import AlertModalPopup from './alertModal';
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;

class SPVFormContainer extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = props.data;
        localStorage.setItem('jurisdiction', this.state.jurisdiction);
        localStorage.setItem("spvStatus", this.state.spvStatus);

        //This flag 'spvstatusBol' will be used to used control Edit flags functionality
        //Edit flag will set, only in case of 'active' asset or 'in progress and newSPVexists'
        let spvstatusBol = false;
        if(this.state.spvStatus){
            if(this.state.spvStatus.toLowerCase()==='active'){
                spvstatusBol = true;
            } else if(this.state.spvStatus.toLowerCase()==='in progress' && this.state.newSpvExists){
                spvstatusBol = true;
            }
        }

        this.state.racfData='';
        this.state.permissionData= {};
        this.state.memberOfDetail='';
        this.state.spvstatusBol = spvstatusBol;
        this.state.isSpvOptionModal = false;
        this.state.cancelAssetModal = false;
        this.state.corporateParentList = [];
    }
    componentWillMount() {
        /* this case will work only when in edit mode data is already preset
           so as to add id which is required for deletion while adding new    
        */
       this.getCorporateParentList();
       
        if (this.state.spvOptionsList.length > 0) {
            const optnList = this.state.spvOptionsList
            for (var i = 0; i < optnList.length; i++) {
                optnList[i].spvoptionID = i + 1;
            }
        }
        if (this.state.propertyList.length > 0) {
            const propList = this.state.propertyList;
            for (var j = 0; j < propList.length; j++) {
                propList[j].spvpropertyID = j + 1;
            }
        }
        this.enableSaveButton();
    }
    componentDidMount(){
        if(this.state.spvStatus === "In Progress" || this.state.spvStatus === "Active"){
        var intervalId = setInterval(this.enableSaveButton, 2000);
        this.setState({intervalId: intervalId});
        }
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
        console.log(this.state.racfData)
    }
    componentWillUnmount() {
        clearInterval(this.state.intervalId);
     }
    componentWillReceiveProps(props) {
        let _updatedData = Object.assign(this.state, props.data)
        this.setState({ _updatedData })
    }
    checkPropetyOptionAdded = () => {
        let optionAdded = false;
        if (this.state.propertyList.length > 0) {
            const len = this.state.propertyList
            for (var i = 0; i < len.length; i++) {
                if (len[i].propertyOptionList.length > 0) {
                    optionAdded = true;
                    break;
                }
            }
        }
        return optionAdded;
    }

    addSPVOption() {
        if (this.checkPropetyOptionAdded()) { 
            this.setState({isSpvOptionModal : true});
            return; 
        }
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if (typeof this.state.spvoptionCount !== 'undefined' && this.state.spvoptionCount == spvOptionLimit) { return }
        if (typeof this.state.spvoptionCount !== 'undefined') {
            this.state.spvoptionCount = this.state.spvoptionCount + 1
        } else {
            this.state.spvoptionCount = this.state.spvOptionsList.length > 0 ? this.state.spvOptionsList.length + 1 : 1
        }

        if (this.state.spvoptionCount <= spvOptionLimit) {
            const defaultState = { ...defaultSpvOption };
            defaultState.dealOptionFlag = this.state.spvstatusBol === true ? 2 : 0
            defaultState.spvoptionID = this.state.spvoptionCount;
            const newState = this.state.spvOptionsList.concat(defaultState);
            this.setState({
                spvOptionsList: newState
            }, () => {
                this.props.data.spvOptionsList = this.state.spvOptionsList;
            });
        }


    }
    removeSPVOption = (param) => {
        this.state.removedspvOptions = typeof this.state.removedspvOptions != "undefined" ? this.state.removedspvOptions : [];
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if(this.state.spvstatusBol && param.state.dealOptionFlag !==2 ){
            let editedOptionList = this.state.spvOptionsList.map((item)=>{
                if(param.state.spvoptionID === item.spvoptionID){
                    item.dealOptionFlag = 1;
                }
                return item;
            })

            this.setState({
                spvOptionsList : [...editedOptionList]
            }, () => {
                this.props.data.spvOptionsList = this.state.spvOptionsList;
            })

        }else{
            let array = this.state.spvOptionsList.filter((item) => {
                return param.props.optiondata.spvoptionID !== item.spvoptionID
            });
    
            // let newcount = this.state.spvoptionCount - 1
            this.setState({
                spvOptionsList: [...array]
            }, () => {
                this.props.data.spvOptionsList = this.state.spvOptionsList;
            });
        }
    }
    openCorporateParentModal() {
        this.setState({ isCorporateParentModalOpen: true });
    }
    closeAddCorporateParentModal() {
        this.setState({ isCorporateParentModalOpen: false });
    }
    selectCorporateParent(val) {
        this.setState({
            corporateParent : val.corporateParentName,
            corporateParentID : val.corporateParentID
            }, ()=>{
            this.props.data.corporateParent = this.state.corporateParent;
            this.props.data.corporateParentID = this.state.corporateParentID;
        })
    }
    updateCorporateParentList() {
        const url = API_ENDPOINT.ADD_NEW_CORPORATE_PARENT;
        var currentComponent = this;
        var newCorporateParent = {
            "corporateParentID" : null,
            "corporateParentName" : this.state.newCorporateParentName,
            "ledgerID" : this.state.newCorporateParentLedgerID,
            "ledgerName" : this.state.newCorporateParentLedgerName
        };
        
        HttpPost(currentComponent, newCorporateParent, url).then((response) => {
            this.setState({ corporateParentList: response.data});
            this.closeAddCorporateParentModal();
        }).catch((error) => {
            console.log(error);
        })
    }
    getCorporateParentList(){
        const url = API_ENDPOINT.GET_CORPORATE_PARENT_LIST;
        const ID = localStorage.getItem('userID');
        // const userURL = API_ENDPOINT.GET_PARTY_DETAIL + '/' + ID;
        var currentComponent = this;
        HttpGet(currentComponent, url).then((response) => {
            if (response.data && response.data.length > 0) {
                this.setState({ corporateParentList : response.data });
            }
        }).catch((error) => {
            console.log(error);
        })

        // HttpGet(userURL).then( (response) => {
        //     // TODO for User name story implementation
            
        //     console.log(response.data);
            
            
        // }).catch(function (error) {
        //     console.log("Error received");
        //     console.log(error);
        // })


    }
    
    checkApprovalStatus(status) {
        this.setState({ 'spvApproval': status }, () => {
            this.props.data.spvApproval = this.state.spvApproval;
        })
    }
    checkMrec(status) {
        this.setState({ 'mrec': status }, () => {
            this.props.data.mrec = this.state.mrec;
        })
    }
    // TODO these are common functions will move them to implemntations
    handleOnChange(e) {
        const name = e.target.name;
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) > 0 ? true : false;
        const flagVal = (this.state.spvstatusBol === true) ? 3 : this.state.spvFlag;
        let value = e.target.value;
        let newVal =""; 
        if(name ==="spvNumber" || name ==="newCorporateParentLedgerID"){
            var regex= /^[0-9\b]+$/;
            if(value !==""){
                if(value.length > e.target.maxLength){
                    newVal = value.substring(value.length-1, value);
                }
                if(!regex.test(value)){
                    newVal =  value.substring(value.length-1, value);
                    value = newVal;
                }
               
            }else {
                // TODO for blank case
            }
            
        }else {
            if(value !==""){
                if(value.length > e.target.maxLength){
                    newVal = value.substring(value.length-1, value);
                }
            }else {
                // TODO for blank case
            }
        }
        
        this.setState({
            spvFlag: flagVal,
            [name]: value
        }, () => {
            this.props.data.spvFlag = this.state.spvFlag;
            this.props.data[name] = this.state[name];
            // console.log("from:handlepropschange", this.state,">>>>" , this.props.data);
        })
    }
    checkSPVnumber() {
        if(null !== this.state.spvNumber && this.state.spvNumber !== ''){
            const api = API_ENDPOINT.CHECK_SPV_NUMBER + this.state.spvNumber;
            var currentComponent = this;
            HttpGet(currentComponent, api).then((response) => {
                if (response.data > 0) {
                    this.setState({ 'isSpvNumberDuplicate': true });
                } else {
                    this.setState({ 'isSpvNumberDuplicate': false });
                }
            }).catch((error) => {
                    console.log(error);
                    new Error(error);
                })
        } else {
            this.setState({ 'isSpvNumberDuplicate': false });
        }
    }
    handleDropDownChange(event, val, type) {
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        const flagVal = (this.state.spvstatusBol === true) ? 3 : this.state.spvFlag;
        if (event === "jurisdiction") { localStorage.setItem('jurisdiction', type.value) }
        if(event === "registrationForm"){
            if(type.value === "OY"){
                this.setState({
                    'showMerc' : true,
                    'mrec' : 1
                })
            } else {
                this.setState({
                    'showMerc' : false,
                    'mrec' : null
                })
            }
        }
        this.setState({
            spvFlag: flagVal,
            [event]: type.value
        }, () => {
            this.props.data.spvFlag = this.state.spvFlag;
            this.props.data[event] = this.state[event];
            
        })
    }
    addProperty() {
        if (typeof this.state.propertyCount !== 'undefined' && this.state.propertyCount == propertyLimit) { 
            return 
        }
        if (typeof this.state.propertyCount !== 'undefined') {
            this.state.propertyCount = this.state.propertyCount + 1;
        } else {
            this.state.propertyCount = this.state.propertyList.length > 0 ? this.state.propertyList.length + 1 : 1
        }

        const propertyData = { ...defaultProperty };
        propertyData.propertyFlag = this.state.spvstatusBol ? 2 : 0;
        propertyData.spvpropertyID = this.state.propertyCount;
        const _modfiedState = this.state.propertyList.concat(propertyData);
        this.setState({
            propertyList: _modfiedState
        }, () => {
            this.props.data.propertyList = this.state.propertyList;
        })
    }

    removeProperty = (param) => {
        // event.stopPropagation();
        
        let dealLinked = false;
        if (!this.state.spvstatusBol || (null != param.propertyFlag && param.propertyFlag===2) ) {
            const newState = this.state.propertyList.filter((item) => {
                return param.spvpropertyID != item.spvpropertyID
            })
            this.setState({
                propertyList: newState
            }, () => {
                this.props.data.propertyList = this.state.propertyList;
            });
        } else {
            this.state.removedProperty = typeof this.state.removedProperty != "undefined" ? this.state.removedProperty : []
            // this.state.propertyList.forEach(elem => {
            //     elem.buildingList.forEach( item =>{
            //         item.areaEOList.forEach( itemchild =>{
            //             if(itemchild.dealStatus !== null && dealstatusArray.indexOf(itemchild.dealStatus) >=0){
            //                 dealLinked = itemchild.dealStatus;
            //             }
            //         })
            //     })
            // })
            const removeObj = this.state.propertyList.filter((item) => {
                if (param.spvpropertyID === item.spvpropertyID) {
                    item.propertyFlag = 1;
                    // item.propertyID = null;
                    return item;
                }
            })
            // this.state.removedProperty.push(removeObj[0]);
            this.forceUpdate();
            // this.setState({ "propertyremoval": true , "dealLinked":dealLinked})
        }
    }
    confirmremoveProperty = () => {
        const newState = this.state.propertyList.filter((item) => {
            return item.propertyFlag != 1
        })
        this.setState({
            "propertyremoval": false,
            "propertyList": newState
        }, () => {
            this.props.data.propertyList = this.state.propertyList;
        });
    }
    saveAssetData = () => {
        console.log("Final state Data", this.state);
        if (this.validateAreaUniqueName()) { return };
        this.setState({ isSucess: true });

    }

    validateAreaUniqueName() {
        var namesSoFar = [], toreturn = false;
        this.state.propertyList.forEach(property => {
            property.buildingList.forEach(building => {
                building.areaEOList.forEach(area => {
                    let areaName = area.areaName !== null ? area.areaName.trim() : ""
                    if (namesSoFar.indexOf(areaName) !== -1) {
                        area.uniqueNameError = true;
                        area.uniqueNameErrorMessage = "Please enter a unique area name";
                        toreturn = true;
                        this.setState({ "isUniqueAreaNameError": true });
                    } else {
                        namesSoFar.push(areaName);
                    }
                })
            })
        });

        return toreturn;
    }

    openCancelAssetModal(){
        this.setState({cancelAssetModal : true});
    }

    cancelAsset() {
        if(this.state.spvStatus !== null ){
            this.props.history.push({
                pathname: '/lms/asset',
                state: { spvID: this.state.spvID, isNewAsset: false }
            }); 
        }else {
            this.props.history.push('viewAssetDetail');
        }
    }

    closemodal = () => {
        //console.log(this.state);
        const closeObj = {
            "isSucess": false,
            "propertyremoval": false,
            "isSpvOptionModal" : false,
            "cancelAssetModal" : false,
        }
        this.setState(closeObj);
    }

    confirmClick = () => {
        let dealstatusVal = false
        var currentComponent = this;
        if (this.state.spvStatus === "Active") {
            this.state.spvID = null;
            for (var i = 0, len = this.state.spvOptionsList; i < len.length; i++) {
                len[i].spvoptionID = null;
                len[i].optionID = null;
            }
           
            this.state.propertyList.forEach(elem => {
                function replaceIdWithNull(item) {
                    if (typeof item.spvID != "undefined") { item.spvID = null }
                    if (typeof item.propertyID != "undefined") { item.propertyID = null };
                    if (typeof item.buildingID != "undefined") { item.buildingID = null };
                    if (typeof item.spvbuildingID != "undefined") { item.spvbuildingID = null };
                    if (typeof item.areaID != "undefined") { item.areaID = null };
                    if (typeof item.subAreaID != "undefined") { item.subAreaID = null };
                    if (typeof item.areaTaxID != "undefined") { item.areaTaxID = null };
                    if (typeof item.optionID != "undefined") { item.optionID = null };
                    if (typeof item.propertyoptionID != "undefined") { item.propertyoptionID = null };
                }
                function checkDealstatus(item){
                    const statusNotin = ["Approved", "Signed", "Active"]
                    if(item.dealStatus !== null && statusNotin.indexOf(item.dealStatus) >=0){
                        dealstatusVal = true
                    }
                }
                replaceIdWithNull(elem);
                elem.buildingList.forEach(elem => {
                    replaceIdWithNull(elem);
                    elem.areaEOList.forEach(item => {
                        checkDealstatus(item);
                        replaceIdWithNull(item);
                        item.areaTaxList.forEach(itemchild => {
                            replaceIdWithNull(itemchild);
                        })
                        item.subAreaList.forEach(itemchild => {
                            replaceIdWithNull(itemchild);
                        })
                    })
                });
                elem.propertyOptionList.forEach(elem => {
                    replaceIdWithNull(elem);
                });
            })
        };
        let payLoadData = this.state;
        if(dealstatusVal) {
            if(this.state.spvFlag === 3){
                this.setState({"isErrorOnSave":true, "isSucess":false}, () =>{
                    window.scrollTo(0, 0);
                });
                return;
               
            }
            
        };
        if(this.state.spvStatus !== null ){
            HttpPut(currentComponent, payLoadData, API_ENDPOINT.CREATE_ASSET).then((response) => {
                this.setState({ isSucess: false });
               // this.props.history.push('viewAssetDetail');
                  this.props.history.push({
                    pathname: '/lms/asset',
                    state: { spvID: response.data.spvID, isNewAsset: false }
                }); 
            }).catch((error) => {
                })
        }else {
            HttpPost(currentComponent, payLoadData, API_ENDPOINT.CREATE_ASSET).then((response) => {
                // console.log("response received from server", response);
                this.setState({ isSucess: false });
                this.props.history.push({
                    pathname: '/lms/asset',
                    state: { spvID: response.data.spvID, isNewAsset: true }
                });
            }).catch((error) => {
                    // to log error
                })
        }
       
       
    }
    enableSaveButton = () =>{
        let _toreturn = true;
        const data = this.state;
        const objectToSkip= ["corporateParentID", "mrec","reasonForRejection","optionCategory","managementFee","optionCategory","areaEffectiveDate","areaLocation","bookValue","dealStatus","leaseContractID","leaseEndDate","leaseStartDate","loRWA","marginAmount","residualValue","leaseFee","tenor","totalRWA","subAreaType", "supportingComments","versionNumber", "removedProperty", "isUniqueAreaNameError","fetching","spvFlag","removedspvOptions","newSpvExists", "corporateParentList" ,"propertyFlag","removedbuilding", "removedpropertyOption", "removedArea", "removedsubArea", "removedTaxCharge","createdBy","updatedBy", "requestedBy","racfData","memberOfDetail"] 
        // remove "createdBy", "updatedBy", "requestedBy" from above
        function chckNullObject(data){
            if(!_toreturn ) {return};
            for( const obj in data){
                if(objectToSkip.indexOf(obj) < 0){
                    if(data[obj] === null || data[obj] ===""){
                        _toreturn = false;
                        //alert("All feilds are mandatory. Please complete them")
                        break;
                    }
                }
            }
        }
        chckNullObject(data);
        data.propertyList.forEach(elem => {
            chckNullObject(elem);
            elem.buildingList.forEach(elem => {
                chckNullObject(elem);
                elem.areaEOList.forEach(item => {
                    chckNullObject(item);
                    item.areaTaxList.forEach(itemchild => {
                        chckNullObject(itemchild);
                    })
                    item.subAreaList.forEach(itemchild => {
                        chckNullObject(itemchild);
                    })
                })
            });
            elem.propertyOptionList.forEach(elem => {
                chckNullObject(elem);
            });
        })

        if(!_toreturn){
            this.setState({disableSaveBtn : true})
        }else{
            this.setState({disableSaveBtn : false})
        }
    }

    returnBtnstate = ()=>{
        if(this.state.spvStatus === "In Progress" && this.state.newSpvExists){
            return this.state.disableSaveBtn;
        }
    }

    render() {
        console.log(this.state.memberOfDetail)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var fucntDisable = true;
        var disableCrprtParent= true;
        
        for(var i = 0 ; i < datalen ; i++){
            if(perData[i] == "Asset_Add_CorporateParent"){
                disableCrprtParent = false; // enable only for CFO
            }
        }
        //rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser
        //check memberOf
        console.log("User type:::");
        
        // if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0){
        // // if(this.state.memberOfDetail == "rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser"){
        //     //fucntDisable= true;
        //     disableCrprtParent = false;
        // }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Asset_Edit") { 
                    fucntDisable = false;
                }
            }
        // }
        
          //Asset_Add_PropertyTax
        //Asset_Add_SubArea
        //console.log("this.state>>", this.state)
        /// for creating Unique date format
        const locale = LocaleCode[localStorage.getItem('jurisdiction')];
        const date = new Date(this.state.createdOn);
        const createdOn = date.toLocaleString(locale, { timezone: 'UTC', timeStyle: 'short', dateStyle: 'medium' })

        const isEditMode = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        const dealLinkedMsg = dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? `The Property you are trying to remove has a linked deal to it in ${this.state.dealLinked} status, please remove the link before proceeding` : modalMessage["propertyMsg"];
        // code for rendering child component depends on object in array
        const child = this.state.spvOptionsList.map((item, index) => {
            if(item.dealOptionFlag!==1){
                return <SPVOptionComponent key={item.spvoptionID} index={index + 1} optiondata={item} parentState={this.state} removeOpt={this.removeSPVOption} />
            }
        });

        const property = this.state.propertyList.map((item, index) => {
            if(item.propertyFlag !== 1){
                return <PropertyContainer key={item.spvpropertyID} data={item} fucntDisable={fucntDisable} optiondata={item} parentData={this.state} removeproperty={this.removeProperty.bind(this)} index={index + 1} />
            }
        })
        /////////////Loop ends///////////////
      const disableSaveBtn = this.returnBtnstate()
          
        return (
            <div className="clearfix " >
                {/* {this.state.propertyremoval ?
                    <ModalPopup headerTitle="Remove property" className={'assetpageModal'} open={true} confirm={this.confirmremoveProperty.bind(this)} confirmBtnText={dealstatusArray.indexOf(this.state.dealLinked) >=0 ? "" : "Yes, remove this property"} close={this.closemodal} data={this.state} modalbody={dealLinkedMsg} /> : null} */}
                {this.state.isSucess ?
                    <ModalPopup headerTitle="Save new asset" className={'assetpageModal'} confirmBtnText="Save new asset" open={this.state.isSucess} confirm={this.confirmClick} close={this.closemodal} data={this.state} modalbody={modalMessage["editassetMsg"]} /> : ""}
                {this.state.cancelAssetModal ?
                    <ModalPopup headerTitle="Cancel asset" className={'assetpageModal'} confirmBtnText="Yes, cancel" cancelBtnText="No, don't cancel" open={this.state.cancelAssetModal} confirm={this.cancelAsset.bind(this)} close={this.closemodal} modalbody={modalMessage["cancelAssetMsg"]} /> : ""}
                {this.state.isUniqueAreaNameError ?
                    <Notification status='error' size='small' className="Confirmation_header_new" >Please enter a unique area name</Notification> : null
                }
                {this.state.isSpvOptionModal ?
                    <AlertModalPopup headerTitle="SPV options" open={true} className={'assetpageModal'} confirmBtnText="OK" confirm={this.closemodal.bind(this)} modalbody={modalMessage["spvOptionMsg"]}/> : null
                }
                {this.state.isErrorOnSave ? <Notification status='error' size='small' className="Confirmation_header_new" >The edit of SPV section is not allowed as it  has a linked deal to it in Approved/Signed/Active status, please remove the link before proceeding</Notification> : null}
                {this.state.isCorporateParentModalOpen ?
                    <Modal title="Add new corporate parent" className='corporateParentModal' 
                    confirm='Save' 
                    cancel='Cancel'
                        withSectioning={false} withPadding isClosable
                        open={this.state.isCorporateParentModalOpen}
                        onConfirm={this.updateCorporateParentList.bind(this)}
                        onCancel={() => { this.closeAddCorporateParentModal() }}>
                        <div className="form-group row">
                            <label htmlFor="newCorporateParentName" className="col-sm-5 col-form-label field_label" >Name</label>
                            <div className="col-sm-7">
                                <input type='text' maxLength="25" className="form-control inputFields" name="newCorporateParentName" onChange={this.handleOnChange.bind(this)} placeholder="Enter"></input>
                            </div>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="newCorporateParentLedgerName" className="col-sm-5 col-form-label field_label" >Ledger name</label>
                            <div className="col-sm-7">
                                <input type='text' maxLength="25" className="form-control inputFields" name="newCorporateParentLedgerName" onChange={this.handleOnChange.bind(this)} placeholder="Enter"></input>
                            </div>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="newCorporateParentLedgerID" className="col-sm-5 col-form-label field_label" >Ledger ID</label>
                            <div className="col-sm-7">
                                <input type='text' maxLength="25" className="form-control inputFields" name="newCorporateParentLedgerID" onChange={this.handleOnChange.bind(this)} placeholder="Enter"></input>
                            </div>
                        </div>
                    </Modal> : null
                }

                <div className="form-group row heading_title">
                    <div className="col-xs-8">
                        {isEditMode ? <Fragment><label className="model_title"> {`Edit ${this.state.spvName}`}</     label><br /> <label className="col-form-label field_label">{`Created by ${this.state.createdBy}      on ${createdOn}`}</label></Fragment> : <label className="model_title">Add new asset</label>
                        }
                    </div>
                    <div className=" col-xs-4">
                        {isEditMode ? <label className="col-form-label field_label pull-right">Status: <b>
                            {`${this.state.spvStatus}`}</b></label> : null}
                    </div>

                </div>
                <Accordion className="accordion_header">
                    <dt open={true} className="genetal_tab"> {isEditMode ? "Special purpose vehicle" : "Add SPV"}</dt>
                    <div className="spvContainer">
                        <div className="form-group row">
                            <label htmlFor="spvName" className="col-sm-4 col-form-label field_label" >SPV name</label>
                            <div className="col-sm-6">
                                <input disabled={fucntDisable} type="text" value={this.state.spvName} maxLength="50" name="spvName"
                                    onChange={this.handleOnChange.bind(this)} className="form-control input_Fields" placeholder="Enter" />
                            </div>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="spvNumber" className="col-sm-4 col-form-label field_label" >SPV number</label>
                            <div className="col-sm-6">
                                <input disabled={fucntDisable} type="text" value={this.state.spvNumber} maxLength="4" name="spvNumber" onBlur={this.checkSPVnumber.bind(this)} onChange={this.handleOnChange.bind(this)}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                        </div>
                        {this.state.isSpvNumberDuplicate ?
                            <div className="form-group row">
                                <div className="col-sm-4 "></div>
                                <div className="col-sm-6" >
                                    <Notification status='error' size='small' withArrow arrowPosition='10px' className="error_notification">Enter a unique SPV number</Notification>
                                </div>
                            </div>
                            : null}
                        <Dropdown isDisabled={fucntDisable} title="Jurisdiction" selectedValue={this.state.jurisdiction}
                            onChange={this.handleDropDownChange.bind(this, 'jurisdiction')} classname="font_config_custom" data={generatedataType['jurisdiction']} errorStatus={false} />
                        <Dropdown isDisabled={fucntDisable} title="Registration form" selectedValue={this.state.registrationForm} classname="font_config_custom" data={generatedataType['registrationform']} errorStatus={false} onChange={this.handleDropDownChange.bind(this, 'registrationForm')} />
                        {this.state.showMerc ? <div className="form-group row">
                            <label className="col-sm-4 col-form-label field_label">MREC</label>
                            <div className="col-sm-8">
                                <div className="approvalSelectBtn_grp">
                                    <div className="btn-group">
                                        <button type="button" onClick={this.checkMrec.bind(this, 0)} className={"btn btn-primary selectBtn " + (this.state.mrec === 0 ? 'dealtype_selected' : 'dealtype_notselected')} >No</button>
                                        <button type="button" onClick={this.checkMrec.bind(this, 1)} className={"btn btn-primary selectBtn " + (this.state.mrec === 1 ? 'dealtype_selected' : 'dealtype_notselected')} >Yes</button>
                                    </div>
                                </div>
                            </div>
                        </div> :  null}
                        <div className="form-group row">
                            <label htmlFor="registrationNumber" className="col-sm-4 col-form-label field_label" >Registration number</label>
                            <div className="col-sm-6">
                                <input disabled={fucntDisable} type="text" value={this.state.registrationNumber} maxLength="50" name="registrationNumber" onChange={this.handleOnChange.bind(this)}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                        </div>
                        <div className="form-group row">
                            <label for="inputState" className="col-sm-4 col-form-label field_label">Corporate parent</label>
                            <div className="col-sm-8">
                                <Select
                                    isDisabled={fucntDisable}
                                    defaultValue={this.state.corporateParent}
                                    suggestions={this.state.corporateParentList}
                                    placeholder='Select'
                                    className={'font_config_custom'}
                                    onSuggestionSelected={(e, { suggestion }) => {
                                        this.selectCorporateParent(suggestion);
                                    }}
                                    renderSuggestion={(suggestion) => {
                                        return (<div>{suggestion.corporateParentName}</div>)
                                    }}
                                    getSuggestionValue={d => d.corporateParentName}
                                />
                            </div>
                        </div>
                        {(this.state.issuperuser) ? <div className="form-group row">
                        
                        <label className={"col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor " + (disableCrprtParent ? 'disabledLabel' : '')}>
                        <span onClick={this.openCorporateParentModal.bind(this)}>
                         <Icon name="plus-xsmall" size="small" />Add corporate parent</span>
                         </label></div> : <span></span>}
                        <div className="form-group row">
                            <label className="col-sm-4 col-form-label field_label">SPV approval received</label>
                            <div className="col-sm-8">
                                <div className="approvalSelectBtn_grp">
                                    <div className="btn-group">
                                        <button disabled={fucntDisable} type="button" onClick={this.checkApprovalStatus.bind(this, 0)} className={"btn btn-primary selectBtn " + (this.state.spvApproval === 0 ? 'dealtype_selected' : 'dealtype_notselected')} >No</button>
                                        <button disabled={fucntDisable}  type="button" onClick={this.checkApprovalStatus.bind(this, 1)} className={"btn btn-primary selectBtn " + (this.state.spvApproval === 1 ? 'dealtype_selected' : 'dealtype_notselected')} >Yes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {child}
                        <div className="form-group row">
                        
                            <label className={"col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor " + (fucntDisable ? 'disabledLabel' : '')}><span onClick={this.addSPVOption.bind(this)}><Icon name="plus-xsmall" size="small" /> {this.state.spvOptionsList.length > 0 ? <span>Add another option</span> : <span>Add option</span>}</span></label>
                        </div>
                    </div>
                </Accordion>

                {property} {/*property section added here*/}
                <div className="addPropertyFooter zb-accordion-header genetal_tab"><span onClick={this.addProperty.bind(this)}><Icon name="plus-xsmall" size="small" /> {(this.state.propertyList.length > 0) ? "Add another property" : "Add property"} </span></div>
                <div className="footer">
                    <button disabled={disableSaveBtn} type="button" id="btt" className="zb-button zb-button-primary save_btn" onClick={this.saveAssetData.bind(this)} >Save asset</button>
                    <button type="button" className="zb-button zb-button-secondary cancel_btn transparent" onClick={this.openCancelAssetModal.bind(this)}>Cancel</button>
                </div>
            </div>
        )
    }
}
export default withRouter(SPVFormContainer);