import React from 'react';
import { connect } from "react-redux";
import { Notification } from '@zambezi/sdk/notification';
import { API_ENDPOINT } from '../../config/config';
import { HttpGet } from '../../services/api';
import VerticalGridComponent from './verticalGridComponent';
import AssetSummaryComponent from './assetSummaryComponent';
import { formatDate, formatCurrencyValue, getCommaSeperatedStringFromArray} from './commonUtilityFunctions';
import { withRouter } from 'react-router-dom';

class assetBuildingDetails extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            displayMode : 'area',
            areaRowHeaders : this.getAreaRowHeaders(),
            buildingRowHeaders : this.getBuildingRowHeaders(),
            areaColumnHeaders : [],
            buildingColumnHeaders : [],
            buildingsData : [],
            buildingsRawData : [],
            areasData : [],
            areasRawData : [],
            spvSummaryData :[],
            spvSummaryRawData :[],
            isError : false,
            errorMessage : '',
        }
    }

    componentWillMount(){
        var getAssetSummaryUrl = API_ENDPOINT.ASSET_SUMMARY+'/'+ this.props.data.spvID;
        var locale = this.props.locale;
        var currentComponent = this;

        HttpGet(currentComponent, getAssetSummaryUrl).then( (response)=> {
            if(response.data){
                this.setState({
                    isError : false,
                    errorMessage : '',
                    spvSummaryRawData : response.data,
                    spvSummaryData : this.formatSpvSummaryData(response.data, this.getSpvSummaryHeaders(), locale)
                });
            }
        }).catch((error)=>{
            console.log(error);
            this.setState({
                isError : true,
                errorMessage : 'Server error while getting asset summary. Please try again later !'
            })
        }).finally(()=>{
            this.fetchAreaTableData();
            this.fetchBuildingTableData();
        });  
    }

    componentWillReceiveProps(props){
        this.updateDataFormat(props.locale);
    }

    fetchAreaTableData(){
        var getAreaListUrl = API_ENDPOINT.ASSET_AREA_LIST+'/'+ this.props.data.spvID;
        var currentComponent = this;

        HttpGet(currentComponent, getAreaListUrl).then( (response)=> {
            if(response.data.length > 0){
                response.data.sort((a, b) => {
                    if (a.areaID > b.areaID) {return 1;}
                    if (b.areaID > a.areaID) {return -1;}
                    return 0;
                });
                this.additionalDataFormatting(response.data);
                this.setState({
                    areasRawData : response.data,
                    areasData : this.formatDisplayData(response.data, this.state.areaRowHeaders, this.props.locale),
                    areaColumnHeaders : this.generateColumnHeaders(response.data.length, 'Area'),
                })
            }
        });
    }

    fetchBuildingTableData(){
        var getBuildingListUrl = API_ENDPOINT.ASSET_BUILDING_LIST+'/'+ this.props.data.spvID;
        var currentComponent = this;

        HttpGet(currentComponent, getBuildingListUrl).then( (response)=> {
            if(response.data.length > 0){
                response.data.sort((a, b) => {
                    if (a.buildingID > b.buildingID) {return 1;}
                    if (b.buildingID > a.buildingID) {return -1;}
                    return 0;
                });
                this.setState({
                    buildingsRawData : response.data,
                    buildingsData : this.formatDisplayData(response.data, this.state.buildingRowHeaders, this.props.locale),
                    buildingColumnHeaders : this.generateColumnHeaders(response.data.length, 'Building'),
                })
            }
        });
    }

    updateDataFormat(locale){

        if(this.state.areasRawData && this.state.areasRawData.length>0){
            this.setState({
                areasData : this.formatDisplayData(this.state.areasRawData, this.state.areaRowHeaders, locale),
                areaColumnHeaders : this.generateColumnHeaders(this.state.areasRawData.length, 'Area'),
            })
        }
        if(this.state.buildingsRawData && this.state.buildingsRawData.length>0){
            this.setState({
                buildingsData : this.formatDisplayData(this.state.buildingsRawData, this.state.buildingRowHeaders, locale),
                buildingColumnHeaders : this.generateColumnHeaders(this.state.buildingsRawData.length, 'Building'),
            })
        }
        if(this.state.spvSummaryRawData){
            this.setState({
                spvSummaryData : this.formatSpvSummaryData(this.state.spvSummaryRawData, this.getSpvSummaryHeaders(), locale)
            }) 
        }
    }

    getBuildingRowHeaders(){
        return [
            {key : 'customerNames', value :'Customers', type : 'name_list'},
            {key : 'customerCount', value :'Number of customers', type : 'name'},
            {key : 'propertyName', value :'Property', type : 'name'},
            {key : 'valuationDate', value :'Valuation  date', type : 'date'},
            {key : 'vacantPossessionValue', value :'VPV', type : 'currency'},
            {key : 'reLetValue', value :'RLV', type : 'currency'},
            {key : 'leaseFee', value :'Lease fee', type : 'currency'},
            {key : 'bookValueSum', value :'Book value', type : 'currency'},
            {key : 'totalRWASum', value :'RWA', type : 'currency'},
            {key : 'marginAmountSum', value :'Margin amount', type : 'currency'},
            {key : 'loRWASum', value :'loRWA', type : 'percent'},
            {key : 'residualValueSum', value :'Residual value', type : 'currency'},
            {key : 'residualValueByVPVSum', value :'Residual value/VPV', type : 'percent'},
        ]
    }

    getAreaRowHeaders(){
        return [
            {key : 'customerName', value :'Customer', type:'name'},
            {key : 'propertyName', value :'Property', type:'name'},            
            {key : 'buildingName', value :'Building', type:'name'},
            {key : 'areaByUse', value :'Area by use', type:'number'},
            {key : 'leaseStartDate', value :'Lease start date', type:'date'},
            {key : 'tenor', value :'Lease term', type:'name'},
            {key : 'leaseEndDate', value :'Lease termination date', type:'date'},
            {key : 'extensionPeriod', value :'Extension period', type:'number'},
            {key : 'vacantPossessionValue', value :'VPV', type:'currency'},
            {key : 'reLetValue', value :'RLV', type:'currency'},
            {key : 'valuationDate', value :'Valuation date', type:'date'},
            {key : 'bookValue', value :'Book value', type:'currency'},
            {key : 'totalRWA', value :'RWA', type:'currency'},
            {key : 'marginAmount', value :'Margin amount', type:'currency'},
            {key : 'loRWA', value :'loRWA', type:'percent'},
            {key : 'residualValue', value :'Residual value', type:'currency'},
            {key : 'residualValueByVPV', value :'Residual value/VPV', type:'percent'},
            {key : 'leaseFee', value :'Lease fee', type:'currency'},
            {key : 'totalPropertyTax', value :'Property tax', type:'currency'},
            {key : 'totalServiceCharge', value :'Service charges', type:'currency'},
        ]
    }

    getSpvSummaryHeaders(){
        return [
            {key : 'propertyCount', value :'Number of properties', type:'number'},
            {key : 'bookValueSum', value :'Book value', type:'currency'},
            {key : 'totalRWASum', value :'RWA', type:'currency'},
            {key : 'vacantPossessionValueSum', value :'VPV', type:'currency'},
            {key : 'buildingCount', value :'Number of buildings', type:'number'},
            {key : 'residualValueSum', value :'Residual value', type:'currency'},
            {key : 'marginAmountSum', value :'Margin amount', type:'currency'},
            {key : 'reLetValueSum', value :'RLV', type:'currency'},
            {key : 'customerCount', value :'Number of customers', type:'number'},
            {key : 'residualValueByVPVSum', value :'Residual value/VPV', type:'percent'},
            {key : 'loRWASum', value :'loRWA', type:'currency'},
            {key : 'customerNameList', value :'Customer names', type:'name_list'},
        ]
    }

    generateColumnHeaders(length, entity){
        let optionColumnHeaders = [];
        for(let i=0; i<length ; i++){
            optionColumnHeaders.push(entity+' '+(i+1));
        }
        return optionColumnHeaders;
    }

    formatDisplayData(data, headers, locale){
        let outputData = [];

        for(let i=0; i<data.length ; i++){
            let tempObj = {...data[i]};
            for(let j=0; j<headers.length ; j++){
                let tempHeader = headers[j];
                if(tempHeader.type == 'date'){
                    tempObj[tempHeader.key] = formatDate(tempObj[tempHeader.key], locale);
                } else if(tempHeader.type == 'currency'){
                    tempObj[tempHeader.key] = formatCurrencyValue(tempObj[tempHeader.key], locale);
                } else if(tempHeader.type == 'name_list' && tempObj[tempHeader.key]){
                    tempObj[tempHeader.key] = getCommaSeperatedStringFromArray(tempObj[tempHeader.key]);
                } else if(tempHeader.type == 'percent'){
                    tempObj[tempHeader.key] = tempObj[tempHeader.key] ? tempObj[tempHeader.key]+'%' : '';
                }
            }
            outputData.push(tempObj);
        }
        return outputData;
    }

    formatSpvSummaryData(data, headers, locale){
        let outputData = [];
        for (let i=0; i<headers.length; i++){
            let tempObj = {};
            let tempHeader = headers[i];
            tempObj.id = tempHeader.key;
            tempObj.key = tempHeader.value;
            tempObj.value = data[tempHeader.key];

            if(tempHeader.type == 'date'){
                tempObj.value= formatDate(tempObj.value, locale);
            } else if(tempHeader.type == 'currency'){
                tempObj.value = formatCurrencyValue(tempObj.value, locale);
            } else if(tempHeader.type == 'name_list' && tempObj.value){
                tempObj.value = getCommaSeperatedStringFromArray(tempObj.value);
            } else if(tempHeader.type == 'percent'){
                tempObj.value = tempObj.value ? tempObj.value+'%' : '';
            }

            outputData.push(tempObj);
        }
        return outputData;
    }

    additionalDataFormatting(data){
        for(var i=0; i<data.length;i++){
            if(data[i].areaByUse && data[i].areaSize){
                data[i].areaByUse += '\n'+data[i].areaSize+" square metres ";
            }
        }
    }

    toggleMode(mode){
        this.setState({displayMode : mode});
    }

    render(){

        return (
        <div className="optionDetails">
            {this.state.isError ? 
            <div className="errorMessage">
                <Notification status="error" size="small">{this.state.errorMessage ? this.state.errorMessage : 'Server error. Please try again later !'}</Notification>
            </div>
            :
            <AssetSummaryComponent data={this.state.spvSummaryData}></AssetSummaryComponent>}
            
            <div className="leftMargin form-group row">
                <div className="col-sm-8">
                    <div className="approvalSelectBtn_grp">
                        <div className="btn-group">
                            <button type="button" onClick={this.toggleMode.bind(this, 'area')} className={"btn btn-primary selectBtn labelFont " + (this.state.displayMode === 'area' ? 'dealtype_selected' : 'dealtype_notselected')} >Area</button>
                            <button type="button" onClick={this.toggleMode.bind(this, 'building')} className={"btn btn-primary selectBtn labelFont " + (this.state.displayMode === 'building' ? 'dealtype_selected' : 'dealtype_notselected')} >Building</button>
                        </div>
                    </div>
                </div>
            </div>
            {
                this.state.displayMode ==='area' ? 
                <VerticalGridComponent rowHeaders={this.state.areaRowHeaders} columnHeaders={this.state.areaColumnHeaders} data={this.state.areasData}></VerticalGridComponent> :
                <VerticalGridComponent rowHeaders={this.state.buildingRowHeaders} columnHeaders={this.state.buildingColumnHeaders} data={this.state.buildingsData}></VerticalGridComponent>
            }
        </div>
        )
    }
}

const mapStateToProps = state => {
    return {
         locale: state.dataFormat,
    }
    
};

const assetBuildingDetailsTab = connect(mapStateToProps)(assetBuildingDetails);

export default withRouter(assetBuildingDetailsTab);