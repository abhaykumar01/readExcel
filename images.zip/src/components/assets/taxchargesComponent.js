import React, { Fragment } from 'react';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import { generatedataType, getCurrencySymbol , spvstatusArray } from './assetConstants';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import { Notification } from '@zambezi/sdk/notification';
import moment from 'moment';

class TaxChargesComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = props.data;
        this.state.spvstatusBol = props.parentData.spvstatusBol;
        this.getEffectiveDate = this.getEffectiveDate.bind(this,'effectiveDate');
    }
    getEffectiveDate(type, e){
        var startDate =moment(Date.parse(e)).format('YYYY-MM-DD');
        this.setState({[type]:startDate}, () => {
            this.props.data[type] = this.state[type];
        })
    }
    componentWillReceiveProps(props) {
        let _updatedData = Object.assign(this.state, props.data)
        this.setState({ _updatedData })
    }
    loadtaxType(event, val, type) {
        //Setting dummy values for service charge for Request approval button validations
        let dummyDate = null;
        let dummyComments = null;
        if(type.value === 'Service charge'){
            dummyDate = moment(new Date()).format('YYYY-MM-DD');
            dummyComments = 'NA';
        }

        this.setState({ 
            [event]: type.value ,
            "effectiveDate": dummyDate,				
            "supportingComments": dummyComments,
        }, () => {
            this.props.data[event] = this.state[event];
            this.props.data.effectiveDate = this.state.effectiveDate;
            this.props.data.supportingComments = this.state.supportingComments;
        })
    }
    calculateTaxValue() {
        let calulatedval = (this.state.taxationValue * this.state.propTaxationValueInPercent)/100 + " "
        this.setState({
            propTaxationValue: calulatedval
        }, () => {
            this.props.data.propTaxationValue = this.state.propTaxationValue
        })
    }
    getpropertyTaxCalculated() {
        let calulatedval = (this.state.propTaxationValue * this.state.propTaxPercent)/100 + " "
        this.setState({
            propTaxValue: calulatedval
        }, () => {
            this.props.data.propTaxValue = this.state.propTaxValue
        })
    }
    handleOnChange(e) {
        const name = e.target.name;
        //const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        // const spvstatusBol = typeof this.state.areaTaxID != "undefined" ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.areaTaxFlag && this.state.areaTaxFlag !== 2)) ? 3 : this.state.areaTaxFlag;
        let value = e.target.value;
        let newVal ="";
        const numFeildArr = ["taxationValue", "propTaxationValueInPercent", "propTaxPercent",  "serviceChargeAmount"] 
        if(numFeildArr.indexOf(name) >= 0){
            var regex= /^[0-9\s]+$/;
            if(name ==="serviceChargeAmount" ){ regex = /^[0-9,]{0,23}.[0-9]{0,2}$/ }
			 if(name ==="taxationValue" ){ regex = /^[0-9]{0,10}$/ }
            if(name ==="propTaxationValueInPercent" || name === "propTaxPercent"){ regex = /^[0-9,]{0,3}.[0-9]{0,2}$/ }
            if(!regex.test(value) ){
                if(value === ""){
                    value ="";
                }else {
                    return ;
                }
            }
        }else {
            if(value !==""){
                if(value.length > e.target.maxLength){
                    newVal = value.substring(value.length-1, value);
                }
            }else {
                // TODO for blank case
            }
        }
        
        this.setState({ areaTaxFlag : optnflag, [name]: value }, () => {
            this.props.data.areaTaxFlag = this.state.areaTaxFlag;
            this.props.data[name] = this.state[name]
        });
    }
    render() {
        console.log(this.props.fucntDisable)
        const isEditMode = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        return (
            <div className="optioncontainer taxComponent">
                <div className="form-group row">
                    <label className="col-sm-4 col-form-label field_label"><b>Tax/Charges </b></label>
                    
                    <label className={"col-sm-6 field_label activeColor removeOptn contentright " + (this.state.taxType === "Service charge" && this.props.fucntDisable && isEditMode ? 'disabledLabel' : '')} ><span onClick={(e) => { this.props.removetax(this, e) }}><Icon name="trash-small" size="small" />Remove Tax/charge</span></label>
                </div>
                <div className="form-group row">
                    <label htmlFor="taxtype" className="col-sm-4 col-form-label field_label" >Tax/charge</label>
                    <div className="col-sm-4">
                        <Select
                            defaultValue={this.state.taxType}
                            suggestions={generatedataType['taxType']}
                            placeholder='Select...'
                            onChange={this.loadtaxType.bind(this, 'taxType')}
                            aria-labelledby='simpleSelectLabel'
                            id='taxtype'
                        />
                    </div>
                    {this.state.taxType === "Property tax" ? <label className="col-sm-4 col-form-label field_label" style={{ 'textAlign': 'left' }}><span>{getCurrencySymbol()}</span> <span>{this.state.propTaxValue}</span></label> : ""}

                </div>
                {
                    this.state.taxType === "Property tax" ?
                        <Fragment>
                            <div className="form-group row">
                                <label htmlFor="taxationValue" className="col-sm-4 col-form-label field_label" >Taxation value</label>
                                <div className="col-sm-5">
                                    <input type="text" onBlur={this.calculateTaxValue.bind(this)} onChange={this.handleOnChange.bind(this)} name="taxationValue" value={this.state.taxationValue}
                                        className="form-control input_Fields" placeholder="Enter" />
                                </div>
                                <label className="col-sm-3 col-form-label field_label" style={{ 'textAlign': 'left' }}>{getCurrencySymbol()}</label>
                            </div>
                            <div className="form-group row">
                                <label htmlFor="propTaxationValueInPercent" className="col-sm-4 col-form-label field_label" >Proportion of taxation value % </label>
                                <div className="col-sm-6">
                                    <input type="text" maxLength="3" onBlur={this.calculateTaxValue.bind(this)} onChange={this.handleOnChange.bind(this)} name="propTaxationValueInPercent" value={this.state.propTaxationValueInPercent}
                                        className={this.state.propTaxationValueInPercent > 100 ? "form-control input_Fields error_message" : "form-control input_Fields"} placeholder="Enter" />
                                    {this.state.propTaxationValueInPercent > 100 ? <Notification status='error' size='small' withArrow arrowPosition='30px' className="error_notification" >Value should be less than 100</Notification> : ""}
                                </div>
                            </div>
                            <div className="form-group row">
                                <label htmlFor="propTaxationValue" className="col-sm-4 col-form-label field_label" >Proportion of taxation value</label>
                               
                                <div className="col-sm-3">
                                <input type="text" disabled readOnly className="form-control input_Fields" value={this.state.propTaxationValue}/>
                                {/* <label className="col-sm-4 col-form-label field_label taxValue" >{this.state.propTaxationValue} </label> */}
                                </div>
                                <label className="col-sm-3 col-form-label field_label" style={{ 'textAlign': 'left' }}>{getCurrencySymbol()}</label>
                            </div>
                            <div className="form-group row">
                                <label htmlFor="propTaxPercent" className="col-sm-4 col-form-label field_label" >Property tax %</label>
                                <div className="col-sm-6">
                                    <input type="text" maxLength="3" onBlur={this.getpropertyTaxCalculated.bind(this)} onChange={this.handleOnChange.bind(this)} name="propTaxPercent" value={this.state.propTaxPercent}
                                        className={this.state.propTaxPercent > 100 ? "form-control input_Fields error_message" : "form-control input_Fields"} placeholder="Enter" />
                                    {this.state.propTaxPercent > 100 ? <Notification status='error' size='small' withArrow arrowPosition='30px' className="error_notification" >Value should be less than 100</Notification> : ""}
                                </div>
                            </div>
                            <Calenderinputfield fieldTitle="Effective from " value={this.state.effectiveDate} onChange={this.getEffectiveDate} inputType="date" name="effectiveDate" placeholder="DD/MM/YYYY" />
                            <div className="form-group row">
                                <label htmlFor="" className="col-sm-4 col-form-label field_label" >Supporting comments</label>
                                <div className="col-sm-6">
                                    <textarea className="form-control input_Fields" placeholder="Enter" onChange={this.handleOnChange.bind(this)} value={this.state.supportingComments} maxLength="255"  name="supportingComments" style={{ 'height': '100px', 'resize': 'none' }}></textarea>
                                </div>
                            </div>
                        </Fragment>
                        :
                        null

                    

                }
                {
                    this.state.taxType === "Service charge" ? 
                    <Fragment>
                           <div className="form-group row">
                            <label htmlFor="" className="col-sm-4 col-form-label field_label" >Service charge amount</label>
                            <div className="col-sm-6">
                                <input disabled={this.props.fucntDisable} type="text" maxLength="100" onChange={this.handleOnChange.bind(this)} name="serviceChargeAmount" value={this.state.serviceChargeAmount}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                        </div> 

                    </Fragment>
                    : null
                }
            </div>
        )
    }
}
export default TaxChargesComponent;