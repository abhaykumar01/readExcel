import React from 'react';
import { Notification } from '@zambezi/sdk/notification';

export const NotificationComponent = (props) =>{
    return <Notification status='error'> {props.content} </Notification>
}