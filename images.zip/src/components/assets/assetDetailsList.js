import React from 'react';
import { connect } from "react-redux";
import Accordion from '@zambezi/sdk/accordion';
import { formatDate, formatCurrencyValue, getCommaSeperatedStringFromArray} from './commonUtilityFunctions';
import { spvLabelsListMode, optionLabelsListMode, propertyLabelsListMode, 
    buildingLabelsListMode, areaLabelsListMode, getAreaTaxLables, subAreaLabelsListMode } from './assetDetailsMappings';
import AssetListModeGridComponent from './assetListModeGridComponent';
import AssetListModeProperty from './assetListModeProperty';

class AssetDetailsList extends React.Component{
    iterationPath = {
        identifier: 'data',
        dataLabel: spvLabelsListMode,
        type : '',
        component : 'spv',
        componentDisplayName : 'SPV',
        editFlagIdentifier : 'spvFlag',
        idAccessor : 'spvID',
        child: [
            {
                identifier: 'propertyList',
                dataLabel: propertyLabelsListMode,
                name:'propertyName',
                type : 'child',
                component : 'property',
                componentDisplayName : 'Property',
                editFlagIdentifier : 'propertyFlag',
                idAccessor : 'spvID',
                child: [
                    {
                        identifier: 'buildingList',
                        dataLabel: buildingLabelsListMode,
                        name:'buildingName',
                        type : 'child',
                        component : 'building',
                        componentDisplayName : 'Building',
                        editFlagIdentifier : 'buildingFlag',
                        idAccessor : 'spvID',
                        child: [{
                            identifier: 'areaEOList',
                            dataLabel: areaLabelsListMode,
                            name:'areaName',
                            type : 'child',
                            component : 'area',
                            componentDisplayName : 'Area',
                            editFlagIdentifier : 'areaFlag',
                            idAccessor : 'spvID',
                            child: [{
                                identifier: 'areaTaxList',
                                getDataLabel: getAreaTaxLables.bind(),
                                labelIdentifier:'taxType',
                                isDynamicDataLabel : true,
                                component : 'areaTax',
                                type : 'secondary',
                                editFlagIdentifier : 'areaTaxFlag',
                                idAccessor : 'spvID',
                                child: []
                            },
                            {
                                identifier: 'subAreaList',
                                dataLabel: subAreaLabelsListMode,
                                type: 'options',
                                component: 'subArea',
                                componentDisplayName: 'Sub area',
                                editFlagIdentifier: 'subAreaFlag',
                                idAccessor : 'spvID',
                                child:[],
                            }]
                        }]
                    },
                    {
                        identifier: 'propertyOptionList',
                        dataLabel: optionLabelsListMode,
                        name:'',
                        type : 'options',
                        component : 'option',
                        componentDisplayName : 'Option',
                        editFlagIdentifier : 'dealOptionFlag',
                        idAccessor : 'spvID',
                        child: []
                    }
                ]
            },
            {
                identifier: 'spvOptionsList',
                dataLabel: optionLabelsListMode,
                name:'',
                type : 'options',
                component : 'option',
                componentDisplayName : 'Option',
                editFlagIdentifier : 'dealOptionFlag',
                idAccessor : 'spvID',
                child: []
            }
        ]
    }

    constructor(props){
        super(props);
        this.state={rawData : props.data, formattedData : {}, prevData: props.prevData};
    }

    componentWillMount(){
        let locale = this.props.locale;
        this.setState({formattedData : this.formatAllData(this.props.data, locale)});
    }
    
    componentWillReceiveProps(props){
        var locale = props.locale;
        this.setState({formattedData : this.formatAllData(this.state.rawData, locale)});
    }

    formatAllData(rawData, locale){
        let spvFormattedData = this.generateDisplayData(rawData, this.iterationPath.dataLabel, locale, this.state.prevData);
        spvFormattedData.editFlag = rawData[this.iterationPath.editFlagIdentifier];

        if(rawData.spvOptionsList && rawData.spvOptionsList.length > 0){
            if(this.state.prevData.spvOptionsList && this.state.prevData.spvOptionsList.length>0){
                spvFormattedData.spvOptionsFormattedList=this.formatDataList(rawData.spvOptionsList, this.iterationPath.child[1], locale, this.state.prevData.spvOptionsList);
            } else{
                spvFormattedData.spvOptionsFormattedList=this.formatDataList(rawData.spvOptionsList, this.iterationPath.child[1], locale);
            }
        } else {
            spvFormattedData.spvOptionsFormattedList = [];
        }
        if(rawData.propertyList && rawData.propertyList.length > 0){
            if(this.state.prevData.propertyList && this.state.prevData.propertyList.length>0){
                spvFormattedData.propertyFormattedList=this.formatDataList(rawData.propertyList, this.iterationPath.child[0], locale, this.state.prevData.propertyList);
            } else {
                spvFormattedData.propertyFormattedList=this.formatDataList(rawData.propertyList, this.iterationPath.child[0], locale);
            }
        } else {
            spvFormattedData.propertyFormattedList = [];
        }
        
        console.log('Formatted SPV Data', spvFormattedData);
        return spvFormattedData;
    }

    formatDataList(list, iterationPath, locale, prevData){
        let formattedList = [];
        let checkSPVExists = ((this.state.rawData.spvStatus === "In Progress" || this.state.rawData.spvStatus.toLowerCase() === "pending approval") && this.state.rawData.newSpvExists) ? true : false ;
            for(var i=0; i<list.length; i++){
                let formattedEntry={};
                let editFlag = list[i][iterationPath.editFlagIdentifier];
                if(iterationPath.isDynamicDataLabel){
                    iterationPath.dataLabel = iterationPath.getDataLabel(list[i][iterationPath.labelIdentifier]);
                }
                formattedEntry = ((editFlag===3) && checkSPVExists && (prevData && prevData[i])) ? this.generateDisplayData(list[i], iterationPath.dataLabel, locale, prevData[i]) : this.generateDisplayData(list[i], iterationPath.dataLabel, locale, {});
                formattedEntry.name = list[i][iterationPath.name];
                formattedEntry.editFlag = editFlag;
                formattedEntry.component = iterationPath.component;

                if(iterationPath.isDynamicDataLabel){
                    formattedEntry.componentDisplayName = list[i][iterationPath.labelIdentifier];
                } else {
                    formattedEntry.componentDisplayName = iterationPath.componentDisplayName;
                }

                if(iterationPath.component === 'property'){
                    formattedEntry.propertyCounts = this.generatePropertyCounts(list[i]);
                }

                if(iterationPath.component === 'area'){
                    let areaObj = list[i];
                    if(areaObj.areaCodeList && areaObj.areaCodeList.length > 0){
                        formattedEntry.areaCode = areaObj.areaCodeList[0].code;
                    } else if(areaObj.subAreaList && areaObj.subAreaList.length > 0){
                        let subAreaCodes = '';
                        areaObj.subAreaList.forEach((element) => {
                            if(element){
                                if(element.areaCode && element.areaCode.code){
                                    subAreaCodes += (element.areaCode.code + ', ');
                                }
                            }
                        })
                        subAreaCodes = subAreaCodes.slice(0, -2); 
                        formattedEntry.subAreaCodes = subAreaCodes;
                    }
                }

                if(iterationPath.component === 'subArea'){
                    let subAreaObj = list[i];
                    if(subAreaObj.areaCode && subAreaObj.areaCode.code){
                        formattedEntry.subHeading = subAreaObj.areaCode.code;
                    }
                }
                
                if(iterationPath.child.length > 0){
                    for(var j=0; j<iterationPath.child.length; j++){
                        let currentIteration = iterationPath.child[j];
                        if(list[i][currentIteration.identifier] && list[i][currentIteration.identifier].length>0){
                            formattedEntry[currentIteration.type] = (checkSPVExists && (prevData && prevData[i])) ? this.formatDataList(list[i][currentIteration.identifier], currentIteration, locale, prevData[i][currentIteration.identifier]) : this.formatDataList(list[i][currentIteration.identifier], currentIteration, locale, {});
                        }
                    }
                }
                formattedList.push(formattedEntry);
            }
        return formattedList;
    }

    generateDisplayData(data, labels, locale, prevData){
        let outputData = {
            displayData : []
            };
        
        for (let i=0; i<labels.length; i++){
            let tempObj = {};
            let tempLabel = labels[i];
            tempObj.id = tempLabel.key;
            tempObj.key = tempLabel.value;
            tempObj.value = data[tempLabel.key];

            if(prevData !== undefined && prevData[tempLabel.key] !== undefined){
                tempObj.isEdited = (data[tempLabel.key] !== prevData[tempLabel.key]) ? true : false;
                tempObj.oldValue = prevData[tempLabel.key];
            }

            // if(tempLabel.key === 'addressLineOne'){
            //     tempObj.value = [data['addressLineOne'],data['addressLineTwo']];
            //     if (prevData !== undefined){
            //         tempObj.oldValue = [prevData['addressLineOne'],prevData['addressLineTwo']]
            //     }
            // }

            if(tempLabel.type === 'date'){
                tempObj.value= formatDate(tempObj.value, locale);
                tempObj.oldValue= formatDate(tempObj.oldValue, locale);
            } else if(tempLabel.type === 'currency'){
                tempObj.value = formatCurrencyValue(tempObj.value, locale);
                tempObj.oldValue = formatCurrencyValue(tempObj.oldValue, locale);
            } else if(tempLabel.type === 'name_list' && tempObj.value){
                tempObj.value = getCommaSeperatedStringFromArray(tempObj.value);
                if(tempObj.oldValue){
                    tempObj.oldValue = getCommaSeperatedStringFromArray(tempObj.oldValue);
                }
            } else if(tempLabel.type === 'percent'){
                tempObj.value = tempObj.value ? tempObj.value+'%' : '';
                tempObj.oldValue = tempObj.oldValue ? tempObj.oldValue+'%' : '';
            } else if(tempLabel.type === 'boolean'){
                if(tempLabel.key==='mrec' && null===tempObj.value){
                    continue;
                }
                tempObj.value = tempObj.value ? 'Yes' : 'No';
                tempObj.oldValue = tempObj.oldValue ? 'Yes' : 'No';
            } else if(tempLabel.type === 'optionType'){
                tempObj.value = tempObj.value == 1 ? 'Put' : 'Call';
                tempObj.oldValue = tempObj.oldValue == 1 ? 'Put' : 'Call';
            }

            outputData.displayData.push(tempObj);
        }

        return outputData;
    }

    generatePropertyCounts(propertyObj){
        let output = {};
        output.optionsCount = propertyObj.totalNoOfOptionsCount ? propertyObj.totalNoOfOptionsCount : 0;
        output.buildingsCount = propertyObj.totalNoOfBuildingsCount ? propertyObj.totalNoOfBuildingsCount : 0;
        output.areasCount = propertyObj.totalNoOfAreaCount ? propertyObj.totalNoOfAreaCount : 0;

        return output;
    }

    breakListIntoChunks(list, width){
        return list.reduce(function (rows, key, index) { 
            return (index % width == 0 ? rows.push([key]) 
              : rows[rows.length-1].push(key)) && rows;
          }, []);
    }

    render(){
        const property = this.state.formattedData.propertyFormattedList.map((element, index)=>{
            return <AssetListModeProperty key={index} data={element}></AssetListModeProperty>
        })
        return (
            <div style={{margin : '65px 0 20px 0'}}>
                <Accordion className="accordion_header">
                    <dt open={true} className="genetal_tab">
                        Special Purpose Vehicle
                    </dt>
                    <div className="spvContainer">
                        <div className="form-group row primaryGrid">
                        <AssetListModeGridComponent heading={'SPV details summary'} bigHeading={true} data={this.state.formattedData.displayData}></AssetListModeGridComponent>
                        </div>
                        {
                            this.state.formattedData.spvOptionsFormattedList ?
                        <div>
                        {
                            this.breakListIntoChunks(this.state.formattedData.spvOptionsFormattedList,3).map((rowData, outIndex)=>{
                                return <div className="form-group row">
                                    {rowData.map((element, index) => {
                                        return <AssetListModeGridComponent isList={true} key={outIndex*3+index} editFlag={element.editFlag} heading={element.componentDisplayName+' '+ (outIndex*3+index+1)} data={element.displayData}></AssetListModeGridComponent>
                                    })} 
                                </div>
                            })
                        }
                        </div> 
                        : null
                        }
                        {/* <AssetListModeGridComponent heading={'SPV Summary'} data={this.state.formattedData.displayData}></AssetListModeGridComponent> */}
                    </div>
                    {/* {this.generateUiComponents(this.state.formattedData.propertyFormattedList)} */}
                    
                </Accordion>
                {property}
            </div>
        )
    }
}

const mapStateToProps = state => {
    console.log("receive user notification data");
    console.log(state.dataFormat);
    // return { usernotifications: state.user };
    return {
        // notifications: Object.assign({}, state.user),
         locale: state.dataFormat,
    }
    
};

const AssetDetailsListMode = connect(mapStateToProps)(AssetDetailsList);

export default AssetDetailsListMode;