import React from 'react';
import { Icon } from '@zambezi/sdk/icons';
import { spvstatusArray } from './assetConstants';

class SubAreaComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = props.data;
        this.state.spvstatusBol = props.parentData.spvstatusBol;
    }
    componentWillReceiveProps(props) {
        let _updatedData = Object.assign(this.state, props.data)
        this.setState({ _updatedData })
    }
    handleOnChange(e) {
        const name = e.target.name;
        //const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        // const spvstatusBol = typeof this.state.subAreaID != "undefined" ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.subAreaFlag && this.state.subAreaFlag !== 2)) ? 3 : this.state.subAreaFlag;
        let value = e.target.value;
        let newVal =""; 
        if(name ==="subAreaPercent" ){
            var regex= /^[0-9,]{0,3}.[0-9]{0,2}$/;
            if(!regex.test(value) ){
                if(value === ""){
                    value ="";
                }else {
                    return ;
                }
            }
        } else {
            if (value.length > e.target.maxLength) {
                value = value.substring(value.length - 1, value);
            }
        }

        this.setState({ subAreaFlag: optnflag, [name]: value }, () => {
            this.props.data.subAreaFlag = this.state.subAreaFlag;
            this.props.data[name] = this.state[name]
        });
    }
    render() {
        return (
            <div className="form-group row">
                <label className="col-sm-4 col-form-label field_label">Sub Area {this.props.index}</label>
                <div className="col-sm-2">
                    <input type="text" onBlur={(e) => { this.props.validatePercentage(this, e) }} onChange={this.handleOnChange.bind(this)} name="subAreaPercent" value={this.state.subAreaPercent}
                        className="form-control input_Fields" placeholder="Enter" />
                </div>
                <label className="col-form-label field_label" style={{ "float": "left" }}>%</label>
                <div className="col-sm-4">
                    <label className="field_label activeColor removeOptn contentright"><span onClick={(e) => { this.props.removesubarea(this, e) }}><Icon name="trash-small" size="small" />Remove sub-area</span></label>
                </div>
            </div>
        )
    }
}
export default SubAreaComponent;