import React from 'react';
import Accordion from '@zambezi/sdk/accordion';
import AssetListModeGridComponent from './assetListModeGridComponent';
import assetGridComponent from './assetGridComponent';

class AssetListModeProperty extends React.Component{
    constructor(props){
        super(props);
        this.state={...props.data}
    }

    componentWillReceiveProps(props){
        this.setState(props.data);
    }

    breakListIntoChunks(list, width){
        return list.reduce(function (rows, key, index) { 
            return (index % width == 0 ? rows.push([key]) 
              : rows[rows.length-1].push(key)) && rows;
          }, []);
    }

    formatChildUIComponents(data){
        let child = []
        if(data && data.length > 0){
            child=data.map((element, index)=>{
                let accordianCustomClass = element.component+'NormalComponent';
                if(element.editFlag == 1){
                    accordianCustomClass = element.component+'DeletedComponent';
                } else if(element.editFlag == 2){
                    accordianCustomClass = element.component+'AddedComponent';
                }
                // else if(element.editFlag == 3){
                //     accordianCustomClass = element.component+'EditedComponent';
                // }
                return <Accordion key={index} className={'list_accordion_header '+accordianCustomClass}>
                    <dt>
                        {element.name}
                        {element.areaCode ? 
                        <div className="row propertyCount">
                            <label className="field_label" style={{marginTop:'0px'}}>{"Area Id : "}</label>
                            <label className="field_label field_value" style={{marginTop:'0px'}}>{element.areaCode}</label>
                        </div>
                        :null}
                        {element.subAreaCodes ? 
                        <div className="row propertyCount">
                            <label className="field_label" style={{marginTop:'0px'}}>{element.subAreaCodes.length>6 ? "Area Ids : " : "Area Id : "}</label>
                            <label className="field_label field_value" style={{marginTop:'0px'}}>{element.subAreaCodes}</label>
                        </div>
                        :null}
                    </dt>
                    <div className="spvContainer primaryGrid">
                        <div className="form-group row">
                            <AssetListModeGridComponent data={element.displayData}></AssetListModeGridComponent>
                        </div>
                        {(element.options)?
                        <div>
                            {
                                this.breakListIntoChunks(element.options,3).map((rowData, outIndex) => {
                                    console.log(rowData);
                                    return <div className="form-group row">
                                        {rowData.map((item, index) => {
                                            let headingText = item.componentDisplayName+' '+(outIndex*3+index+1);
                                            if(item.subHeading){
                                                headingText = headingText+' - '+ item.subHeading;
                                            }
                                            return <AssetListModeGridComponent key={outIndex*3+index} editFlag={item.editFlag} isList={true} heading={headingText} data={item.displayData}></AssetListModeGridComponent> 
                                        })
                                        }
                                    </div>
                                })
                            }
                        </div>
                        :
                        null
                    }
                    {(element.secondary)?
                        <div className="form-group row">
                            {
                                element.secondary.map((item, index) => {
                                    return <AssetListModeGridComponent key={index} editFlag={item.editFlag} heading={item.componentDisplayName} data={item.displayData}></AssetListModeGridComponent>
                                })
                            }
                        </div>
                        :
                        null
                    }
                        {element.child ? this.formatChildUIComponents(element.child) : null}
                    </div>
                </Accordion>
            })
        }
        return child; 
    }

    render(){
        let child = this.formatChildUIComponents(this.state.child);
        let accordianCustomClass = this.state.component+'';
        if (this.state.editFlag == 1) {
            accordianCustomClass = this.state.component+'DeletedComponent';
        } else if (this.state.editFlag == 2) {
            accordianCustomClass = this.state.component+'AddedComponent';
        } 
        // else if (this.state.editFlag == 3) {
        //     accordianCustomClass = this.state.component+'EditedComponent';
        // }

        return (
            <Accordion className={"accordion_header "+accordianCustomClass} withPadding={false}>
                <dt>
                    {this.state.name}
                    <div className='row propertyCount'>
                        <div className='col-sm-4 contentWidth'>
                            <div className='form-group row countDiv'>
                            <label className="col-sm-6 col-form-label field_label">{'Options: '}</label>
                            <label className="col-sm-6 col-form-label field_label field_value">{this.state.propertyCounts.optionsCount}</label>
                            </div>
                        </div>
                        <div className='col-sm-4 contentWidth'>
                            <div className='form-group  row countDiv'>
                            <label className="col-sm-6 col-form-label field_label">{'Buildings: '}</label>
                            <label className="col-sm-6 col-form-label field_label field_value">{this.state.propertyCounts.buildingsCount}</label>
                            </div>
                        </div>
                        <div className='col-sm-4 contentWidth'>
                        <div className='form-group row countDiv'>
                            <label className="col-sm-6 col-form-label field_label">{'Areas: '}</label>
                            <label className="col-sm-6 col-form-label field_label field_value">{this.state.propertyCounts.areasCount}</label>
                            </div>
                        </div>
                    </div>
                </dt>
                <div className="spvContainer">
                    <Accordion className="list_accordion_header normalComponent">
                    <dt open={true}>{'Property details'}</dt>
                    <div>
                    <div className="form-group row primaryGrid">
                        <AssetListModeGridComponent bigHeading={true} data={this.state.displayData}></AssetListModeGridComponent>
                    </div>
                    {this.state.options ?
                            <div>
                            {
                                this.breakListIntoChunks(this.state.options,3).map((rowData, outIndex) => {
                                    console.log(rowData);
                                    return <div className="form-group row">
                                        {rowData.map((item, index) => {
                                            return <AssetListModeGridComponent key={outIndex*3+index} editFlag={item.editFlag} isList={true} heading={item.componentDisplayName+' '+(outIndex*3+index+1)} data={item.displayData}></AssetListModeGridComponent> 
                                        })
                                        }
                                    </div>
                                })
                            }
                        </div>
                        :
                        null
                    }
                    </div>
                    </Accordion>
                    {child}
                </div>
            </Accordion>
        )
    }
}

export default AssetListModeProperty;