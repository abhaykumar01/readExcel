import React from 'react';
import { connect } from "react-redux";
import './assetPage.css';
import '../../index.css';
import matchSorter from 'match-sorter';
import moment from 'moment';
import AssetGridComponent from "./assetGridComponent";
import { Tabs, Tab } from 'react-bootstrap-tabs';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import { HttpGet } from '../../services/api';
import { API_ENDPOINT } from '../../config/config';
import { Notification } from '@zambezi/sdk/notification';
import { formatDate, getCommaSeperatedStringFromArray} from './commonUtilityFunctions'
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;

class viewAssetList extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        var columnHeadersList = {
            active : [],
            inProgress : [],
            pendingApproval  : [],
            archived : []
        }
        var gridColumnHeaders = {
            active : [],
            inProgress : [],
            pendingApproval  : [],
            archived : []
        };
        columnHeadersList.active = this.getColumnHeadersList('ACTIVE');
        columnHeadersList.inProgress = this.getColumnHeadersList('IN_PROGRESS');
        columnHeadersList.pendingApproval = this.getColumnHeadersList('PENDING_APPROVAL');
        columnHeadersList.archived = this.getColumnHeadersList('ARCHIVED');

        gridColumnHeaders.active = this.getGridColumnHeaders(columnHeadersList.active);
        gridColumnHeaders.inProgress = this.getGridColumnHeaders(columnHeadersList.inProgress);
        gridColumnHeaders.pendingApproval = this.getGridColumnHeaders(columnHeadersList.pendingApproval);
        gridColumnHeaders.archived = this.getGridColumnHeaders(columnHeadersList.archived);
        
        this.state = {
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            searchInput: "",
            recordView: 20,
            gridData : {
                active : [],
                inProgress : [],
                pendingApproval  : [],
                archived : []
            },
            gridRawData : [],
            gridColumnHeaders : gridColumnHeaders,
            selectedTab : 0,
            loading : true,
            isHttpError : false
        }
        localStorage.setItem("approver", 'false');

    }

    componentDidMount() {
        var url = API_ENDPOINT.ASSET_LIST + '/0/500/spvID';
        var locale = this.props.locale;
        var currentComponent = this;

        HttpGet(currentComponent, url).then( (response)=> {
            response.data.sort((a,b) => {
                    if (a.createdOn > b.createdOn) {
                        return -1;
                    }
                    if (b.createdOn > a.createdOn) {
                        return 1;
                    }
                    return 0;
            });
            this.setState({gridRawData : response.data});
            this.updateDataFormat(response.data, locale);
        })
        .catch( (error)=>{
            console.log('Error in getting Asset list');
            console.log(error);
            this.setState({loading : false , isHttpError: true ,httpErrorMessage :"Server error, Please try again later"});
        });
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }

    componentWillReceiveProps(props){
        var locale=props.locale;
        if(this.state.gridRawData && this.state.gridRawData.length>0){
            this.updateDataFormat(this.state.gridRawData, locale);
        }
    }

    updateDataFormat(data, locale){
        var gridData={
            active : [],
            inProgress : [],
            pendingApproval  : [],
            archived : []
        };
        var columnHeadersList = {
            active : [],
            inProgress : [],
            pendingApproval  : [],
            archived : []
        }
        columnHeadersList.active = this.getColumnHeadersList('ACTIVE');
        columnHeadersList.inProgress = this.getColumnHeadersList('IN_PROGRESS');
        columnHeadersList.pendingApproval = this.getColumnHeadersList('PENDING_APPROVAL');
        columnHeadersList.archived = this.getColumnHeadersList('ARCHIVED');
        data.forEach((element) => {
            var tempObject = {};
            if (!element.spvStatus || element.spvStatus.toLowerCase() === 'active') {
                columnHeadersList.active.forEach(columnHeader => {
                    tempObject[columnHeader.id] = this.formatAPIResponseForColumn(element, columnHeader, locale);
                });
                gridData.active.push(tempObject);
            } else if (element.spvStatus.toLowerCase() === 'in progress') {
                columnHeadersList.inProgress.forEach(columnHeader => {
                    tempObject[columnHeader.id] = this.formatAPIResponseForColumn(element, columnHeader, locale);
                });
                gridData.inProgress.push(tempObject);
            } else if (element.spvStatus.toLowerCase() === 'pending approval') {
                columnHeadersList.pendingApproval.forEach(columnHeader => {
                    tempObject[columnHeader.id] = this.formatAPIResponseForColumn(element, columnHeader, locale);
                });
                gridData.pendingApproval.push(tempObject);
            } else if (element.spvStatus.toLowerCase() === 'archived') {
                columnHeadersList.archived.forEach(columnHeader => {
                    tempObject[columnHeader.id] = this.formatAPIResponseForColumn(element, columnHeader, locale);
                });
                gridData.archived.push(tempObject);
            };
        });
        this.setState({ loading: false, gridData: gridData });
    }

    HandleSelectChange(event, type) {
        this.setState({ recordView: type.value });
    }

    handleOnTabChange(index){
        this.setState({selectedTab : index});
    }

    addParty() {
        this.props.history.push('/lms/property');
    }

    formatAPIResponseForColumn(spv, columnHeader, locale){
        var result;
        if(spv[columnHeader.id] && ['optionDate', 'createdOn', 'updatedOn'].indexOf(columnHeader.id) >= 0){
            // var obj = new Date(spv[columnHeader.id]);
            // let time = moment(obj).format('DD/MM/YYYY');
            result = formatDate(spv[columnHeader.id], locale);
        } else if(columnHeader.id === 'customerNames'){
            result = getCommaSeperatedStringFromArray(spv[columnHeader.id]);
        }else if(columnHeader.id === 'spvNumber'){
            if(spv[columnHeader.id]){
                result = spv[columnHeader.id].toString();
            } else {
                result = spv[columnHeader.id];
            }
        } else {
            if(spv[columnHeader.id]){
                result = spv[columnHeader.id].toString();
            } else {
                result = spv[columnHeader.id];
            }
        }
        return result;
    }

    getColumnHeadersList(tabName){
        var columnHeadersList ;
        if(tabName === 'IN_PROGRESS' || tabName === 'ACTIVE'){
            columnHeadersList = [
                {id : 'spvID', headerName : 'SPV ID'},
                {id : 'spvNumber', headerName : 'SPV number'},
                {id : 'spvName', headerName : 'SPV name'},
                {id : 'customerNames', headerName : 'Customers'},
                {id : 'bookValue', headerName : 'Book value'},
                {id : 'optionDate', headerName : 'Option date'},
                {id : 'createdBy', headerName : 'Created by'},
                {id : 'createdOn', headerName : 'Created on'}
            ];
        } else if(tabName === 'PENDING_APPROVAL'){
            columnHeadersList = [
                {id : 'spvID', headerName : 'SPV ID'},
                {id : 'spvNumber', headerName : 'SPV number'},
                {id : 'spvName', headerName : 'SPV name'},
                {id : 'customerNames', headerName : 'Customers'},
                {id : 'bookValue', headerName : 'Book value'},
                {id : 'optionDate', headerName : 'Option date'},
                {id : 'requestedBy', headerName : 'Requested by'},
                {id : 'createdOn', headerName : 'Created on'}
            ];
        } else if(tabName === 'ARCHIVED'){
            columnHeadersList = [
                {id : 'spvID', headerName : 'SPV ID'},
                {id : 'spvNumber', headerName : 'SPV number'},
                {id : 'spvName', headerName : 'SPV name'},
                {id : 'customerNames', headerName : 'Customers'},
                {id : 'updatedOn', headerName : 'Archival date'},
                {id : 'createdBy', headerName : 'Created by'},
                {id : 'createdOn', headerName : 'Created on'}
            ];
        }
        return columnHeadersList;
    }

    getGridColumnHeaders(columnHeadersList){
        var gridColumnHeadersList = [];

        columnHeadersList.forEach((element)=>{
            if(element.id === 'spvID'){
                return;
            }
            var tempColumnHeader = {
                id : element.id,
                Header: element.headerName,
                accessor: element.id,
                // headerClassName: 'theader',
                sortable: false,
                filterable: true
            };
            tempColumnHeader.filterMethod = (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.CASE_STARTS_WITH , keys: [element.id] });
            tempColumnHeader.filterAll= true;

            if(element.id === "customerNames" || element.id==="spvName"){
                tempColumnHeader.Cell = row => (
                    <div style = {{overflow : 'hidden', whiteSpace: 'normal', textOverflow : 'ellipsis', display:'-webkit-box', WebkitLineClamp : '2', WebkitBoxOrient:'vertical'}}>
                    {row.value}
                    </div>
                ) 
            }

            if(['optionDate', 'createdOn', 'updatedOn'].indexOf(element.id) >= 0){
                tempColumnHeader.filterMethod = (filter, rows) => matchSorter(rows, filter.value, { threshold: matchSorter.rankings.EQUAL , keys: [element.id] });
                tempColumnHeader.Filter = ({ filter, onChange }) => (<div className="form-group row view_search">
                <div className="col-sm-6 table_input_search" style={{ width: '100%' }}>
                    <input type="text"
                        onChange={event => onChange(event.target.value)} class="form-control" 
                        placeholder="All" value={filter ? filter.value : ''}
                        style={{
                            width: '100%',
                            height: '44px'
                        }} />
                </div>
                <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                    <Icon name="calendar-small" size="small" />
                </div>
            </div>);
            } else {
                tempColumnHeader.Filter= ({ filter, onChange }) => (
                    <div className="form-group row view_search">
                        <div className="col-sm-6 table_input_search" style={{ width: '95%' }}>
                            <input type="text" onChange={event => onChange(event.target.value)}
                                class="form-control" placeholder="All" value={filter ? filter.value : ''}
                                style={{ width: '100%', height: '44px' }} />
                        </div>
                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '-61px' }}>
                            <Icon name="search-small" size="small" />
                        </div>
                    </div>
                    );
            }
            gridColumnHeadersList.push(tempColumnHeader);
        })

        return gridColumnHeadersList;
    }

    render() {
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btndisable = true;
        //check memberOf
        //Asset_Add_PropertyTax
        //Asset_Add_SubArea
       // if(this.state.memberOfDetail == "rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser"){
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Asset_Add") { 
                    btndisable = false;
                }
            }
       // }
        
        console.log("Button disabled");
        console.log(btndisable);

        return (
            <div className="assetpage container-fluid">
                { this.state.isHttpError ? 
                    <Notification status='error' size='small' className="Confirmation_header_new" >{this.state.httpErrorMessage}</Notification> : null
                } 
                <div>
                    <label className="model_title" style={{margin:'15px 0 0 15px', lineHeight:'1.5'}}>Assets</label>
                    <div className="inner_header">
                    
                        <div className={"col-sm-4 new_party_btn " + (btndisable ? 'disabledLabel' : '')}>
                            <Icon name="plus-xsmall" size='small' /> <label className="uploadDocument" onClick={this.addParty.bind(this)}> Add new asset</label>
                        </div>
                        <Tabs selected = {this.state.selectedTab} onSelect = {this.handleOnTabChange.bind(this)}
                        style={{ margin: '20px 0 0 0', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }} 
                        headerStyle={{backgroundColor: '#f5f5f5', color: '#ad1982', fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'pointer'}} 
                        activeHeaderStyle={{ backgroundColor: '#ffffff', color: '#42145f',fontSize: '16px', fontFamily: 'RNFontRegularWoff', cursor: 'default' }}>
                            <Tab label="Active">
                                <div className="grid_layout">
                                <AssetGridComponent selectedRecord={parseInt(this.state.recordView)} columns={this.state.gridColumnHeaders.active} customerRecord= {this.state.gridData.active} loading ={this.state.loading}/>
                                    <span class="select-wrap -pageSizeOptions select_record">
                                        <span className="select_page">Per page</span>                                       
                                        <Select
                                            defaultValue='20'
                                            suggestions={['20', '40', '60', '80', '100']}
                                            className='select_row_customer'
                                            isError={false}
                                            onChange={this.HandleSelectChange.bind(this)}
                                        />
                                    </span>
                                </div>
                            </Tab>
                            <Tab label="In Progress">
                                <div className="grid_layout">
                                <AssetGridComponent selectedRecord={parseInt(this.state.recordView)} columns={this.state.gridColumnHeaders.inProgress} customerRecord= {this.state.gridData.inProgress} loading ={this.state.loading} />
                                <span class="select-wrap -pageSizeOptions select_record">
                                        <span className="select_page">Per page</span>                                       
                                        <Select
                                            defaultValue='20'
                                            suggestions={['20', '40', '60', '80', '100']}
                                            className='select_row_customer'
                                            isError={false}
                                            onChange={this.HandleSelectChange.bind(this)}
                                        />
                                    </span>
                                </div>
                             </Tab>
                             <Tab label="Pending Approval">
                             <div className="grid_layout">
                             <AssetGridComponent selectedRecord={parseInt(this.state.recordView)} columns={this.state.gridColumnHeaders.pendingApproval} customerRecord= {this.state.gridData.pendingApproval} loading ={this.state.loading}/>
                                 <span class="select-wrap -pageSizeOptions select_record">
                                        <span className="select_page">Per page</span>                                       
                                        <Select
                                            defaultValue='20'
                                            suggestions={['20', '40', '60', '80', '100']}
                                            className='select_row_customer'
                                            isError={false}
                                            onChange={this.HandleSelectChange.bind(this)}
                                        />
                                    </span> 
                                </div>
                             </Tab>
                            <Tab label="Archived">
                            <div className="grid_layout">
                            <AssetGridComponent selectedRecord={parseInt(this.state.recordView)} columns={this.state.gridColumnHeaders.archived} customerRecord= {this.state.gridData.archived} loading ={this.state.loading}/>
                                <span class="select-wrap -pageSizeOptions select_record">
                                        <span className="select_page">Per page</span>                                       
                                        <Select
                                            defaultValue='20'
                                            suggestions={['20', '40', '60', '80', '100']}
                                            className='select_row_customer'
                                            isError={false}
                                            onChange={this.HandleSelectChange.bind(this)}
                                        />
                                    </span>
                                </div>
                             </Tab>
                        </Tabs>
                    </div>
                </div>
            </div>
        )
    }

}

const mapStateToProps = state => {
    console.log("receive user notification data");
    console.log(state.dataFormat);
    // return { usernotifications: state.user };
    return {
        // notifications: Object.assign({}, state.user),
         locale: state.dataFormat,
    }
    
};

const viewAssets = connect(mapStateToProps)(viewAssetList);

export default viewAssets;
