import React from 'react';
import help from '../../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import { Icon } from '@zambezi/sdk/icons';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import { getCurrencySymbol , spvstatusArray} from './assetConstants';
import moment from 'moment';

class PropertyOptionComponent extends React.Component {
    constructor(props){
        super(props);
        this.state = props.optiondata;
        this.state.spvstatusBol = props.spvstatusBol;
        this.getOptionDate = this.getOptionDate.bind(this,'optionDate');
        this.getEarliestNoticeDate = this.getEarliestNoticeDate.bind(this,'earliestNoticeDate');
        this.getLatestNoticeDate = this.getLatestNoticeDate.bind(this,'latestNoticeDate');
    }
    getOptionDate(type, e){
        this.updateEditedOptionFlag();
        var startDate =moment(Date.parse(e)).format('YYYY-MM-DD');
        this.setState({[type]:startDate}, () => {
            this.props.optiondata[type] = this.state[type];
        })
    }
    getEarliestNoticeDate(type, e){
        this.updateEditedOptionFlag();
        var startDate =moment(Date.parse(e)).format('YYYY-MM-DD');
        this.setState({[type]:startDate}, () => {
            this.props.optiondata[type] = this.state[type];
        })
    }
    getLatestNoticeDate(type, e){
        this.updateEditedOptionFlag();
        var startDate =moment(Date.parse(e)).format('YYYY-MM-DD');
        this.setState({[type]:startDate}, () => {
            this.props.optiondata[type] = this.state[type];
        })
    }
    componentWillReceiveProps(props){
        let _updatedData = Object.assign(this.state, props.optiondata)
        this.setState({_updatedData})
    }
    handleOnChange (e) {
        const name = e.target.name;
        //const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        // const spvstatusBol = (typeof this.state.optionID != "undefined") ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.dealOptionFlag && this.state.dealOptionFlag !== 2)) ? 3 : this.state.dealOptionFlag;
        let value = e.target.value;
        let newVal =""; 
        if(name ==="optionStrikePrice" || name ==="upfrontOptionPremium" ||  name ==="paidPremium"){
            var regex= /^[0-9,]{0,23}.[0-9]{0,2}$/;
            if(!regex.test(value) ){
                if(value === ""){
                    value ="";
                }else {
                    return ;
                }
            }
        }else {
            if(value !==""){
                if(value.length > e.target.maxLength){
                    newVal = value.substring(value.length-1, value);
                }
            }else {
                // TODO for blank case
            }
        }
        
        this.setState({dealOptionFlag : optnflag , [name]:value}, () => {
            this.props.optiondata.dealOptionFlag = this.state.dealOptionFlag;
            this.props.optiondata[name] = this.state[name];
        })
    }
    updateEditedOptionFlag(){
        const optnflag = (this.state.spvstatusBol && (null != this.state.dealOptionFlag && this.state.dealOptionFlag !== 2)) ? 3 : this.state.dealOptionFlag;
        this.setState({dealOptionFlag : optnflag},() => {
            this.props.optiondata.dealOptionFlag = this.state.dealOptionFlag;
        });
    }
    checkApprovalStatus(status){
        this.updateEditedOptionFlag();
        this.setState({'optionType': status}, () =>{
            this.props.optiondata.optionType = this.state.optionType;
        })
    }
    render() {
        const isEditMode = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        const data = this.state
       // console.log("frompropertyoptions>>>", data);
        return (
            <div className="optioncontainer" data-option= {data.propertyoptionID}>
                <div className="row">
                    <label className="col-sm-4 col-form-label field_label_model" ><b>Option {this.props.index}</b>
                         <FlyoutTrigger showOn='hover' position='bottom' flyout={<Flyout> Lorem Ipsum</Flyout>}>
                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    
                    <label className={"col-sm-6 field_label activeColor removeOptn contentright " + (this.props.fucntDisable && isEditMode ? 'disabledLabel' : '')}><span  onClick= { ()=> {this.props.removeOption(this)}}><Icon name="trash-small" size="small" />Remove Option</span></label>
                </div>
                <div className="form-group row">
                    <label className="col-sm-4 col-form-label field_label">Option type</label>
                    <div className="col-sm-8">
                        <div className="approvalSelectBtn_grp">
                            <div className="btn-group">
                                <button disabled={this.props.fucntDisable} type="button" onClick={this.checkApprovalStatus.bind(this, '0')} className={"btn btn-primary selectBtn " + (this.state.optionType == "0" ? 'dealtype_selected' : 'dealtype_notselected')} >Call</button>
                                <button disabled={this.props.fucntDisable} type="button" onClick={this.checkApprovalStatus.bind(this, '1')} className={"btn btn-primary selectBtn " + (this.state.optionType == "1" ? 'dealtype_selected' : 'dealtype_notselected')} >Put</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="form-group row">
                    <label htmlFor="optionStrikePrice" className="col-sm-4 col-form-label field_label" >Option strike price
                         <FlyoutTrigger showOn='hover' position='bottom' flyout={<Flyout> Option strike price is  the sum of Option strike price of all deals linked with area on this SPV  </Flyout>}>
                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-6">
                        <input disabled={this.props.fucntDisable} type="text" maxLength="25" value={data.optionStrikePrice} name="optionStrikePrice" onChange={this.handleOnChange.bind(this)} 
                            className="form-control input_Fields" placeholder="Enter" />
                    </div>
                    <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                </div>
                <div className="form-group row">
                    <label htmlFor="upfrontOptionPremium" className="col-sm-4 col-form-label field_label" >Upfront option premium
                         <FlyoutTrigger showOn='hover' position='bottom' flyout={<Flyout> Upfront option premium  is sum of  the upfront of option premium of all deals linked with area to this SPV </Flyout>}>
                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-6">
                        <input disabled={this.props.fucntDisable} type="text" value={data.upfrontOptionPremium}  maxLength="25" name="upfrontOptionPremium" onChange={this.handleOnChange.bind(this)} 
                            className="form-control input_Fields" placeholder="Enter" />
                    </div>
                    <label className="col-sm-1 col-form-label field_label currencySymbol" > {getCurrencySymbol()}</label>
                </div>
                <div className="form-group row">
                    <label htmlFor="paidPremium" className="col-sm-4 col-form-label field_label" >Premium paid at option exercise date
                         <FlyoutTrigger showOn='hover' position='bottom' flyout={<Flyout> Premium paid at option exercise date   is the sum of the Premium paid at option exercise date of all deals linked with area on this SPV  </Flyout>}>
                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-6">
                        <input disabled={this.props.fucntDisable} type="text" value={data.paidPremium} maxLength="25" name="paidPremium" onChange={this.handleOnChange.bind(this)} 
                            className="form-control input_Fields" placeholder="Enter" />
                    </div>
                    <label className="col-sm-1 col-form-label field_label currencySymbol" > {getCurrencySymbol()}</label>
                </div>
                <Calenderinputfield isDisabled={this.props.fucntDisable} fieldTitle="Option date" value={data.optionDate} inputType="date" onChange={this.getOptionDate} name="optionDate" placeholder="DD/MM/YYYY" />
                <Calenderinputfield isDisabled={this.props.fucntDisable} fieldTitle="Earliest notice date" onChange={this.getEarliestNoticeDate} value={data.earliestNoticeDate} inputType="date" name="earliestNoticeDate" placeholder="DD/MM/YYYY" />
                <Calenderinputfield isDisabled={this.props.fucntDisable} fieldTitle="Latest notice date" onChange={this.getLatestNoticeDate} value={data.latestNoticeDate} inputType="date" name="latestNoticeDate" placeholder="DD/MM/YYYY" />
            </div>
        )
    }
}

export default PropertyOptionComponent;
