import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import Pagination from '../../commonComponents/pagination';
import { Route, withRouter } from 'react-router-dom';

class assetGridComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentpageSize: "5",
            customerRecord: [],
            // loading: false,
            // selected: null
        }
    }

    render() {
        console.log(this.props.customerRecord);
        const columns = [];
        
        this.props.columns.forEach((column) => {
            var temp = {...column};
            columns.push(temp)
        })

        return <ReactTable
            data={this.props.customerRecord}
            // columns={this.props.columns}
            columns={columns}
            loading={this.props.loading}
            showPagination = {true}
            showPaginationTop = {false}
            showPaginationBottom = {true}
            showPageSizeOptions = {true}
            className= 'tabledata'
            defaultPageSize = {5}
            pageSize={this.props.selectedRecord}
            PaginationComponent={Pagination}
            onFilteredChange = {undefined}
            defaultSortDesc = {false}
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            noDataText= 'No rows found'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
            filterable
            defaultFilterMethod={(filter, row) =>
                String(row[filter.id]) === filter.value}
            getTrProps={(state, rowInfo) => {
                if (rowInfo && rowInfo.row) {
                    return {
                        onClick: (e) => {
                            this.setState({
                                selected: rowInfo.index
                            });
                            this.props.history.push({
                                pathname: '/lms/asset',
                                state: { spvID: rowInfo.original.spvID, isNewAsset: false }
                            })
                        },
                        style: {
                            background: rowInfo.index === this.state.selected ? '#009FAC' : 'white',
                            color: rowInfo.index === this.state.selected ? 'white' : 'black'
                        }
                    }
                } else {
                    return {}
                }
            }
            }
        />
    }
}

export default withRouter(assetGridComponent);