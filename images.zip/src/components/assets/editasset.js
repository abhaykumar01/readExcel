import React from 'react';
import { API_ENDPOINT } from '../../config/config';
import { HttpGet } from '../../services/api.js';
import SPVFormContainer from './spvformcontainer';
//import {dummydata} from './assetConstants';
import '../../index.css';

class editAsset extends React.Component {
    constructor(props) {
        super(props);
        console.log(">>>>>>>>>>>>>>>>>>EDIT>>>>>>>>>>>>>>>>>>>>>>");
        const notification = {"isSucess":false, "isUniqueAreaNameError" : false, "fetching":false, "disableSaveBtn":false}
        this.state= {...notification}
    }
    componentDidMount() {
         const spvId = localStorage.getItem('spvId');
        const api = API_ENDPOINT.ASSET_LIST +"/" +  spvId
        var currentComponent = this;

      HttpGet(currentComponent, api).then((response) => {
            this.state.fetching = true;
            this.setState({...this.state, ...response.data});
            
        })
        .catch((error) => {
                new Error(error);
        })  
    }
    render() {
        return (
            <div className="assetpage container-fluid">
            { this.state.fetching ?  
                <SPVFormContainer data= {this.state}/> : null }
            </div>
        )
    }
}
export default editAsset;

