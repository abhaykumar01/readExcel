import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import viewAssets from './viewAssetList';
import Adapter from 'enzyme-adapter-react-16';
import InputField from '../../commonComponents/inputField';
import renderer from 'react-test-renderer';
import Dropdown from '../../commonComponents/dropdown';
import SearchInput from '../../commonComponents/searchinput';
import { create } from "react-test-renderer";
import { BrowserRouter as Router } from 'react-router-dom';

Enzyme.configure({ adapter: new Adapter() });

let wrapper;
beforeEach(() => {
    wrapper = shallow(<viewAssets />);
});

describe('Customer component', () => {
    test('should shallow correctly', () => {
        expect(wrapper).toMatchSnapshot()
    })
    test('should mount correctly', () => {
        expect(mount(
            <Router>
                <viewAssets />
            </Router>
        )).toMatchSnapshot()
    })
    test('should render correctly', () => {
        expect(render(
            <Router>
                <viewAssets />
            </Router>
        )).toMatchSnapshot()
    })

    test('should render Five <button>', () => {
        expect(wrapper.find('button')).toHaveLength(0);
    });
});