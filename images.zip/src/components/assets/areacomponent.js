import React, { Fragment } from 'react';
import { Select } from '@zambezi/sdk/dropdown-list';
import Accordion from '@zambezi/sdk/accordion';
import { API_ENDPOINT } from '../../config/config';
import { HttpGet } from '../../services/api.js';
import { Icon } from '@zambezi/sdk/icons';
import { ComboBox } from '@zambezi/sdk/dropdown-list'
import { generatedataType, subareaLimit, taxchargeLimit, defaultsubarea, defaultTax, spvstatusArray, modalMessage, dealstatusArray, getCurrencySymbol } from './assetConstants';
import SubAreaComponent from './subareaComponent';
import TaxChargesComponent from './taxchargesComponent';
import { Notification } from '@zambezi/sdk/notification';
import ModalPopup from './modal';

class AreaComponent extends React.Component {
    constructor(props) {
        super(props);
        const customer = { 'customerArray': [] }
        this.state = { ...props.data, ...customer };
        this.state.spvstatusBol = props.parentData.spvstatusBol;
        this.state.areaRemoval = false;
    }
    componentWillMount() {
        this.validateSubAreaTotalPercentage();
        if (typeof this.props.parentData.customerArray === "undefined") {
            const api = API_ENDPOINT.GET_CUSTOMER_NAME
            let currentComponent = this;
            HttpGet(currentComponent, api).then((response) => {
                this.state.customerArray.push(response.data)
                this.setState({ ...this.state }, () => {
                    this.props.parentData.customerArray = this.state.customerArray;
                    this.setCustomerName();
                })
            })
                .catch((error) => {
                    new Error(error);
                })
        } else {
            this.setState({ 'customerArray': this.props.parentData.customerArray }, () => {
                this.setCustomerName();
            })
        }


        if (this.state.subAreaList.length > 0) {
            const subareaList = this.state.subAreaList
            for (var i = 0; i < subareaList.length; i++) {
                subareaList[i].subareaID = i + 1;
            }
        }

        if (this.state.areaTaxList.length > 0) {
            const taxList = this.state.areaTaxList
            for (var j = 0; j < taxList.length; j++) {
                taxList[j].taxId = j + 1;
            }
        }
    }
    componentWillReceiveProps(props) {
        let _updatedData = Object.assign(this.state, props.data)
        this.setState({ _updatedData })
    }
    handleOnChange(e) {
        const name = e.target.name;
        // const spvstatusBol = typeof this.state.areaID != "undefined"  ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.areaFlag && this.state.areaFlag !== 2)) ? 3 : this.state.areaFlag;
        let value = e.target.value;
        let newVal =""; 
        if(name ==="extensionPeriod" ||  name ==="vacantPossessionValue" || name==="reLetValue" || name === "areaSize"){
            var regex = /^[0-9,]{0,50}.[0-9]{0,2}$/;
            if( name ==="areaSize"){ regex = /^[0-9]{0,6}$/}
            if(name ==="extensionPeriod"){regex = /^[0-9,]{0,23}.[0-9]{0,2}$/}
            if(!regex.test(value) ){
               if(value === ""){
                    value ="";
                }else {
                    return ;
                }
            }

        } else {
            if (value.length > e.target.maxLength) {
                value = value.substring(value.length - 1, value);
            }
        }

        if (name === 'areaSize') {
            const areaSquareMetre = value;
            const buildingSquareMetre = this.props.parentData.lettableArea;
            const buildingRLV = this.props.parentData.reLetValue;
            const buildingVPV = this.props.parentData.vacantPossessionValue;

            if (areaSquareMetre && buildingSquareMetre) {
                if (areaSquareMetre > 0 && buildingSquareMetre > 0) {
                    this.state.reLetValue = (areaSquareMetre / buildingSquareMetre) * buildingRLV;
                    this.state.vacantPossesionValue = (areaSquareMetre / buildingSquareMetre) * buildingVPV;
                } else {
                    this.state.reLetValue = buildingRLV;
                    this.state.vacantPossesionValue = buildingVPV;
                }
            } else {
                this.state.reLetValue = buildingRLV;
                this.state.vacantPossesionValue = buildingVPV;
            }
            this.props.data.reLetValue = this.state.reLetValue;
            this.props.data.vacantPossesionValue = this.state.vacantPossesionValue;
            this.setState(this.state);
        }

        if (name === 'areaName') {
            this.setState({ uniqueNameError: false, uniqueNameErrorMessage: '' }, () => {
                this.props.data.uniqueNameError = false;
                this.props.data.uniqueNameErrorMessage = "";
            });
        }
        this.setState({ areaFlag: optnflag, [name]: value }, () => {
            this.props.data.areaFlag = this.state.areaFlag;
            this.props.data[name] = this.state[name]
        });
    }
    handleDropDownChange(event, val, type) {
        //const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false;
        // const spvstatusBol = typeof this.state.areaID != "undefined"  ? true : false;
        const optnflag = (this.state.spvstatusBol && (null != this.state.areaFlag && this.state.areaFlag !== 2)) ? 3 : this.state.areaFlag;
        this.setState({ areaFlag: optnflag, [event]: type.value }, () => {
            this.props.data.areaFlag = this.state.areaFlag;
            this.props.data[event] = this.state[event];
        })
    }
    clickSelect(val) {
        const optnflag = (this.state.spvstatusBol && (null != this.state.areaFlag && this.state.areaFlag !== 2)) ? 3 : this.state.areaFlag;
        const custArray = this.state.customerArray[0];
        let custID = "";
        for (var i = 0; i < custArray.length; i++) {
            var curr = custArray[i];
            if (curr.partyName === val) {
                custID = curr.partyID;
                break;
            }
        }
        this.setState({ areaFlag: optnflag, partyID: custID }, () => {
            this.props.data.partyID = this.state.partyID;
            //this.props.data.customerID = this.state.customerID;
        });
    }

    setCustomerName() {
        if (this.state.customerArray && this.state.customerArray.length > 0) {
            const custArray = this.state.customerArray[0];
            if (null != this.state.partyID) {
                for (let i = 0; i < custArray.length; i++) {
                    if (custArray[i].partyID === this.state.partyID) {
                        this.setState({ customerName: custArray[i].partyName });
                    }
                }
            }
        }
    }

    addsubarea() {
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if (typeof this.state.areaCount !== "undefined" && this.state.subareaCount == subareaLimit) { return }
        if (typeof this.state.subareaCount !== 'undefined') {
            this.state.subareaCount = this.state.subareaCount + 1
        } else {
            this.state.subareaCount = this.state.subAreaList.length > 0 ? this.state.subAreaList.length + 1 : 1
        }
        if (this.state.subareaCount <= subareaLimit) {
            let subarea = { ...defaultsubarea, 'subareaID': this.state.subareaCount }
            subarea.subAreaFlag = (this.state.spvstatusBol) ? 2 : 0;
            const modfiedState = this.state.subAreaList.concat(subarea)
            this.setState({
                subAreaList: modfiedState
            }, () => {
                this.props.data.subAreaList = this.state.subAreaList
            });
        }
    }
    removeSubArea = (param, event) => {
        event.stopPropagation();
        this.state.removedsubArea = typeof this.state.removedsubArea != "undefined" ? this.state.removedsubArea : []
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        /// no modal required for sub area
        const newState = this.state.subAreaList.filter((item) => {
            if (param.props.data.subareaID === item.subareaID) {
                item.subAreaFlag = !this.state.spvstatusBol || (param.state.subAreaFlag && param.state.subAreaFlag === 2) ? 0 : 1;
                this.state.removedsubArea.push(item)
            }

            return param.props.data.subareaID != item.subareaID
        })
        this.setState({
            subAreaList: newState
        }, () => {
            this.props.data.removedsubArea = this.state.removedsubArea;
            this.props.data.subAreaList = this.state.subAreaList;
            this.validateSubAreaTotalPercentage();
        });


    }
    validateSubAreaTotalPercentage = () => {
        let totalSubAreaPercentage = this.state.subAreaList.reduce((currentSum, currentVal) => {
            let total = currentSum + parseFloat(currentVal.subAreaPercent);
            return +total.toPrecision(5);
        }, 0);
        let errostatus = false;
        if (totalSubAreaPercentage !== 100) { errostatus = true }
        this.setState({
            'totalSubAreaPercentage': totalSubAreaPercentage,
            'totalSubAreaError': errostatus
        }, () => {
            this.props.data.totalSubAreaPercentage = this.state.totalSubAreaPercentage
        });
    }
    addTaxCharge() {
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        if (typeof this.state.taxCount !== "undefined" && this.state.taxCount == taxchargeLimit) { return }
        if (typeof this.state.taxCount !== 'undefined') {
            this.state.taxCount = this.state.taxCount + 1
        } else {
            this.state.taxCount = this.state.areaTaxList.length > 0 ? this.state.areaTaxList.length + 1 : 1
        }
        if (this.state.taxCount <= taxchargeLimit) {
            let taxcharge = { ...defaultTax, 'taxId': this.state.taxCount }
            taxcharge.areaTaxFlag = (this.state.spvstatusBol) ? 2 : 0
            const modfiedState = this.state.areaTaxList.concat(taxcharge)
            this.setState({
                areaTaxList: modfiedState
            }, () => {
                this.props.data.areaTaxList = this.state.areaTaxList
            });
        }
    }
    removeTaxArea = (param, event) => {
        event.stopPropagation();
        this.state.removedTaxCharge = typeof this.state.removedTaxCharge != "undefined" ? this.state.removedTaxCharge : []
        // const spvstatusBol = spvstatusArray.indexOf(localStorage.getItem('spvStatus')) >= 0 ? true : false
        const newState = this.state.areaTaxList.filter((item) => {
            if (param.props.data.taxId === item.taxId) {
                item.areaTaxFlag = !this.state.spvstatusBol || (param.state.areaTaxFlag && param.state.areaTaxFlag === 2) ? 0 : 1;
                this.state.removedTaxCharge.push(item);
            }
            return param.props.data.taxId != item.taxId
        })
        this.setState({
            areaTaxList: newState
        }, () => {
            this.props.data.removedTaxCharge = this.state.removedTaxCharge;
            this.props.data.areaTaxList = this.state.areaTaxList;
        });
    }

    removeArea() {
        let dealLinked = false;
        if (this.state.dealStatus !== null && dealstatusArray.indexOf(this.state.dealStatus) >= 0) {
            dealLinked = this.state.dealStatus;
        }
        this.setState({ "areaRemoval": true, "dealLinked": dealLinked });
    }

    onConfirmAreaRemoval() {
        this.setState({ areaRemoval: false }, () => {
            this.props.removearea(this);
        })
    }

    closemodal = () => {
        const closeObj = {
            "areaRemoval": false,
        }
        this.setState(closeObj);
    }

    fnDisableAreaName() {
        if (localStorage.getItem('spvStatus') === "Active") {
            const statusNotin = ["Approved", "Signed", "Active"];
            return (statusNotin.indexOf(this.state.dealStatus) >= 0);
        } else {
            return false;
        }

    }
    render() {

        // console.log("from:arerender", this.state);
        const customer = this.state.customerArray.length > 0 ? this.state.customerArray[0].map((c) => c.partyName) : []
        const subarea = this.state.subAreaList.map((item, index) => {
            if (item.subAreaFlag !== 1) {
                return <SubAreaComponent key={item.subareaID} parentData={this.state} data={item} validatePercentage={this.validateSubAreaTotalPercentage} index={index + 1} removesubarea={this.removeSubArea} />
            }
        })
        const taxarea = this.state.areaTaxList.map((item, index) => {
            if (item.areaTaxFlag !== 1) {
                return <TaxChargesComponent fucntDisable={this.props.fucntDisable} key={item.taxId} parentData={this.state} data={item} index={index + 1} removetax={this.removeTaxArea} />
            }
        })
        const dealLinkedMsg = dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? `The area you are trying to remove has a linked deal to it in ${this.state.dealLinked} status, please remove the link before proceeding` : modalMessage["areaMsg"];
        const disableAreaName = this.fnDisableAreaName();
        return (
            <Fragment>
                {this.state.areaRemoval ?
                    <ModalPopup headerTitle="Remove Area" className={'assetpageModal'} open={this.state.areaRemoval} confirmBtnText={dealstatusArray.indexOf(this.state.dealLinked) >= 0 ? "" : "Yes, remove this area"} confirm={this.onConfirmAreaRemoval.bind(this)} close={this.closemodal} data={this.state} modalbody={dealLinkedMsg} /> : null}

                <Accordion className="areaComponent" >
                    <dt open={true} >Area {this.props.index} <span className="accordianRightlabel" onClick={this.removeArea.bind(this)}><Icon name="trash-small" size="small" />Remove area</span></dt>
                    <div className="">
                        <div className="form-group row">
                            <label htmlFor="areaName" className="col-sm-4 col-form-label field_label" >Unique area name</label>
                            <div className="col-sm-6">
                                <input disabled={disableAreaName} type="text" maxLength="50" onChange={this.handleOnChange.bind(this)} name="areaName" value={this.state.areaName}
                                    className={this.state.uniqueNameError ? "form-control input_Fields error_message" : "form-control input_Fields"} placeholder="Enter" />
                            </div>
                        </div>

                        {this.state.uniqueNameError ?
                            <div className="form-group row">
                                <div className="col-sm-4 "></div>
                                <div className="col-sm-6" >
                                    <Notification status='error' size='small' withArrow arrowPosition='10px' className="error_notification">{this.state.uniqueNameErrorMessage}</Notification>
                                </div>
                            </div>
                            : null}

                        <div className="form-group row">
                            <label htmlFor="partyID" className="col-sm-4 col-form-label field_label" >Customer name</label>
                            <div className="col-sm-6">
                                <ComboBox
                                    aria-label='Combo box example'
                                    suggestions={customer}
                                    defaultValue={this.state.customerName}
                                    placeholder='Search...'
                                    isDisabled={disableAreaName ? true : false}
                                    inputProps={{
                                        autoCapitalize: 'false',
                                        spellCheck: true,
                                        tabIndex: 10
                                    }}
                                    onSuggestionSelected={(e, { suggestion }) => {
                                        //console.log('Selected', suggestion)
                                        this.clickSelect(suggestion);
                                    }}
                                />
                            </div>
                        </div>
                        <div className="form-group row">
                            <label className="col-sm-4 col-form-label field_label">Area by use</label>
                            <div class="col-sm-6" style={{ "display": "flex" }}>
                                <div>
                                    <Select title="" defaultValue={this.state.areaByUse} onChange={this.handleDropDownChange.bind(this, 'areaByUse')} suggestions={generatedataType['areabyUse']} placeholder='Select' className="font_config_custom" multiple />
                                </div>

                                <label htmlFor="areaSize" className="squaremeterlabel col-form-label field_label" >Square meters (Optional)</label>
                                <input type="text" maxLength="6" onChange={this.handleOnChange.bind(this)} name="areaSize" value={this.state.areaSize} className="form-control input_Fields squaremeterinput" placeholder="Enter" />

                            </div>
                        </div>

                                <div className="form-group row">
                                    <label htmlFor="vacantPossessionValue" className="col-sm-4 col-form-label field_label" >VPV</label>
                                    <div className="col-sm-6">
                                        <input type="text" disabled={this.props.fucntDisable} maxLength="25" onChange={this.handleOnChange.bind(this)} name="vacantPossesionValue" value={this.state.vacantPossesionValue}
                                            className="form-control input_Fields" placeholder="Enter" />
                                    </div>
                                    <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                                </div> 
                        
                        <div className="form-group row">
                            <label htmlFor="reLetValue" className="col-sm-4 col-form-label field_label" >RLV</label>
                            <div className="col-sm-6">
                                <input type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="reLetValue" value={this.state.reLetValue}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label className="col-sm-1 col-form-label field_label currencySymbol" >{getCurrencySymbol()}</label>
                        </div>
                        <div className="form-group row">
                            <label htmlFor="extensionPeriod" className="col-sm-4 col-form-label field_label" >Extension period</label>
                            <div className="col-sm-5">
                                <input type="text" maxLength="25" onChange={this.handleOnChange.bind(this)} name="extensionPeriod" value={this.state.extensionPeriod}
                                    className="form-control input_Fields" placeholder="Enter" />
                            </div>
                            <label htmlFor="extensionPeriod" className="col-form-label field_label">years</label>

                        </div>
                        <div className="form-group row" style={{ 'marginBottom': '10px' }}>
                            <label className="col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor"> <span onClick={this.addTaxCharge.bind(this)}><Icon name="plus-xsmall" size="small" /> <span>Add Tax/charges</span></span></label>
                        </div>
                        {(this.state.subAreaList.length > 0) ?
                            <div className="optioncontainer">
                                <div className="form-group row">
                                    <label className="col-sm-4 col-form-label field_label"><b>Proportion of area (%) </b></label>
                                </div>
                                {subarea}
                                <div className="form-group row">
                                    <label className="col-sm-4 col-form-label field_label">Total</label>
                                    <div className="col-sm-2">
                                        <input type="number" readOnly className="form-control input_Fields" placeholder="Enter" value={this.state.totalSubAreaPercentage} />
                                    </div>
                                </div>
                                <div className="col-sm-6 col-sm-offset-4">
                                    {this.state.totalSubAreaError ?
                                        <Notification status='error' size='small' withArrow arrowPosition='20px' className="error_notification">Total proportion area must be 100% </Notification>
                                        : ""}</div>
                            </div> : ""}

                        {taxarea}
                        <div className="form-group row" style={{ 'marginBottom': '0px' }}>
                            <label className="col-xs-8 col-xs-offset-4 field_label labelcorpparent activeColor"  > <span onClick={this.addsubarea.bind(this)}><Icon name="plus-xsmall" size="small" /> <span>{(this.state.subAreaList.length > 0 ? "Add another sub-area" : "Add sub-area")}</span></span></label>
                        </div>
                    </div>
                </Accordion>
            </Fragment>
        )
    }
}
export default AreaComponent;
