import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import Customer from './customer';
import Adapter from 'enzyme-adapter-react-16';
import InputField from '../../commonComponents/inputField';
import renderer from 'react-test-renderer';
import Form from '../../commonComponents/form';
import Dropdown from '../../commonComponents/dropdown';
import SearchInput from '../../commonComponents/searchinput';
import Header from '../../commonComponents/header';
import { BrowserRouter as Router } from 'react-router-dom';
import { create } from "react-test-renderer";

Enzyme.configure({ adapter: new Adapter() });


let wrapper1;
    beforeEach(() => {
        wrapper1 = shallow(<Customer />);
    });

describe('Customer component', () => {
    test('should shallow correctly', () => {
        expect(wrapper1).toMatchSnapshot() 
    })
    test('should mount correctly', () => {
        expect(mount(
          <Customer />
        )).toMatchSnapshot() 
    })
    test('should render correctly', () => {
        expect(render(
          <Customer />
        )).toMatchSnapshot() 
    })

    test('should render one <form>', () => {
        expect(wrapper1.find('form')).toHaveLength(4);
    });

    test('should render Five <button>', () => {
        expect(wrapper1.find('button')).toHaveLength(4);
    });

    test('onClick called', () => {
        const mockOnClick = jest.fn();
        const wrapper = shallow(<Customer onClick={mockOnClick} />)
        wrapper.find('button#btt').simulate('click', 'junk')
        expect(mockOnClick.mock.calls.length).toEqual(0)
    });
    it('should be handling cancelRegistration function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().cancelRegistration()).toEqual(true);
      });
    it('should be handling saveUserData function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().saveUserData()).toEqual(true);
    });
    it('should be handling validateField function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().validateField()).toEqual(true);
    });
    it('should be handling handleChange function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().handleChange()).toEqual(true);
    });
    test('Should render dropdown component', () => {
        const dropdownField = wrapper1.find(Dropdown).at(0).dive()
        expect(dropdownField.children()).toHaveLength(1);
    });
    test('Should render dropdown component', () => {
        const dropdownField = wrapper1.find(Dropdown).at(1).dive()
        expect(dropdownField.children()).toHaveLength(1);
    });
    test('Should render dropdown component', () => {
        const dropdownField = wrapper1.find(Dropdown).at(2).dive()
        expect(dropdownField.children()).toHaveLength(1);
    });
    test('Should render dropdown component', () => {
        const dropdownField = wrapper1.find(Dropdown).at(3).dive()
        expect(dropdownField.children()).toHaveLength(1);
    });
    test('Should render dropdown component', () => {
        const dropdownField = wrapper1.find(Dropdown).at(4).dive()
        expect(dropdownField.children()).toHaveLength(1);
    });
    test('Should render InputField component', () => {
        const inputField = wrapper1.find(InputField).at(0).dive()
        expect(inputField.children()).toHaveLength(1);
    });
    test('Should render InputField component', () => {
        const inputField = wrapper1.find(InputField).at(1).dive()
        expect(inputField.children()).toHaveLength(1);
    });
    test('Should render InputField component', () => {
        const inputField = wrapper1.find(InputField).at(2).dive()
        expect(inputField.children()).toHaveLength(1);
    });
    test('Should render InputField component', () => {
        const inputField = wrapper1.find(InputField).at(3).dive()
        expect(inputField.children()).toHaveLength(1);
    });
    test('Should render InputField component', () => {
        const inputField = wrapper1.find(InputField).at(4).dive()
        expect(inputField.children()).toHaveLength(1);
    });
    test('Should render SearchInput component', () => {
        const searchInput = wrapper1.find(SearchInput).at(0).dive()
        expect(searchInput.children()).toHaveLength(3);
    });
    it('should be handling selectDealType function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().addMoreSPV()).toEqual(true);
    });

    it('should be handling selectDealType function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().deleteMoreSPV()).toEqual(true);
    });
    it('should be handling selectDealType function', () => {
        const wrapper1 = shallow(<Customer />);
        expect(wrapper1.instance().getDropdownItem()).toEqual(true);
    });
  });

  describe('Render Header', () => {
        it('Render Header component correctly', () => {   
            const header = shallow(
                <Router>
                    <Header />
                </Router>);   
                expect(header).toMatchSnapshot();
        });
  });



  describe('Render SearchInput', () => {
    it('Render search component correctly', () => {      
        const DropdownComponent = renderer.create(<SearchInput />).toJSON();    
        expect(DropdownComponent).toMatchSnapshot();
    });

    it('render SearchInput correctly with null value', () => {      
        const props = {
            value: "",
            onChange: () => { return {value}}
        },        
        SearchInputComponent = mount(<SearchInput {...props} />);    
        expect((SearchInputComponent).prop('value')).toEqual("");
    });

    it('check the type of value', () => {      
        const props = { value: "Monika" },       
        SearchInputComponent = mount(<SearchInput {...props} />);    
        expect(SearchInputComponent.prop('value')).toBeString;
    });

    it('renders Search input with label (default type)', () => {
        const wrapper = mount(<SearchInput name="spv" fieldTitle="SPV" />);
        const label = wrapper.find('label');
        expect(label.text()).toEqual('SPV');
        const select = wrapper.find('input');
        expect(select.prop('name')).toEqual('spv');
        // expect(input.prop('placeholder')).toEqual('Customer name');
    });
    
  });

  const moment = "2013-11-18T19:55:00+08:00";
describe('Render Input', () => {

    it('Render input component correctly', () => {      
        const InputComponent = renderer.create(<InputField />).toJSON();    
        expect(InputComponent).toMatchSnapshot();
    });

    it('render input correctly with null value', () => {      
        const props = {
            value: "",
            onChange: () => { return {value}}
        },        
        InputComponent = mount(<InputField {...props} />);    
        expect((InputComponent).prop('value')).toEqual("");
    });

    it('check the type of value', () => {      
        const props = { value: "Monika" },       
        InputComponent = mount(<InputField {...props} />);    
        expect(InputComponent.prop('value')).toBeString;
    });

    it('renders text input with label (default type)', () => {
        const wrapper = mount(<InputField name="customername" fieldTitle="Customer name" />);
        const label = wrapper.find('label');
        expect(label.text()).toEqual('Customer name');
        const input = wrapper.find('input');
        expect(input.prop('name')).toEqual('customername');
        // expect(input.prop('placeholder')).toEqual('Customer name');
    });
    it('renders Credit rating input with label given the type', () => {
        const wrapper = mount(<InputField type="number" name="creditrating" fieldTitle="Credit rating" />);
        const label = wrapper.find('label');
        expect(label).toHaveLength(1);
        expect(label.text()).toEqual('Credit rating');
        const input = wrapper.find('input');
        // expect(input.prop('type')).toEqual('number');
        expect(input.prop('name')).toEqual('creditrating');
      });

      it('renders a email input', () => {
        expect(shallow(<InputField />).find('input').length).toEqual(1)
       })
    });

    let wrapper2;

    beforeEach(() => {
        wrapper2 = shallow(<Form/>);
    });

    describe('<Form /> rendering', () => {
    it('renders correctly', () => {
        expect(wrapper2).toMatchSnapshot();
    });

    it('should render one <form>', () => {
        expect(wrapper2.find('form')).toHaveLength(1);
    });

});