import React from 'react';
import './customer.css';
import Dropdown from '../../commonComponents/dropdown';
import Inputfield from '../../commonComponents/inputField.js';
import Searchinputfield from '../../commonComponents/searchinput.js';
import { RegisterParty } from '../../models/dataModel.js';
import { HttpPost, HttpGet } from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { validate } from '../../utils/validation.js';
import '../../index.css';
import moment from 'moment';
import { Icon } from '@zambezi/sdk/icons';
import Popup from '../../commonComponents/popupMessage';
import Calenderinputfield from '../../commonComponents/calenderInputCustomerCustom.js';

import ButtonGroup from '@zambezi/sdk/button-group';
import { Notification } from '@zambezi/sdk/notification';
import {Checkbox}  from '@zambezi/sdk/form-elements';
import Accordion from '@zambezi/sdk/accordion';
import {
    DropdownListTrigger,
    SelectDropdownList,
    MultiSelectDropdownList,
    DropdownList
} from '@zambezi/sdk/dropdown-list'
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;

class addCustomer extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);

        this.state = this.getInitialState();

        this.handleChange = this.handleChange.bind(this);
        //this.getAnnualRateReviewDate = this.getAnnualRateReviewDate.bind(this);

    }

    getInitialState = () => {
        const initialState = {
            optionState1: [0],
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            userData:[],
            accessType: true,
            partyTypeSelect: true,
            saveButtonStatus: true,
            success_status: false,
            partyType: "",
            customerName: "",
            customerType: "Primary",
            customerSector: "",
            companytype: "",
            isAllowedToAllUsers:0,
            CISCode: "",
            orgNumber: "",
            mgs: "",
            mgsError: "",
            mgsErrorMessage: "",
            kycStatus: "",
            peers: "",
            webpage: "",
            webpageTextError: false,
            webpageTextErrorMessage: "",
            customerStatus: "",
            fieldErrorStatus: true,
            customerNameError: false,
            customerNameErrorMessage: "",
            customerTypeError: false,
            customerTypeErrorMessage: "",
            peers_tooltiptext: "Enter the names of competitors to the customer",

            creditratingError: "",
            creditratingErrorMessage: "",
            ratingsourceError: "",
            ratingsourceErrorMessage: "",
            ratingsourcewebpageError: "",
            ratingsourcewebpageErrorMessage: "",
            annualReviewDate:"",

            postcodeError: false,
            postcodeErrorMessage: "",
            contactNameError: "",
            contactNameErrorMessage: "",
            contactOfficeNumberError: "",
            contactOfficeNumberErrorMessage: "",
            addressLineError: "",
            addressLineErrorMessage: "",
            addressLine2Error: "",
            addressLine2ErrorMessage: "",
            mobileNumberError: "",
            mobileNumberErrorMessage: "",
            emailError: "",
            emailErrorMessage: "",
            countryError: false,
            countryErrorMessage: '',
            mandateField: true,
            cityErrorMessage: '',
            //  server_success_message: "",
            spvNumber: [],
            spvCount: [2, 3, 4, 5, 6, 7, 8, 9, 10],
            spvItemCount: ["2", "3", "4", "5", "6", "7", "8", "9", "10"],
            userNumber: [],
            userCount: [2, 3, 4, 5, 6, 7, 8, 9, 10],
            userItemCount: ["2", "3", "4", "5", "6", "7", "8", "9", "10"],
            relationNumber: [],
            relationCount: [2, 3, 4, 5, 6, 7, 8, 9, 10],
            creditNumber: [],
            creditCount: [2, 3],
            contactNumber: [],
            contactCount: [2, 3, 4, 5, 6, 7, 8, 9, 10],
            initialRatingSourceData: [{ val: "S&P", isSelected: false },
            { val: "Fitch", isSelected: false },
            { val: "Moody's", isSelected: false }],
            companyCountry: "",
        };
        return initialState;
    }
    selectAccessType(accesstype) {
        console.log("Deal type", accesstype);
        if (accesstype === 'Allow') {
            this.setState({ accessType: true,
                isAllowedToAllUsers:0 
            });
        } else {
            this.setState({ accessType: false,
                isAllowedToAllUsers:1 
            });
        }
        return true;
    }
    
    getAllUsers(){
        var currentComponent = this;
            let endPoint = API_ENDPOINT.GET_ALL_USERS;
            console.log("Service call");
            HttpGet(currentComponent, endPoint).then(function (response) {
                console.log(response);
                if(response.data != undefined && response.data.length > 0 && response.data != null){
                    for(var i =0 ; i < response.data.length ; i++){
                        response.data[i].isChecked=false;
                    }
                }
                console.log(response.data);
                currentComponent.setState({
                    userData: response.data
                });
            }).catch(function (error) {
                console.log("Error received");
                console.log(error);
            })
        
    }
    generateState() {
        var spvState = {};
        var userState = [];
        var userObject = {
            name: '',
        };
        var relationState = [];
        var relationobject = {
            id: 0,
            name: '',
            type: 'Parent company'
        };
        var partyRest=[];
        var partyObj= {
            userID:'',
            userName:'',
            racfID:'',
        };
        var creditState = [];
        var creditobject = {
            rating: '',
            source: '',
            webpage: '',
            ratingError: false,
            ratingErrorMessage: '',
            sourceError: false,
            sourceErrorMessage: '',
            webpageError: false,
            webpageErrorMessage: '',
        };
        var contactState = [];
        var contactobject = {
            name: '',
            role: '',
            officeno: '',
            moobileno: '',
            email: '',
            address1: '',
            address2: '',
            city: '',
            postcode: '',
            country: '',
            nameError: false,
            nameErrorMessage: '',
            officeError: false,
            officeErrorMessage: '',
            mobileError: false,
            mobileErrorMessage: '',
            emailError: false,
            emailErrorMessage: '',
            addressError: false,
            addressErrorMessage: '',
            address2Error: false,
            address2ErrorMessage: '',
            cityError: false,
            cityErrorMessage: '',
            postcodeError: false,
            postcodeErrorMessage: '',
            countryError: false,
            countryErrorMessage: ''
        };
        for (let i = 0; i < this.state.spvItemCount.length; i++) {
            spvState[this.state.spvItemCount[i]] = '';
        }
        for (let j = 0; j < 10; j++) {
            relationobject.id = j + 2;
            relationobject.name = '';
            relationobject.type = 'Parent company';
            userObject.name = '';
            var obj = JSON.parse(JSON.stringify(relationobject));
            relationState.push(obj);
            var obj1 = JSON.parse(JSON.stringify(contactobject));
            contactState.push(obj1);
            var obj2 = JSON.parse(JSON.stringify(userObject));
            userState.push(obj2);
            // contactState.push(contactobject);
        }
        for (let j = 0; j < 3; j++) {
            creditobject.rating = '';
            creditobject.source = '';
            creditobject.webpage = '';
            var obj = JSON.parse(JSON.stringify(creditobject));
            creditState.push(obj);
        }
        // console.log(creditState);
        this.setState({ spvState, userState, relationState, creditState, contactState, partyRest }, function () {
            console.log("user count");
            console.log(this.state.relationState);
            console.log(this.state.spvState);
            console.log(this.state.userState);
        });

    }

    componentDidMount() {
        this.getAllUsers();
        this.generateState();
        this.getSelectedIndex('customer');
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }

    cancelRegistration = () => {
        localStorage.setItem('datasave', 'false');
        localStorage.setItem('datachange', 'false');
        //    console.log("Cancel registration");/generateState
        this.setState(this.getInitialState(), function () {
            this.setState(this.generateState());
        });
        return true;
    }

    // getAnnualRateReviewDate(e){
    //     if (e != null) {
    //     var endDate = Date.parse(e);
    //     this.state.annualRateReviewDate = moment(endDate).format('YYYY-MM-DD');
    // }      
    //     return true;
    // }
    addMoreSPV(type) {
        if (type == "spv") {
            if (this.state.spvCount[0] != undefined) {
                var joined = this.state.spvNumber.concat(this.state.spvCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    spvNumber: sort,
                    spvCount: this.state.spvCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        } else if (type == "user") {
            if (this.state.userCount[0] != undefined) {
                var joined = this.state.userNumber.concat(this.state.userCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    userNumber: sort,
                    userCount: this.state.userCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        } else if (type == "relation") {
            if (this.state.relationCount[0] != undefined) {
                var joined = this.state.relationNumber.concat(this.state.relationCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    relationNumber: sort,
                    relationCount: this.state.relationCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        } else if (type == "credit") {
            if (this.state.creditCount[0] != undefined) {
                var joined = this.state.creditNumber.concat(this.state.creditCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    creditNumber: sort,
                    creditCount: this.state.creditCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        } else if (type == "contact") {
            if (this.state.contactCount[0] != undefined) {
                var joined = this.state.contactNumber.concat(this.state.contactCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    contactNumber: sort,
                    contactCount: this.state.contactCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        }

        return true;
    }
    deleteMoreSPV(type, index, no, source) {
        console.log(no);
        console.log("Source::", source);
        if (type == "spv") {
            this.state.spvCount.unshift(no);
            this.state.spvCount.sort(function (a, b) { return a - b; });
            this.state.spvState[no] = '';
            this.setState({
                spvNumber: this.state.spvNumber.filter((_, i) => i !== index)
            }, function () {
            });
        } else if (type == "user") {
            this.state.userCount.unshift(no);
            this.state.userCount.sort(function (a, b) { return a - b; });
            this.state.userState[no - 1].name = '';
            this.setState({
                userNumber: this.state.userNumber.filter((_, i) => i !== index)
            }, function () {
            });
        } else if (type == "relation") {
            this.state.relationCount.unshift(no);
            this.state.relationCount.sort(function (a, b) { return a - b; });
            this.setState({
                relationNumber: this.state.relationNumber.filter((_, i) => i !== index)
            }, function () {
            });
        } else if (type == "credit") {
            this.state.creditCount.unshift(no);
            this.state.creditCount.sort(function (a, b) { return a - b; });
            this.state.creditState[no - 1].rating = '';
            this.state.creditState[no - 1].source = '';
            this.state.creditState[no - 1].webpage = '';
            this.setState({
                creditNumber: this.state.creditNumber.filter((_, i) => i !== index)
            }, function () {
            });
            console.log("Delete SPV");
            let data = [...this.state.initialRatingSourceData];
            for (var sample of data) {
                if (sample.val == source) {
                    sample.isSelected = false;
                }
            }
            this.setState({ data }, function () {
                console.log("data after getDropdownItem", this.state.initialRatingSourceData);
            });
        } else if (type == "contact") {
            this.state.contactCount.unshift(no);
            this.state.contactCount.sort(function (a, b) { return a - b; });
            this.state.contactState[no - 1].name = '';
            this.state.contactState[no - 1].role = '';
            this.state.contactState[no - 1].officeno = '';
            this.state.contactState[no - 1].moobileno = '';
            this.state.contactState[no - 1].email = '';
            this.state.contactState[no - 1].address1 = '';
            this.state.contactState[no - 1].address2 = '';
            this.state.contactState[no - 1].city = '';
            this.state.contactState[no - 1].postcode = '';
            this.state.contactState[no - 1].country = '';
            // this.state.contactCount.sort(function (a, b) { return a - b; });
            this.setState({
                contactNumber: this.state.contactNumber.filter((_, i) => i !== index)
            }, function () {
            });
        }
        return true;
    }

    saveUserData() {
        this.validateField();
        return true;
    }

    saveParty() { 
        var currentComponent = this;
        //pass this.state.racfDetail into RegsiterParty below
        let payLoadData = RegisterParty(this.state, this.state.count);
        console.log("Call service234324");
        console.log(this.state.creditratingErrorMessage);
        // debugger;
        if (this.state.customerNameErrorMessage == "" && this.state.customerTypeErrorMessage == "" && this.state.mgsErrorMessage == "" &&
            this.state.contactNameErrorMessage == "" && this.state.addressLineErrorMessage == "" &&
            this.state.mobileNumberErrorMessage == "" && this.state.contactOfficeNumberErrorMessage == "" &&
            this.state.emailErrorMessage == "" && this.state.postcodeErrorMessage == "" &&
            this.state.countryErrorMessage == "" && this.state.cityErrorMessage == "" &&
            this.state.addressLine2ErrorMessage == "" && this.state.ratingsourcewebpageErrorMessage == "" &&
            this.state.webpageTextErrorMessage == "" && this.state.creditratingErrorMessage == "") {
            console.log("service response");
            console.log(payLoadData);
            //only in case of allow not in restrict
            if (this.state.isAllowedToAllUsers == 0) {//{get access to all}  	
                payLoadData.isAllowedToAllUsers = 0;
            }
            else {
                payLoadData.isAllowedToAllUsers = 1;
            }
            let output = HttpPost(currentComponent, payLoadData, API_ENDPOINT.CREATE_PARTY)
                .then(function (response) {
                    localStorage.setItem('datasave', 'true');
                    // currentComponent.setState({server_success_message: response.data});
                    localStorage.setItem("approver", 'false');                    
                    localStorage.setItem('userID', response.data.partyID);
                    localStorage.setItem('userStatus', response.data.partyStatus);
                    localStorage.setItem('partyFlag', 'MAIN');
                    currentComponent.props.history.push({
                        pathname: '/lms/viewCustomerDetail',
                        state: { rowID: response.data.partyID , status: response.data.partyStatus }
                    })
                })
                .catch(function (error) {
                    currentComponent.setState({ success_status: false });
                })
        } else { 
            console.log("Page error");
        }
        
    }

    validateField() {

        let v = validate('customername', this.state.customerName);
        console.log("Validate field");
        console.log(v);
        // debugger;
        if (v[0] == null) {
            this.setState({ customerNameError: false, customerNameErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ customerNameError: !v[0], customerNameErrorMessage: v[1] }, function () { 
                console.log("after data update1");
            });
        }
        let v1 = validate('customertype', this.state.customerType);
        console.log("Validate field");
        console.log(v1);
        if (v1[0] == null) {
            this.setState({ customerTypeError: false, customerTypeErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ customerTypeError: !v1[0], customerTypeErrorMessage: v1[1] }, function () {
                console.log("after data update2");
            });
        }

        let v2 = validate('contactname', this.state.contactState["0"].name);
        if (v2[0] == null) {
            this.setState({ contactNameError: false, contactNameErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ contactNameError: !v2[0], contactNameErrorMessage: v2[1] }, function () {
                console.log("after data update3");
            });
        }

        let v3 = validate('address', this.state.contactState["0"].address1);
        if (v3[0] == null) {
            this.setState({ addressLineError: false, addressLineErrorMessage: v3[1] });
        } else if (v3[0] != null) {
            this.setState({ addressLineError: !v3[0], addressLineErrorMessage: v3[1] }, function () {
                console.log("after data update4");
            });
        }

        let v4 = validate('mobilenumber', this.state.contactState["0"].moobileno);
        if (v4[0] == null) {
            this.setState({ mobileNumberError: false, mobileNumberErrorMessage: v4[1] });
        } else if (v4[0] != null) {
            this.setState({ mobileNumberError: !v4[0], mobileNumberErrorMessage: v4[1] }, function () {
                console.log("after data update5");
            });
        }

        let v5 = validate('officenumber', this.state.contactState["0"].officeno);
        if (v5[0] == null) {
            this.setState({ contactOfficeNumberError: false, contactOfficeNumberErrorMessage: v5[1] });
        } else if (v5[0] != null) {
            this.setState({ contactOfficeNumberError: !v5[0], contactOfficeNumberErrorMessage: v5[1] }, function () {
                console.log("after data update6");
            });
        }

        let v6 = validate('email', this.state.contactState["0"].email);
        if (v6[0] == null) {
            this.setState({ emailError: false, emailErrorMessage: v6[1] });
        } else if (v6[0] != null) {
            this.setState({ emailError: !v6[0], emailErrorMessage: v6[1] }, function () {
                console.log("after data update7");
            });
        }

        let v7 = validate('postcode', this.state.contactState["0"].postcode);
        if (v7[0] == null) {
            this.setState({ postcodeError: false, postcodeErrorMessage: v7[1] });
        } else if (v7[0] != null) {
            this.setState({ postcodeError: !v7[0], postcodeErrorMessage: v7[1] }, function () {
                console.log("after data update8");
            });
        }

        let v8 = validate('country', this.state.contactState["0"].country);
        if (v8[0] == null) {
            this.setState({ countryError: false, countryErrorMessage: v8[1] });
        } else if (v8[0] != null) {
            this.setState({ countryError: !v8[0], countryErrorMessage: v8[1] }, function () {
                console.log("after data update9");
                this.saveParty();
            });
        }

        localStorage.setItem('errorStatus', 'false');
        console.log("CustomernameStatus");
        console.log(this.state.customerNameErrorMessage);
        // debugger;
        

        // setTimeout(function () {
        //     if (this.state.customerNameErrorMessage != "" || this.state.customerTypeErrorMessage != "" ||
        //         this.state.contactNameErrorMessage != "" || this.state.addressLineErrorMessage != "" ||
        //         this.state.mobileNumberErrorMessage != "" || this.state.contactOfficeNumberErrorMessage != "" ||
        //         this.state.emailErrorMessage != "" || this.state.postcodeErrorMessage != "" ||
        //         this.state.countryErrorMessage != "") {
        //         console.log("Inside main error")
        //         localStorage.setItem('errorStatus', 'true');
        //     }
        // }, 3000);

        // for (var i = 0; i < this.state.creditNumber.length; i++) {
        //     if (this.state.creditState[((parseInt(i+1) - 1)).toString()].ratingErrorMessage == "" || this.state.creditState[((parseInt(i+1) - 1)).toString()].webpageErrorMessage == "") {
        //         console.log("Inside credit error")
        //         localStorage.setItem('errorStatus', 'true');
        //     }
        // }

        // for (var i = 0; i < this.state.contactNumber.length; i++) {
        //     if (this.state.contactState[((parseInt(i+1) - 1)).toString()].nameErrorMessage != "" || this.state.contactState[((parseInt(i+1) - 1)).toString()].officeErrorMessage == "" ||
        //         this.state.contactState[((parseInt(i+1) - 1)).toString()].mobileErrorMessage != "" || this.state.contactState[((parseInt(i+1) - 1)).toString()].emailErrorMessage != "" ||
        //         this.state.contactState[((parseInt(i+1) - 1)).toString()].addressErrorMessage != "" || this.state.contactState[((parseInt(i+1) - 1)).toString()].address2ErrorMessage != "" ||
        //         this.state.contactState[((parseInt(i+1) - 1)).toString()].cityErrorMessage != "" || this.state.contactState[((parseInt(i+1) - 1)).toString()].postcodeErrorMessage != "" ||
        //         this.state.contactState[((parseInt(i+1) - 1)).toString()].countryErrorMessage != "") {
        //         console.log("Inside Contact error")
        //         localStorage.setItem('errorStatus', 'true');
        //     }
        // }

        // let v8 = validate('city', this.state.contactState["0"].city);
        // if (v8[0] == null) {
        //      this.setState({ cityError: true, cityErrorMessage: v8[1] });
        // } else if (v8[0] != null) {
        //      this.setState({ cityError: !v8[0], cityErrorMessage: v8[1] });
        // }


        // let v9= validate('addressline2', this.state.contactState["0"].address2);
        // if (v9[0] == null) {
        //       this.setState({ addressLine2ErrorError: true, addressLine2ErrorMessage: v9[1] });
        // } else if (v9[0] != null) {
        //       this.setState({ addressLine2Error: !v9[0], addressLine2ErrorMessage: v9[1] });
        // }

        // let v10 = validate('webpage', this.state.creditState["0"].webpage);
        // if (v10[0] == null) {
        //     this.setState({ ratingsourcewebpageError: true, ratingsourcewebpageErrorMessage: v10[1] });
        // } else if (v10[0] != null) {
        //     this.setState({ ratingsourcewebpageError: !v10[0], ratingsourcewebpageErrorMessage: v10[1] });
        // }

        // let v11 = validate('webpageText', this.state.webpage);
        // if (v11[0] == null) {
        //     this.setState({ webpageTextError: true, webpageTextErrorMessage: v11[1] });
        // } else if (v11[0] != null) {
        //     this.setState({ webpageTextError: !v11[0], webpageTextErrorMessage: v11[1] });
        // }



        return true;
    }

    getDropdownItem(event, ID, val, type) {
        if (event == "partyrelationtype") {
            // this.state.relationState[e.target.id] = val;
        } else if (event == "country") {
            var _ID = ((parseInt(ID)) - 1).toString();
            this.state.contactState[_ID.toString()].country = type.value;
            let v = validate('country', type.value);
            if (ID == "1") {
                if (v[0] == null) {
                    this.setState({ countryError: false, countryErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ countryError: !v[0], countryErrorMessage: v[1] });
                }
            } else {
                if (v[0] == null) {
                    this.state.contactState[_ID.toString()].countryError = false;
                    this.state.contactState[_ID.toString()].countryErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.contactState[_ID.toString()].countryError = !v[0];
                    this.state.contactState[_ID.toString()].countryErrorMessage = v[1];
                }
                this.forceUpdate();
            }
        }
        else if (event == "companycountry") {
            console.log("companycountry::  ", type.value);
            if (type.value != "") {
               
                //this.state.companyCountry = type.value;
                this.setState({companyCountry : type.value});
                 console.log("companyCountry state set::  ", this.state.companyCountry);
            } 
        } else if (event == "relationtype") {
            if (type.value != "") {
                var _ID = ((parseInt(ID)) - 1).toString();
                this.state.relationState[_ID.toString()].type = type.value;
            } else {

            }
        } else if (event === "customertype") {
            this.setState({ customerType: type.value });
            let v = validate('customertype', type.value);
            if (v[0] == null) {
                this.setState({ customerTypeError: false, customerTypeErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ customerTypeError: !v[0], customerTypeErrorMessage: v[1] });
            }
        } else if (event === "companytype") {
            this.setState({ companytype: type.value });
        } else if (event === "MGS") {
            this.setState({ mgs: type.value });
        } else if (event === "kyc") {
            this.setState({ kycStatus: type.value });
        } else if (event === "customerSector") {
            this.setState({ customerSector: type.value });
        } else if (event === "ratingsource") {
            var _ID = ((parseInt(ID)) - 1).toString();
            var previousVal = this.state.creditState[_ID.toString()].source;

            this.state.creditState[_ID.toString()].source = type.value;
            let data = [...this.state.initialRatingSourceData];
            console.log("Selected ratingsource value-->" + type.value + " /data=", data)
            for (var sample of data) {
                if (sample.val == type.value) {
                    sample.isSelected = true;
                } else if (sample.val == previousVal) {
                    sample.isSelected = false;
                }
            }
            this.setState({ data }, function () {
                console.log("data after getDropdownItem", this.state.initialRatingSourceData);
            });

            let v = validate('ratingsource', type.value);
            if (ID == "1") {
                if (v[0] == null) {
                    this.setState({ ratingsourceError: false, ratingsourceErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ ratingsourceError: !v[0], ratingsourceErrorMessage: v[1] });
                }
            } else {
                if (v[0] == null) {
                    this.state.creditState[_ID.toString()].ratingsourceErrorMessage = false;
                    this.state.creditState[_ID.toString()].ratingsourceErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.creditState[_ID.toString()].ratingsourceError = !v[0];
                    this.state.creditState[_ID.toString()].ratingsourceErrorMessage = v[1];
                }
                this.forceUpdate();
            }
        }
        return true;
    }



    handleChange = (e) => {
        if (e) {
            var val = e.target.value;
            var dataVal = val.trimLeft();
            if (e.target.name == "spv") {
                this.state.spvState[e.target.id] = dataVal;
            } else if (e.target.name == "mgs") { 
                this.setState({ mgs: dataVal });
                let v = validate('mgs', dataVal);
                console.log("mgs validation::");
                console.log(v);
                if (v[0] == null) {
                    this.setState({ mgsError: false, mgsErrorMessage: v[1] });
                } else if (v[0] != null) {
                    console.log(!v[0]);
                    this.setState({ mgsError: !v[0], mgsErrorMessage: v[1] });
                }
            } else if (e.target.name == "useraccess") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.userState[ID.toString()].name = dataVal;
                // this.state.userState[e.target.id] = dataVal;
            } else if (e.target.name == "partyrelationname") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.relationState[ID.toString()].name = dataVal;
            } else if (e.target.name == "creditrating") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.creditState[ID.toString()].rating = dataVal;
                let v = validate('creditrating', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ creditratingError: false, creditratingErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ creditratingError: !v[0], creditratingErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.creditState[ID.toString()].ratingError = false;
                    //     this.state.creditState[ID.toString()].ratingErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.creditState[ID.toString()].ratingError = !v[0];
                    //     this.state.creditState[ID.toString()].ratingErrorMessage = v[1];
                    // }
                }
            } else if (e.target.name == "ratingsource") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.creditState[ID.toString()].source = dataVal;
            } else if (e.target.name == "ratingsourcewebpage") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.creditState[ID.toString()].webpage = dataVal;

                let v = validate('webpage', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ ratingsourcewebpageError: false, ratingsourcewebpageErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ ratingsourcewebpageError: !v[0], ratingsourcewebpageErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.creditState[ID.toString()].webpageError = false;
                    //     this.state.creditState[ID.toString()].webpageErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.creditState[ID.toString()].webpageError = !v[0];
                    //     this.state.creditState[ID.toString()].webpageErrorMessage = v[1];
                    // }
                }
            } else if (e.target.name == "contactname") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].name = dataVal;
                let v = validate('contactname', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ contactNameError: false, contactNameErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ contactNameError: !v[0], contactNameErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.contactState[ID.toString()].nameError = false;
                    //     this.state.contactState[ID.toString()].nameErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.contactState[ID.toString()].nameError = !v[0];
                    //     this.state.contactState[ID.toString()].nameErrorMessage = v[1];
                    // }
                }
            }
            else if (e.target.name == "contactrole") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].role = dataVal;
            }
            else if (e.target.name == "officename") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].officeno = dataVal;
                let v = validate('officenumber', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ contactOfficeNumberError: false, contactOfficeNumberErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ contactOfficeNumberError: !v[0], contactOfficeNumberErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.contactState[ID.toString()].officeError = false;
                    //     this.state.contactState[ID.toString()].officeErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.contactState[ID.toString()].officeError = !v[0];
                    //     this.state.contactState[ID.toString()].officeErrorMessage = v[1];
                    // }
                }
            }
            else if (e.target.name == "mobilenumber") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].moobileno = dataVal;
                let v = validate('mobilenumber', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ mobileNumberError: false, mobileNumberErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ mobileNumberError: !v[0], mobileNumberErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.contactState[ID.toString()].mobileError = false;
                    //     this.state.contactState[ID.toString()].mobileErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.contactState[ID.toString()].mobileError = !v[0];
                    //     this.state.contactState[ID.toString()].mobileErrorMessage = v[1];
                    // }
                }
            }
            else if (e.target.name == "email") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].email = dataVal;
                let v = validate('email', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ emailError: false, emailErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ emailError: !v[0], emailErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.contactState[ID.toString()].emailError = false;
                    //     this.state.contactState[ID.toString()].emailErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.contactState[ID.toString()].emailError = !v[0];
                    //     this.state.contactState[ID.toString()].emailErrorMessage = v[1];
                    // }
                }
            }
            else if (e.target.name == "addressline1") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].address1 = dataVal;
                let v = validate('address', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ addressLineError: false, addressLineErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ addressLineError: !v[0], addressLineErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.contactState[ID.toString()].addressError = false;
                    //     this.state.contactState[ID.toString()].addressErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.contactState[ID.toString()].addressError = !v[0];
                    //     this.state.contactState[ID.toString()].addressErrorMessage = v[1];
                    // }
                }
            }
            else if (e.target.name == "addressline2") {

                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].address2 = e.target.value;
                let v = validate('addressline2', e.target.value);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ addressLine2Error: false, addressLine2ErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ addressLine2Error: !v[0], addressLine2ErrorMessage: v[1] });
                    }
                } else {
                    //  if (v[0] == null) {
                    //      this.state.contactState[ID.toString()].address2Error = false;
                    //      this.state.contactState[ID.toString()].address2ErrorMessage = v[1];
                    //  } else if (v[0] != null) {
                    //      this.state.contactState[ID.toString()].address2Error = !v[0];
                    //      this.state.contactState[ID.toString()].address2ErrorMessage = v[1];
                    //  }
                  }
            } else if (e.target.name == "city") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].city = e.target.value;
                let v = validate('city', e.target.value);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ cityError: false, cityErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ cityError: !v[0], cityErrorMessage: v[1] });
                    }
                } else {
                    //  if (v[0] == null) {
                    //         this.state.contactState[ID.toString()].cityError = false;
                    //         this.state.contactState[ID.toString()].cityErrorMessage = v[1];
                    //  } else if (v[0] != null) {
                    //         this.state.contactState[ID.toString()].cityError = !v[0];
                    //         this.state.contactState[ID.toString()].cityErrorMessage = v[1];
                    //  }
                 }
            } else if (e.target.name == "postcode") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.contactState[ID.toString()].postcode = dataVal;
                let v = validate('postcode', dataVal);
                if (e.target.id == "1") {
                    if (v[0] == null) {
                        this.setState({ postcodeError: false, postcodeErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ postcodeError: !v[0], postcodeErrorMessage: v[1] });
                    }
                } else {
                    // if (v[0] == null) {
                    //     this.state.contactState[ID.toString()].postcodeError = false;
                    //     this.state.contactState[ID.toString()].postcodeErrorMessage = v[1];
                    // } else if (v[0] != null) {
                    //     this.state.contactState[ID.toString()].postcodeError = !v[0];
                    //     this.state.contactState[ID.toString()].postcodeErrorMessage = v[1];
                    // }
                }
            }
            this.setState({ saveButtonStatus: false });
            if (e.target.name === "partyType") {
                this.setState({ partyType: dataVal })
            } else if (e.target.name === "customername") {
                this.setState({ customerName: dataVal })
                let v = validate('customername', dataVal);
                if (v[0] == null) {
                    this.setState({ customerNameError: false, customerNameErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ customerNameError: !v[0], customerNameErrorMessage: v[1] });
                }
            } else if (e.target.name === "customersector") {
                this.setState({ customerSector: dataVal })
            } else if (e.target.name === "ciscode") {
                this.setState({ CISCode: dataVal });
            }  else if (e.target.name === "annualreviewdate") {
                this.setState({ annualReviewDate: dataVal })
            }else if (e.target.name === "orgnumber") {
                this.setState({ orgNumber: dataVal })
            } else if (e.target.name === "peers") {
                this.setState({ peers: dataVal });
            } else if (e.target.name === "webpage") {
                this.setState({ webpage: dataVal });
                let v = validate('webpageText', dataVal);
                if (v[0] == null) {
                    this.setState({ webpageTextError: false, webpageTextErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ webpageTextError: !v[0], webpageTextErrorMessage: v[1] });
                }
            }
        }
        return true;
    }

    getSelectedIndex(type) {
        if (type === 'customer') {
            this.setState({
                partyTypeSelect: true,
                peers_tooltiptext: 'Enter the names of competitors to the customer'
            });
        } else {
            this.setState({
                partyTypeSelect: false,
                peers_tooltiptext: 'Enter the names of competitors to the seller'
            });
        }
        return true;
    }

    generateData(type) {
        const data = [];
        if (type == "companytype") {
            data.push(
                "",
                "Listed",
                "Non-listed",
                "Public Sector"
            );
        } else if (type == 'mgs') {
            data[0] = '';
            for (var i = 1; i < 28; i++) {
                data.push(i);
            }

        } else if (type == "customertype") {
            data.push(
                "",
                "Primary",
                "Secondary",
                "Tenant"
            );
        } else if (type == "kyc") {
            data.push(
                "",
                "Verified",
                "Unverified"
            );
        } else if (type == "relationtype") {
            data.push(
                "",
                "Parent company",
                "Primary customer",
                "Secondary customer"
            );
        } else if (type == "country") {
            data.push(
                "",
                "Denmark",
                "Finland",
                "Norway",
                "Sweden"
            );
        }  else if (type == "companycountry") {
            data.push(
                "",
                "Denmark",
                "Finland",
                "Norway",
                "Sweden"               
            );
        }
        else if (type == "customerSector") {
            data.push(
                "",
                "Retail", "Construction", "Hotel & Leisure", "Automotive",
                "Power Utilities", "Building Materials", "Land Transport and Logistics",
                "Food and consumer", "Airlines & Aerospace","Public", "Chemicals",
                "Financial institutions", "Services", "Other"
            );
        } else if (type == "ratingsource") {
            data.push(
                "",
                "S&P",
                "Fitch",
                "Moody's"
            );
        }

        return data
    }

    genearteRatingData() {
        //this.state.initialRatingSourceData
        const data = [""];
        let len = this.state.initialRatingSourceData.length;
        for (var i = 0; i < len; i++) {
            if (this.state.initialRatingSourceData[i].isSelected == false) {
                data.push(this.state.initialRatingSourceData[i].val);
            }
        }
        console.log("Return source data");
        console.log(data);
        return data;
    }
    selectUser(userId){
        console.log(this.state.userData)
        var completeData = this.state.userData;
        // console.log(completeData);
        if(completeData){
            for(var i =0 ; i < completeData.length ; i++){
                console.log(completeData[i].isChecked)
                if(completeData[i].userID == userId){
                    if(completeData[i].isChecked == false){
                            completeData[i].isChecked=true;
                        }
                        else{
                                completeData[i].isChecked=false;
                        }
                }
            }
            this.setState({
                userData: completeData
            },function(){
                console.log(this.state.userData);
            });

        }
        // console.log(completeData);
}

    render() {
        let racfId = localStorage.getItem('racfID');
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btndisable = false;
        //rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser
        //check memberOf
        //this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0
            if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0){
                // if(this.state.memberOfDetail == "rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser"){
                    for (var i = 0; i < datalen; i++) { 
                        if (perData[i] == "Customer_Edit_Contact") { 
                            btndisable = true;
                        }
                    }
                }
        
        
        console.log("Button disabled");
        console.log(btndisable);

        var showSuccessMessage;
        if(this.state.accessType){

        }
        // if (this.state.success_status == true) {
        //     showSuccessMessage = <div class="Success_msg"><span class="msg_text">{this.state.server_success_message}</span></div>
        // }
        return (
            <div className="background">
                <div className="inner_container" style={{
                    width: '1244px',
                    margin: '30px auto 0px auto'
                }}>

                    <div class="form-group row">
                        <label className="customer_title">Add customer</label>
                    </div>


                    
                    {/* <div class="col-sm-4 customer_type" style={{ marginLeft: '-15px' }}>
                        <div class="btn-group" style={{
                            width: '218px',
                            height: '44px',
                            border: 'solid 1px #c9c6c6',
                            backgroundColor: '#fff'
                        }}>
                            <button type="button" className={"btn btn-primary customer_btn " + (this.state.partyTypeSelect ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.getSelectedIndex.bind(this, 'customer')}>Customer</button>
                            <button type="button" className={"btn btn-primary customer_btn " + (!this.state.partyTypeSelect ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.getSelectedIndex.bind(this, 'seller')}>Seller</button>
                        </div>
                    </div> */}
                    <div className="">
                        <div class="col-xs-12 customer_container" style={{ marginBottom: '24px' }}>
                            <div class="inner_column">
                                <label class="label_title">Company details</label><br/>
                                <label className="mandatory_field">Fields marked with <span style={{color: 'red'}}>*</span> are mandatory</label>
                                <form class="user_form">
                                    <Inputfield fieldTitle="Customer name" maxlength="30" value={this.state.customerName} inputType="text"
                                        name="customername" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.customerNameError}
                                        errorMessage={this.state.customerNameErrorMessage} mandatory={true} />
                                    <Dropdown isDisabled={btndisable} title="Customer type" selectedValue={this.state.customerType} classname="font_config_custom" data={this.generateData('customertype')}
                                        errorStatus={this.state.customerTypeError}
                                        errorMessage={this.state.customerTypeErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'customertype', 1)} />
                                    <Dropdown isDisabled={btndisable} title="Customer sector/sub-sector" selectedValue={this.state.customerSector} classname="font_config_custom" data={this.generateData('customerSector')} errorStatus={false} onChange={this.getDropdownItem.bind(this, 'customerSector', 1)} />
                                    <Dropdown isDisabled={btndisable} title="Company type" selectedValue={this.state.companytype} classname="font_config_custom" data={this.generateData('companytype')} errorStatus={false} onChange={this.getDropdownItem.bind(this, 'companytype', 1)} />
                                    <Inputfield fieldTitle="CIS code" isDisabled={btndisable} helpIcon={true} maxlength="10" helpIconValue="Counterparty Identification System code" helpID="cis" mandateField={!this.state.mandateField} value={this.state.CISCode} inputType="text" name="ciscode" onChange={this.handleChange} placeholder="Enter" />
                                    <Inputfield fieldTitle="Organisation number" isDisabled={btndisable} maxlength="50" mandateField={this.state.mandateField} value={this.state.orgNumber} inputType="text" name="orgnumber" onChange={this.handleChange} placeholder="Enter" />
                                    <Inputfield  isDisabled={btndisable} fieldTitle="Annual Review Date" maxlength="50" mandateField={this.state.mandateField} value={this.state.annualReviewDate} inputType="text" name="annualreviewdate" onChange={this.handleChange} placeholder="DD/MM" />
                                    <Dropdown  isDisabled={btndisable} title="Country" selectedValue={this.state.companyCountry }
                                                classname="font_config_custom" name="companycountry" data={this.generateData('companycountry')}
                                                errorStatus={this.state.countryError} errorMessage={this.state.countryErrorMessage}
                                                onChange={this.getDropdownItem.bind(this, 'companycountry', 1)} />
                                    {/* <div className="row">
                                    <div className="col-sm-8">
                                    <Calenderinputfield classname="font_config_custom" fieldTitle="Annual review date" 
                                     value={this.state.annualRateReviewDate}
                                    inputType="date" name="annualratereviewdate" 
                                     onChange={this.getAnnualRateReviewDate} 
                                    placeholder="DD/MM/YYYY" />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div> */}


                                    <div className="Separator_line"></div>

                                    <label class="label_title" style={{
                                        fontSize: '16px',
                                        marginLeft: '176px'
                                    }}>Credit rating 1</label>

                                    <div className="form-group row">
                                        <div className="col-sm-12">
                                            <label className="col-sm-4 col-form-label field_label_credit">Credit rating</label>
                                            <div className="col-sm-2">
                                                <input type="text" disabled={btndisable} maxlength="10" name="creditrating" id="1"
                                                    onChange={this.handleChange}
                                                    value={this.state.creditState ? this.state.creditState["0"].rating : null}
                                                    className="form-control credit_rating" placeholder="Enter"
                                                />

                                            </div>
                                            <div className="col-sm-6" style={{ marginLeft: '-92px' }}>
                                                <label className="col-sm-3 col-form-label field_label_rating">Rating source</label>
                                                <div className="col-sm-2 rating_source_dropdown">
                                                    <Dropdown

                                                        name="ratingsource" isDisabled={btndisable} id="1" onChange={this.getDropdownItem.bind(this, 'ratingsource', 1)}
                                                        selectedValue={this.state.creditState ? this.state.creditState["0"].source : null}
                                                        data={this.genearteRatingData()}
                                                        selectedvalueMap={this.state.initialRatingSourceData}
                                                    />
                                                </div>
                                            </div>

                                            {
                                                this.state.creditratingError ?
                                                    <div className="form-group row">
                                                        <label className="col-sm-4 col-form-label field_label_model"
                                                            style={{ marginLeft: '0px' }}></label>
                                                        <div className="col-sm-5" style={{ width: '34.7%', marginTop: '10px' }}>
                                                            <Notification
                                                                status='error'
                                                                size='small'
                                                                withArrow
                                                                arrowPosition='14px'
                                                                className="error_notification"
                                                            >
                                                                {this.state.creditratingErrorMessage}
                                                            </Notification>
                                                        </div>
                                                    </div>
                                                    : null
                                            }
                                        </div>
                                    </div>
                                    <Inputfield fieldTitle="Rating source webpage" maxlength="150" id="1" isDisabled={btndisable}
                                        mandateField={this.state.mandateField} inputType="text" name="ratingsourcewebpage"
                                        onChange={this.handleChange} placeholder="Enter"
                                        value={this.state.creditState ? this.state.creditState["0"].webpage : null}
                                        errorStatus={this.state.ratingsourcewebpageError}
                                        errorMessage={this.state.ratingsourcewebpageErrorMessage} />

                                    {this.state.creditNumber.map((object, i) => (
                                        <div>
                                            <label className="col-xs-5 label_title" style={{
                                                fontSize: '16px',
                                                marginLeft: '165px'
                                            }}>Credit rating {object}</label>

                                            <div className="col-xs-3" style={{ marginTop: '25px', marginLeft: '-54px' }}
                                                onClick={this.deleteMoreSPV.bind(this, "credit", i, object, this.state.creditState[((parseInt(object) - 1)).toString()].source)}>
                                                <Icon name="trash-small" size="small" title="" /><span style={{ marginLeft: '5px', position: 'absolute' }}>Remove Credit rating</span>
                                            </div>

                                            <div className="form-group row">
                                                <div className="col-sm-12">
                                                    <label className="col-sm-4 col-form-label field_label_credit">Credit rating</label>
                                                    <div className="col-sm-2">
                                                        <input type="text" maxlength="10"
                                                            value={this.state.creditState[((parseInt(object) - 1)).toString()].rating} name="creditrating" id={object} onChange={this.handleChange} className="form-control credit_rating" placeholder="Enter" />

                                                    </div>



                                                    <div className="col-sm-6" style={{ marginLeft: '-92px' }}>
                                                        <label className="col-sm-3 col-form-label field_label_rating">Rating source</label>
                                                        <div className="col-sm-3 rating_source_dropdown" >
                                                            <Dropdown
                                                                selectedValue={this.state.creditState[((parseInt(object) - 1)).toString()].source}
                                                                name="ratingsource" id={object} data={this.genearteRatingData()}
                                                                onChange={this.getDropdownItem.bind(this, 'ratingsource', object)}
                                                                disable={this.state.creditState[((parseInt(object) - 1)).toString()].source}
                                                                selectedvalueMap={this.state.initialRatingSourceData} />

                                                        </div>
                                                    </div>



                                                </div>



                                                {
                                                    this.state.creditState[((parseInt(object) - 1)).toString()].ratingError ?
                                                        <div className="form-group row">
                                                            <label className="col-sm-4 col-form-label field_label_model"
                                                                style={{ marginLeft: '0px' }}></label>
                                                            <div className="col-sm-5" style={{ width: '34.7%', marginTop: '10px' }}>
                                                                <Notification
                                                                    status='error'
                                                                    size='small'
                                                                    withArrow
                                                                    arrowPosition='14px'
                                                                    className="error_notification"
                                                                >
                                                                    {this.state.creditState[((parseInt(object) - 1)).toString()].ratingErrorMessage}
                                                                </Notification>
                                                            </div>
                                                        </div>
                                                        : null
                                                }


                                            </div>
                                            <Inputfield fieldTitle="Rating source webpage" maxlength="150" id={object}
                                                mandateField={this.state.mandateField}
                                                value={this.state.creditState[((parseInt(object) - 1)).toString()].webpage}
                                                inputType="text" name="ratingsourcewebpage" onChange={this.handleChange}
                                                placeholder="Enter"
                                                errorStatus={this.state.creditState[((parseInt(object) - 1)).toString()].webpageError}
                                                errorMessage={this.state.creditState[((parseInt(object) - 1)).toString()].webpageErrorMessage}
                                            />

                                        </div>
                                    )
                                    )}

                                    <div className="form-group row">
                                        <div className="col-sm-12 add_credit_rating">
                                            <label className="col-sm-3 col-form-label field_label_credit"></label>
                                            <div className={"col-sm-4 add_credit_rating_btn " + (btndisable ? 'disabledLabel' : '')} onClick={this.addMoreSPV.bind(this, "credit")}>
                                                <Icon name="plus-xsmall" size='small' title="" /> <label className="uploadDocument" >Add another credit rating</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="Separator_line"></div>

                                    <div style={{ marginTop: '20px' }}>
                                        <div className="form-group row">
                                            <div className="col-sm-12">
                                                <label className="col-sm-4 col-form-label field_label_credit">MGS</label>
                                                <div className="col-sm-2">
                                                    <input type="text" maxlength="2" disabled={btndisable}
                                                        value={this.state.mgs} name="mgs" id="1" onChange={this.handleChange} className="form-control credit_rating" placeholder="Enter" />

                                                </div>
                                            </div>
                                        </div>

                                        {
                                            this.state.mgsError ?
                                                <div className="form-group row">
                                                    <label className="col-sm-4 col-form-label field_label_model"
                                                        style={{ marginLeft: '0px' }}></label>
                                                    <div className="col-sm-5" style={{ width: '34.7%', marginTop: '10px' }}>
                                                        <Notification
                                                            status='error'
                                                            size='small'
                                                            withArrow
                                                            arrowPosition='14px'
                                                            className="error_notification"
                                                        >
                                                            {this.state.mgsErrorMessage}
                                                        </Notification>
                                                    </div>
                                                </div>
                                                : null
                                        }
                                        {/* <Dropdown title="MGS" classname="font_config_customer" selectedValue={this.state.mgs} data={this.generateData('mgs')}
                                            errorStatus={false} onChange={this.getDropdownItem.bind(this, 'MGS', 1)} /> */}
                                        <Dropdown title="KYC Status" helpIcon={true} isDisabled={btndisable}
                                            selectedValue={this.state.kycStatus}
                                            helpIconValue="Know your customer status" helpID="kyc" classname="font_config_custom" data={this.generateData('kyc')} errorStatus={false} onChange={this.getDropdownItem.bind(this, 'kyc', 1)} />
                                        <Inputfield isDisabled={btndisable} fieldTitle="Peers" maxlength="150" helpIcon={true}
                                            helpIconValue={this.state.peers_tooltiptext} helpID="peers"
                                            mandateField={!this.state.mandateField} value={this.state.peers} inputType="text" name="peers" onChange={this.handleChange} placeholder="Enter" />
                                        <Inputfield isDisabled={btndisable} fieldTitle="Webpage" maxlength="150"
                                            mandateField={!this.state.mandateField}
                                            value={this.state.webpage} inputType="text" name="webpage"
                                            onChange={this.handleChange} placeholder="Enter"
                                            errorStatus={this.state.webpageTextError}
                                            errorMessage={this.state.webpageTextErrorMessage} />
                                    </div>

                                    <div className="Separator_line"></div>

                                    <div class="col-xs-12">
                                        <label class="label_title">Contact details</label>
                                        <form class="form_content">
                                            <label class="label_title" style={{
                                                fontSize: '16px',
                                                marginLeft: '141px'
                                            }}>Contact 1</label>

                                            <Inputfield fieldTitle="Contact name" maxlength="15" id="1"
                                                value={this.state.contactState ? this.state.contactState["0"].name : null}
                                                inputType="text" name="contactname" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.contactNameError}
                                                errorMessage={this.state.contactNameErrorMessage} />
                                            <Inputfield fieldTitle="Contact role" value={this.state.contactState ? this.state.contactState["0"].role : null}
                                                maxlength="30" id="1" inputType="text" name="contactrole" onChange={this.handleChange}
                                                placeholder="Enter" />
                                            <Inputfield fieldTitle="Office number" value={this.state.contactState ? this.state.contactState["0"].officeno : null}
                                                maxlength="15" id="1" inputType="text" name="officename" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.contactOfficeNumberError} errorMessage={this.state.contactOfficeNumberErrorMessage} />
                                            <Inputfield fieldTitle="Mobile number" value={this.state.contactState ? this.state.contactState["0"].moobileno : null}
                                                maxlength="15" id="1" inputType="text" name="mobilenumber" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.mobileNumberError} errorMessage={this.state.mobileNumberErrorMessage} />
                                            <Inputfield fieldTitle="Email address" value={this.state.contactState ? this.state.contactState["0"].email : null}
                                                maxlength="30" id="1" inputType="text" name="email" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.emailError} errorMessage={this.state.emailErrorMessage} />
                                            <Inputfield fieldTitle="Address line 1" value={this.state.contactState ? this.state.contactState["0"].address1 : null}
                                                maxlength="50" id="1" inputType="text" name="addressline1" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.addressLineError} errorMessage={this.state.addressLineErrorMessage} />
                                            <Inputfield fieldTitle="Address line 2" value={this.state.contactState ? this.state.contactState["0"].address2 : null}
                                                maxlength="50" id="1" inputType="text" name="addressline2" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.addressLine2Error} errorMessage={this.state.addressLine2ErrorMessage} />
                                            <Inputfield fieldTitle="City" id="1" value={this.state.contactState ? this.state.contactState["0"].city : null}
                                                maxlength="50" inputType="text" name="city" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.cityError} errorMessage={this.state.cityErrorMessage} />
                                            <Inputfield fieldTitle="Postcode" id="1" value={this.state.contactState ? this.state.contactState["0"].postcode : null}
                                                maxlength="10" inputType="text" name="postcode" onChange={this.handleChange}
                                                placeholder="Enter" errorStatus={this.state.postcodeError} errorMessage={this.state.postcodeErrorMessage} />
                                            <Dropdown title="Country" id="1" selectedValue={this.state.contactState ? this.state.contactState["0"].country : ""}
                                                classname="font_config_custom" name="country" data={this.generateData('country')}
                                                errorStatus={this.state.countryError} errorMessage={this.state.countryErrorMessage}
                                                onChange={this.getDropdownItem.bind(this, 'country', 1)} />
                                        </form>

                                        {this.state.contactNumber.map((object, i) => (

                                            <form class="form_content">
                                                <label class="col-xs-5 label_title" style={{
                                                    fontSize: '16px',
                                                    marginLeft: '141px'
                                                }}>Contact {object}</label>

                                                <div className="col-xs-3" style={{ marginTop: '25px', marginLeft: '6px' }}
                                                    onClick={this.deleteMoreSPV.bind(this, "contact", i, object)}>
                                                    <Icon name="trash-small" size="small" title="" /><span style={{ marginLeft: '5px', position: 'absolute' }}>Remove Contact</span>
                                                </div>

                                                <Inputfield fieldTitle="Contact name" id={object} inputType="text" maxlength="15"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].name} name="contactname"
                                                    onChange={this.handleChange} placeholder="Enter"
                                                    errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].nameError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].nameErrorMessage} />
                                                <Inputfield fieldTitle="Contact role" id={object} inputType="text" maxlength="30"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].role} name="contactrole" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactRoleError} errorMessage={this.state.contactRoleErrorMessage} />
                                                <Inputfield fieldTitle="Office number" id={object} inputType="text" maxlength="15"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].officeno} name="officename" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].officeError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].officeErrorMessage} />
                                                <Inputfield fieldTitle="Mobile number" id={object} inputType="text" maxlength="15"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].moobileno} name="mobilenumber" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].mobileError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].mobileErrorMessage} />
                                                <Inputfield fieldTitle="Email address" id={object} inputType="text" maxlength="30"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].email} name="email" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].emailError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].emailErrorMessage} />
                                                <Inputfield fieldTitle="Address line 1" id={object} inputType="text" maxlength="50"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].address1} name="addressline1" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].addressError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].addressErrorMessage} />
                                                <Inputfield fieldTitle="Address line 2" id={object} inputType="text" maxlength="50"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].address2} name="addressline2" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].address2Error}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].address2ErrorMessage} />
                                                <Inputfield fieldTitle="City" id={object} inputType="text" maxlength="50"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].city} name="city" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].cityError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].cityErrorMessage} />
                                                <Inputfield fieldTitle="Postcode" id={object} inputType="text" maxlength="10"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].postcode} name="postcode" onChange={this.handleChange}
                                                    placeholder="Enter" errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].postcodeError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].postcodeErrorMessage} />
                                                <Dropdown title="Country" id={object} classname="font_config_custom"
                                                    value={this.state.contactState[((parseInt(object) - 1)).toString()].country}
                                                    selectedValue={this.state.contactState[((parseInt(object) - 1)).toString()].country} name="country"
                                                    data={this.generateData('country')}
                                                    errorStatus={this.state.contactState[((parseInt(object) - 1)).toString()].countryError}
                                                    errorMessage={this.state.contactState[((parseInt(object) - 1)).toString()].countryErrorMessage}
                                                    onChange={this.getDropdownItem.bind(this, 'country', object)} />
                                            </form>
                                        )
                                        )}

                                        <div className="form-group row">
                                            <div className="col-sm-12 add_credit_rating">
                                                <label className="col-sm-3 col-form-label field_label_credit"></label>
                                                <div className="col-sm-4 add_credit_rating_btn" onClick={this.addMoreSPV.bind(this, "contact")}>
                                                    <Icon name="plus-xsmall" size='small' title="" /> <label className="uploadDocument" > Add another Contact</label>
                                                </div>
                                            </div>
                                            <div className="col-sm-12" style={{ marginLeft: '-12px' }}>
                                                <div className="Separator_line"></div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* <div class="col-xs-12">
                                        <label class="label_title">Special Purpose Vehicle</label>
                                        <div>
                                            <label class="label_title" style={{
                                                fontSize: '16px',
                                                marginLeft: '242px'
                                            }}>SPV 1</label>
                                            <form class="user_form" style={{ marginTop: '0px' }}>
                                                <Searchinputfield isDisabled={btndisable} fieldTitle="SPV number" maxlength="15" id="1" inputType="text" name="spv" onChange={this.handleChange} placeholder="Search" />

                                            </form>
                                        </div>
                                        {this.state.spvNumber.map((object, i) => (
                                            <div>
                                                <label className="col-xs-5 label_title" style={{
                                                    fontSize: '16px',
                                                    marginLeft: '228px'
                                                }}>SPV {object}</label>

                                                <div className="col-xs-3" style={{ marginTop: '25px', marginLeft: '-49px' }} onClick={this.deleteMoreSPV.bind(this, "spv", i, object)}>
                                                    <Icon name="trash-small" size="small" title="" /><span style={{ marginLeft: '5px', position: 'absolute' }}>Remove SPV</span>
                                                </div>

                                                <form class="user_form" style={{ marginTop: '0px' }}>
                                                    <Searchinputfield isDisabled={btndisable} fieldTitle="SPV number" maxlength="15" value={this.state.spvState[object]} inputType="text" id={object} name="spv" onChange={this.handleChange} placeholder="Search" />

                                                </form>
                                            </div>
                                        )
                                        )}
                                        <div className="form-group row">
                                            <div className="col-sm-12 add_credit_rating">
                                                <label className="col-sm-3 col-form-label field_label_credit"></label>
                                                <div className={"col-sm-4 add_credit_rating_btn " + (btndisable ? 'disabledLabel' : '')} onClick={this.addMoreSPV.bind(this, "spv")}>
                                                    <Icon name="plus-xsmall" size='small' title="" /> <label className="uploadDocument" > Add another SPV</label>
                                                </div>

                                            </div>
                                            <div className="col-sm-12" style={{ marginLeft: '-12px' }}>
                                                <div className="Separator_line"></div>
                                            </div>
                                        </div>
                                    </div> */}

<div className="col-sm-12" style={{ marginLeft: '-12px' }}>
                                                {/* <div className="Separator_line"></div> */}
                                            </div>
                                    <div class="col-xs-12 ">
                                        <label class="label_title">Relationships</label>
                                        <div>
                                            <label class="label_title" style={{
                                                fontSize: '16px',
                                                marginLeft: '171px'
                                            }}>Relationship 1</label>
                                            <form class="user_form" style={{ marginTop: '0px' }}>
                                                <Searchinputfield isDisabled={btndisable} fieldTitle="Customer name" maxlength="50" inputType="text" id="1" name="partyrelationname" onChange={this.handleChange} placeholder="Search" />
                                                <Dropdown isDisabled={btndisable} title="Relationship type" selectedValue={this.state.relationState ? this.state.relationState["0"].type : ""} classname="font_config_custom" data={this.generateData('relationtype')} errorStatus={false} onChange={this.getDropdownItem.bind(this, 'relationtype', 1)} />
                                            </form>
                                        </div>
                                        {this.state.relationNumber.map((object, i) => (
                                            <div>
                                                <label class="col-xs-5 label_title" style={{
                                                    fontSize: '16px',
                                                    marginLeft: '171px'
                                                }}>Relationship {object}</label>

                                                <div className="col-xs-3" style={{ marginTop: '25px', marginLeft: '6px' }} onClick={this.deleteMoreSPV.bind(this, "relation", i, object)}>
                                                    <Icon name="trash-small" size="small" title="" /><span style={{ marginLeft: '5px', position: 'absolute' }}>Remove user</span>
                                                </div>

                                                <form class="user_form" style={{ marginTop: '0px' }}>
                                                    {/* <p>hello {this.state.relationState[((parseInt(object)- 1)).toString()].name}</p> */}
                                                    <Searchinputfield isDisabled={btndisable} fieldTitle="Customer name" maxlength="50" inputType="text" value={this.state.relationState[((parseInt(object) - 1)).toString()].name} name="partyrelationname" id={object} onChange={this.handleChange} placeholder="Search" />
                                                    <Dropdown isDisabled={btndisable} title="Relationship type" selectedValue={this.state.relationState[((parseInt(object) - 1)).toString()].type} classname="font_config_custom" data={this.generateData('relationtype')} errorStatus={false} onChange={this.getDropdownItem.bind(this, 'relationtype', object)} />
                                                </form>
                                            </div>
                                        )

                                        )}
                                        <div className="form-group row">
                                            <div className="col-sm-12 add_credit_rating">
                                                <label className="col-sm-3 col-form-label field_label_credit"></label>
                                                <div className={"col-sm-4 add_credit_rating_btn " + (btndisable ? 'disabledLabel' : '')} onClick={this.addMoreSPV.bind(this, "relation")}>
                                                    {/* <button type="button" class="btn btn-info add_credit_rating_btn" onClick={this.addMoreSPV.bind(this, "relation")}> */}
                                                    <Icon name="plus-xsmall" size='small' title="" /> <label className="uploadDocument" > Add another Relationship</label>
                                                    {/* </button> */}
                                                </div>
                                            </div>
                                            <div className="col-sm-12" style={{ marginLeft: '-12px' }}>
                                                <div className="Separator_line"></div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-xs-12 ">
                                        <label class="label_title">User access</label>
                                        <div class="form-group row" style={{marginLeft:'-3.4em'}}>
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Allow access to all users</label>
                                    <div className="col-sm-4">
                                        <div class="customer_type_model">
                                            <div class="btn-group">
                                                <button type="button" className={"btn btn-primary standard_btn " + (this.state.accessType ? 'customertype_selected' : 'customertype_notselected')} onClick={this.selectAccessType.bind(this, 'Allow')}>Allow</button>
                                                <button type="button" className={"btn btn-primary construction_btn " + (!this.state.accessType ? 'customertype_selected' : 'customertype_notselected')} onClick={this.selectAccessType.bind(this, 'Restrict')}>Restrict</button>
                                            </div>
                                        </div>
                                    </div>  
                                </div>
                                        {/* <div>
                                            <label class="label_title" style={{
                                                fontSize: '16px',
                                                marginLeft: '233px'
                                            }}>User 1</label>
                                            <form class="user_form" style={{ marginTop: '0px' }}>
                                                <Inputfield fieldTitle="User" maxlength="50" value={this.state.userState ? this.state.userState["0"].name : null}
                                                    mandateField={!this.state.mandateField} id="1" inputType="text" name="useraccess" onChange={this.handleChange} placeholder="Enter" />
                                            </form>
                                        </div> */}
                                        {/* {this.state.userNumber.map((object, i) => (
                                            <div>
                                                <label class="col-xs-5 label_title" style={{
                                                    fontSize: '16px',
                                                    marginLeft: '226px'
                                                }}>User {object}</label>

                                                <div className="col-xs-3" style={{ marginTop: '25px', marginLeft: '-49px' }} onClick={this.deleteMoreSPV.bind(this, "user", i, object)}>
                                                    <Icon name="trash-small" size="small" title="" /><span style={{ marginLeft: '5px', position: 'absolute' }}>Remove user</span>
                                                </div>

                                                <form class="user_form" style={{ marginTop: '0px' }}>
                                                    <Inputfield fieldTitle="User" maxlength="50" mandateField={!this.state.mandateField} value={this.state.userState[((parseInt(object) - 1)).toString()].name} id={object} inputType="text" name="useraccess" onChange={this.handleChange} placeholder="Enter" />
                                                </form>
                                            </div>
                                        )

                                        )} */}

                                        <div className="form-group row hide">
                                            <div className="col-sm-12 add_credit_rating">
                                                <label className="col-sm-3 col-form-label field_label_credit"></label>
                                                <div className="col-sm-4 add_credit_rating_btn" onClick={this.addMoreSPV.bind(this, "user")}>
                                                    <Icon name="plus-xsmall" size='small' title="" /> <label className="uploadDocument" > Add another user</label>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    
                                    <div className={"form-group row " + (this.state.accessType ? 'hide' : '')} style={{"marginLeft":'1em'}}>
                                            <div className="col-sm-12 add_credit_rating"  style={{"marginTop":'3px'}}>
                                            <Accordion className="accordion_header">
                                    <dt open={true}>Users</dt>
                                    <div>
                                    <form class="model_form" style={{ marginLeft: '2.5em' }}>
                                    <div class="form-group row" style={{ marginBottom: '0px' }}>
                                    <label className="field_label_model">Add users to allow access</label>
                                    <br/>
                                    {this.state.userData.map((i) => (
                                        <div class="col-xs-3">
                                    <table className="">
                                    <tbody style={{ lineHeight: '27px'}}>
                                    <tr>
                                        <td>
                                            <div style={{'marginLeft':'1em'}}>
                                            <Checkbox disabled ={i.userID === racfId} defaultChecked={i.userID === racfId}  onChange={this.selectUser.bind(this,i.userID)}
                                            />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{i.userName}
                                            <br/><br/>
                                        </div>
                                         </td>
                                     </tr>
                                     </tbody>
                                     </table>
                                    </div>
                                    )
                                    )}
                                    </div>
                                    </form>
                                    </div>
                                    </Accordion>
                                    </div>
                                    </div>
                                   
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="footer">
                        <button type="button" id="btt" class="zb-button zb-button-primary save_btn" onClick={this.saveUserData.bind(this)}>Save customer</button>
                        <button type="button" class="zb-button zb-button-secondary cancel_btn" data-toggle="modal" data-target="#cancelSave">Cancel</button>
                    </div>
                    <Popup headerTitle="Cancel saving"
                        headerbody="Are you sure you want to cancel saving? All information will be deleted." buttontext1="Yes, cancel saving" buttontext2="No, don’t cancel saving" datatarget="cancelSave" onClick={this.cancelRegistration.bind(this)} />
                </div>
            </div>
        )

    }
}

export default addCustomer
