import React, { Fragment } from 'react';
import './modelNewDeal.css';
import Inputfield from '../../commonComponents/inputDealField';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import Dropdownfield from '../../commonComponents/DropdownField';
import TLPGrid from '../../commonComponents/TLPGrid';
import help from '../../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { API_ENDPOINT } from '../../config/config.js';
import { HttpPost, HttpGet } from '../../services/api.js';
import { validate } from '../../utils/validation.js';
import {dealValidate} from '../../utils/dealValidation.js';
import moment from 'moment';
import Accordion from '@zambezi/sdk/accordion';
import Modal from '@zambezi/sdk/modal';
import { Notification } from '@zambezi/sdk/notification';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Icon } from '@zambezi/sdk/icons';
import ButtonGroup from '@zambezi/sdk/button-group';
import ModelIndexation from './ModelIndexation.js';
import ModelInterestRate from './ModelInterestRate.js';
import ModelOption from './ModelOption';
import { RegisterLeaseModel, RegisterLeaseParent } from '../../models/LeaseModelRegistry.js';
import { RegisterForPeriod } from '../../models/dataModelPeriod.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Popup from '../../commonComponents/popupMessage';
import InputTextfield from '../../commonComponents/inputField.js';
import { ComboBox } from '@zambezi/sdk/dropdown-list';
import {roundedDecimal, Comma, removeComma, nullCheck} from '../../utils/LeaseUtils.js';
import PopupApprovalWF from '../../commonComponents/popupDeals.js';
import {CopyModelDeal} from '../../models/CopyDeal.js';
import {Checkbox}  from '@zambezi/sdk/form-elements';
import DealCheckBox from '../../commonComponents/dealCheckBox.js';

//Auto-populate Commas

class ModelNewDeal extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            optionState1: [0],
            customerName: "",
            spv:"",
            dealType: true,
            itemPanel: true,
            leaseTenure: "",
            currencyName: "",
            currencyStatus: false,
            leaseStartDate: "",
            leaseStartDateError: false,
            leaseEndDateError: false,
            tenorErrorState: false,
            tenorErrorMessage: "",
            tlp_value: "",
            pageErrorStatus: false,
            showTLPGrid: false,
            vpvValue:'',
            rvlValue:'',
            aquisitioncost:'',
            corporatetax:'',
            faxRate:'',
            GBP:'',
            leaseEndDate:'',
            modeltypeData :'',
            paymentterm :'',
            mgs :'',
            leasetype :'',
            invoicing :'',
            returnmodel :'',
            LGD:'',
            indexasionStateval:[],
            interestRtStateVal:[],
            optionStateval:[],
            firstPeriodLeaseFeeValue:'',
            residualValue:'',
            turnover:'',
            maintenance:'',
            upfrontFee:'',
            
            aquisitioncostError: false,
            aquisitioncostMessage:'',
            dealErrorMessage: 'Please complete this field',
            endDateMessage: '',
            startDateMessage: '',
            invoicingStatus: false,
            residualValueStatus: false,
            paymenttermStatus: false,
            modeltypeStatus: false, 
            vpvValueStatus: false,
            rvlValueStatus: false,
            corporateTaxError: false,
            corporateTaxErrorMessage: '',
            descriptionError: false,
            descriptionErrorMessage: '',
            customerNameError: false,
            customerNameErrorMessage: '',
            spvError: false,
            spvErrorMessage: '',
            firstPeriodLeaseFeeError: false,
            firstPeriodLeaseFeeErrorMessage: '',
            residualValueError: false,
            residualValueErrorMessage: '',
            lgdError: false,
            lgdErrorMessage: '',
            rlvError: false,
            rlvErrorMessage: '',
            vpvError: false,
            vpvErrorMessage: '',
            acquisitionCostError: false,
            acquisitionCostErrorMessage: '',
            fxRateError: false,
            fxRateErrorMessage: '',
            turnoverError: false,
            turnoverErrorMessage: '',
            upfrontFeeStatus:false,
            upfrontFeeErrorMessage:'',
            returnmodelError: false,
            returnmodelErrorMessage: '',
            mgsError:false,
            leaseTypeError:false,
            customerLookupList:[],
            spvLookupList:[],
            areaLookupList:[],
            editContractid: '',
            status:'',
            dealNumber:'',
            dealReferenceNumber:'',
            invoicingMethod:'',
            invoicingMethodError:false,
            isDepreciation:false,
            isInvoicing:false,
            modelAppliesToStatus:false,
            modelAppliesToErrorMessage:'',
            
        };
        this.indexationChild = React.createRef();
        this.optionChild = React.createRef();
        this.interestRateChild = React.createRef();
        this.handleChange = this.handleChange.bind(this);
        this.getleaseStartDate = this.getleaseStartDate.bind(this);
        this.getleaseEndDate = this.getleaseEndDate.bind(this);
    
    }
    
    componentDidMount() {
        if(this.props.enableIndexDep == true){
            this.generateInvoDepDeal();
        } else {
            this.generateCopyDeal();
        }
    }

    generateCopyDeal = () => {
        var leaseParent = JSON.parse(localStorage.getItem('leaseResponseDataState'));
        var reqType = localStorage.getItem('DealRequestType');
        if(reqType == "COPY_DEAL" || reqType == "EDIT_DEAL"){
            var result = CopyModelDeal(this.props.leaseContract);
            this.setState(result,()=> {
                this.setTenorFrequency(this.state.invoicing);
            } );
        } 
    }

    generateInvoDepDeal = () => {
        if(this.props.enableIndexDep == true && this.props.leaseContract !== null){
            var result = CopyModelDeal(this.props.leaseContract);
            this.setState(result,()=> {
                this.setTenorFrequency(this.state.invoicing);
            } );
            if(this.props.isInvoicingDeal){
                this.setState({isInvoicing:true, isDepreciation:false});
            }else if(this.props.isDepreciationDeal){
                this.setState({isInvoicing:false, isDepreciation:true});
            }
        }
    }
    
    generateDealContents = () => {
        var currentComponent = this;
        currentComponent.indexationChild.current.sendData();
        currentComponent.interestRateChild.current.sendData();
        currentComponent.optionChild.current.sendData();
        currentComponent.forceUpdate();
        let payLoadData = RegisterLeaseModel(this.state, this.props.leaseParentData);
        return payLoadData;
    }


    // Lease end date
    getleaseEndDate(e){
        console.log("time");
        console.log(e);
        /* if(e != null){
            var endDate = Date.parse(e);
            console.log("endDate="+endDate);
            let month = moment(endDate).subtract('year', parseInt(this.state.leaseTenure)).month() + 1;
            this.state.leaseStartDate =  moment(endDate).subtract('year', parseInt(this.state.leaseTenure)).startOf('month', parseInt(month)).format('L');
            this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure);
            console.log("this.state.leaseEndDate="+this.state.leaseEndDate);
            console.log("this.state.leaseStartDate="+this.state.leaseStartDate);
        }*/
        let dateFlag= moment(e, 'DD/MM/YYYY', true).isValid();
        if(dateFlag){
        let isValidEndDate = true;
        let date=moment(e,'DD/MM/YYYY').toDate();
        if(this.state.leaseStartDate!=null && this.state.leaseStartDate !==''){
            let tempStartDate = moment(this.state.leaseStartDate);
            let tempEndDate = moment(e,'DD/MM/YYYY');
            if(tempEndDate.isSameOrBefore(tempStartDate, 'date')){
                isValidEndDate = false;
            }
        }
        if (e != "" && isValidEndDate) {
            this.setState({ leaseEndDate: date, leaseEndDateError: false },()=>{
                if(this.state.leaseStartDate != null && this.state.leaseStartDate !== ''){
                    this.updateTenorPeriod(this.state.updatedTenorModal ? true:false);
                }
            });
        }else if(!isValidEndDate){
            this.setState({ leaseEndDate: "", leaseEndDateError: true, endDateMessage: "End date must be greater than start date" });
        } else { 
            this.setState({ leaseEndDate: "", leaseEndDateError: true });
        }
        return true;
        } else {
            this.setState({leaseEndDateError: true, endDateMessage : 'Please enter a valid date' });
        }
    }

    getleaseStartDate(e) {
        // if (e != null) {
        //     var startDate = new Date(e); 
        //     console.log("startDate=" + startDate);  
        //     var year = startDate.getFullYear();
        //     var month = startDate.getMonth() -1;
        //     var day = startDate.getDate();
        //     var tenor;
        //     if(this.state.leaseTenure == null || this.state.leaseTenure === ""){
        //         tenor = 0;
        //     }else{
        //         tenor = parseInt(this.state.leaseTenure);
        //     }
        //     var eDate = new Date(year+ tenor, month, day);
        //     if(tenor != 0){
        //     this.state.leaseEndDate = moment(eDate).endOf('month', month).format('L');
        //     }else{
        //         this.state.leaseEndDate = '';
        //     }
        //     let leaseStartDateTemp =  moment(startDate).format('L');
        //     this.interestRateChild.current.setParameterFromParent(leaseStartDateTemp, this.state.leaseEndDate, this.state.leaseTenure, this.state.currencyName);
        //     console.log("this.state.leaseEndDate=" + this.state.leaseEndDate);
        //     console.log("this.state.leaseStartDate=" + this.state.leaseStartDate);
        //     /*var startDate = Date.parse(e);
        //     let month = moment(startDate).add('year', parseInt(this.state.leaseTenure)).month() + 1;
        //     this.state.leaseEndDate = moment(startDate).add('year', parseInt(this.state.leaseTenure)).endOf('month', month).format('L');
        //     this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure);
        //     console.log("this.state.leaseEndDate=" + this.state.leaseEndDate);
        //     console.log("this.state.leaseStartDate=" + this.state.leaseStartDate);*/
        // }
        console.log(e);
        if (e != "") {
            let dateFlag= moment(e, 'DD/MM/YYYY', true).isValid();
            if(dateFlag){
                let date=moment(e,'DD/MM/YYYY').toDate();
                this.setState({ leaseStartDate: date, leaseStartDateError: false }, ()=>{
                    // if((this.state.leaseTenure != null && this.state.leaseTenure != '') || 
                    // (this.state.leaseTenurePeriod != null && this.state.leaseTenurePeriod != null)){
                    //     this.populateLeaseDates('endDate', false);
                    // }
                    this.setState({ leaseEndDate: null, leaseTenure :'', leaseTenurePeriod :''});
                });
            }else{
                this.setState({leaseStartDateError: true, startDateMessage : 'Please enter a valid date' });
            }
        } else {
            this.setState({ leaseStartDate: "", leaseStartDateError: true });
        }
        return true;
    }
    
    isDepreciationCheckBox = (e, isChecked) => {
        this.setState({isDepreciation:isChecked, modelAppliesToStatus:false, modelAppliesToErrorMessage:''});

    }

    isInvoicingCheckBox = (e, isChecked) => {
        this.setState({isInvoicing:isChecked, modelAppliesToStatus:false, modelAppliesToErrorMessage:''});

    }

    handleChange = (e) => {
        // console.log(e.target.value);
        if (e !== undefined && e.target !== undefined && e.target.name !== undefined ) { 
            if (e.target.name === "tenor") {
                if (e.target.value.match(/^[0-9]{0,2}$/) || e.target.value == "") {
                    let v = validate('tenor', e.target.value);
                    if (v[0] == null) {
                        this.setState({ leaseTenure: e.target.value, tenorErrorState: false, tenorErrorMessage: v[1]});                        
                    } else if (v[0] != null) {
                        this.setState({ leaseTenure: e.target.value, tenorErrorState: !v[0], tenorErrorMessage: v[1] });
                    }
                }
            } else if (e.target.name == "description"){
                this.setState({ description: e.target.value });
                let v = dealValidate('description', e.target.value);
                if (v[0] == null) {
                    this.setState({ descriptionError: false, descriptionErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ descriptionError: !v[0], descriptionErrorMessage: v[1] });    
                }
            } else if (e.target.name == "customerName"){
                this.setState({ customerName: e.target.value });
                let v = dealValidate('customerName', e.target.value);
                if (v[0] == null) {
                    this.setState({ customerNameError: false, customerNameErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ customerNameError: !v[0], customerNameErrorMessage: v[1] });    
                }
                
            } else if (e.target.name == "spv"){
                this.setState({ spv: e.target.value });
                let v = dealValidate('spv', e.target.value);
                if (v[0] == null) {
                    this.setState({ spvError: false, spvErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ spvError: !v[0], spvErrorMessage: v[1] });    
                }
                
            } else if (e.target.name == "vpvValue"){
                var vpvvalue = Comma(e.target.value);
                this.setState({ vpvValue:  vpvvalue});
                this.setState({ vpvValueStatus: false });
                let v = dealValidate('VPV', e.target.value);
                if (v[0] == null) {
                    this.setState({ vpvError: false, vpvErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ vpvError: !v[0], vpvErrorMessage: v[1] });    
                }
            } else if (e.target.name == "rvlValue"){
                var rvlvalue = Comma(e.target.value);
                this.setState({ rvlValue:  rvlvalue});
                this.setState({ rvlValueStatus: false });
                let v = dealValidate('RLV', e.target.value);
                if (v[0] == null) {
                    this.setState({ rlvError: false, rlvErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ rlvError: !v[0], rlvErrorMessage: v[1] });    
                }
            }else if (e.target.name == "aquisitioncost"){
                let acquisitionCostWithoutComma = removeComma(e.target.value);
                if(acquisitionCostWithoutComma.match(/^[0-9,]{0,15}.?[0-9]{0,2}$/) || e.target.value == "") {
                    var ac = Comma(e.target.value);
                    this.setState({ aquisitioncost: ac });
                    this.setState({ aquisitioncostError: false });
                    let v = dealValidate('AquisitionCost', e.target.value);
                    if (v[0] == null) {
                        this.setState({ acquisitionCostError: false, acquisitionCostErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ acquisitionCostError: !v[0], acquisitionCostErrorMessage: v[1] });    
                    }
                }
            } else if (e.target.name == "corporatetax"){
                this.setState({ corporatetax: e.target.value });
                let v = dealValidate('CorporateTaxRate', e.target.value);
                if (v[0] == null) {
                    this.setState({ corporateTaxError: false, corporateTaxErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ corporateTaxError: !v[0], corporateTaxErrorMessage: v[1] });
                }
            } else if (e.target.name == "faxrate"){
                this.setState({ faxRate: e.target.value });
                let v = dealValidate('fxRate', e.target.value);
                if (v[0] == null) {
                    this.setState({ fxRateError: false, fxRateErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ fxRateError: !v[0], fxRateErrorMessage: v[1] });    
                }
            } else if (e.target.name == "GBP"){
                this.setState({ GBP: e.target.value });
            } else if (e.target.name == "tlp_value"){
                this.setState({ tlp_value: e.target.value });
            } else if (e.target.name == "upfrontFee"){
                let v = dealValidate('UpfrontFee', e.target.value);
                if (v[0] == null) {
                    this.setState({ upfrontFeeStatus: false, upfrontFeeErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ upfrontFeeStatus: !v[0], upfrontFeeErrorMessage: v[1] });    
                }
                this.setState({ upfrontFee: e.target.value });
            } else if (e.target.name == "LGD"){
                this.setState({ LGD: e.target.value });
                let v = dealValidate('LGD', e.target.value);
                if (v[0] == null) {
                    this.setState({ lgdError: false, lgdErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ lgdError: !v[0], lgdErrorMessage: v[1] });    
                }
            } else if(e.target.name == "residualValue"){
                var rv = Comma(e.target.value);
                this.setState({ residualValue: rv});
                this.setState({ residualValueStatus: false });
                let v = dealValidate('ResidualValue', e.target.value);
                if (v[0] == null) {
                    this.setState({ residualValueError: false, residualValueErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ residualValueError: !v[0], residualValueErrorMessage: v[1] });    
                }
            } else if(e.target.name == "firstPeriodLeaseFeeValue"){
                let firstperiodleaseFeeWithoutComma = removeComma(e.target.value);
                if(firstperiodleaseFeeWithoutComma.match(/^[0-9,]{0,15}.?[0-9]{0,2}$/) || e.target.value == "") {
                    var firstPLeaseFValue = Comma(e.target.value);
                    this.setState({ firstPeriodLeaseFeeValue: firstPLeaseFValue});
                    let v = dealValidate('FirstPeriodLeaseFee', e.target.value);
                    if (v[0] == null) {
                        this.setState({ firstPeriodLeaseFeeError: false, firstPeriodLeaseFeeErrorMessage: v[1] });
                    } else if (v[0] != null) {
                        this.setState({ firstPeriodLeaseFeeError: !v[0], firstPeriodLeaseFeeErrorMessage: v[1] });    
                    }
                }
            } else if(e.target.name == "turnover"){
                var turnOver = Comma(e.target.value);
                this.setState({ turnover: turnOver});
                let v = dealValidate('Turnover', e.target.value);
                if (v[0] == null) {
                    this.setState({ turnoverError: false, turnoverErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ turnoverError: !v[0], turnoverErrorMessage: v[1] });    
                }
            } else if (e.target.name == "tenorPeriod"){
                if (e.target.value.match(/^[0-9]{0,3}$/) || e.target.value == "") {
                    if(e.target.value < this.state.tenorFrequencyValue){
                        this.setState({ leaseTenurePeriod: e.target.value, 
                            tenorPeriodErrorState : false, 
                            tenorPeriodErrorMessage : '' });
                    }
                } 
                // let v = dealValidate('description', e.target.value);
                // if (v[0] == null) {
                //     this.setState({ descriptionError: false, descriptionErrorMessage: v[1] });
                // } else if (v[0] != null) {
                //     this.setState({ descriptionError: !v[0], descriptionErrorMessage: v[1] });    
            }
        }
        return true;
    }

    LeaseTenureCalculation() {
        console.log(this.state.leaseStartDate);
        console.log(this.state.leaseTenure);
        console.log(this.state.leaseEndDate);
    }

    setLeaseDates(e, field){
        if(e !== undefined){
            if(e === 'leaseEndDate'){
                let time = moment(field).format('DD/MM/YYYY');
                this.setState({ leaseEndDate: time });
            }
        }
    }
    
    getDropdownItem(event, val, type) { 
        console.log("currency");
        console.log(event);
        console.log(val);
        console.log(type);
        if (event == "currency") {
            if (type.value != "") {
                this.setState({ currencyName: type.value, currencyStatus: false });
                this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure, type.value);
            } else {
                this.setState({ currencyName: type.value, currencyStatus: true });
            }
        } else if(event == "modeltype"){
            this.setState({ modeltypeData: type.value });
            this.setState({ modeltypeStatus: false });
            
        } else if(event == "paymentterm"){
            this.setState({ paymentterm: type.value});
            this.setState({ paymenttermStatus: false });
        } else if(event == "mgs"){
            this.setState({ mgs: type.value});
            this.setState({ mgsError: false });
        } else if(event == "leasetype"){
            this.setState({ leasetype: type.value});
            this.setState({ leaseTypeError: false });
        } else if(event == "invoicing"){
            this.setState({ invoicing: type.value });
            this.setState({ invoicingStatus: false });
            this.setTenorFrequency(type.value);
        } else if(event == "returnmodel"){
            //this.setState({ returnmodel: type.value});
            if (type.value != "") {
                this.setState({ returnmodel: type.value, returnmodelError: false });
            } else {
                this.setState({ returnmodel: type.value, returnmodelError: true });
            }
            if(type.value === "Public Sector"){
                this.setState({ LGD: 45});
                this.setState({lgdError: false});
            } else if(type.value === "Large Corporate" || type.value === "Small Corporate"){
                this.setState({ LGD: 35});
                this.setState({lgdError: false});
            } else{
                this.setState({ LGD: ""}); 
                this.setState({lgdError: true, lgdErrorMessage: "Please complete this field"});
            }
           
        } else if(event == "maintenance"){
            this.setState({ maintenance: type.value });
        } else if(event == "invoicingMethod"){
            this.setState({ invoicingMethod: type.value });
            this.setState({ invoicingMethodError: false });
        }
        // true;
    }

    fetchTLPCalculation() {
        this.validation();
        console.log("Fetch TLP");
        console.log(this.state.leaseStartDate);
        console.log(this.state.leaseTenure);
        console.log(this.state.currencyName);
        if (this.state.leaseStartDate && this.state.leaseTenure && this.state.currencyName) {
            this.setState({ pageErrorStatus: false });
            let time = moment(this.state.leaseStartDate).format('DD-MM-YYYY');
            var currentComponent = this;
            let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/' + this.state.leaseTenure + '/' + this.state.currencyName + '/' + time + '/12-12-2080';
            console.log("Fetch tlp");
            console.log(endPoint);
            let output1 = HttpGet(endPoint).then(function (response) {
                console.log("Response received from server");
                console.log(response.data);
                console.log(response.data.tlp);
                currentComponent.setState({ tlp_value: response.data.tlp });
            })
                .catch(function (error) {
                    console.log("Error received");
                    console.log(error);
                })
        } else {
            this.setState({ pageErrorStatus: true });
        }
        return true;
    }
    
    tlpValidation=(leaseStartDate, leaseEndDate)=>{
        let v = validate('tenor', this.state.leaseTenure);
        console.log("Validation:: ", v[0]);
        if (v[0] == null) {
            this.setState({ tenorErrorState: false, tenorErrorMessage: v[1] });
        } else if (v[0] != null){
            this.setState({ tenorErrorState: !v[0], tenorErrorMessage: v[1] });
        }
       console.log("lease start date");
        console.log(this.state.leaseStartDate);
        if (this.state.leaseStartDate == "" || this.state.leaseStartDate == null) {
            this.setState({ leaseStartDateError: true });
        } else { 
            
            this.setState({ leaseStartDateError: false });
            // console.log(time);
        }
        if (this.state.currencyName == "") {
            this.setState({ currencyStatus: true });
        } else {
            this.setState({ currencyStatus: false });
        }
    }

    validation(){
        let v = validate('tenor', this.state.leaseTenure);
        console.log("Validation:: ", v[0]);
        if (v[0] == null) {
            this.setState({ tenorErrorState: false, tenorErrorMessage: v[1] });
        } else if (v[0] != null){
            this.setState({ tenorErrorState: !v[0], tenorErrorMessage: v[1] });
        }

        let v1 = dealValidate('CorporateTaxRate', this.state.corporatetax);
            if (v1[0] == null) {
                this.setState({ corporateTaxError: false, corporateTaxErrorMessage: v1[1] });
            } else if (v1[0] != null) {
                this.setState({ corporateTaxError: !v1[0], corporateTaxErrorMessage: v1[1] });
         }

        let v2 = dealValidate('description', this.state.description);
            if (v2[0] == null) {
                this.setState({ descriptionError: false, descriptionErrorMessage: v2[1] });
        } else if (v2[0] != null) {
                this.setState({ descriptionError: !v2[0], descriptionErrorMessage: v2[1] });
        }

        let v3 = dealValidate('FirstPeriodLeaseFee', this.state.firstPeriodLeaseFeeValue);
            if (v3[0] == null) {
                this.setState({ firstPeriodLeaseFeeError: false, firstPeriodLeaseFeeErrorMessage: v3[1] });
            } else if (v3[0] != null) {
                this.setState({ firstPeriodLeaseFeeError: !v3[0], firstPeriodLeaseFeeErrorMessage: v3[1] });    
            }

        let v4 = dealValidate('customerName', this.state.customerName);
            if (v4[0] == null) {
                this.setState({ customerNameError: false, customerNameErrorMessage: v4[1] });
            } else if (v3[0] != null) {
                 this.setState({ customerNameError: !v4[0], customerNameErrorMessage: v4[1] });    
            }
        let v5 = dealValidate('ResidualValue', this.state.residualValue);
             if (v5[0] == null) {
                this.setState({ residualValueError: false, residualValueErrorMessage: v5[1] });
            } else if (v5[0] != null) {
                this.setState({ residualValueError: !v5[0], residualValueErrorMessage: v5[1] });    
            }
        let v6 = dealValidate('LGD', this.state.LGD);
            if (v6[0] == null) {
                this.setState({ lgdError: false, lgdErrorMessage: v6[1] });
            } else if (v6[0] != null) {
                this.setState({ lgdError: !v6[0], lgdErrorMessage: v6[1] });    
            }

        let v7 = dealValidate('RLV', this.state.rvlValue);
            if (v7[0] == null) {
                this.setState({ rlvError: false, rlvErrorMessage: v7[1] });
            } else if (v7[0] != null) {
                this.setState({ rlvError: !v7[0], rlvErrorMessage: v7[1] });    
            }
        let v8 = dealValidate('VPV', this.state.vpvValue);
            if (v8[0] == null) {
                this.setState({ vpvError: false, vpvErrorMessage: v8[1] });
            } else if (v8[0] != null) {
                this.setState({ vpvError: !v8[0], vpvErrorMessage: v8[1] });    
            }
        let v9 = dealValidate('AquisitionCost', this.state.aquisitioncost);
            if (v9[0] == null) {
                this.setState({ acquisitionCostError: false, acquisitionCostErrorMessage: v9[1] });
            } else if (v9[0] != null) {
                this.setState({ acquisitionCostError: !v9[0], acquisitionCostErrorMessage: v9[1] });    
            }   
            
        let v10 = dealValidate('fxRate', this.state.faxRate);
            if (v10[0] == null) {
                this.setState({ fxRateError: false, fxRateErrorMessage: v10[1] });
            } else if (v10[0] != null) {
                this.setState({ fxRateError: !v10[0], fxRateErrorMessage: v10[1] });    
            }

        let v11 = dealValidate('Turnover', this.state.turnover);
            if (v11[0] == null) {
                this.setState({ turnoverError: false, turnoverErrorMessage: v11[1] });
            } else if (v11[0] != null) {
                this.setState({ turnoverError: !v11[0], turnoverErrorMessage: v11[1] });    
            }
        let v12 = dealValidate('spv', this.state.spvError);
            if (v12[0] == null) {
                this.setState({ spvError: false, spvErrorMessage: v12[1] });
            } else if (v12[0] != null) {
                this.setState({ spvError: !v12[0], spvErrorMessage: v12[1] });    
            }
        let v13 = dealValidate('UpfrontFee', this.state.upfrontFee);
        if (v13[0] == null) {
            this.setState({ upfrontFeeStatus: false, upfrontFeeErrorMessage: v13[1] });
        } else if (v13[0] != null) {
            this.setState({ upfrontFeeStatus: !v13[0], upfrontFeeErrorMessage: v13[1] });    
        }
        /*let v14 = dealValidate('returnModel', this.state.returnmodel);
            if (v14[0] == null) {
                this.setState({ returnmodelError: false, returnmodelErrorMessage: v14[1] });
            } else if (v14[0] != null) {
                this.setState({ returnmodelError: !v14[0], returnmodelErrorMessage: v14[1] });    
            }*/
        console.log("lease start date");
        console.log(this.state.leaseStartDate);
        if (this.state.leaseStartDate == "" || this.state.leaseStartDate == null) {
            this.setState({ leaseStartDateError: true });
        } else { 
            
            this.setState({ leaseStartDateError: false });
            // console.log(time);
        }
        // lease end date
        console.log("lease end date");
        console.log(this.state.leaseEndDate);
        if (this.state.leaseEndDate == "" || this.state.leaseEndDate == null) {
            this.setState({ leaseEndDateError: true });
        } else { 
            
            this.setState({ leaseEndDateError: false });
            // console.log(time);
        }
        // lease end date
        if (this.state.currencyName == "") {
            this.setState({ currencyStatus: true });
        } else {
            this.setState({ currencyStatus: false });
        }
        if (this.state.returnmodel == "") {
            this.setState({ returnmodelError: true });
        } else {
            this.setState({ returnmodelError: false });
        }

    }

    selectDealType(dealtype) {
        console.log("Deal type", dealtype);
        if (dealtype === 'standard') {
            this.setState({ dealType: true });
        } else {
            this.setState({ dealType: false });
        }
        return true;
    }

    updateGridStatus(val) {
        console.log("update grid status ", val);
        if (val == "Pending_For_Approval") {
            this.setState({ gridStatus: 'Pending' });
        } else {
            this.setState({ gridStatus: val });
        }

        if (val != '') {
            this.setState({ showGridStatus: true });
        } else {
            this.setState({ showGridStatus: false });
        }
    }

    viewTLPGrid=  () =>{
        console.log("view tlp grid");
        localStorage.setItem('approvalPending', 'Approved');
        this.setState({ showTLPGrid: true });
        this.forceUpdate();
    }

    getOptionInputDate(error, type) {
        console.log(error);
    }

    generateData(type) {
        const data = [];
        if (type == "currency") {
            data.push(
                "EUR",
                "DKK",
                "SEK",
                "NOK",
            );
        } else if (type == 'mgs') {
            data[0] = '';
            for (var i = 1; i < 28; i++) {
                data.push(i);
            }
            
        } else if (type == "modeltype") { 
            data.push(
                "Solving for lease fee",
                "Solving for residual value",
                "Solving for margin"
            );
        } else if (type == "paymentterm") {
            data.push(
                "Advanced",
                "Arrears"
            );
        } else if (type == "leasetype") {
            data.push(
                "Operating",
                "Finance",
                "Fail Sale"
            );
        } else if (type == "returnmodel") {
            data.push(
                "Public Sector",
                "Large Corporate",
                "Small Corporate"
            );
        } else if (type == "invoicing") {
            data.push(
                "Monthly",
                "Quarterly",
                "Semi-Annually",
                "Annually"
            );
        } else if (type == "maintenance") {
            data.push(
                "Triple-net",
                "Double-net",
                "Synthetic Triple-net"
            );
        } else if (type == "invoicingMethod") {
            data.push(
                "Index",
                "Interest"
            );
        }
        
        return data
    }

    populateNext = (optionState2) =>{
        this.setState({optionState1:optionState2});
    }

    populateOptionInState = (optionState) => {
        this.setState({optionStateval:optionState});
    }
    populateIndexationInState = (indexasionState) => {
        this.setState({indexasionStateval:indexasionState});
    }

    populateInterestRtState = (interestState) => {
        this.setState({interestRtStateVal:interestState});
    }

	// viewTLPState = () => {
    //     // this.setState({showTLPGrid:viewtlp});
    //     localStorage.setItem('approvalPending', 'Approved');
    //     this.setState({ showTLPGrid: true });
    // }


    validateField() {
        var currentComponent = this;
        this.validation();
        var flag = false;

        if(this.state.aquisitioncost == ""){
            this.setState({ aquisitioncostError: true  });
            flag = true;
        } else {
            this.setState({ aquisitioncostError: false });
        }

        if (this.state.invoicing == "") {
            this.setState({ invoicingStatus: true  });
            flag = true;
        } else {
            this.setState({ invoicingStatus: false });
        }

        if (this.state.modeltypeData == "") {
            this.setState({ modeltypeStatus: true  });
            flag = true;
        } else {
            this.setState({ modeltypeStatus: false });
        }

        if (this.state.mgs == "") {
            this.setState({ mgsError: true  });
            flag = true;
        } else {
            this.setState({ mgsError: false });
        }

        if (this.state.leasetype == "") {
            this.setState({ leaseTypeError: true  });
            flag = true;
        } else {
            this.setState({ leaseTypeError: false });
        }
        if (this.state.paymentterm == "") {
            this.setState({ paymenttermStatus: true  });
            flag = true;
        } else {
            this.setState({ paymenttermStatus: false });
        }
        if (this.state.currencyName == "") {
            this.setState({ currencyStatus: true  });
            flag = true;
        } else {
            this.setState({ currencyStatus: false });
        }

        // if (this.state.invoivingMethod == "") {
        //     this.setState({ invoicingMethodError: true  });
        //     flag = true;
        // } else {
        //     this.setState({ invoicingMethodError: false });
        // }

        if(this.state.modeltypeData == "Solving for lease fee"){
            if (this.state.residualValue == "") {
                this.setState({ residualValueError: true  });
                this.setState({ residualValueErrorMessage: "Please complete this field"});
                flag = true;
            } 
        } else if(this.state.modeltypeData == "Solving for residual value"){
            if (this.state.firstPeriodLeaseFeeValue == "") {
                this.setState({ firstPeriodLeaseFeeError: true  });
                this.setState({ firstPeriodLeaseFeeErrorMessage: "Please complete this field"});
                flag = true;
            }
        } else if(this.state.modeltypeData == "Solving for margin"){
            if (this.state.residualValue == "") {
                this.setState({ residualValueError: true  });
                this.setState({ residualValueErrorMessage: "Please complete this field"});
                flag = true;
            } 
            if (this.state.firstPeriodLeaseFeeValue == "") {
                this.setState({ firstPeriodLeaseFeeError: true  });
                this.setState({ firstPeriodLeaseFeeErrorMessage: "Please complete this field"});
                flag = true;
            }

        }
        if (this.state.returnmodel == "Small Corporate" && this.state.turnover == "") {
            this.setState({ turnoverError: true });
            this.setState({ turnoverErrorMessage: "Please complete this field"});
            flag = true;
        } else {
            this.setState({ turnoverError: false });
        }

        if(this.state.isDepreciation || this.state.isInvoicing){
            this.setState({ modelAppliesToStatus: false, modelAppliesToErrorMessage:'' });
        } else {
            this.setState({ modelAppliesToStatus: true, modelAppliesToErrorMessage:'Please complete this field' });
            flag = true;
        }

        return flag;
    }

    validateChildState = () =>{

		var currentComponent = this;
        if(this.state.leaseTenure !== '' && this.state.leaseStartDate !== ''
         && this.state.leaseEndDate !== '' && this.state.invoicing !== ''){
            let payLoadData = RegisterForPeriod(this.state);
            console.log('API_ENDPOINT.PERIOD_LIST = ' + API_ENDPOINT.PERIOD_LIST);
            let periodEndpoint = API_ENDPOINT.PERIOD_LIST;
            console.log('periodEndpoint = ' + periodEndpoint);
            let output = HttpPost(this, payLoadData, periodEndpoint)
            .then(function (response) {
                console.log("response received from server");
                console.log(response);
                console.log(response.data);
                console.log('b4 setting local storage');
                localStorage.setItem('leaseResponseForPeriod',JSON.stringify(response.data));
				
				var validationError = currentComponent.indexationChild.current.validateFields(currentComponent.state.leaseStartDate, currentComponent.state.leaseEndDate);
				var intValError = currentComponent.interestRateChild.current.validateFields(currentComponent.state.leaseStartDate, currentComponent.state.leaseEndDate);
				var optionvalError = currentComponent.optionChild.current.validateFields(currentComponent.state.leaseStartDate, currentComponent.state.leaseEndDate);
				if(validationError || intValError || optionvalError){
                    localStorage.setItem('childValidationError', 'true');
                    currentComponent.forceUpdate();
				} else{
                    localStorage.setItem('childValidationError', 'false');
                    if(currentComponent.props.isSingleDeal == true){
                        currentComponent.saveDealDBCall();
                        currentComponent.forceUpdate();
                    }
                    

				}
            })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
            });
         } else {
             //Basic Errors
            var validationError = currentComponent.indexationChild.current.validateFields(currentComponent.state.leaseStartDate, currentComponent.state.leaseEndDate);
            var intValError = currentComponent.interestRateChild.current.validateFields(currentComponent.state.leaseStartDate, currentComponent.state.leaseEndDate);
            var optionvalError = currentComponent.optionChild.current.validateFields(currentComponent.state.leaseStartDate, currentComponent.state.leaseEndDate);
            
         }
        
        
    }
    

    //Next button implementation
    onClickOpen(){
        
        window.scrollTo(0,1530);
        this.setState({optionState1 : [0,1]});
        
    }

    //Changes for Cutomer and SPV look ups
    onChangeCustomerName(value){
        var charOffset = 3;
        this.setState({customerName : value});
        if(value && value.length === charOffset){
            this.fetchDynamicData('customer', value).then((response) =>{
                this.setState({customerLookupList : response.data})
            })
        }
    }

    onChangeSpvNumber(value){
        var charOffset = 1;
        this.setState({spv : value});
        if(value && value.length === charOffset){
            this.fetchDynamicData('spv', value).then((response) =>{
                this.setState({spvLookupList : response.data})
            })
        }
    }

    fetchDynamicData(entityName, val){
        let url;
        if(entityName === 'customer'){
            url = API_ENDPOINT.GET_CUSTOMER_LIST+'/'+val;
        } else if(entityName === 'spv'){
            url = API_ENDPOINT.GET_SPV_LIST+'/'+val;
        }
        return HttpGet(this, url);
    }

    onSelectCustomer(customer){
        const custArray = this.state.customerLookupList;
        let custID=null;
        for( var i=0; i<custArray.length; i++){
            let curr = custArray[i];
            if(curr.partyName === customer){
                custID = curr.partyID;
                break;
            }
        }
        this.setState({ partyIdCustomer: custID, customerName : customer});
    }

    onSelectSPV(spvNumber){
        const spvArray = this.state.spvLookupList;
        let spvID="";
        for( var i=0; i<spvArray.length; i++){
            let tempSpv = spvArray[i];
            if(tempSpv.spvNumber === spvNumber){
                spvID = tempSpv.spvID;
                break;
            }
        }
        this.setState({ spvId: spvID , spv: spvNumber,
            areaId: null , areaName: '', areaLookupList: [] },()=>{
            this.getAreaList(this.state.spvId);
        });
    }

    onSelectArea(areaName){
        const areaArray = this.state.areaLookupList;
        let areaId="";
        for( var i=0; i<areaArray.length; i++){
            let tempArea = areaArray[i];
            if(tempArea.name === areaName){
                areaId = tempArea.areaID;
                break;
            }
        }
        this.setState({ areaId: areaId , areaName: areaName});  
    }

    getAreaList(spvID){
        if(spvID != null && spvID !== ''){
            let url = url = API_ENDPOINT.GET_AREA_LIST + '/' + spvID;

            HttpGet(this, url).then((response) => {
                let areaNames = response.data;
                if(areaNames && areaNames.length > 0){
                    areaNames=areaNames.filter((item) => {
                        if(item.isLinkedToDeal === 1){
                            return false;
                        }else {
                            return true;
                        }
                    })
                } else {
                    areaNames =[];
                }
                this.setState({
                    areaLookupList: areaNames,
                })
            })
        }
    }

    setTenorFrequency(invoicingFrequency){
        if(invoicingFrequency && invoicingFrequency !== ''){
            let tenorFrequencyLable;
            let tenorFrequencyValue; 
            let showTenorFrequencyUI = false;
            if(invoicingFrequency === 'Monthly'){
                tenorFrequencyLable = 'Months';
                tenorFrequencyValue = 12;
                showTenorFrequencyUI = true;
            } else if(invoicingFrequency === 'Quarterly'){
                tenorFrequencyLable = 'Quarters';
                tenorFrequencyValue = 4;
                showTenorFrequencyUI = true;
            } else if(invoicingFrequency === 'Semi-Annually'){
                tenorFrequencyLable = 'Semi-Annual';
                tenorFrequencyValue = 2;
                showTenorFrequencyUI = true;
            } else if(invoicingFrequency === 'Annually'){
                tenorFrequencyValue = 1;
                showTenorFrequencyUI = false;
            }

            this.setState({
                tenorFrequencyLable : tenorFrequencyLable,
                tenorFrequencyValue : tenorFrequencyValue,
                showTenorFrequencyUI : showTenorFrequencyUI,
            }, ()=>this.populateLeaseDates('tenor' , false));
        }
    }

    setTenureFromPeriod(e){
        if(e){
            e.stopPropagation();
        }
        let tenurePeriodValue = this.state.leaseTenurePeriod;
        let invoicingFreq = this.state.tenorFrequencyValue;
        
        let extraTenor = parseInt(tenurePeriodValue/invoicingFreq);
        let remainderTenor = parseInt(tenurePeriodValue%invoicingFreq);
        let updatedTenor = parseInt(this.state.leaseTenure != null && this.state.leaseTenure !== '' ? this.state.leaseTenure : 0)+extraTenor; 

        this.setState({
            leaseTenure : updatedTenor.toString(),
            leaseTenurePeriod :remainderTenor,
        }, ()=>this.populateLeaseDates('endDate', true));
    }

    populateLeaseDates(propToUpdate, isModalNeeded){
        if(propToUpdate==='endDate'){
            if((this.state.leaseTenure != null && this.state.leaseTenure != '') && 
            (this.state.leaseStartDate != null && this.state.leaseStartDate != '')){
                let startDate = moment(new Date(this.state.leaseStartDate));

                startDate = startDate.toDate();
                console.log("startDate=" + startDate);
                var year = startDate.getFullYear();
                var month = startDate.getMonth();
                var day = startDate.getDate();
                var tenor = parseInt(this.state.leaseTenure);
                var tenorPeriod = parseInt(this.state.leaseTenurePeriod ? this.state.leaseTenurePeriod : 0);
                var tenorFrequency = this.state.tenorFrequencyValue;
                // var endDateMonth = month;
                if(tenor === 0 && tenorPeriod === 0){
                    this.setState({
                        tenorPeriodErrorState : true,
                        tenorPeriodErrorMessage : 'Please enter a valid value'
                    })
                    return;
                } else {
                    this.setState({
                        tenorPeriodErrorState : false,
                        tenorPeriodErrorMessage : '',
                    })
                }
                if(tenorFrequency){
                    month += (12/tenorFrequency)*(tenorPeriod);
                }
                var eDate = moment(new Date(year + tenor, month, day-1)).format('L');
                this.state.leaseEndDate = eDate;
                this.setState({leaseEndDate : eDate}, this.updateTenorPeriod.bind(this, isModalNeeded));
                // this.state.leaseEndDate = moment(eDate).endOf('month', month).format('L'); 
            }
        } 
        else if(propToUpdate==='tenor'){
            if(this.state.leaseEndDate != null && this.state.leaseEndDate != ''
            && this.state.leaseStartDate != null && this.state.leaseStartDate != ''){
                this.updateTenorPeriod();
            }
        }
        let startDate = moment(new Date(this.state.leaseStartDate));
        let interestStartDate;
        if(!startDate.isSame(this.getFirstDayOfPeriod(this.state.leaseStartDate, this.state.invoicing),'date')){
            interestStartDate = this.getLastDayOfPeriod(this.state.leaseStartDate, this.state.invoicing).add(1,'day').format('L');
        } else {
            interestStartDate = this.state.leaseStartDate;
        }
        this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure, this.state.currencyName, interestStartDate);
        // this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure, this.state.currencyName);
        this.forceUpdate();
    }

    //For handling broken period
    updateTenorPeriod(isModalNeeded){
        let modalFlag = false;
        if(this.state.leaseStartDate != null && this.state.leaseStartDate !== ''){
            if(this.state.leaseEndDate != null && this.state.leaseEndDate !==''){
                let brokenMonths=0;
                let startDate = moment(new Date(this.state.leaseStartDate));
                let endDate = moment(new Date(this.state.leaseEndDate));
                
                if(!startDate.isSame(this.getFirstDayOfPeriod(this.state.leaseStartDate, this.state.invoicing),'date')){
                    startDate= this.getEffectiveStartDate(this.state.leaseStartDate, this.state.invoicing)
                    if(isModalNeeded){
                        modalFlag = true;
                    }
                }
                if(!endDate.isSame(this.getLastDayOfPeriod(this.state.leaseEndDate, this.state.invoicing),'date')){
                    endDate=this.getEffectiveEndDate(this.state.leaseEndDate, this.state.invoicing);
                    if(isModalNeeded){
                        modalFlag = true;
                    }
                }

                var diffMonths = Math.ceil(endDate.diff(startDate, 'months', true));
                var tenor = parseInt(diffMonths / 12);
                var extraMonths = diffMonths % 12;
                if(extraMonths < 0){
                    extraMonths = 0;
                }

                if (this.state.tenorFrequencyValue) {
                    extraMonths = parseInt(extraMonths * (this.state.tenorFrequencyValue / 12));
                }

                this.setState({
                    leaseTenure : tenor,
                    leaseTenurePeriod : extraMonths,
                    updatedTenorModal : isModalNeeded ? true && modalFlag : false,
                });
            }
            let startDate = moment(new Date(this.state.leaseStartDate));
            let interestStartDate;
            if (!startDate.isSame(this.getFirstDayOfPeriod(this.state.leaseStartDate, this.state.invoicing), 'date')) {
                interestStartDate = this.getLastDayOfPeriod(this.state.leaseStartDate, this.state.invoicing).add(1, 'day').format('L');
            } else {
                interestStartDate = this.state.leaseStartDate;
            }
            this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure, this.state.currencyName, interestStartDate);
            // this.interestRateChild.current.setParameterFromParent(this.state.leaseStartDate, this.state.leaseEndDate, this.state.leaseTenure, this.state.currencyName);
        }
    }

    getFirstDayOfPeriod(date, invoicing){
        let period = this.getInvoicePeriod(invoicing);

        if(period === 'semi-annual'){
            let tempDate = new Date(date);
            let year = tempDate.getFullYear();
            let month = tempDate.getMonth() < 6 ? 0 : 6;

            return moment(new Date(year, month, 1));

        } else {
            return moment(new Date(date)).startOf(period);
        }
    }

    getLastDayOfPeriod(date, invoicing){
        let period = this.getInvoicePeriod(invoicing);

       if(period === 'semi-annual'){
            let tempDate = new Date(date);
            let year = tempDate.getFullYear();
            let month = tempDate.getMonth()<6 ? 5 : 11;
            let day = month===5 ? 30 : 31;
            
            return moment(new Date(year, month, day));

        }else {
            return moment(new Date(date)).endOf(period);
        }  
    }

    getEffectiveStartDate(date, invoicing){
        let period = this.getInvoicePeriod(invoicing);

        if(period === 'semi-annual'){
            let tempDate = new Date(date);
            let year = tempDate.getFullYear();
            let month;
            if(tempDate.getMonth() < 6){
                month = 6;
            } else {
                month = 0;
                year += 1;
            }

            return moment(new Date(year, month, 1));
        } else {
            return moment(date).endOf(period).add(1,'day');
        }
    }

    getEffectiveEndDate(date, invoicing){
        let period = this.getInvoicePeriod(invoicing);

       if(period === 'semi-annual'){
            let tempDate = new Date(date);
            let year = tempDate.getFullYear();
            let month = tempDate.getMonth()<6 ? 11 : 5;
            if(tempDate.getMonth() < 6){
                month = 11;
                year = year-1;
            } else {
                month = 5;
            }
            return moment(new Date(year, month, 31));
        }else {
            return  moment(date).startOf(period).add(-1,'day');
        }  
    }

    getInvoicePeriod(invoicing){
        let period;
        if(!invoicing || invoicing === 'Monthly'){
            period = 'month';
        } else if(invoicing === 'Quarterly'){
            period = 'quarter';
        } else if(invoicing === 'Semi-Annually'){
            period = 'semi-annual'
        } else if(invoicing === 'Annually'){
            period = 'year';
        }

        return period;
    }
    
    //Changes Due to Ping.
    saveDealDBCall = ()=>{
        var currentComponent = this;
        var validationError = this.validateField();
        var dealErrorStatus = localStorage.getItem('dealErrorStatus');
        var childValidationError = localStorage.getItem('childValidationError');
        if(validationError == false && childValidationError == 'false' && dealErrorStatus == 'false'){
            let payLoadData = RegisterLeaseParent(this.state, this.props.leaseParentData);
            var toHit = API_ENDPOINT.MODEL_A_NEW_DEAL;
            let output = HttpPost(currentComponent, payLoadData, toHit)
            .then(function (response) {
                console.log("response received from server");
                console.log(response);
                console.log(response.data);
                localStorage.setItem('leaseResponseDataState',JSON.stringify(response.data));
                currentComponent.props.onsaveRoute();
                // currentComponent.props.history.push({
                //     pathname: '/lms/mainSummaryTabsPage',
                //      state: { leaseResponseDataState: response.data , fromDealURL:"ModelANewDeal"}
                // })
            })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
                // window.alert(error);
            });
        }
    }

    goToPage = (pagename) => {
        // this.props.history.push({
        //   pathname: '/lms/' + pagename
        // })
        this.props.goToPage(pagename);
        return true;
      }

      cancelRegistration = () => {
        var currentComponent = this;
        this.props.cancelRegistration();
    }

    saveModelDeal(){
       console.log("saveModelDeal");
       var currentComponent = this;
        localStorage.setItem('dealErrorStatus', 'false');
        localStorage.setItem('childValidationError', 'false');
        var validationError = this.validateField();
        let useroutput = this.validateChildState();
        currentComponent.indexationChild.current.sendData();
        currentComponent.interestRateChild.current.sendData();
        currentComponent.optionChild.current.sendData();
        return true;
    }
    
      render() {
        return (
            <div>
                {
                    this.state.pageErrorStatus ?
                        <Notification status='error' className="Confirmation_header_new" size='medium' title='There are errors in the form'>
                              {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                </Notification>
                        : null
                }

                {
                    this.state.updatedTenorModal ? 
                        <Modal
                            title='Tenor updated'
                            className="tenorUpdatedModal"
                            confirm={'OK'}
                            withSectioning={false}
                            withPadding
                            isClosable={false}
                            open={this.state.updatedTenorModal}
                            onConfirm={() => {
                                this.setState({updatedTenorModal : false})
                            }}>
                            <label className='col-form-label field_label' style={{ color: '#000000', textAlign: 'left' }}>
                                {'Effective tenor is updated, since you chose a broken period as the tenor'}
                            </label>
                        </Modal>
                    : null
                }
                {/* <label className="model_title" style={{marginLeft: '90px', marginBottom: '10px'}}>Model new deal</label> */}
                <div className="model_deal_container">

                    <Accordion className="accordion_header" allowMultipleOpen  openItems= {this.state.optionState1}>
                        <dt open={true} className="genetal_tab">General</dt>
                        <div>
                            <form class="model_form">
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Customer name (optional)</label>
                                    <div class="col-sm-5 inner-addon right-addon search_column">
                                        <ComboBox
                                            className="dealSPVSelection"
                                            aria-label='Customer Name'
                                            suggestions={this.state.customerLookupList.map(item => item.partyName)}
                                            placeholder='Search'
                                            inputProps={{
                                                autoCapitalize: false,
                                                spellCheck: false,
                                                maxLength: 15
                                            }}
                                            value={this.state.customerName}
                                            onChange={(e) => { this.onChangeCustomerName(e.target.value) }}
                                            onSuggestionSelected={(e, { suggestion }) => {
                                                this.onSelectCustomer(suggestion);
                                            }}
                                        />
                                    </div>
                                    <div class="spv_btn_modelDeal col-sm-3 add_btn_model addNewLabel" 
                                    style={{ marginTop: '-31px' }}
                                    onClick={this.goToPage.bind(this, 'addCustomer')}>
                                        <span class="glyphicon glyphicon-plus"></span> Add new customer
                                    </div>
                                </div>
                                {this.state.customerNameError ?
                                    <div className="form-group row" >
                                        <label className="col-sm-3 col-form-label field_label_model"></label>
                                        <div className="col-sm-6" style= {{marginLeft:'65px'}}>
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                                >
                                                {this.state.customerNameErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                : null}
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">SPV (optional)
                                              <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Special Purpose Vehicle
                                                        </Flyout>
                                            }>
                                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                                        </FlyoutTrigger>
                                    </label>
                                    <div class="col-sm-5 inner-addon right-addon search_column">
                                        <ComboBox
                                            className="dealSPVSelection"
                                            aria-label='SPV Name'
                                            suggestions={this.state.spvLookupList.map(item => item.spvNumber)}
                                            placeholder='Search'
                                            inputProps={{
                                                autoCapitalize: false,
                                                spellCheck: false,
                                                maxLength: 15
                                            }}
                                            value={this.state.spv}
                                            onChange={(e) => { this.onChangeSpvNumber(e.target.value) }}
                                            onSuggestionSelected={(e, { suggestion }) => {
                                                this.onSelectSPV(suggestion);
                                            }}
                                        />
                                    </div>
                                    <div class="spv_btn_modelDeal col-sm-3 add_btn_model_spv addNewLabel" 
                                    style={{ marginTop: '-31px' }}
                                    onClick={this.goToPage.bind(this, 'property')}>    
                                            <span class="glyphicon glyphicon-plus"></span> Add SPV
                                    </div>
                                </div>
                                {this.state.spvError ?
                                    <div className="form-group row" >
                                        <label className="col-sm-3 col-form-label field_label_model"></label>
                                        <div className="col-sm-6" style= {{marginLeft:'65px'}}>
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                                >
                                                {this.state.spvErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                : null}
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Area (optional)
                                    </label>
                                    <div class="col-sm-5 inner-addon right-addon search_column">
                                        <Select
                                            className="dealSPVSelection"
                                            aria-label='Area'
                                            suggestions={this.state.areaLookupList.map(item => item.name)}
                                            value={this.state.areaName}
                                            placeholder='Select'
                                            inputProps={{
                                                autoCapitalize: false,
                                                spellCheck: false,
                                                maxLength: 15
                                            }}
                                            onSuggestionSelected={(e, { suggestion }) => {
                                                this.onSelectArea(suggestion);
                                            }}
                                        />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Deal type</label>
                                    <div className="col-sm-4">
                                        <div class="customer_type_model">
                                            <div class="btn-group">
                                                <button type="button" className={"btn btn-primary standard_btn " + (this.state.dealType ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.selectDealType.bind(this, 'standard')}>Standard</button>
                                                <button type="button" className={"btn btn-primary construction_btn " + (!this.state.dealType ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.selectDealType.bind(this, 'construction')}>Construction</button>
                                            </div>
                                        </div>
                                    </div>  
                                </div>
                                
                                <Dropdownfield title="Model type" classname="font_config_custom" 
                                    data={this.generateData('modeltype')} value={this.state.modeltypeData}
                                    errorStatus={this.state.modeltypeStatus} errorMessage={this.state.dealErrorMessage}
                                    onChange={this.getDropdownItem.bind(this, 'modeltype')} />
                                
                                <DealCheckBox title = "Model applies to" onChangeDepreciation={this.isDepreciationCheckBox.bind(this)}
                                    OnChangeInvoicing ={this.isInvoicingCheckBox.bind(this)} 
                                    depreciationValue= {this.state.isDepreciation} 
                                    errorStatus={this.state.modelAppliesToStatus} errorMessage={this.state.modelAppliesToErrorMessage}
                                    invoicingValue ={this.state.isInvoicing} 
                                    isdisabled = {this.props.enableIndexDep ? this.props.enableIndexDep :false}
                                ></DealCheckBox>

                                <Dropdownfield title="Payment terms" classname="font_config_custom" 
                                    data={this.generateData('paymentterm')} value={this.state.paymentterm}
                                    errorStatus={this.state.paymenttermStatus} errorMessage={this.state.dealErrorMessage}
                                    onChange={this.getDropdownItem.bind(this, 'paymentterm')} />

                                <Dropdownfield title="Invoicing" classname="font_config_custom" 
                                    data={this.generateData('invoicing')} value={this.state.invoicing}
                                    errorStatus={this.state.invoicingStatus} errorMessage={this.state.dealErrorMessage}
                                    onChange={this.getDropdownItem.bind(this, 'invoicing')} 
                                    />
                                

                                <Inputfield fieldTitle="Description" mandateField={this.state.mandateField} 
                                    value={this.state.description} inputType="text" name="description" 
                                    onChange={this.handleChange} placeholder="Enter" maxLength="150"
                                    errorStatus={this.state.descriptionError} errorMessage={this.state.descriptionErrorMessage} />

                                <Dropdownfield title="MGS" classname="font_config_custom" data={this.generateData('mgs')} 
                                     onChange={this.getDropdownItem.bind(this, 'mgs')} value={this.state.mgs}
                                     errorStatus={this.state.mgsError} errorMessage={this.state.dealErrorMessage} />

                                <Dropdownfield title="Maintenance" classname="font_config_custom" data={this.generateData('maintenance')} 
                                    value={this.state.maintenance}
                                    errorStatus={false} onChange={this.getDropdownItem.bind(this, 'maintenance')} />

                                <Dropdownfield title="Lease type" classname="font_config_custom" data={this.generateData('leasetype')} 
                                    value={this.state.leasetype}
                                    errorStatus={false} onChange={this.getDropdownItem.bind(this, 'leasetype')} />

                                
                                <Calenderinputfield fieldTitle="Lease start date" 
                                    errorStatus={this.state.leaseStartDateError} value={this.state.leaseStartDate}
                                    inputType="date" name="leasestartdate"  errorMessage = {this.state.startDateMessage}
                                    // onError={this.handleError.bind(this, 'startDate')} 
                                    onUserChange={this.getleaseStartDate}
                                    getOptionInputDate={this.getleaseStartDate}
                                    placeholder="DD/MM/YYYY" />

                                <div className="form-group row">
                                    <label className="col-sm-4 col-form-label field_label_model">Tenor</label>
                                    <div className="col-sm-1">
                                        <input type="number" value={this.state.leaseTenure} name="tenor" id="tenor" 
                                        onChange={this.handleChange}
                                        onBlur={()=>{this.populateLeaseDates('endDate', true)}}
                                        className={"form-control input_Fields_mgs " + (this.state.tenorErrorState ? 'error_field' : '')}  
                                        placeholder="Enter" />
                                    </div>
                                    <span className="col-sm-1 postfix_title">Years</span>
                                    {this.state.showTenorFrequencyUI ?
                                    <Fragment>
                                    <div className="col-sm-1">
                                        <input type="number" value={this.state.leaseTenurePeriod} name="tenorPeriod" id="tenor" 
                                        onChange={this.handleChange}
                                        tabindex="-1"
                                        onBlur={this.setTenureFromPeriod.bind(this)}
                                        className={"form-control input_Fields_mgs " + (this.state.tenorPeriodErrorState ? 'error_field' : '')}  
                                        placeholder="Enter" />
                                    </div>
                                    <span className="col-sm-2 postfix_title">{this.state.tenorFrequencyLable}</span>
                                    </Fragment> : null}
                                </div>

                                {this.state.tenorErrorState ?
                                    <div className="form-group row" >
                                        <label className="col-sm-4 col-form-label field_label_model"></label>
                                        <div className="col-sm-6" 
                                        // style= {{marginLeft:'65px'}}
                                        >
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                                >
                                                {this.state.tenorErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                : null}
                                {this.state.tenorPeriodErrorState ?
                                    <div className="form-group row" >
                                        <label className="col-sm-4 col-form-label field_label_model"></label>
                                        <div className="col-sm-6" 
                                        // style= {{marginLeft:'65px'}}
                                        >
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='166px'
                                                className="error_notification"
                                                >
                                                {this.state.tenorPeriodErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                : null}

                                <Calenderinputfield fieldTitle="Lease end date" 
                                    errorStatus={this.state.leaseEndDateError} value={this.state.leaseEndDate} 
                                    inputType="date" name="leaseenddate"  errorMessage = {this.state.endDateMessage}
                                    // onError={this.handleError.bind(this, 'endDate')}
                                    onUserChange={this.getleaseEndDate}
                                    getOptionInputDate={this.getleaseEndDate} placeholder="DD/MM/YYYY" />

                        
                                <div className="form-group row">
                                    <label for="inputState" className="col-sm-4 col-form-label field_label_model">Returns model</label>
                                    <div className="col-sm-3" style={{ width: '273px'}}>
                                        <Select
                                            value={this.state.returnmodel}
                                            suggestions={this.generateData('returnmodel')}
                                            placeholder='Select'
                                            isError={false}
                                            onChange={this.getDropdownItem.bind(this, 'returnmodel')}
                                        />
                                    </div>
                                    <label className="col-sm-2 col-form-label field_label_model_lease">LGD
                                                <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Loss Given Default
                                                        </Flyout>
                                            }>
                                            <img src={help} style={{ marginTop: '-5px' }} onClick={e => e.preventDefault()} className="tooltip_help" />
                                        </FlyoutTrigger>
                                    </label>
                                    <div className="col-sm-1" style={{ marginLeft: '-73px' }}>
                                        <input type="text" value={this.state.LGD} name="LGD" id="LGD" onChange={this.handleChange} 
                                            className="form-control input_Fields_mgs" placeholder="Enter"/>
                                    </div>
                                    <span className="col-sm-1 postfix_title">%</span>
                                </div>
                                {this.state.returnmodelError ?
                                    <div className="form-group row" >
                                        <label className="col-sm-4 col-form-label field_label_model"></label>
                                        <div className="col-sm-4" style= {{marginLeft:'-10px'}}>
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                                >
                                                {this.state.dealErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                    : null}
                                     {this.state.lgdError ?
                                        <div className="form-group row" >
                                            <label className="col-sm-2 col-form-label field_label_model"></label>
                                            <div className="col-sm-3" style= {{marginLeft:'600px'}}>
                                                <Notification
                                                    status='error'
                                                    size='small'
                                                    withArrow
                                                    arrowPosition='40px'
                                                    className="error_notification"
                                                    >
                                                    {this.state.lgdErrorMessage}
                                                </Notification>
                                            </div>
                                        </div>
                                    : null}
                                    
                                    {this.state.returnmodel ==="Small Corporate" ?
                                        <Inputfield fieldTitle="Turnover"  
                                            mandateField={this.state.mandateField} value={this.state.turnover} 
                                            inputType="text" name="turnover" onChange={this.handleChange} placeholder="Enter"
                                            errorStatus={this.state.turnoverError} errorMessage={this.state.turnoverErrorMessage} />
                                    :null}
                                <Dropdownfield title="Currency" classname="font_config_custom" 
                                    data={this.generateData('currency')} value={this.state.currencyName}
                                    errorStatus={this.state.currencyStatus} errorMessage={this.state.dealErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'currency')} />

                                <Inputfield fieldTitle="VPV" helpIcon={true} helpIconValue="Vacant Possession Value" 
                                    helpID="vpv" mandateField={this.state.mandateField} value={this.state.vpvValue} 
                                    inputType="text" name="vpvValue" onChange={this.handleChange} placeholder="Enter"
                                    errorStatus={this.state.vpvErrorMessage} errorMessage={this.state.vpvErrorMessage} />
                                   
                                <Inputfield fieldTitle="RLV" helpIcon={true} helpIconValue="Re-let Value" helpID="rlv" 
                                    mandateField={this.state.mandateField} value={this.state.rvlValue} inputType="text" 
                                    name="rvlValue" onChange={this.handleChange} placeholder="Enter" 
                                    errorStatus={this.state.rlvError} errorMessage={this.state.rlvErrorMessage} />
                                
                                {/* <div className="form-group row">
                                    <label className="col-sm-4 col-form-label field_label_model">TLP
                                           <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Term Liquidity Premium
                                                        </Flyout>
                                            }>
                                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                                        </FlyoutTrigger>
                                    </label>
                                    <div className="col-sm-1">
                                        <input type="number" value={this.state.tlp_value} name="tlp_value" id="tlp_value"
                                            onChange={this.handleChange} className="form-control input_Fields_mgs" 
                                            placeholder="Enter" />
                                    </div>
                                    <span className="col-sm-1 postfix_title">%</span>
                                    <div className="col-sm-1 fetch_tlp_calc" onClick={this.fetchTLPCalculation.bind(this)}>
                                        <label className="fetch_tlp_calc_text">Fetch TLP</label></div>
                                    <span className="col-sm-3 tlpgrid_title"  data-toggle="modal" data-target="#myModal" 
                                        onClick={this.viewTLPGrid.bind(this)}>View TLP Grid</span>
                                </div> */}

                                <Inputfield fieldTitle="Acquisition cost" 
                                 value={this.state.aquisitioncost} inputType="text" name="aquisitioncost" 
                                 onChange={this.handleChange} placeholder="Enter"
                                    errorStatus={this.state.acquisitionCostError} errorMessage={this.state.acquisitionCostErrorMessage} />
                               
                                { this.state.modeltypeData == "Solving for residual value" || this.state.modeltypeData == "Solving for margin"
                                    ? <Inputfield fieldTitle="First period lease fee" mandateField={this.state.mandateField} 
                                    value={this.state.firstPeriodLeaseFeeValue} inputType="text"  name="firstPeriodLeaseFeeValue" 
                                    onChange={this.handleChange} placeholder="Enter" 
                                    errorStatus={this.state.firstPeriodLeaseFeeError} errorMessage={this.state.firstPeriodLeaseFeeErrorMessage} />

                                    : null
                                }

                                {this.state.modeltypeData == "Solving for lease fee" || this.state.modeltypeData == "Solving for margin"
                                    ? <Inputfield fieldTitle="Residual value" mandateField={this.state.mandateField}
                                        value={this.state.residualValue} inputType="text" name="residualValue"
                                        onChange={this.handleChange} placeholder="Enter"
                                        errorStatus={this.state.residualValueError} errorMessage={this.state.residualValueErrorMessage} />
                                    : null
                                }

                                <InputPercField fieldTitle="Upfront fee" value={this.state.upfrontFee} inputType='number'
                                    id="upfrontFee" name="upfrontFee" onChange={this.handleChange} placeholder="Enter"
                                    errorMessage={this.state.upfrontFeeErrorMessage} errorStatus={this.state.upfrontFeeStatus} />


                                <InputPercField fieldTitle="Corporate rate tax (optional)" value = {this.state.corporatetax}
                                    id="corporatetax" name= "corporatetax" onChange= {this.handleChange} placeholder="Enter" inputType='number' 
                                    errorMessage = {this.state.corporateTaxErrorMessage} errorStatus = {this.state.corporateTaxError} />

                                <div className="form-group row">
                                    <label className="col-sm-4 col-form-label field_label_model">FX rate (optional)</label>
                                    <div className="col-sm-2">
                                        <input type="number" value={this.state.faxRate} 
                                        name="faxrate" id="faxrate" onChange={this.handleChange} 
                                            className="form-control input_Fields_mgs" 
                                            style={{ width: '125px' }} placeholder="Enter CCY" />
                                    </div>
                                    <label className="col-sm-1 col-form-label field_label_model_lease" style={{ marginLeft: '10px', fontWeight: 'bold' }}>{this.state.currencyName}/GBP</label>
                                    {/* <div className="col-sm-2">
                                        <input type="text" name="GBP" id="GBP" onChange={this.handleChange} 
                                            value={this.state.GBP}
                                            className="form-control input_Fields_mgs" style={{ width: '60px' }}
                                             placeholder="Enter" />
                                    </div> */}
                                </div>
                                {this.state.fxRateError ?
                                    <div className="form-group row" >
                                        <label className="col-sm-3 col-form-label field_label_model"></label>
                                        <div className="col-sm-6" style= {{marginLeft:'300px'}}>
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                                >
                                                {this.state.fxRateErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                : null}

                                <Dropdownfield title="Invoicing method" classname="font_config_custom" 
                                    helpIcon={true} helpIconValue={"Use index when there is a base lease fee which is uplifted "
                                    +"by either a fixed or floating index. Use interest when there is an appendix in the "
                                    +"contract with the curve and the lease fee is computed according to the curve."}

                                    data={this.generateData('invoicingMethod')} value={this.state.invoicingMethod}
                                    errorStatus={this.state.invoicingMethodError} errorMessage={this.state.dealErrorMessage}
                                    onChange={this.getDropdownItem.bind(this, 'invoicingMethod')} />

                                <div className="form-group row">
                                    <div className="col-sm-12 model_next_btn">
                                        <button type="button" class="btn btn-default next_btn" onClick= {this.onClickOpen.bind(this)}>Next</button>
                                    </div>
                                </div>
                            </form>
                            </div>
                        <dt>Options </dt>
                        <div>
                            <ModelOption parentCallbackOption = {this.populateOptionInState} nextAndPrevious = {this.populateNext}
                            ref = {this.optionChild}
                            enableIndexDep = {this.props.enableIndexDep} leaseContract = {this.props.leaseContract} /> </div>
                        <dt>Indexation</dt>
                            <div>
                                <ModelIndexation parentCallbackIndexation = {this.populateIndexationInState} nextAndPrevious = {this.populateNext}
                                 ref={this.indexationChild}
                                 enableIndexDep = {this.props.enableIndexDep} leaseContract = {this.props.leaseContract} />
                            </div>
                        <dt>Interest rates</dt>
                            <div>
                                <ModelInterestRate leaseStartDate={this.state.leaseStartDate} 
                                    parentCallbackInterestRt = {this.populateInterestRtState} 
                                    nextAndPrevious = {this.populateNext} modelType = {this.state.modeltypeData}
                                    ref = {this.interestRateChild} viewTLPState = {this.viewTLPGrid}
                                    validation={this.tlpValidation}
                                    enableIndexDep = {this.props.enableIndexDep} leaseContract = {this.props.leaseContract}/>
                            </div>
                </Accordion>

                </div>
                <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog" style={{width: '954px'}}>
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss='modal'>&times;</button>
                                <h4 class="modal-title header_title">TLP Grid</h4>
                            </div>
                            <div class="modal-body">
                                {this.state.showTLPGrid ?
                                    <TLPGrid updateGridStatus={this.updateGridStatus.bind(this)} />
                                    : null
                                }
                            </div>
                        </div>
                    </div>
                </div> 
            
                {this.props.enableIndexDep ?
                     null:
                    <div class="modal-footer" style={{
                        display: 'table', border: 'none', margin: '10px auto auto 75px' }}>
                        <button type="button" onClick={this.saveModelDeal.bind(this)} style={{padding: '2% 3%'}}class="zb-button zb-button-primary model_deal_btn">Model deal</button>
                        <button type="button" class="zb-button zb-button-secondary cancel_deal_btn" data-toggle="modal" data-target="#cancelSave">Cancel</button>
                    </div>
                }
                
                <Popup headerTitle="Cancel saving"
                        headerbody="Are you sure you want to cancel? Any changes will be lost." buttontext1="Yes, cancel saving" buttontext2="No, don't cancel saving" 
                        datatarget="cancelSave" onClick={this.cancelRegistration.bind(this)} />
            </div>
        )
    }
}

export default ModelNewDeal;