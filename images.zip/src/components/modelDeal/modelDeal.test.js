import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import ModelNewDeal from './modelNewDeal.js';
import Adapter from 'enzyme-adapter-react-16';
import renderer from 'react-test-renderer';
import { BrowserRouter as Router } from 'react-router-dom';
import { create } from "react-test-renderer";
import Inputfield from '../../commonComponents/inputDealField';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import Dropdownfield from '../../commonComponents/DropdownField/';
import TLPGrid from '../../commonComponents/TLPGrid';

Enzyme.configure({ adapter: new Adapter() });

let wrapper;
beforeEach(() => {
    wrapper = shallow(<ModelNewDeal />);
});

describe('Customer component', () => {
    test('should shallow correctly', () => {
        expect(wrapper).toMatchSnapshot()
    })

    test('should mount correctly', () => {
        expect(mount(
            <Router>
                <ModelNewDeal />
            </Router>
        )).toMatchSnapshot()
    })

    // test('should render <button>', () => {
    //     expect(wrapper.find('button')).toHaveLength(9);
    // });

    // test('should render <label>', () => {
    //     expect(wrapper.find('label')).toHaveLength(21);
    // });

    // test('should render <input>', () => {
    //     expect(wrapper.find('input')).toHaveLength(12);
    // });

    // test('should render <Accordion>', () => {
    //     expect(wrapper.find('Accordion')).toHaveLength(1);
    // });

    // test('should render <Notification>', () => {
    //     expect(wrapper.find('Notification')).toHaveLength(0);
    // });

    // test('should render <Select>', () => {
    //     expect(wrapper.find('Select')).toHaveLength(1);
    // });

    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(0).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(0).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(1).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(1).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(2).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(2).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(3).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(3).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(4).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(4).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(5).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(5).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(6).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(6).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(7).simulate("change", {
    //         target: { value: "Hello" }
    //     });
    //     expect(wrapper.find('input').at(7).props().value).toEqual("");
    // });
    // test('User text is echoed', () => {
    //     const wrapper = shallow(<ModelNewDeal getDropdownItem={() => { }} />);
    //     wrapper.find("input").at(8).simulate("change", {
    //         target: { value: "1" }
    //     });
    //     expect(wrapper.find('input').at(8).props().value).toEqual("1");
    // });
    // test('User text is echoed', () => {
    //     const mockCallBack = jest.fn();

    //     const button = shallow((<ModelNewDeal selectDealType={mockCallBack} />));
    //     button.find('button').at(4).simulate('click');
    //     expect(mockCallBack.mock.calls.length).toEqual(0);
    // });
    // it('should be handling selectDealType function', () => {
    //     const wrapper1 = shallow(<ModelNewDeal />);
    //     expect(wrapper1.instance().selectDealType()).toEqual(true);
    // });
    // it('should be handling handleChange function', () => {
    //     const wrapper1 = shallow(<ModelNewDeal />);
    //     expect(wrapper1.instance().handleChange()).toEqual(true);
    // });
    // it('should be handling getDropdownItem function', () => {
    //     const wrapper1 = shallow(<ModelNewDeal />);
    //     expect(wrapper1.instance().getDropdownItem()).toEqual(true);
    // });
    // it('should be handling getleaseStartDate function', () => {
    //     const wrapper1 = shallow(<ModelNewDeal />);
    //     expect(wrapper1.instance().getleaseStartDate()).toEqual(true);
    // });
    // it('should be handling fetchTLPCalculation function', () => {
    //     const wrapper1 = shallow(<ModelNewDeal />);
    //     expect(wrapper1.instance().fetchTLPCalculation()).toEqual(true);
    // });
    // test('Should render dropdown component', () => {
    //     const radioGroupField = wrapper.find(Dropdownfield).at(0).dive()
    //     expect(radioGroupField.children()).toHaveLength(2);
    // });
    // test('Should render dropdown component', () => {
    //     const radioGroupField = wrapper.find(Dropdownfield).at(1).dive()
    //     expect(radioGroupField.children()).toHaveLength(2);
    // });
    // test('Should render dropdown component', () => {
    //     const radioGroupField = wrapper.find(Dropdownfield).at(2).dive()
    //     expect(radioGroupField.children()).toHaveLength(2);
    // });
    // test('Should render dropdown component', () => {
    //     const radioGroupField = wrapper.find(Dropdownfield).at(3).dive()
    //     expect(radioGroupField.children()).toHaveLength(2);
    // });
    // test('Should render dropdown component', () => {
    //     const radioGroupField = wrapper.find(Dropdownfield).at(4).dive()
    //     expect(radioGroupField.children()).toHaveLength(2);
    // });
    // test('Should render Calenderinputfield component', () => {
    //     const radioGroupField = wrapper.find(Calenderinputfield).at(0).dive()
    //     expect(radioGroupField.children()).toHaveLength(1);
    // });
    // test('Should render Calenderinputfield component', () => {
    //     const radioGroupField = wrapper.find(Calenderinputfield).at(1).dive()
    //     expect(radioGroupField.children()).toHaveLength(1);
    // });
    // test('Should update state', () => {
    //     const radioGroupField = wrapper.find(ModelNewDeal).at(1).dive()
    //     expect(radioGroupField.children()).toHaveLength(1);
    // });
    // test('Should render dropdown component', () => {
    //     const wrapper = mount(<Router><ModelNewDeal /> </Router>);
    //     expect(wrapper.children(Inputfield).length).toEqual(0);
    // });
    // test('Should render dropdown component', () => {
    //     const wrapper = mount(<Router><ModelNewDeal /> </Router>);
    //     expect(wrapper.children(Calenderinputfield).length).toEqual(0);
    // });
    // test('Should render dropdown component', () => {
    //     const wrapper = mount(<Router><ModelNewDeal /> </Router>);
    //     expect(wrapper.children(TLPGrid).length).toEqual(0);
    // });
});