import React, { Children } from 'react';
import moment from 'moment';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Inputfield from '../../commonComponents/inputDealField';
import { Icon } from '@zambezi/sdk/icons';
import './commonModel.css';
import { Notification } from '@zambezi/sdk/notification';
import { validate } from '../../utils/validation.js';
import { dealValidate } from '../../utils/dealValidation.js';
import Dropdownfield from '../../commonComponents/DropdownField';
import DatePicker from '@zambezi/sdk/date-picker';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import help from '../../assets/images/help.png';
import { CopyDealOption } from '../../models/CopyDeal.js';

class ModelOption extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            flag: true,
            flag1: true,
            counter: 0,
            optionState2 : [0,1,2],
            optionState3 : [0,1],
            optionType: true,
            optionsVal: "No",
            showOption: false,
            optionDateVal: '',
            // optionDateValError: false,
            optionDateValErrorMessage: 'Please complete this field',
            optionNumber: [],
            optionCount: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40],
            optionState : [
                {
                    exciseType: true,
                    premiumType: true,
                    applyto: true,
                    spv: '',
                    spvError: false,
                    spvErrorMessage: '',
                    type: true,
                    upfrontPremium: '',
                    upfrontPremiumError: false,
                    upfrontPremiumErrorMessage: '',
                    exercisePremium: '',
                    exercisePremiumError: false,
                    exercisePremiumErrorMessage: '',
                    optiondate: '',
                    optiondateError: false,
                    optiondateErrorMessage: '',
                    earliernoticedate: '',
                    latestnoticedate: '',
                    optionDateValError: false,
                    earlierNoticeDateValError: false,
                    latestNoticeDateValError: false,
                    optionDateValErrorMessage: '',
                    editOptionId:'',
                    upfrontPremiumType:'amount',
                    exerciseDateType:'amount',
                }
            ],
            calendarErrorMessage: ''
        }
    }

    componentDidMount() {
        this.generateState();
        this.sendData();
    }

    generateState() {
        var reqType = localStorage.getItem('DealRequestType');
        if(this.props.enableIndexDep !== null && this.props.enableIndexDep !== undefined
            && this.props.leaseContract !== null && this.props.leaseContract !== undefined){
            this.generateCopy(this.props.leaseContract);
        } else if(reqType == "SAVE_DEAL"){
            var optionobject = {
            	exciseType: true,
                premiumType: true,
                applyto: true,
                spv: '',
                spvError: false,
                spvErrorMessage: '',
                type: true,
                upfrontPremium: '',
                upfrontPremiumError: false,
                upfrontPremiumErrorMessage: '',
                exercisePremium: '',
                exercisePremiumError: false,
                exercisePremiumErrorMessage: '',
                optiondate: '',
                optiondateError: false,
                optiondateErrorMessage: '',
                earliernoticedate: '',
                latestnoticedate: '',
                optionDateValError: false,
                editOptionId:'',
                upfrontPremiumType:'amount',
                exerciseDateType:'amount',
            };
            for (let j = 0; j < 39; j++) {
                var obj = JSON.parse(JSON.stringify(optionobject));
                this.state.optionState.push(obj);
            }
            this.setState( state =>{
                const optionState = state.optionState;
                return{optionState, value:''};
           });
        } else if(reqType == "COPY_DEAL" || reqType == "EDIT_DEAL"){
            // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
            // var leaseContractOptions = leaseContract.leaseOptions;
            // if(leaseContractOptions !== undefined && leaseContractOptions.length > 0){
                this.generateCopy(this.props.leaseContract);
            this.forceUpdate();
        } 
    }

    generateCopy = (leaseContract) => {
        this.setState({optionsVal:'Yes'});
        var result = CopyDealOption(leaseContract);
                 this.setState( state =>{
                    const optionState = result.leaseOptState;
                    const optionNumber = result.leaseOptionCount;
                    const optionCount = result.OptionRemainingCount;
                    const showOption = result.showOptionVar;
                    return{optionState, optionNumber, showOption, optionCount};
            });
    }

    handleError(type, object, error) {
        console.error('date picker error', error);
        if (error.message) {
            switch (type) {
                case 'earliernoticedate':
                    this.state.optionState['0'].earlierNoticeDateValError = true;
                    this.setState({ calendarErrorMessage: 'Please enter valid date format' });
                    break;
                case 'latestnoticedate':
                    this.state.optionState['0'].latestNoticeDateValError = true;
                    this.setState({ calendarErrorMessage: 'Please enter valid date format' });
                    break;
                case 'earliernoticedates':
                    this.state.optionState[((parseInt(object) - 1)).toString()].earlierNoticeDateValError = true;
                    this.setState({ calendarErrorMessage: 'Please enter valid date format' });
                    break;
                case 'latestnoticedates':
                    this.state.optionState[((parseInt(object) - 1)).toString()].latestNoticeDateValError = true;
                    this.setState({ calendarErrorMessage: 'Please enter valid date format' });
                    break;
                case 'optiondate':
                    this.state.optionState[0].optionDateValError = true;
                    this.setState({ optionDateValErrorMessage: 'Please enter valid date format' });
                    break;
                case 'optiondates':
                    this.state.optionState[((parseInt(object) - 1)).toString()].optionDateValError = true;
                    this.setState({ optionDateValErrorMessage: 'Please enter valid date format' });
                    break;
                default:
            }
        }
        else {
            this.state.optionState[[((parseInt(object) - 1)).toString()]].latestNoticeDateValError = false;
            this.state.optionState[[((parseInt(object) - 1)).toString()]].earlierNoticeDateValError = false;
        }
    }

    validateFields(leaseStartDate, leaseEndDate){

        var validationErrorFlag = false;
        if(this.state.optionState !== null){
            if(this.state.optionNumber != null && 
                this.state.optionNumber != undefined && this.state.showOption !== undefined && 
                        this.state.showOption == true){

                    var startDate = moment(Date.parse(leaseStartDate));
                    var endDate = moment(Date.parse(leaseEndDate));
                    this.state.optionState["0"].optionDateValErrorMessage = null;
                    if(this.state.optionState["0"].optiondate == ""){
                        this.state.optionState["0"].optionDateValError = true;
                        this.state.optionState["0"].optionDateValErrorMessage = "Please complete this field";
                        validationErrorFlag=true;
                    } else {
                    	var optionDate = moment(Date.parse(this.state.optionState["0"].optiondate));
                            if(optionDate.isSame(startDate) || 
                                (optionDate.isAfter(startDate) && optionDate.isBefore(endDate))){
                                    let periodResponseInStr = localStorage.getItem('leaseResponseForPeriod');
                                    let periodResponseInJson = JSON.parse(periodResponseInStr);

                                    let isDateMatched = false;
                                    let optionDateTemp = moment(Date.parse(this.state.optionState["0"].optiondate)).format('YYYY-MM-DD');
                                    
                                    for(let i=0;i<periodResponseInJson.periodRangeDTOList.length;i++){
                                        var periodEndDate = periodResponseInJson.periodRangeDTOList[i].periodEndDate;
                                        if(optionDateTemp.match(periodEndDate)) {
                                            isDateMatched = true;
                                            break;
                                        }
                                    }
                                    if(!isDateMatched) {
                                        this.state.optionState["0"].optionDateValError = true;
                                        this.state.optionState["0"].optionDateValErrorMessage ="Choose a date which is a period closing date";    
                                    } else {
                                        this.state.optionState["0"].optionDateValError = false;
                                    }

                                }else if(optionDate.isAfter(endDate)){
                                    this.state.optionState["0"].optionDateValError = true;
                                    this.state.optionState["0"].optionDateValErrorMessage =  "Option date  cannot be greater than  the lease end date.";   
                                } else {
                                    this.state.optionState["0"].optionDateValError = true;
                                    this.state.optionState["0"].optionDateValErrorMessage ="Please enter date falling between Lease start date and Lease end date";
                                }
                        }

              /*  let v = dealValidate('UpfrontOptionPremium', this.state.optionState["0"].upfrontPremium);
                    if (v[0] == null) {
                        this.state.optionState["0"].upfrontPremiumError = false;
                        this.state.optionState["0"].upfrontPremiumErrorMessage = v[1];
                    } else if (v[0] != null) {
                        this.state.optionState["0"].upfrontPremiumError = !v[0];
                        this.state.optionState["0"].upfrontPremiumErrorMessage = v[1];    
                    }
                let v1 = dealValidate('PremiumAtExerciseDate', this.state.optionState["0"].exercisePremium);
                    if (v1[0] == null) {
                        this.state.optionState["0"].excercisePremiumError = false;
                        this.state.optionState["0"].excercisePremiumErrorMessage = v1[1];
                    } else if (v1[0] != null) {
                        this.state.optionState["0"].excercisePremiumError = !v[0];
                        this.state.optionState["0"].excercisePremiumErrorMessage = v1[1];
                    }*/
                    
                    for (var i = 0; i < this.state.optionNumber.length; i++) {
                        var object = this.state.optionNumber[i];
                        if(this.state.optionState[object -1].optiondate == ""){
                            this.state.optionState[object -1].optionDateValError = true;
                            this.state.optionState[object -1].optionDateValErrorMessage = "Please complete this field";
                            validationErrorFlag=true;
                        } else {
                            let previousDateConsecutiveChk = moment(Date.parse(this.state.optionState[0].optiondate)).format('YYYY-MM-DD');
                            var optionDate = moment(Date.parse(this.state.optionState[object -1].optiondate));
                            if(optionDate.isSame(startDate) || 
                                (optionDate.isAfter(startDate) && optionDate.isBefore(endDate))){
                                    this.state.optionState[object -1].dateErrorField = false;
                                    let periodResponseInStr = localStorage.getItem('leaseResponseForPeriod');
                                    let periodResponseInJson = JSON.parse(periodResponseInStr);

                                    let isDateMatched = false;
                                    let optionDateTemp = moment(Date.parse(this.state.optionState[object -1].optiondate)).format('YYYY-MM-DD');
                                    
                                    for(let i=0;i<periodResponseInJson.periodRangeDTOList.length;i++){
                                        var periodEndDate = periodResponseInJson.periodRangeDTOList[i].periodEndDate;
                                        if(optionDateTemp.match(periodEndDate)) {
                                            isDateMatched = true;
                                            break;
                                        }
                                    }
                                    
                                    if(!isDateMatched) {
                                        this.state.optionState[object -1].optionDateValError = true;
                                        this.state.optionState[object -1].optionDateValErrorMessage ="Choose a date which is a period closing date";    
                                    } else {
                                        if(optionDate.isAfter(previousDateConsecutiveChk)){
                                            this.state.optionState[object -1].optionDateValError = false;
                                            previousDateConsecutiveChk = optionDate;
                                        } else {
                                            validationErrorFlag = true;
                                            this.state.optionState[object -1].optionDateValError = true;
                                            this.state.optionState[object -1].optionDateValErrorMessage ="Option date already exists.";
                                        }
                                       // this.state.optionState[object -1].optionDateValError = false;
                                    }

                                }else if(optionDate.isAfter(endDate)){
                                    this.state.optionState[object -1].optionDateValError = true;
                                    this.state.optionState[object -1].optionDateValErrorMessage =  "Option date  cannot be greater than  the lease end date.";   
                                } else {
                                    this.state.optionState[object -1].dateErrorField = true;
                                    this.state.optionState[object -1].optionDateValError = true;
                                    this.state.optionState[object -1].optiondateErrorMessage ="Please enter date falling between Lease start date and Lease end date";

                                }
                        }
                    }
                }
        }
        return validationErrorFlag;
    }

    handleChange = (e) => {
        if (e.target.name === "spvOptional") {
            var ID = ((parseInt(e.target.id)) - 1).toString();
            this.state.optionState[ID.toString()].spv = e.target.value;
            let v = validate('Validation', e.target.value);
            if (e.target.id == "1") {
                if (v[0] == null) {
                    this.setState({ selectSpvError: false, selectSpvErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ selectSpvError: !v[0], selectSpvErrorMessage: v[1] });
                }
            } else {
                if (v[0] == null) {
                    this.state.optionState[ID.toString()].spvError = false;
                    this.state.optionState[ID.toString()].spvErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.optionState[ID.toString()].spvError = !v[0];
                    this.state.optionState[ID.toString()].spvErrorMessage = v[1];
                }
            }
        } else if (e.target.name === "upfrontPremium") {
            
            var ID = ((parseInt(e.target.id)) - 1).toString();
            this.state.optionState[ID.toString()].upfrontPremium = e.target.value;
            var v = null;
            if(this.state.flag1 == true){
                v = dealValidate('UpfrontOptionPremium', e.target.value);
            }else{
                v = dealValidate('UpfrontOptionPremiumPercent', e.target.value);
            }
            console.log(v);
            if (e.target.id == "1") {
                if (v[0] == null) {
                   this.setState({ upfrontPremiumError: false, upfrontPremiumErrorMessage: v[1] });
                } else if (v[0] != null) {
                   this.setState({ upfrontPremiumError: !v[0], upfrontPremiumErrorMessage: v[1] });
                }
            } else {
                if (v[0] == null) {
                    this.state.optionState[ID.toString()].upfrontPremiumError = false;
                    this.state.optionState[ID.toString()].upfrontPremiumErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.optionState[ID.toString()].upfrontPremiumError = !v[0];
                    this.state.optionState[ID.toString()].upfrontPremiumErrorMessage = v[1];
                }
                this.forceUpdate();
            }
        } 
        else if (e.target.name === "excerciseDatePremium") {
            var ID = ((parseInt(e.target.id)) - 1).toString();
            this.state.optionState[ID.toString()].exercisePremium = e.target.value;
            var v = null;
            if(this.state.flag == true){
                 v = dealValidate('PremiumAtExerciseDate', e.target.value);
            }else{
             v = dealValidate('PremiumAtExerciseDatePercent', e.target.value);
        }
            console.log("credit rating validation::");
            console.log(v);
            if (e.target.id == "1") {
                if (v[0] == null) {
                    this.setState({ excercisePremiumError: false, excercisePremiumErrorMessage: v[1] });
                } else if (v[0] != null) {
                    this.setState({ excercisePremiumError: !v[0], excercisePremiumErrorMessage: v[1] });
                }
            } else {
                if (v[0] == null) {
                    this.state.optionState[ID.toString()].exercisePremiumError = false;
                    this.state.optionState[ID.toString()].exercisePremiumErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.optionState[ID.toString()].exercisePremiumError = !v[0];
                    this.state.optionState[ID.toString()].exercisePremiumErrorMessage = v[1];
                }
                this.forceUpdate();
            }
        } 
        this.sendData();
    }

    getOptionDate(index, type, e) { 
       
        if (e != null) {
            if (type == "optiondate") {
                var ID = ((parseInt(index)) - 1).toString();
                // let time = moment(e).format('DD/MM/YYYY');
                let time = e;
                this.state.optionState[ID.toString()].optiondate = time;
                let v = validate('option', e);
                
                    if (v[0] == null) {
                        this.state.optionState[ID.toString()].optionDateValError = false;
                        this.state.optionState[ID.toString()].optiondateError = false;
                        this.state.optionState[ID.toString()].optiondateErrorMessage = v[1];
                    } else if (v[0] != null) {
                        this.state.optionState[ID.toString()].optiondateError = !v[0];
                        this.state.optionState[ID.toString()].optiondateErrorMessage = v[1];
                        this.state.optionState[ID.toString()].optionDateValError = false;
                    }                
            } else if (type == "earlierdate") { 
                var ID = ((parseInt(index)) - 1).toString();
                let time = e;
                this.state.optionState[ID.toString()].earliernoticedate = time;
                this.state.optionState[ID.toString()].earlierNoticeDateValError = false;
            } else if (type == "latestdate") {
                var ID = ((parseInt(index)) - 1).toString();
                let time = e;
                this.state.optionState[ID.toString()].latestnoticedate = time;
                this.state.optionState[ID.toString()].latestNoticeDateValError = false;
            } 
            // this.forceUpdate();
        }
    }

    selectDealType(dealtype, index) {
         if (dealtype === "spv") {
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].applyto = true;
            this.setState({ applyType: true });
        } else if (dealtype === "property") {
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].applyto = false;
            this.setState({ applyType: false });
        } else if (dealtype === "call") {
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].type = true;
            this.setState({ optionType: true });
        } else if (dealtype === "put") { 
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].type = false;
            this.setState({ optionType: false });
        } else if (dealtype === "Amount") {
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].premiumType = true;
            this.state.optionState[ID.toString()].upfrontPremiumType = 'amount';
            this.setState({ optionType: true });
            this.setState({flag1: true});
        } else if (dealtype === "%") { 
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].premiumType = false;
            this.state.optionState[ID.toString()].upfrontPremiumType = 'percent';
            this.setState({ optionType: false });
            this.setState({flag1: false});
        }  
        return true;
    }

    selectDealOption(dealtype, index) {
        if (dealtype === "Amount") {
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].exciseType = true;
            this.state.optionState[ID.toString()].exerciseDateType = 'amount';
            this.setState({ optionType: true });
            this.setState({flag: true});
        } else if (dealtype === "%") { 
            var ID = ((parseInt(index)) - 1).toString();
            this.state.optionState[ID.toString()].exciseType = false;
            this.state.optionState[ID.toString()].exerciseDateType = 'percent';
            this.setState({ optionType: false });
            this.setState({flag: false});
        }
        return true;
    }

    generateData(type) {
        const data = [];
        if (type == "options") {
            data.push(
                "Yes",
                "No"
            );
        }
        return data
    }

    addMore(type) {
         if (type == "option") {
            if (this.state.optionCount[0] != undefined) {
                var joined = this.state.optionNumber.concat(this.state.optionCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    optionNumber: sort,
                    optionCount: this.state.optionCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        } 
        this.sendData();
        return true;
    }

    deleteMore(type, index, no) {
         if (type == "option") { 
            this.state.optionCount.unshift(no);
            this.state.optionCount.sort(function (a, b) { return a - b; });
            this.state.optionState[no - 1].applyto = true;
            this.state.optionState[no - 1].spv = '';
            this.state.optionState[no - 1].type = true;
            this.state.optionState[no - 1].upfrontPremium = 0;
            this.state.optionState[no - 1].exercisePremium = 0;
            this.state.optionState[no - 1].optiondate = '';
            this.state.optionState[no - 1].earliernoticedate = '';
            this.state.optionState[no - 1].latestnoticedate = '';
            // this.state.contactCount.sort(function (a, b) { return a - b; });
            this.setState({
                optionNumber: this.state.optionNumber.filter((_, i) => i !== index)
            }, function () {
            });
        }
        this.sendData();
        return true;
    }

    getDropdownItem(event, val, type) {
         if (event == "options") {
            if (type.value == "Yes") {
                this.setState({ showOption: true });
            } else { 
                this.setState({ showOption: false });
            }
        }
        return true;
    }

    getOptionShowVal(val){
        if (val == true) {
            return "Yes";
        } else { 
            return "No";
        }
    }

    getOptionInputDate(index, type, e) {

        if (e != null) {
            if (type == "optiondate") {
                var ID = ((parseInt(index)) - 1).toString();
                // let time = moment(e).format('DD/MM/YYYY');
                let time = e;
                this.state.optionState[ID.toString()].optiondate = time;
                let v = validate('option', e);
                if (index == "1") {
                    if (v[0] == null) {
                        // this.setState({ optionDateValError: false, optionDateValErrorMessage: v[1] });
                            this.state.optionState[0].optiondateError = false;
                        // this.state.optionState[0].optiondateErrorMessage = v[1];
                    } else if (v[0] != null) {
                        // this.setState({ optionDateValError: !v[0], optionDateValErrorMessage: v[1] });
                    }
                } else {
                    if (v[0] == null) {
                        this.state.optionState[ID.toString()].optiondateError = false;
                        // this.state.optionState[ID.toString()].optiondateError = false;
                        // this.state.optionState[ID.toString()].optiondateErrorMessage = v[1];
                    } else if (v[0] != null) {
                        this.state.optionState[ID.toString()].optiondateError = !v[0];
                        // this.state.optionState[ID.toString()].optiondateError = !v[0];
                        // this.state.optionState[ID.toString()].optiondateErrorMessage = v[1];
                    }
                }
            //     this.setState( state =>{
            //         const optionState = state.optionState;
            //         return{optionState, value:''};
            //    });
            } else if (type == "earlierdate") {
                var ID = ((parseInt(index)) - 1).toString();
                let time = moment(e).format('DD/MM/YYYY');
                this.state.optionState[ID.toString()].earliernoticedate = time;
            } else if (type == "latestdate") {
                var ID = ((parseInt(index)) - 1).toString();
                let time = moment(e).format('DD/MM/YYYY');
                this.state.optionState[ID.toString()].latestnoticedate = time;
            }

        }
    }

    getOptionDetails = () =>{ 
       
        console.log("Get Index state");
        window.scrollTo(0,1740);
        this.setState({optionState2 : [0,1,2]});
        this.props.nextAndPrevious(this.state.optionState2);
        

        }
        prevBotton = () =>{ 
            window.scrollTo(0,240);
            this.setState({optionState3 : [0,1]});
            this.props.nextAndPrevious(this.state.optionState3);
            
            }

    sendData = () => {
        this.props.parentCallbackOption(this.state.optionState);
        
    }

    render(){
        return(
            <div>
                <Dropdownfield title="Do you want to add options?" classname="font_config_custom"
                    data={this.generateData('options')}
                    errorStatus={false} onChange={this.getDropdownItem.bind(this, 'options')}
                    value={this.getOptionShowVal(this.state.showOption)}
                    defaultval="No" />
                
                {this.state.showOption ?
                    <div>
                       {/* <div className="Separator_line model_Separator_line" />*/}
                    <div className="form-group row">
                        <div class="col-xs-12">
                            <form class="form_content">
                                <label class="label_title" style={{
                                    fontSize: '16px',
                                    marginLeft: '217px'
                                }}>Option 1</label>
                            
                            </form>
                        </div>
                    </div>
                    
                    {/*<div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">Applies to
                    <FlyoutTrigger
                                showOn='hover'
                                position='bottom'
                                flyout={
                                    <Flyout>
                                        An option can be applied to either a SPV or a Property
                                            </Flyout>
                                }>
                                <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                            </FlyoutTrigger>
                        </label>
                        <div className="col-sm-4">
                            <div class="apply_type_model">
                                <div class="btn-group">
                                    <div
                                            className={"btn btn-primary standard_btn " + (this.state.optionState["0"].applyto ? 'dealtype_selected' : 'dealtype_notselected')}
                                            onClick={this.selectDealType.bind(this, 'spv', 1)}
                                            style={{ width: '96px' }} id="1">SPV</div>
                                    <div
                                            className={"btn btn-primary construction_btn " + (!this.state.optionState["0"].applyto ? 'dealtype_selected' : 'dealtype_notselected')}
                                            onClick={this.selectDealType.bind(this, 'property', 1)}
                                        style={{ width: '96px' }}>Property</div>
                                </div>
                            </div>
                        </div>
                            </div>*/}

                    {/* <form class="user_form" style={{ marginTop: '0px', marginLeft: '45px' }}>
                        <div className="form-group row">
                            <label className="col-sm-4 col-form-label field_label">Select SPV (optional)</label>
                        
                            <div className="col-sm-4">
                                <input type="text" maxlength="150" name="spvOptional" id="1"
                                    className="form-control input_Fields" onChange={this.handleChange} placeholder="Enter"
                                        style={{ marginLeft: '2px' }} val={this.state.optionState ? this.state.optionState["0"].spv : null}/>
                            </div>
                            <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '82px' }}>
                                <Icon name="search-small" size="small" />
                            </div>
                        </div>
                        {
                            this.state.selectSpvError ?
                                <div className="form-group row">
                                    <label className="col-sm-4 col-form-label field_label_model" style={{ marginLeft: '0px' }}></label>
                                    <div className="col-sm-5">
                                        <Notification
                                            status='error'
                                            size='small'
                                            withArrow
                                            arrowPosition='14px'
                                            className="error_notification"
                                        >
                                            {this.state.selectSpvErrorMessage}
                                        </Notification>
                                    </div>
                                </div>
                                : null
                        } 
                    </form> */}

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">
                            Option type
                    </label>
                        <div className="col-sm-4">
                            <div class="apply_type_model" style={{ width: '132px' }}>
                                <div class="btn-group">
                                    <div
                                            className={"btn btn-primary standard_btn " + (this.state.optionState["0"].type ? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealType.bind(this, 'call', 1)}
                                        style={{ width: '60px' }}>Call</div>
                                    <div
                                            className={"btn btn-primary construction_btn " + (!this.state.optionState["0"].type? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealType.bind(this, 'put', 1)}
                                        style={{ width: '60px' }}>Put</div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">
                        Upfront option premium
                        <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Enter upfront option premium
                                                        </Flyout>
                                            }>
                        <img src={help} style={{ marginTop: '-5px' }} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-1">
                            <div class="apply_type_model" style={{ width: '192px' }}>
                                <div class="btn-group">
                                    <div
                                            className={"btn btn-primary standard_btn " + (this.state.optionState["0"].upfrontPremiumType==='amount' ? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealType.bind(this, 'Amount', 1)}
                                        style={{ width: '90px' }}>Amount</div>
                                    <div
                                            className={"btn btn-primary construction_btn " + (this.state.optionState["0"].upfrontPremiumType!=='amount'? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealType.bind(this, '%', 1)}
                                        style={{ width: '90px' }}>%</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-1" style={{marginLeft:'130px'}} >
                        <input
                        value={this.state.optionState ? this.state.optionState["0"].upfrontPremium : null}
                        mandateField={this.state.mandateField} type="number" id="1"
                        className="form-control input_Fields_mgs  +"
                        name="upfrontPremium" onChange={this.handleChange} placeholder="Enter"
                        errorStatus={this.state.upfrontPremiumError}
                        errorMessage={this.state.upfrontPremiumErrorMessage} /></div>
                        
                    </div>
                    {this.state.upfrontPremiumError ?
                            <div className="form-group row">
                                <label className="col-sm-2 col-form-label field_label_model"></label>
                            <div className="col-sm-3" style={{ marginLeft:'530px', width: '40%'}}>
                                    <Notification
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification"
                                    >
                                    {this.state.upfrontPremiumErrorMessage}
                            </Notification>
                                </div>
                            </div>
                            : null}

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">
                        Premium paid at option exercise date
                        <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Enter premium paid at option exercise date
                                                        </Flyout>
                                            }>
                        <img src={help} style={{ marginTop: '-5px' }} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-1">
                            <div class="apply_type_model" style={{ width: '192px' }}>
                                <div class="btn-group">
                                    <div
                                            className={"btn btn-primary standard_btn " + (this.state.optionState["0"].exerciseDateType==='amount' ? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealOption.bind(this, 'Amount', 1)}
                                        style={{ width: '90px' }}>Amount</div>
                                    <div
                                            className={"btn btn-primary construction_btn " + (this.state.optionState["0"].exerciseDateType!=='amount'? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealOption.bind(this, '%', 1)}
                                        style={{ width: '90px' }}>%</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-1" style={{marginLeft:'130px'}} >
                        <input
                        value={this.state.optionState ? this.state.optionState["0"].exercisePremium : null}
                        mandateField={this.state.mandateField} type="number" id="1"
                         className="form-control input_Fields_mgs  +"
                        name="excerciseDatePremium" onChange={this.handleChange} placeholder="Enter"
                        errorStatus={this.state.excercisePremiumError}
                        errorMessage={this.state.excercisePremiumErrorMessage} /></div>
                    </div>
                    {this.state.excercisePremiumError ?
                            <div className="form-group row">
                                <label className="col-sm-2 col-form-label field_label_model"></label>
                            <div className="col-sm-3" style={{ marginLeft:'530px', width: '40%'}}>
                                    <Notification
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification"
                                    >
                                    {this.state.excercisePremiumErrorMessage}
                            </Notification>
                                </div>
                            </div>
                            : null}

                    {/*<Inputfield fieldTitle="Upfront option premium" helpIcon={true}
                        helpIconValue="Enter upfront option premium"
                        helpID="premium" value={this.state.optionState ? this.state.optionState["0"].upfrontPremium : null}
                        mandateField={this.state.mandateField} inputType="number" id="1"
                        name="upfrontPremium" onChange={this.handleChange} placeholder="Enter"
                        errorStatus={this.state.upfrontPremiumError}
                                        errorMessage={this.state.upfrontPremiumErrorMessage} />*/}
                
                    {/*<Inputfield fieldTitle="Premium paid at option exercise date" helpIcon={true}
                            helpIconValue="Enter premium paid at option exercise date" helpID="premium" id="1"
                            mandateField={this.state.mandateField} inputType="number" value={this.state.optionState ? this.state.optionState["0"].exercisePremium : null}
                            name="excerciseDatePremium" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.excercisePremiumError}
                                    errorMessage={this.state.excercisePremiumErrorMessage} />*/}
                    
                        <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">Option date</label>
                        <div className="col-sm-6 inner-addon right-addon search_column" >
                                <DatePicker
                                    className="large-date-picker zb_datePicker"
                                    date={this.state.optionState ? this.state.optionState["0"].optiondate : null}
                                    onChange={this.getOptionDate.bind(this, "1", "optiondate")}
                                    placeholder='DD/MM/YYYY'
                                    onInputChange={this.getOptionInputDate.bind(this, "1", "optiondate")}
                                    error={this.state.optionState["0"].optionDateValError}
                                    name='optiondate'
                                    dateFormat='DD/MM/YYYY'
                                    id='1'
                                    onError={this.handleError.bind(this, 'optiondate','0')}/>
                            </div>
                        </div>
                    {this.state.optionState["0"].optionDateValError ?
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label field_label_model"></label>
                            <div className="col-sm-6" style={{ width: '47.5%' }}>
                                    <Notification
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification"
                                    >
                                    {this.state.optionState["0"].optionDateValErrorMessage}
                            </Notification>
                                </div>
                            </div>
                            : null}

                        <Calenderinputfield fieldTitle="Earliest notice date (optional)" 
                            errorStatus={this.state.optionState[0].earlierNoticeDateValError} id='1' 
                            value={this.state.optionState ? this.state.optionState["0"].earliernoticedate : ''}
                            inputType="date" name="earliernoticedate" 
                            onError={this.handleError.bind(this, 'earliernoticedate','0')}
                            onChange={this.getOptionDate.bind(this, "1", "earlierdate")} 
                            placeholder="DD/MM/YYYY"   errorMessage={this.state.calendarErrorMessage} />
                        <Calenderinputfield fieldTitle="Latest notice date (optional)" 
                        errorStatus={this.state.optionState[0].latestNoticeDateValError}  id='1' 
                            value={this.state.optionState ? this.state.optionState["0"].latestnoticedate : ''}
                            inputType="date" name="latestnoticedate" onError={this.handleError.bind(this, 'latestnoticedate','0')}
                            onChange={this.getOptionDate.bind(this, "1", "latestdate")} 
                            placeholder="DD/MM/YYYY"   errorMessage={this.state.calendarErrorMessage} />                 
                        
                        {this.state.optionNumber.map((object, i) => (
                
                            <div>
                                
                                <div className="form-group row">
                                    <div class="col-xs-12">
                                    <div className="Separator_line model_Separator_line" />

                                        <form class="form_content">
                                            <label class="col-xs-5 label_title" style={{
                                                fontSize: '16px',
                                                marginLeft: '217px'
                                            }}>Option {object}</label>

                                            <div className="col-xs-3 " style={{ marginTop: '25px' }}
                                                onClick={this.deleteMore.bind(this, "option", i, object)}>
                                                <Icon name="trash-small" size="small" /><span 
                                                className="remove_icon_span"
                                                style={{
                                                    marginLeft: '5px',
                                                    position: 'absolute'
                                                }}>Remove Option</span>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                {/*<div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Applies to
                    <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    An option can be applied to either a SPV or a Property
                                            </Flyout>
                                            }>
                                            <img src={help} onClick={e => e.preventDefault()} className="tooltip_help" />
                                        </FlyoutTrigger>
                                    </label>
                                    <div className="col-sm-4">
                                        <div class="apply_type_model">
                                            <div class="btn-group">
                                                <div
                                                    className={"btn btn-primary standard_btn " + (this.state.optionState[((parseInt(object) - 1)).toString()].applyto ? 'dealtype_selected' : 'dealtype_notselected')}
                                                    onClick={this.selectDealType.bind(this, 'spv', object)}
                                                    style={{ width: '96px' }}>SPV</div>
                                                <div
                                                    className={"btn btn-primary construction_btn " + (!this.state.optionState[((parseInt(object) - 1)).toString()].applyto ? 'dealtype_selected' : 'dealtype_notselected')}
                                                    onClick={this.selectDealType.bind(this, 'property', object)}
                                                    style={{ width: '96px' }}>Property</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>*/}

                                {/*<form class="user_form" style={{ marginTop: '0px', marginLeft: '45px' }}>
                                    <div className="form-group row">
                                        <label className="col-sm-4 col-form-label field_label">Select SPV (optional) </label>

                                        <div className="col-sm-4">
                                            <input type="text" maxlength="20" name="spvOptional" id={object}
                                                className="form-control input_Fields" onChange={this.handleChange} placeholder="Enter"
                                                style={{ marginLeft: '2px' }} val={this.state.optionState[((parseInt(object) - 1)).toString()].spv} />
                                        </div>
                                        <div className="col-sm-1" style={{ marginTop: '10px', marginLeft: '82px' }}>
                                            <Icon name="search-small" size="small" />
                                        </div>
                                    </div>
                                    {
                                        this.state.selectSpvError ?
                                            <div className="form-group row">
                                                <label className="col-sm-4 col-form-label field_label_model" style={{ marginLeft: '0px' }}></label>
                                                <div className="col-sm-5">
                                                    <Notification
                                                        status='error'
                                                        size='small'
                                                        withArrow
                                                        arrowPosition='14px'
                                                        className="error_notification"
                                                    >
                                                        {this.state.selectSpvErrorMessage}
                                                    </Notification>
                                                </div>
                                            </div>
                                            : null
                                    }
                                </form>*/}

                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Option type</label>
                                    <div className="col-sm-4">
                                        <div class="apply_type_model" style={{ width: '132px' }}>
                                            <div class="btn-group">
                                                <div
                                                    className={"btn btn-primary standard_btn " + (this.state.optionState[((parseInt(object) - 1)).toString()].type ? 'dealtype_selected' : 'dealtype_notselected')}
                                                    onClick={this.selectDealType.bind(this, 'call', object)}
                                                    style={{ width: '60px' }}>Call</div>
                                                <div
                                                    className={"btn btn-primary construction_btn " + (!(this.state.optionState[((parseInt(object) - 1)).toString()].type) ? 'dealtype_selected' : 'dealtype_notselected')}
                                                    onClick={this.selectDealType.bind(this, 'put', object)}
                                                    style={{ width: '60px' }}>Put</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                    <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">
                        Upfront option premium
                        <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Enter upfront option premium
                                                        </Flyout>
                                            }>
                        <img src={help} style={{ marginTop: '-5px' }} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-1">
                            <div class="apply_type_model" style={{ width: '192px' }}>
                                <div class="btn-group">
                                    <div
                                            className={"btn btn-primary standard_btn " + (this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumType==='amount' ? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealType.bind(this, 'Amount', object)}
                                        style={{ width: '90px' }}>Amount</div>
                                    <div
                                            className={"btn btn-primary construction_btn " + ((this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumType!=='amount')? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealType.bind(this, '%', object)}
                                        style={{ width: '90px' }}>%</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-1" style={{marginLeft:'130px'}} >
                        <input
                        value={this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremium}
                        mandateField={this.state.mandateField} type="number" id={object}
                         className="form-control input_Fields_mgs  +"
                        name="upfrontPremium" onChange={this.handleChange} placeholder="Enter"
                        errorStatus={this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumError}
                        errorMessage={this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumErrorMessage} /></div>
                    </div>
                    {this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumError ?
                            <div className="form-group row">
                                <label className="col-sm-2 col-form-label field_label_model"></label>
                            <div className="col-sm-3" style={{ marginLeft:'530px', width: '40%'}}>
                                    <Notification
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification"
                                    >
                                    {this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumErrorMessage}
                            </Notification>
                                </div>
                            </div>
                            : null}
                               {/*} <Inputfield fieldTitle="Upfront option premium" helpIcon={true} helpIconValue="Enter upfront option premium"
                                    helpID="premium" value={this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremium}
                                    mandateField={this.state.mandateField} inputType="number" id={object}
                                    name="upfrontPremium" onChange={this.handleChange} placeholder="Enter"
                                    errorStatus={this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumError}
		                            errorMessage={this.state.optionState[((parseInt(object) - 1)).toString()].upfrontPremiumErrorMessage} />*/}

                        <div class="form-group row">
                        <label for="" class="col-sm-4 col-form-label field_label_model">
                        Premium paid at option exercise date
                        <FlyoutTrigger
                                            showOn='hover'
                                            position='bottom'
                                            flyout={
                                                <Flyout>
                                                    Enter premium paid at option exercise date
                                                        </Flyout>
                                            }>
                        <img src={help} style={{ marginTop: '-5px' }} onClick={e => e.preventDefault()} className="tooltip_help" />
                        </FlyoutTrigger>
                    </label>
                    <div className="col-sm-1">
                            <div class="apply_type_model" style={{ width: '192px' }}>
                                <div class="btn-group">
                                    <div
                                            className={"btn btn-primary standard_btn " + (this.state.optionState[((parseInt(object) - 1)).toString()].exerciseDateType==='amount' ? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealOption.bind(this, 'Amount', object)}
                                        style={{ width: '90px' }}>Amount</div>
                                    <div
                                            className={"btn btn-primary construction_btn " + ((this.state.optionState[((parseInt(object) - 1)).toString()].exerciseDateType!=='amount')? 'dealtype_selected' : 'dealtype_notselected')}
                                        onClick={this.selectDealOption.bind(this, '%', object)}
                                        style={{ width: '90px' }}>%</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-1" style={{marginLeft:'130px'}} >
                        <input
                        value={this.state.optionState[((parseInt(object) - 1)).toString()].exercisePremium}
                        mandateField={this.state.mandateField} type="number" id={object}
                         className="form-control input_Fields_mgs  +"
                        name="excerciseDatePremium" onChange={this.handleChange} placeholder="Enter"
                        errorStatus={this.state.optionState[((parseInt(object) - 1)).toString()].exercisePremiumError}
                        errorMessage={this.state.optionState[((parseInt(object) - 1)).toString()].exercisePremiumErrorMessage} /></div>
                        
                    </div>
                    {this.state.optionState[((parseInt(object) - 1)).toString()].excercisePremiumError ?
                            <div className="form-group row">
                                <label className="col-sm-2 col-form-label field_label_model"></label>
                            <div className="col-sm-3" style={{ marginLeft:'530px', width: '40%'}}>
                                    <Notification
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification"
                                    >
                                    {this.state.optionState[((parseInt(object) - 1)).toString()].excercisePremiumErrorMessage}
                            </Notification>
                                </div>
                            </div>
                            : null}

                               {/* <Inputfield fieldTitle="Premium paid at option exercise date" helpIcon={true}
                                    helpIconValue="Enter premium paid at option exercise date" helpID="premium"
                                    value={this.state.optionState[((parseInt(object) - 1)).toString()].exercisePremium}
                                    mandateField={this.state.mandateField} inputType="number" id={object}
                                    name="excerciseDatePremium" onChange={this.handleChange} placeholder="Enter" 
                                    errorStatus={this.state.optionState[((parseInt(object) - 1)).toString()].exercisePremiumError}
                                    errorMessage={this.state.optionState[((parseInt(object) - 1)).toString()].exercisePremiumErrorMessage} />*/}

                                <div class="form-group row">
                                    <label for="" class="col-sm-4 col-form-label field_label_model">Option date</label>
                                    <div className="col-sm-6 inner-addon right-addon search_column" >
                                        <DatePicker
                                            className="large-date-picker zb_datePicker"
                                            date={this.state.optionState[((parseInt(object) - 1)).toString()].optiondate}
                                            onChange={this.getOptionDate.bind(this, object, "optiondate")}
                                            placeholder='DD/MM/YYYY'
                                            onInputChange={this.getOptionInputDate.bind(this, object, "optiondate")}
                                            error={this.state.optionState[((parseInt(object) - 1)).toString()].optionDateValError}
                                            name='optiondate'
                                            dateFormat='DD/MM/YYYY'
                                            id={object}
                                            onError={this.handleError.bind(this, 'optiondates',object)}
                                        />
                                    </div>
                                </div>
                                {this.state.optionState[((parseInt(object) - 1)).toString()].optionDateValError ?
                                    <div className="form-group row">
                                        <label className="col-sm-4 col-form-label field_label_model"></label>
                                        <div className="col-sm-6" style={{ width: '47.5%' }}>
                                            <Notification
                                                status='error'
                                                size='small'
                                                withArrow
                                                arrowPosition='14px'
                                                className="error_notification"
                                            >
                                                {this.state.optionState[((parseInt(object) - 1)).toString()].optionDateValErrorMessage}
                                            </Notification>
                                        </div>
                                    </div>
                                    : null}

                                <Calenderinputfield fieldTitle="Earliest notice date (optional)" errorStatus={this.state.optionState[((parseInt(object) - 1)).toString()].earlierNoticeDateValError} id={object} 
                                    value={this.state.optionState? this.state.optionState[((parseInt(object) - 1)).toString()].earliernoticedate:''}
                                    inputType="date" name="earliernoticedate" onError={this.handleError.bind(this, 'earliernoticedates',object)}
                                    onChange={this.getOptionDate.bind(this, object, "earlierdate")} onInputChange={this.getOptionInputDate.bind(this, object, "earlierdate")}
                                    placeholder="DD/MM/YYYY"  errorMessage={this.state.calendarErrorMessage} />
                                <Calenderinputfield fieldTitle="Latest notice date (optional)"errorStatus={this.state.optionState[((parseInt(object) - 1)).toString()].latestNoticeDateValError} id={object} 
                                    value={this.state.optionState? this.state.optionState[((parseInt(object) - 1)).toString()].latestnoticedate:''} 
                                    inputType="date" name="latestnoticedate"
                                    onError={this.handleError.bind(this, 'latestnoticedates',object)}
                                    onChange={this.getOptionDate.bind(this, object , "latestdate")} onInputChange={this.getOptionInputDate.bind(this, object, "latestdate")}
                                    placeholder="DD/MM/YYYY"  errorMessage={this.state.calendarErrorMessage}/>
                            </div>
                            
                        ))}
                        <div className="form-group row">
                            <div className="col-sm-12 add_credit_rating">
                                <label className="col-sm-3 col-form-label field_label_credit"></label>
                                <div className="col-sm-4 add_credit_rating_btn" style={{ marginLeft: '110px' }} >
                                    <Icon name="plus-xsmall" size='small' /> <label className="uploadDocument" onClick={this.addMore.bind(this, "option")}> Add another option</label>
                                </div>
                            </div>
                        </div>
                    </div>
                : null}

                <div className="model_line" style={{
                    width: '800px',
                    margin: 'auto'
                }}></div>
                <div className="form-group row" style={{ marginTop: '16px' }}>
                    <div className="col-sm-3 model_next_btn" style={{ float: 'right'}}>
                        <button type="button" class="zb-button zb-button-primary next_btn" 
                        onClick={this.getOptionDetails.bind(this)} 
                            style={{
                                width: '179px',
                            }}>Next</button>
                    </div>
                    <div className="col-sm-3 model_next_btn" style={{
                        float: 'right',
                    }}>
                        <button type="button" class=" zb-button zb-button-secondary next_btn"
                            style={{
                                width: '181px',
                                marginRight: '0px'
                            }} onClick = {this.prevBotton.bind(this)}>Back to general</button>
                    </div>
                </div>
            </div>

    );
}
}
export default ModelOption;