import React from 'react';
import moment from 'moment';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Inputfield from '../../commonComponents/inputDealField';
import { Icon } from '@zambezi/sdk/icons';
import './commonModel.css';
import TwoWayButton from '../../commonComponents/twoWayFormBntGrp';
import { validate } from '../../utils/validation.js';
import { dealValidate } from '../../utils/dealValidation.js'
import { API_ENDPOINT } from '../../config/config.js';
import { HttpGet } from '../../services/api.js';
import { Notification } from '@zambezi/sdk/notification';
import { CopyDealInterestRate } from '../../models/CopyDeal.js';

class ModelInterestRate extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            optionState2 : [0,1,2,3],
            zeroIntRtFloor: true,
            interestNumber: [],
            interestCount: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
            interestState : [{
                date: '',
                tlpPeriod: '',
                marginPeriod: '',
                ReferencePeriod: '',
                dateErrorField:false,
                tlpPeriodErrorField:false,
                marginPeriodErrorField:false,
                referencePeriodErrorField:false,
                referenceRatePeriodErrorMessage: '',
                marginPeriodErrorMessage: '',
                tlpPeriodErrorMessage: '',
                editInterestRtId:'',

               
            }],
            dealErrorMessage: 'Please complete this field',
            calendarErrorMessage: '',
            leaseTenure: '',
            leaseStartDate:'',
            currencyName: ''
        }
        
        this.handleChange = this.handleChange.bind(this);
        this.fetchTLPCalculation = this.fetchTLPCalculation.bind(this);
    }

    componentDidMount() {
        this.generateState();
        this.sendData();
    }

    validateFields(leaseStartDate, leaseEndDate){
        var validationErrorFlag = false;
        let previousDateConsecutiveChk = moment(Date.parse(leaseStartDate)).format('YYYY-MM-DD');
        if(this.state.interestState !== null){
            if(this.state.interestNumber != null && 
                this.state.interestNumber != undefined){

                    var startDate = moment(Date.parse(leaseStartDate));
                    var endDate = moment(Date.parse(leaseEndDate));
                    this.state.interestState["0"].interestDateStatus = null;
                    if(this.state.interestState["0"].date == ""){
                        this.state.interestState["0"].dateErrorField = true;
                        this.state.interestState["0"].interestDateStatus = "Please complete this field";
                        validationErrorFlag = true;
                    } else {
                        var indexDate = moment(Date.parse(this.state.interestState["0"].date));
                        this.state.interestState["0"].dateErrorField = false;
                        if(indexDate.isSame(startDate) || 
                            (indexDate.isAfter(startDate) && indexDate.isBefore(endDate))){
                                this.state.interestState["0"].dateErrorField = false;
                                let periodResponseInStr = localStorage.getItem('leaseResponseForPeriod');
                                    let periodResponseInJson = JSON.parse(periodResponseInStr);

                                    let isDateMatched = false;
                                    let interestDateTemp = moment(Date.parse(this.state.interestState["0"].date)).format('YYYY-MM-DD');
                                    if(null!= periodResponseInJson.periodRangeDTOList){
                                    for(let i=0;i<periodResponseInJson.periodRangeDTOList.length;i++){
                                        var periodStartDate = periodResponseInJson.periodRangeDTOList[i].periodStartDate;
                                        if(interestDateTemp.match(periodStartDate)) {
                                            isDateMatched = true;
                                            break;
                                        }
                                    }
                                }
                                    if(!isDateMatched) {
                                        validationErrorFlag = true;
                                        this.state.interestState["0"].dateErrorField = true;
                                        this.state.interestState["0"].interestDateStatus ="Please enter date as start date of any period";    
                                    } else {
                                        this.state.interestState["0"].dateErrorField = false;
                                    }
                        } else {
                            this.state.interestState["0"].interestDateStatus ="Please enter date falling between Lease start date and Lease end date";
                            this.state.interestState["0"].dateErrorField = true;
                            validationErrorFlag=true;
                        }
                    }
                    
                    let v = dealValidate('ReferenceRatePeriod', this.state.interestState["0"].ReferencePeriod);
                        if (v[0] == null) {
                            this.state.interestState["0"].referencePeriodErrorField = false;
                            this.state.interestState["0"].referenceRatePeriodErrorMessage = v[1];
                        } else if (v[0] != null) {
                            this.state.interestState["0"].referencePeriodErrorField = !v[0];
                            this.state.interestState["0"].referenceRatePeriodErrorMessage = v[1];
                        }
                        if(!this.props.modelType == "Solving for margin"){
                            let v1 = dealValidate('MarginPeriod', this.state.interestState["0"].marginPeriod);
                            if (v1[0] == null) {
                                this.state.interestState["0"].marginPeriodErrorField = false;
                                this.state.interestState["0"].marginPeriodErrorMessage = v1[1];
                            } else if (v1[0] != null) {
                                this.state.interestState["0"].marginPeriodErrorField = !v1[0];
                                this.state.interestState["0"].marginPeriodErrorMessage = v1[1];
                            }
                        } 
                    
                    let v2 = dealValidate('TLPPeriod', this.state.interestState["0"].tlpPeriod);
                        if (v2[0] == null) {
                            this.state.interestState["0"].tlpPeriodErrorField = false;
                            this.state.interestState["0"].tlpPeriodErrorMessage = v2[1];
                        } else if (v2[0] != null) {
                            this.state.interestState["0"].tlpPeriodErrorField = !v2[0];
                            this.state.interestState["0"].tlpPeriodErrorMessage = v2[1];
                        }

                        
                    for (var i = 0; i < this.state.interestNumber.length; i++) {
                        var object = this.state.interestNumber[i];
                        this.state.interestState[object -1].interestDateStatus = null;

                        if(this.state.interestState[object -1].date == ""){
                            this.state.interestState[object -1].dateErrorField = true;
                            this.state.interestState[object -1].interestDateStatus = "Please complete this field";
                            validationErrorFlag=true;
                        } else { 
                            var indexDate = moment(Date.parse(this.state.interestState[object -1].date));
                            this.state.interestState[object -1].dateErrorField = false;
                            if(indexDate.isSame(startDate) || 
                                (indexDate.isAfter(startDate) && indexDate.isBefore(endDate))){

                                    let periodResponseInStr = localStorage.getItem('leaseResponseForPeriod');
                                    let periodResponseInJson = JSON.parse(periodResponseInStr);

                                    let isDateMatched = false;
                                    let interestDateTemp = moment(Date.parse(this.state.interestState[object -1].date)).format('YYYY-MM-DD');
                                    
                                    for(let i=0;i<periodResponseInJson.periodRangeDTOList.length;i++){
                                        var periodStartDate = periodResponseInJson.periodRangeDTOList[i].periodStartDate;
                                        if(interestDateTemp.match(periodStartDate)) {
                                            isDateMatched = true;
                                            break;
                                        }
                                    }

                                    if(!isDateMatched) {
                                        validationErrorFlag = true;
                                        this.state.interestState[object -1].dateErrorField = true;
                                        this.state.interestState[object -1].interestDateStatus ="Please enter date as start date of any period.";    
                                    } else {
                                       if(indexDate.isAfter(previousDateConsecutiveChk)){
                                            this.state.interestState[object -1].dateErrorField = false;
                                            previousDateConsecutiveChk = interestDateTemp;
                                        } else {
                                            validationErrorFlag = true;
                                            this.state.interestState[object -1].dateErrorField = true;
                                            this.state.interestState[object -1].interestDateStatus ="Please enter date greater than previous period.";
                                        }
                                    }

                            } else {
                                this.state.interestState[object -1].interestDateStatus ="Please enter date falling between Lease start date and Lease end date";
                                this.state.interestState[object -1].dateErrorField = true;
                                validationErrorFlag=true;
                            }
                        }

                        let v = dealValidate('ReferenceRatePeriod', this.state.interestState[object -1].ReferencePeriod);
                        if (v[0] == null) {
                            this.state.interestState[object -1].referencePeriodErrorField = false;
                            this.state.interestState[object -1].referenceRatePeriodErrorMessage = v[1];
                        } else if (v[0] != null) {
                            this.state.interestState[object -1].referencePeriodErrorField = !v[0];
                            this.state.interestState[object -1].referenceRatePeriodErrorMessage = v[1];
                        }
                        if(!this.props.modelType == "Solving for margin"){
                            let v1 = dealValidate('MarginPeriod', this.state.interestState[object-1].marginPeriod);
                            if (v1[0] == null) {
                                this.state.interestState[object-1].marginPeriodErrorField = false;
                                this.state.interestState[object-1].marginPeriodErrorMessage = v1[1];
                            } else if (v1[0] != null) {
                                this.state.interestState[object-1].marginPeriodErrorField = !v1[0];
                                this.state.interestState[object-1].marginPeriodErrorMessage = v1[1];
                            }
                        }
                        
                    let v2 = dealValidate('TLPPeriod', this.state.interestState[object-1].tlpPeriod);
                        if (v2[0] == null) {
                            this.state.interestState[object-1].tlpPeriodErrorField = false;
                            this.state.interestState[object-1].tlpPeriodErrorMessage = v2[1];
                        } else if (v2[0] != null) {
                            this.state.interestState[object-1].tlpPeriodErrorField = !v2[0];
                            this.state.interestState[object-1].tlpPeriodErrorMessage = v2[1];
                        }

                      
                    }
                }
        }
        return validationErrorFlag;
    }

    generateState() { 
        // var interestState = [];
        var reqType = localStorage.getItem('DealRequestType');
        if(this.props.enableIndexDep !== null && this.props.enableIndexDep !== undefined
            && this.props.leaseContract !== null && this.props.leaseContract !== undefined){
            this.generateCopy(this.props.leaseContract);
        } else if(reqType == "SAVE_DEAL"){
            var interestobject = {
                date: '',
                tlpPeriod: '',
                marginPeriod: '',
                ReferencePeriod: '',
                dateErrorField:false,
                tlpPeriodErrorField:false,
                marginPeriodErrorField:false,
                referencePeriodErrorField:false,
                referenceRatePeriodErrorMessage: '',
                marginPeriodErrorMessage: '',
                tlpPeriodErrorMessage: '',
                editInterestRtId:'',
    
            };
            for (let j = 0; j < 19; j++) {
                var obj = JSON.parse(JSON.stringify(interestobject));
                this.state.interestState.push(obj);
            }
            this.setState( state =>{
                const interestState = state.interestState;
                return{interestState, value:''};
           });
        } else if(reqType == "COPY_DEAL" || reqType == "EDIT_DEAL"){
            // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
            this.generateCopy(this.props.leaseContract);
        } 
        
    }

    generateCopy = (leaseContract) => {
        var interestCopyState = CopyDealInterestRate(leaseContract);
            this.state.interestState = interestCopyState.interestRtState;
            this.state.interestNumber = interestCopyState.interestRtCount;
            this.setState( state =>{
                const interestState = interestCopyState.interestRtState;
                const interestNumber = interestCopyState.interestRtCount;
                const interestCount = interestCopyState.interestRemainCount;
                return{interestState, interestNumber, interestCount};
           });
           this.forceUpdate();
    }

    selectZeroIntRtFloor(zeroRt) {
        if(zeroRt !== undefined){
            if (zeroRt === 'Yes') {
                this.setState({ zeroIntRtFloor: true });
            } else {
                this.setState({ zeroIntRtFloor: false });
            }
        }
        return true;
    }

    handleChange = (e) => {
        if (e !== undefined && e.target !== undefined && e.target.name !== undefined ) { 
             if (e.target.name === "tlpperiod") {
                var ID = ((parseInt(e.target.id)) - 1).toString();
                this.state.interestState[ID.toString()].tlpPeriod = e.target.value;
                this.state.interestState[ID.toString()].tlpPeriodErrorField = false;
                let v = dealValidate('TLPPeriod', e.target.value);
                        if (v[0] == null) {
                            this.state.interestState[ID.toString()].tlpPeriodErrorField = false;
                            this.state.interestState[ID.toString()].tlpPeriodErrorMessage = v[1];
                            //this.setState({ tlpPeriodError: false, tlpPeriodErrorMessage: v[1] });
                        } else if (v[0] != null) {
                            this.state.interestState[ID.toString()].tlpPeriodErrorField = !v[0];
                            this.state.interestState[ID.toString()].tlpPeriodErrorMessage = v[1];
                           // this.setState({ tlpPeriodError: !v[0], tlpPeriodErrorMessage: v[1] });
                        }
                console.log("state set::  ", this.state.interestState)
            }else if (e.target.name === "marginperiod") {
                // var ID = ((parseInt(e.target.id)) - 1).toString();
                // this.state.interestState[ID.toString()].marginPeriod = e.target.value;
                this.state.interestState[e.target.id-1].marginPeriod = e.target.value;
                this.state.interestState[e.target.id-1].marginPeriodErrorField = false;
                let v = dealValidate('MarginPeriod', e.target.value);
                        if (v[0] == null) {
                            this.state.interestState[e.target.id-1].marginPeriodErrorField = false;
                            this.state.interestState[e.target.id-1].marginPeriodErrorMessage = v[1];
                            //this.setState({ marginPeriodError: false, marginPeriodErrorMessage: v[1] });
                        } else if (v[0] != null) {
                            this.state.interestState[e.target.id-1].marginPeriodErrorField = !v[0];
                            this.state.interestState[e.target.id-1].marginPeriodErrorMessage = v[1];
                            //this.setState({ marginPeriodError: !v[0], marginPeriodErrorMessage: v[1] });
                        }
            } else if (e.target.name === "referenceperiod") {
                // var ID = ((parseInt(e.target.id)) - 1).toString();
                // this.state.interestState[ID.toString()].ReferencePeriod = e.target.value;
                this.state.interestState[e.target.id-1].ReferencePeriod = e.target.value;
                this.state.interestState[e.target.id-1].referencePeriodErrorField = false;
                let v = dealValidate('ReferenceRatePeriod', e.target.value);
                        if (v[0] == null) {
                            this.state.interestState[e.target.id-1].referencePeriodErrorField = false;
                            this.state.interestState[e.target.id-1].referenceRatePeriodErrorMessage = v[1];
                            //this.setState({ referenceRatePeriodError: false, referenceRatePeriodErrorMessage: v[1] });
                        } else if (v[0] != null) {
                            this.state.interestState[e.target.id-1].referencePeriodErrorField = !v[0];
                            this.state.interestState[e.target.id-1].referenceRatePeriodErrorMessage = v[1];
                            //this.setState({ referenceRatePeriodError: !v[0], referenceRatePeriodErrorMessage: v[1] });
                        }
            } 
        }
        this.setState( state =>{
            const interestState = state.interestState;
            return{interestState, value:''};
       });
       this.sendData();
        return true;
    }

    validation(leaseStartDate, leaseEndDate){
        let v = validate('tenor', this.state.leaseTenure);
        if (v[0] == null) {
            this.setState({ tenorErrorState: false, tenorErrorMessage: v[1] });
        } else if (v[0] != null){
            this.setState({ tenorErrorState: !v[0], tenorErrorMessage: v[1] });
        }
        if (this.state.leaseStartDate == "" || this.state.leaseStartDate == null) {
            this.setState({ leaseStartDateError: true });
        } else { 
            
            this.setState({ leaseStartDateError: false });
        }
        if (this.state.currencyName == "") {
            this.setState({ currencyStatus: true });
        } else {
            this.setState({ currencyStatus: false });
        }
    }

    setInterestRateState(){
        this.setState( state =>{
                    const interestState = state.interestState;
                    return{interestState, value:''};
               });
    }

    getInterestrateDate(e, ID, val) {
        if (val != "") {
            let obj = val;
            // let time = moment(obj).format('DD/MM/YYYY');
            var _ID = ((parseInt(ID)) - 1).toString();
            this.state.interestState[_ID.toString()].date = obj;
            this.state.interestState[_ID.toString()].dateErrorField = false;
            console.log("state set::  ", this.state.interestState);
        } else {
            var _ID = ((parseInt(ID)) - 1).toString();
            this.state.interestState[_ID.toString()].date = "";
        }
        this.setState( state =>{
            const interestState = state.interestState;
            return{interestState, value:''};
       });
        return true;
    }

    fetchTLPCalculation(e) {
        let arrIndex = ((parseInt(e.target.id) - 1)).toString();
        this.validation();
        this.props.validation();
        console.log("Fetch TLP");
        console.log(this.state.leaseStartDate);
        console.log(this.state.leaseTenure);
        console.log(this.state.currencyName);
        if (this.state.leaseStartDate && this.state.leaseTenure && this.state.currencyName) {
            this.setState({ pageErrorStatus: false });
            let time = moment(this.state.leaseStartDate).format('DD-MM-YYYY');
            var currentComponent = this;
            let endPoint = API_ENDPOINT.TLP_BASE_GRID + '/' + this.state.leaseTenure + '/' + this.state.currencyName + '/' + time + '/12-12-2080';
            let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
                console.log("Response received from server");
                console.log(response.data);
                console.log(response.data.tlp);
                console.log("Response received from server");
                currentComponent.state.interestState[arrIndex].tlpPeriod = response.data.tlp;
                currentComponent.setState({ interestState: currentComponent.state.interestState }, function(){
                    currentComponent.forceUpdate();
                });
            })
                .catch(function (error) {
                })
        } else {
            this.setState({ pageErrorStatus: true });
        }
        return true;
    }

    updateGridStatus(val) {
        if (val == "Pending_For_Approval") {
            this.setState({ gridStatus: 'Pending' });
        } else {
            this.setState({ gridStatus: val });
        }

        if (val != '') {
            this.setState({ showGridStatus: true });
        } else {
            this.setState({ showGridStatus: false });
        }
    }


    addMore(type) {
        if (type == "interest") {
            if (this.state.interestCount[0] != undefined) {
                var joined = this.state.interestNumber.concat(this.state.interestCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    interestNumber: sort,
                    interestCount: this.state.interestCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        }
        this.sendData();
        return true;
    }
	
	viewTLPGrid() {
        this.props.viewTLPState();
    }

    prevBotton = () =>{ 
        this.setState({optionState2 : [0,1,2,3]});
        this.props.nextAndPrevious(this.state.optionState2);
        window.scrollTo(0,1740);
             }

    sendData = () => {
        this.props.parentCallbackInterestRt(this.state.interestState);
    }

    deleteMore(type, index, no) {
        if (type == "interest") {
          this.state.interestCount.unshift(no);
          this.state.interestCount.sort(function (a, b) { return a - b; });
          this.state.interestState[no - 1].date = '';
          this.state.interestState[no - 1].tlpPeriod = '';
          this.state.interestState[no - 1].marginPeriod = '';
          this.state.interestState[no - 1].ReferencePeriod = '';
        //   this.state.interestCount.sort(function (a, b) { return a - b; });
            this.setState({
                interestNumber: this.state.interestNumber.filter((_, i) => i !== index)
            }, function () {
            });
        }
        this.sendData();
        return true;
    }

	handleError(type, object, error) {
        console.error('date picker error', error);
        if (error.message && type === 'interestratedate') {
           this.setState({calendarErrorMessage: 'Enter valid date format'});
            this.state.interestState["0"].dateErrorField  = true;
        }
        else if (error.message && type === 'interestratedates'){
            this.setState({calendarErrorMessage: 'Enter valid date format'});
            this.state.interestState[((parseInt(object) - 1)).toString()].dateErrorField = true;
        }
        else {
            this.state.interestState["0"].dateErrorField  = false;
            this.state.interestState[((parseInt(object) - 1)).toString()].dateErrorField = false;            
        }
    }

    setParameterFromParent (leaseStartDate, leaseEndDate, tenor, currencyName, interestDate) {
        if(interestDate && moment(interestDate).isValid()){
            this.state.interestState["0"].date = interestDate;
        }
        this.state.leaseTenure = tenor;
        this.state.leaseStartDate = leaseStartDate;
        this.state.currencyName = currencyName;
    
    }


    render(){
        return (<div>
        <form class="form_content">
            <div className="form-group row">
                <label class="col-sm-4 label_title subsection_lable_title">Interest rate 1</label>
            </div>
            <div>
                <Calenderinputfield fieldTitle="Interest rate date"
                    value={this.state.interestState["0"].date} isDisabled ={true}
                    inputType="date" name="interestratedate" placeholder="DD/MM/YYYY"
                    errorStatus={this.state.interestState["0"].dateErrorField} 
                    onError={this.handleError.bind(this, 'interestratedate','0')}
                    errorMessage={this.state.interestState["0"].interestDateStatus ? this.state.interestState["0"].interestDateStatus : this.state.calendarErrorMessage}
                    />

                <div className="form-group row">
                    <label className="col-sm-4 col-form-label field_label_model">TLP period</label>
                    <div className="col-sm-1">
                        <input type="number" value={this.state.interestState ? this.state.interestState["0"].tlpPeriod : null}
                            name="tlpperiod" id="1" onChange={this.handleChange} 
                            className="form-control input_Fields_mgs +"
                            placeholder="Enter" />
                    </div>
                    <span className="col-sm-1 postfix_title">%</span>
                    <div className="col-sm-1 fetch_tlp_calc"><label id={1} onClick={this.fetchTLPCalculation.bind(this)} className="fetch_tlp_calc_text">Fetch TLP</label></div>
                    <span className="col-sm-3 tlpgrid_title" style={{ marginRight: '52px' }} data-toggle="modal" data-target="#myModal" onClick={this.viewTLPGrid.bind(this)}>View TLP Grid</span>
                    {
                         this.state.interestState["0"].tlpPeriodErrorField ?
                        <div className="form-group row" >
                        <label className="col-sm-4 col-form-label field_label_model" style= {{marginTop:'16px'}}></label>
                        <div className="col-sm-5" style= {{marginTop:'16px'}}>
                                    <Notification 
                                        status='error'
                                        size='small'
                                        withArrow
                                        arrowPosition='14px'
                                        className="error_notification errorWidthField"
                                    >
                                        {this.state.interestState["0"].tlpPeriodErrorMessage} 
                                    </Notification>
                                </div>
                                </div>
                            : null
                        }
                        
                </div>
                { (!(this.props.modelType == "Solving for margin")) ?
                    <InputPercField fieldTitle="Margin Period"
                        value={this.state.interestState ? this.state.interestState["0"].marginPeriod : null}
                        name="marginperiod" inputType='number' onChange={this.handleChange.bind(this)} 
                        id = "1" placeholder= "Enter" 
                        errorStatus={this.state.interestState["0"].marginPeriodErrorField} errorMessage={this.state.interestState["0"].marginPeriodErrorMessage}/>
                    :null}
                <InputPercField fieldTitle="Reference rate period"
                    value={this.state.interestState ? this.state.interestState["0"].ReferencePeriod : null}
                    name="referenceperiod" inputType='number' onChange={this.handleChange.bind(this)} 
                    id = "1" placeholder= "Enter"
                    errorStatus={this.state.interestState["0"].referencePeriodErrorField} errorMessage={this.state.interestState["0"].referenceRatePeriodErrorMessage}/>
                    
            </div>
            {this.state.interestNumber.map((object, i) => (
                <div>
                    <div className="Separator_line model_Separator_line"></div>
                    <div className="form-group row">
                        <label class="col-xs-4 label_title subsection_lable_title" >Interest rate {object} </label>

                        <div className="col-xs-4" style={{
                            marginLeft: '-29px',
                            textAlign: 'right'
                        }} onClick={this.deleteMore.bind(this, "interest", i, object)}>
                            <Icon name="trash-small" size="small" />
                            <span className="remove_icon_span">Remove Interest rate</span>
                        </div>
                    </div>
                    <div>
                        <Calenderinputfield fieldTitle="Interest rate date"
                            value={this.state.interestState[((parseInt(object) - 1)).toString()].date}
                            inputType="date" name="interestratedate" placeholder="DD/MM/YYYY"
                            errorStatus={this.state.interestState[((parseInt(object) - 1)).toString()].dateErrorField} 
                            errorMessage={this.state.interestState[((parseInt(object) - 1)).toString()].interestDateStatus ? this.state.interestState[((parseInt(object) - 1)).toString()].interestDateStatus : this.state.calendarErrorMessage}
                            onChange={this.getInterestrateDate.bind(this, 'interestratedate', object)}
                            onError={this.handleError.bind(this, 'interestratedates', object)}/>
                        <div className="form-group row">
                            <label className="col-sm-4 col-form-label field_label_model">TLP period</label>
                            <div className="col-sm-1">
                                <input type="number" value={this.state.interestState[((parseInt(object) - 1)).toString()].tlpPeriod}
                                    name="tlpperiod" id={object} onChange={this.handleChange} className="form-control input_Fields_mgs" placeholder="Enter" />
                                
                            </div>
                            <span className="col-sm-1 postfix_title">%</span>
                            <div className="col-sm-1 fetch_tlp_calc"><label id={object} onClick={this.fetchTLPCalculation.bind(this)} className="fetch_tlp_calc_text">Fetch TLP</label></div>
							<span className="col-sm-3 tlpgrid_title" style={{ marginRight: '52px' }} data-toggle="modal" data-target="#myModal" onClick={this.viewTLPGrid.bind(this)} >View TLP Grid</span>
                            {this.state.interestState[((parseInt(object) - 1)).toString()].tlpPeriodErrorField ?
                                    <div className="form-group row" >
                                    <label className="col-sm-4 col-form-label field_label_model" style= {{marginTop:'16px'}}></label>
                                    <div className="col-sm-5" style= {{marginTop:'16px'}}>
                                                <Notification 
                                                    status='error'
                                                    size='small'
                                                    withArrow
                                                    arrowPosition='14px'
                                                    className="error_notification errorWidthField"
                                                >
                                                    {this.state.interestState[((parseInt(object) - 1)).toString()].tlpPeriodErrorMessage} 
                                                </Notification>
                                            </div>
                                            </div>
                                        : null
                                    }
                                    
                        </div>
                        
                        { (!(this.props.modelType == "Solving for margin")) ?
                            <InputPercField fieldTitle="Margin Period"
                            value={this.state.interestState[((parseInt(object) - 1)).toString()].marginPeriod}
                            name="marginperiod" inputType='number' onChange={this.handleChange.bind(this)} 
                            id = {object} placeholder= "Enter"
                            errorStatus={this.state.interestState[((parseInt(object) - 1)).toString()].marginPeriodErrorField} errorMessage={this.state.interestState[((parseInt(object) - 1)).toString()].marginPeriodErrorMessage}/>
                           :null
                        }
                         
                        <InputPercField fieldTitle="Reference rate period"
                            value={this.state.interestState[((parseInt(object) - 1)).toString()].referenceperiod}
                            name="referenceperiod" inputType='number' onChange={this.handleChange.bind(this)} 
                            id = {object} placeholder= "Enter"
                            errorStatus={this.state.interestState[((parseInt(object) - 1)).toString()].referencePeriodErrorField} errorMessage={this.state.interestState[((parseInt(object) - 1)).toString()].referenceRatePeriodErrorMessage}/>
                               
                    </div>
            </div>
        )
        )}

            <div className="form-group row">
                <div className="col-sm-12 add_interest_rate">
                    <label className="col-sm-5 col-form-label field_label_credit"></label>
                    <div className="col-sm-4 add_interest_rate_btn" onClick={this.addMore.bind(this, "interest")}>
                        <Icon name="plus-xsmall" size='small' /> 
                        <label className="uploadDocument" > Add another interest rate</label>
                    </div>
                </div>
            </div>
            <div className="Separator_line"></div>
             <div class="form-group row" style={{ marginTop: '10px'}}>
                <label for="" class="col-sm-4 col-form-label field_label_model" style={{ marginTop: '15px'}}>0% interest rate floor?</label>
                <div className="col-sm-4">
                    <div class="interest_rate_model">
                        <div class="btn-group">
                            <button type="button" className={"btn btn-primary interest_rate_yes " + (!this.state.zeroIntRtFloor ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.selectZeroIntRtFloor.bind(this, 'No')}>No</button>
                            <button type="button" className={"btn btn-primary interest_rate_no " + (this.state.zeroIntRtFloor ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.selectZeroIntRtFloor.bind(this, 'Yes')}>Yes</button>
                        </div>
                    </div>
                </div>
            </div> 
            
            <div class="form-group row" style={{ marginBottom: '32px'}}>
                <button type="button" class="zb-button zb-button-secondary back_indexation_btn" onClick = {this.prevBotton.bind(this)}>Back to indexation</button>
            </div>
           
        </form>
       
    </div>);
    }
    }

    export default ModelInterestRate;
