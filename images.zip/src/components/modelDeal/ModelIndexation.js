import React, { Children } from 'react';
import moment from 'moment';
import Calenderinputfield from '../../commonComponents/calenderInput.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Inputfield from '../../commonComponents/inputDealField';
import { Icon } from '@zambezi/sdk/icons';
import './commonModel.css';
import { dealValidate } from '../../utils/dealValidation.js' 
import { Notification } from '@zambezi/sdk/notification';
import { CopyDealIndexation } from '../../models/CopyDeal.js';

function trimString (string, length) {
    return string.length > length ? string.substring(0, length) : string;
  };

class ModelIndexation extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            optionState2 : [0,1,2,3],
            optionState3 : [0,1,2],
            indexationNumber: [],
            indexationCount: [],
            indexasionState:[{
                indexationDate : '',
                floor:'',
                indexationPercentage:'',
                franchiseName:'',
                indexationName:'',
                baseIndexName:'',
                baseIndexDate:'',
                baseIndexNumber:'',
                indexationScaling: 100,
                indexationType:true,
                indexationPercentageStatus:false,
                indexationDateStatus:false,
                indexationStartDateError :'',
                baseIndexDateStatus: false,
                indexationNameError: false,
                indexationNameErrorMessage: '',
                floorError: false,
                floorErrorMessage: '',
                indexationScalingError: false,
                indexationScalingErrorMessage: '',
                indexationErrorMessage: '',
                baseIndexNumberError: false,
                baseIndexNumberErrorMessage: '',
                editIndexationId:'',
            },],
            dealErrorMessage: 'Please complete this field',
            calendarErrorMessage: ''
        }
    }

    componentDidMount() {
        this.generateState();
        this.sendData();
    }

    generateState() { 
        var reqType = localStorage.getItem('DealRequestType');
        if(this.props.enableIndexDep !== null && this.props.enableIndexDep !== undefined
            && this.props.leaseContract !== null && this.props.leaseContract !== undefined){
            this.generateCopy(this.props.leaseContract);
        } else if(reqType == "SAVE_DEAL"){
            var indexationobject = {
                indexationDate : '',
                floor:'',
                indexationPercentage:'',
                franchiseName:'',
                indexationName:'',
                baseIndexName:'',
                baseIndexDate:'',
                baseIndexNumber:'',
                indexationScaling:100,
                indexationType:true,
                indexationPercentageStatus:false,
                indexationDateStatus:false,
                indexationStartDateError :'',
                indexationNameError: false,
                indexationNameErrorMessage: '',
                floorError: false,
                floorErrorMessage: '',
                indexationScalingError: false,
                indexationScalingErrorMessage: '',
                indexationErrorMessage: '',
                baseIndexNumberError: false,
                baseIndexNumberErrorMessage: '',
                editIndexationId:'',
            };
            for (let j = 1; j <= 39; j++) {
                var obj = JSON.parse(JSON.stringify(indexationobject));
                this.state.indexasionState.push(obj);
            }
            for (let j = 2; j <= 40; j++) {
                this.state.indexationCount.push(j);
            }
            this.setState( state =>{
                const indexasionState = state.indexasionState;
                return{indexasionState, value:''};
           });
        } else if(reqType == "COPY_DEAL" || reqType == "EDIT_DEAL"){
            // var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
            var indexCopyState = CopyDealIndexation(this.props.leaseContract);
            this.setState( state =>{
                const indexasionState = indexCopyState.indexasionState;
                const indexationNumber = indexCopyState.indexationCount;
                const indexationCount = indexCopyState.indexRemainCount;
                return{indexasionState, indexationNumber, indexationCount};
           });
            this.forceUpdate();
        } 
        this.handleChange = this.handleChange.bind(this);
        
    }

    generateCopy = (leaseContract) => {
        var indexCopyState = CopyDealIndexation(leaseContract);
            this.setState( state =>{
                const indexasionState = indexCopyState.indexasionState;
                const indexationNumber = indexCopyState.indexationCount;
                const indexationCount = indexCopyState.indexRemainCount;
                return{indexasionState, indexationNumber, indexationCount};
           });
           this.forceUpdate();
    }

    handleChange = (e) => {
        if (e !== undefined && e.target !== undefined && e.target.name !== undefined ) { 
            if (e.target.name === "indexationPercentage") {
                this.state.indexasionState[e.target.id-1].indexationPercentage = e.target.value;
                this.state.indexasionState[e.target.id -1].indexationPercentageStatus = false;
                if(e.target.value !== ""){
                    let v = dealValidate('Indexation', e.target.value);
                    if (v[0] == null) {
                        this.state.indexasionState[e.target.id -1].indexationPercentageStatus = false;
                        this.state.indexasionState[e.target.id -1].indexationErrorMessage = v[1];
                    } else if (v[0] != null) {
                        this.state.indexasionState[e.target.id -1].indexationPercentageStatus = !v[0];
                        this.state.indexasionState[e.target.id -1].indexationErrorMessage = v[1];
                    }
                }
            } if(e.target.name === "floor"){
                this.state.indexasionState[e.target.id-1].floor = e.target.value;
                let v = dealValidate('Floor', e.target.value);
                if (v[0] == null) {
                    this.state.indexasionState[e.target.id-1].floorError = false;
                    this.state.indexasionState[e.target.id-1].floorErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.indexasionState[e.target.id-1].floorError = !v[0];
                    this.state.indexasionState[e.target.id-1].floorErrorMessage = v[1];
                }
            } if(e.target.name === "franchiseName"){
                this.state.indexasionState[e.target.id-1].franchiseName = e.target.value;
            } if(e.target.name === "indexationType"){
                this.state.indexasionState[e.target.id-1].indexationType = e.target.value;
            } if(e.target.name === "baseIndexName"){
                this.state.indexasionState[e.target.id-1].baseIndexName = e.target.value;
            } if(e.target.name === "baseIndexNumber"){
                this.state.indexasionState[e.target.id-1].baseIndexNumber = e.target.value;
                let v = dealValidate('baseIndexNumber', e.target.value);
                if (v[0] == null) {
                    this.state.indexasionState[e.target.id-1].baseIndexNumberError = false;
                    this.state.indexasionState[e.target.id-1].baseIndexNumberErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.indexasionState[e.target.id-1].baseIndexNumberError = !v[0];
                    this.state.indexasionState[e.target.id-1].baseIndexNumberErrorMessage = v[1];
                }
            } if(e.target.name === "indexationScaling"){
                this.state.indexasionState[e.target.id-1].indexationScaling = e.target.value;
                let v = dealValidate('IndexationScaling', e.target.value);
                if(e.target.value !== ""){
                    if (v[0] == null) {
                        this.state.indexasionState[e.target.id-1].indexationScalingError = false;
                        this.state.indexasionState[e.target.id-1].indexationScalingErrorMessage = v[1];
                    } else if (v[0] != null) {
                        this.state.indexasionState[e.target.id-1].indexationScalingError = !v[0];
                        this.state.indexasionState[e.target.id-1].indexationScalingErrorMessage = v[1];
                    }
                }
            } if(e.target.name === "indexationName"){
                var iName = trimString(e.target.value, 30)
                this.state.indexasionState[e.target.id-1].indexationName = iName;
                let v = dealValidate('indexationName', e.target.value);
                if (v[0] == null) {
                    this.state.indexasionState[e.target.id-1].indexationNameError = false;
                    this.state.indexasionState[e.target.id-1].indexationNameErrorMessage = v[1];
                } else if (v[0] != null) {
                    this.state.indexasionState[e.target.id-1].indexationNameError = !v[0];
                    this.state.indexasionState[e.target.id-1].indexationNameErrorMessage = v[1];
                }
            }
            this.setState( state =>{
                const indexasionState = state.indexasionState;
                return{indexasionState, value:''};
           });
        }
        this.sendData();
        return true;
    }

    selectIdxnType(e, index) {
        if(e !== undefined){
            if (e === 'Fixed') {
                this.state.indexasionState[index-1].indexationType = true;
            } else {
                this.state.indexasionState[index-1].indexationType = false;
            }
            this.setState( state =>{
                const indexasionState = state.indexasionState;
                return{indexasionState, value:''};
           });
       
        }
        return true;
    }

    validateFields(leaseStartDate, leaseEndDate, periodDto){
        var validationErrorFlag = false;
        let previousDateConsecutiveChk = moment(Date.parse(leaseStartDate)).format('YYYY-MM-DD');
        if(this.state.indexasionState !== null){
            if(this.state.indexationNumber != null && 
                this.state.indexationNumber != undefined){

                    var startDate = moment(Date.parse(leaseStartDate));
                    var endDate = moment(Date.parse(leaseEndDate));
                    this.state.indexasionState["0"].indexationStartDateError = null;
                    if(this.state.indexasionState["0"].indexationDate == ""){
                        this.state.indexasionState["0"].indexationDateStatus = false;
                    } else {
                        var indexDate = moment(Date.parse(this.state.indexasionState["0"].indexationDate));
                        this.state.indexasionState["0"].indexationDateStatus = false;
                        if(indexDate.isSame(startDate) || (indexDate.isAfter(startDate) && indexDate.isBefore(endDate))){
                            this.state.indexasionState["0"].indexationDateStatus = false;
                            if(indexDate.isSame(startDate)){
                                validationErrorFlag = true;
                                this.state.indexasionState["0"].indexationStartDateError ="Indexation cannot be applied to the first period";
                                this.state.indexasionState["0"].indexationDateStatus = true;
                            } else {
                                let periodResponseInStr = localStorage.getItem('leaseResponseForPeriod');
                                let periodResponseInJson = JSON.parse(periodResponseInStr);

                                let isDateMatched = false;
                                let indexDateTemp = moment(Date.parse(this.state.indexasionState["0"].indexationDate)).format('YYYY-MM-DD');
                                
                                for(let i=1;i<periodResponseInJson.periodRangeDTOList.length;i++){
                                    var periodStartDate = periodResponseInJson.periodRangeDTOList[i].periodStartDate;
                                    if(indexDateTemp.match(periodStartDate)) {
                                        isDateMatched = true;
                                        break;
                                    }
                                }

                                if(!isDateMatched) {
                                    validationErrorFlag = true;
                                    this.state.indexasionState["0"].indexationDateStatus = true;
                                    this.state.indexasionState["0"].indexationStartDateError ="Please enter date as start date of any period";    
                                } else {
                                    this.state.indexasionState["0"].indexationDateStatus = false;
                                }
                            } 
                            
                        } else {
                            this.state.indexasionState["0"].indexationStartDateError ="Please enter date falling between Lease start date and Lease end date";
                            this.state.indexasionState["0"].indexationDateStatus = true;
                            validationErrorFlag=true;
                        }
                        
                        
                    }
                    if(this.state.indexasionState["0"].indexationDate != ""){
                    let v = dealValidate('Indexation', this.state.indexasionState["0"].indexationPercentage);
                    if (v[0] == null) {
                        this.state.indexasionState["0"].indexationPercentageStatus = false;
                        this.state.indexasionState["0"].indexationErrorMessage = v[1];
                    } else if (v[0] != null) {
                        this.state.indexasionState["0"].indexationPercentageStatus = !v[0];
                        this.state.indexasionState["0"].indexationErrorMessage = v[1];
                    }

                    if(!this.state.indexasionState["0"].indexationType) {
                        let v1 = dealValidate('IndexationScaling', this.state.indexasionState["0"].indexationScaling);
                        if (v1[0] == null) {
                            this.state.indexasionState["0"].indexationScalingError = false;
                            this.state.indexasionState["0"].indexationScalingErrorMessage = v1[1];
                        } else if (v1[0] != null) {
                            this.state.indexasionState["0"].indexationScalingError = !v1[0];;
                            this.state.indexasionState["0"].indexationScalingErrorMessage = v1[1];
                        }
                        let v2 = dealValidate('Floor', this.state.indexasionState["0"].floor);
                        if (v1[0] == null) {
                            this.state.indexasionState["0"].floorError = false;
                            this.state.indexasionState["0"].floorErrorMessage = v1[1];
                        } else if (v1[0] != null) {
                            this.state.indexasionState["0"].floorError = !v1[0];;
                            this.state.indexasionState["0"].floorErrorMessage = v1[1];
                        }
                    } else {
                        this.state.indexasionState["0"].indexationScalingError = false;
                        this.state.indexasionState["0"].floorError = false;
                    }
                    
                }
                    
                    for (var i = 0; i < this.state.indexationNumber.length; i++) {
                        var object = this.state.indexationNumber[i];
                        this.state.indexasionState[object -1].indexationStartDateError = null;
                        if(this.state.indexasionState[object -1].indexationDate == ""){
                            this.state.indexasionState[object -1].indexationDateStatus = false;
                            // validationErrorFlag=true;
                        } else {
                                var indexDate = moment(Date.parse(this.state.indexasionState[object -1].indexationDate));
                                this.state.indexasionState[object -1].indexationDateStatus = false;
                                if(indexDate.isSame(startDate) || (indexDate.isAfter(startDate) && indexDate.isBefore(endDate))){
                                    this.state.indexasionState[object -1].indexationDateStatus = false;
                                    if(indexDate.isSame(startDate)){
                                        this.state.indexasionState[object -1].indexationStartDateError ="Indexation cannot be applied to the first period";
                                        this.state.indexasionState[object -1].indexationDateStatus = true;
                                        validationErrorFlag=true;

                                    } else{
                                        let periodResponseInStr = localStorage.getItem('leaseResponseForPeriod');
                                        let periodResponseInJson = JSON.parse(periodResponseInStr);

                                        let isDateMatched = false;
                                        let indexDateTemp = moment(Date.parse(this.state.indexasionState[object -1].indexationDate)).format('YYYY-MM-DD');
                                        
                                        for(let i=1;i<periodResponseInJson.periodRangeDTOList.length;i++){
                                            var periodStartDate = periodResponseInJson.periodRangeDTOList[i].periodStartDate;
                                            if(indexDateTemp.match(periodStartDate)) {
                                                isDateMatched = true;
                                                break;
                                            }
                                        }

                                        if(!isDateMatched) {
                                            validationErrorFlag = true;
                                            this.state.indexasionState[object -1].indexationDateStatus = true;
                                            this.state.indexasionState[object -1].indexationStartDateError ="Please enter date as start date of any period";    
                                        } else {
                                            if(indexDate.isAfter(previousDateConsecutiveChk)){
                                                this.state.indexasionState[object -1].indexationDateStatus = false;
                                                previousDateConsecutiveChk = indexDate;
                                            } else {
                                                validationErrorFlag = true;
                                                this.state.indexasionState[object -1].indexationDateStatus = true;
                                                this.state.indexasionState[object -1].indexationStartDateError ="Please enter date greater than previous period.";
                                            }
                                        }
                                    } 
                                    
                            } else {
                                this.state.indexasionState[object -1].indexationStartDateError ="Please enter date falling between Lease start date and Lease end date";
                                this.state.indexasionState[object -1].indexationDateStatus = true;
                                validationErrorFlag=true;
                            }
                        }
                        if(this.state.indexasionState[object -1].indexationDate != ""){
                            let v = dealValidate('Indexation', this.state.indexasionState[object -1].indexationPercentage);
                            if (v[0] == null) {
                                this.state.indexasionState[object -1].indexationPercentageStatus = false;
                                this.state.indexasionState[object -1].indexationErrorMessage = v[1];
                            } else if (v[0] != null) {
                                this.state.indexasionState[object -1].indexationPercentageStatus = !v[0];
                                this.state.indexasionState[object -1].indexationErrorMessage = v[1];
                            }
                            
                            if(!this.state.indexasionState[object -1].indexationType) {
                                let v1 = dealValidate('IndexationScaling', this.state.indexasionState[object -1].indexationScaling);
                                if (v1[0] == null) {
                                    this.state.indexasionState[object -1].indexationScalingError = false;
                                    this.state.indexasionState[object -1].indexationScalingErrorMessage = v1[1];
                                } else if (v1[0] != null) {
                                    this.state.indexasionState[object -1].indexationScalingError = !v1[0];;
                                    this.state.indexasionState[object -1].indexationScalingErrorMessage = v1[1];
                                }
                                let v2 = dealValidate('Floor', this.state.indexasionState[object -1].floor);
                                if (v1[0] == null) {
                                    this.state.indexasionState[object -1].floorError = false;
                                    this.state.indexasionState[object -1].floorErrorMessage = v1[1];
                                } else if (v1[0] != null) {
                                    this.state.indexasionState[object -1].floorError = !v1[0];;
                                    this.state.indexasionState[object -1].floorErrorMessage = v1[1];
                                }
                            } else {
                                this.state.indexasionState[object -1].indexationScalingError = false;
                            }
                        }
                        /*if(this.state.indexasionState[object -1].indexationPercentage == "" && this.state.indexasionState[object -1].indexationDate != ""){
                            this.state.indexasionState[object -1].indexationPercentageStatus = true;
                            validationErrorFlag=true;
                        } else {
                            this.state.indexasionState[object -1].indexationPercentageStatus = false;
                        }*/
                    }
                }
        }
        return validationErrorFlag;
    }

    getIndexationDate(e, ID, val) {
        if (val != "") {
            let obj = val;
            // let time = moment(obj).format('DD/MM/YYYY');
            let time = obj;
            var _ID = ((parseInt(ID)) - 1).toString();
            if(e === 'indexationDate'){
                this.state.indexasionState[_ID.toString()].indexationDate = time;
                this.state.indexasionState[_ID.toString()].indexationDateStatus = false;
            } else if (e ==='baseIndexDate'){
                this.state.indexasionState[_ID.toString()].baseIndexDate = time;
                this.state.indexasionState[_ID.toString()].baseIndexDateStatus = false;
            }
        } else {
            var _ID = ((parseInt(ID)) - 1).toString();
            if(e === 'indexationDate'){
                this.state.indexasionState[_ID.toString()].indexationDate = "";
            } else if (e ==='baseIndexDate'){
                this.state.indexasionState[_ID.toString()].baseIndexDate = "";
            }
        }
        this.setState( state =>{
            const indexasionState = state.indexasionState;
            return{indexasionState, value:''};
       });
        return true;
    }

    addMore(type) {
        if (type == "indexation"){
            if (this.state.indexationCount[0] != undefined) {
                var joined = this.state.indexationNumber.concat(this.state.indexationCount[0]);
                var sort = joined.sort(function (a, b) { return a - b; });
                this.setState({
                    indexationNumber: sort,
                    indexationCount: this.state.indexationCount.filter((_, i) => i !== 0)
                }, function () {
                })
            }
        }
        this.sendData();
        return true;
    }

    deleteMore(type, index, no) {
        if(type == "indexation"){
          this.state.indexationCount.unshift(no);
          this.state.indexationCount.sort(function (a, b) { return a - b; });
          this.state.indexasionState[no - 1].indexationDate = '';
          this.state.indexasionState[no - 1].floor = '';
          this.state.indexasionState[no - 1].indexationPercentage = '';
          this.state.indexasionState[no - 1].franchiseName = '';
          this.state.indexasionState[no - 1].indexationName = '';
          this.state.indexasionState[no - 1].baseIndexName = '';
          this.state.indexasionState[no - 1].baseIndexDate = '';
          this.state.indexasionState[no - 1].baseIndexNumber = '';
          this.state.indexasionState[no - 1].indexationScaling = '';
          this.state.indexasionState[no - 1].indexationType = '';

          this.setState({
            indexationNumber: this.state.indexationNumber.filter((_, i) => i !== index)
        }, function () {
        });
        }
        this.sendData();
        return true;
    }

    getOptionDetails = () =>{ 
        window.scrollTo(0,2540);
        this.setState({optionState2 : [0,1,2,3]});
        this.props.nextAndPrevious(this.state.optionState2);
       
        
        }

    prevBotton = () =>{ 
        window.scrollTo(0,1530);
        this.setState({optionState3 : [0,1,2]});
        this.props.nextAndPrevious(this.state.optionState3);
                 
         }

    sendData = () => {
        this.props.parentCallbackIndexation(this.state.indexasionState);
    }

    handleError(type, object, error) {
        console.error('date picker error', error);
        if (error.message)
            switch (type) {
                case 'indexationDate':
                    this.state.indexasionState["0"].indexationDateStatus = true;
                    break;
                case 'indexationDates':
                    this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationDateStatus = true;
                    break;
                case 'baseIndexDate':
                    this.state.indexasionState['0'].baseIndexDateStatus = true;
                    break;
                case 'baseIndexDates':
                    this.state.indexasionState[((parseInt(object) - 1)).toString()].baseIndexDateStatus = true;
                    break;
                default:
                this.state.indexasionState[((parseInt(object) - 1)).toString()].baseIndexDateStatus = false;
                this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationDateStatus = false;
                break;
            }
            this.setState({ calendarErrorMessage: 'Enter valid date format' });
    }

    render(){
        return (<div>
                <div className="form-group row">
                    <label class="col-sm-4 subsection_lable_title">Indexation 1</label>
                </div>
                <div>
                <Calenderinputfield fieldTitle="Indexation date" id = "1"
                    value={this.state.indexasionState ? this.state.indexasionState["0"].indexationDate : null}
                    inputType="date" name="indexationDate" placeholder="DD/MM/YYYY"
                    errorStatus={this.state.indexasionState ? this.state.indexasionState["0"].indexationDateStatus : null} 
                    errorMessage={this.state.indexasionState["0"].indexationStartDateError ? this.state.indexasionState["0"].indexationStartDateError : this.state.calendarErrorMessage}
                    onChange={this.getIndexationDate.bind(this, 'indexationDate', 1)}
                    onError={this.handleError.bind(this, 'indexationDate','0')}
                    />

                <InputPercField fieldTitle="Indexation"
                    value={this.state.indexasionState ? this.state.indexasionState["0"].indexationPercentage : null}
                    name="indexationPercentage" inputType='number' onChange={this.handleChange.bind(this)} 
                    errorStatus={this.state.indexasionState["0"].indexationPercentageStatus} 
                    errorMessage={this.state.indexasionState["0"].indexationErrorMessage}
                    id = "1" placeholder= "Enter"/>
                    
                
                <div class="form-group row" style={{ marginTop: '10px'}}>
                                <label for="" class="col-sm-4 col-form-label field_label_model" style={{ marginTop: '15px'}}>Indexation type</label>
                                <div className="col-sm-4">
                                    <div class="customer_type_model" style = {{width:'155px'}} >
                                        <div class="btn-group">
                                            <button type="button" id = "1" style = {{width:'71px'}}
                                                className={"btn btn-primary standard_btn " + (this.state.indexasionState["0"].indexationType ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.selectIdxnType.bind(this, 'Fixed', 1)}>Fixed</button>
                                            <button type="button" id = "1" style = {{width:'71px'}}
                                                className={"btn btn-primary standard_btn " + (!this.state.indexasionState["0"].indexationType ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.selectIdxnType.bind(this, 'CPI', 1)}>CPI</button>
                                        </div>
                                    </div>

                                </div>
                            </div> 

                <InputPercField fieldTitle="Floor"
                    value={this.state.indexasionState ? this.state.indexasionState["0"].floor : null}
                    name="floor" inputType='number' onChange={this.handleChange} 
                    id = "1" placeholder= "Enter" errorStatus={this.state.indexasionState["0"].floorError} 
                    errorMessage={this.state.indexasionState["0"].floorErrorMessage} 
                    isReadOnly={this.state.indexasionState["0"].indexationType} />
                

                <InputPercField fieldTitle="Indexation scaling"
                    value={this.state.indexasionState ? this.state.indexasionState["0"].indexationScaling : null}
                    name="indexationScaling" inputType='number' onChange={this.handleChange} 
                    id = "1" placeholder= "Enter" errorStatus = {this.state.indexasionState["0"].indexationScalingError} 
                    errorMessage = {this.state.indexasionState["0"].indexationScalingErrorMessage} 
                    isReadOnly={this.state.indexasionState["0"].indexationType} />
                
                <Inputfield fieldTitle="Indexation name" id = "1"
                    value={this.state.indexasionState ? this.state.indexasionState["0"].indexationName : null}
                    inputType="text" name="indexationName" onChange={this.handleChange} placeholder="Enter" 
                    errorStatus = {this.state.indexasionState["0"].indexationNameError}
                    errorMessage = {this.state.indexasionState["0"].indexationNameErrorMessage}
                    isReadOnly={this.state.indexasionState["0"].indexationType}
                    />
                
                <Calenderinputfield fieldTitle="Base Index date" id = "1"
                    inputType="date" name="baseIndexDate" placeholder="DD/MM/YYYY"
                    onChange={this.getIndexationDate.bind(this, 'baseIndexDate', 1)}
                    errorStatus={this.state.indexasionState[0].baseIndexDateStatus} 
                    onError={this.handleError.bind(this, 'baseIndexDate','0')}
                    errorMessage={this.state.calendarErrorMessage}
                    isReadOnly={this.state.indexasionState["0"].indexationType}
                    isDisabled = {this.state.indexasionState["0"].indexationType}
                    />

                <Inputfield fieldTitle="Base Index number" id = "1"
                    value={this.state.indexasionState ? this.state.indexasionState["0"].baseIndexNumber : null}
                    inputType="number" name="baseIndexNumber" onChange={this.handleChange} placeholder="Enter" 
                     errorStatus = {this.state.indexasionState["0"].baseIndexNumberError} errorMessage={this.state.indexasionState["0"].baseIndexNumberErrorMessage} 
                     isReadOnly={this.state.indexasionState["0"].indexationType} />
                </div>

                {this.state.indexationNumber.map((object, i) => (
                    <div>
                        <div className="Separator_line model_Separator_line" />
                        <div className="form-group row">
                            <label class="col-xs-4 subsection_lable_title">Indexation {object} </label>

                            <div className="col-xs-4" style={{marginLeft: '-29px', textAlign: 'right', marginTop:'32px'}}
                                    onClick={this.deleteMore.bind(this, "indexation", i, object)}>
                                    <Icon name="trash-small" size="small" />
                                    <span className="remove_icon_span">Remove Indexation </span>
                            </div> {/* End Delete Icon*/}

                        </div> {/* form 1 row */}
                        
                        <Calenderinputfield fieldTitle="Indexation date"
                            value={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationDate}
                            inputType="date" name="indexationDate" placeholder="DD/MM/YYYY"
                            onChange={this.getIndexationDate.bind(this, 'indexationDate', object)}
                            errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationDateStatus}
                            errorMessage={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationStartDateError ? this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationStartDateError : this.state.calendarErrorMessage}
                            onError={this.handleError.bind(this, 'indexationDates',object)}/>

                        <InputPercField fieldTitle="Indexation" id = {object} 
                            value = {this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationPercentage}
                            name="indexationPercentage" inputType='number' onChange={this.handleChange} 
                            placeholder= "Enter"
                            errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationPercentageStatus} 
                            errorMessage={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationErrorMessage}/>

                        <div class="form-group row" style={{ marginTop: '10px'}}>
                                <label for="" class="col-sm-4 col-form-label field_label_model" style={{ marginTop: '15px'}}>Indexation type</label>
                                <div className="col-sm-4">
                                    <div class="customer_type_model" style = {{width:'155px'}} >
                                        <div class="btn-group">
                                            <button type="button" id = {object} style = {{width:'71px'}}
                                                className={"btn btn-primary standard_btn " + (this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType ? 'dealtype_selected' : 'dealtype_notselected')} 
                                                onClick={this.selectIdxnType.bind(this, 'Fixed', object)}>Fixed</button>
                                            <button type="button" id = {object} style = {{width:'71px'}}
                                                className={"btn btn-primary standard_btn " + (!this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType ? 'dealtype_selected' : 'dealtype_notselected')} 
                                                onClick={this.selectIdxnType.bind(this, 'CPI', object)}>CPI</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <InputPercField fieldTitle="Floor" id = {object} 
                            value = {this.state.indexasionState[((parseInt(object) - 1)).toString()].floor}
                            name="floor" inputType='number' onChange={this.handleChange} 
                             placeholder= "Enter" errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].floorError}
                             errorMessage={this.state.indexasionState[((parseInt(object) - 1)).toString()].floorErrorMessage}
                             isReadOnly={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType} />

                        <InputPercField fieldTitle="Indexation scaling" id = {object} 
                            value = {this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationScaling}
                            name="indexationScaling" inputType='number' 
                            onChange={this.handleChange} placeholder= "Enter" 
                            errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationScalingError} 
                            errorMessage={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationScalingErrorMessage}
                            isReadOnly={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType} />
                        
                        <Inputfield fieldTitle="Indexation name" id = {object}
                            value = {this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationName}
                            inputType="text" name="indexationName" onChange={this.handleChange} placeholder="Enter" 
                            errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationNameError} 
                            errorMessage={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationNameErrorMessage}
                            isReadOnly={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType} />
                        
                        <Calenderinputfield fieldTitle="Base Index date" id = {object} 
                            inputType="date" name="baseIndexDate" placeholder="DD/MM/YYYY"
                            onChange={this.getIndexationDate.bind(this, 'baseIndexDate', 1)}
                            errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].baseIndexDateStatus}
                            onError={this.handleError.bind(this, 'baseIndexDates',object)}
                            errorMessage={this.state.calendarErrorMessage}
                            isReadOnly={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType}
                            isDisabled={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType} 
                            />

                        <Inputfield fieldTitle="Base Index number" id = {object} 
                            value = {this.state.indexasionState[((parseInt(object) - 1)).toString()].baseIndexNumber}
                            inputType="text" name="baseIndexNumber" onChange={this.handleChange} placeholder="Enter" 
                            errorStatus={this.state.indexasionState[((parseInt(object) - 1)).toString()].baseIndexNumberError} 
                            errorMessage={this.state.indexasionState[((parseInt(object) - 1)).toString()].baseIndexNumberErrorMessage}
                            isReadOnly={this.state.indexasionState[((parseInt(object) - 1)).toString()].indexationType} />
                            
                                            
                    </div>
                ))}
                <div className="form-group row">
                        <div className="col-sm-12 add_interest_rate">
                            <label className="col-sm-5 col-form-label field_label_credit"></label>
                                <div className="col-sm-4 add_interest_rate_btn" onClick={this.addMore.bind(this, "indexation")}>
                                    <Icon name="plus-xsmall" size='small' /> 
                                     <label className="uploadDocument" > Add another indexation</label>
                                </div>
                        </div>
                </div>

                <div className="model_line" style={{
                width: '800px',
                margin: 'auto'
                }}></div>

                <div className="form-group row" style={{ marginTop: '16px' }}>
                <div className="col-sm-3 model_next_btn" style={{ float: 'right'}}>
                    <button type="button" class="zb-button zb-button-primary next_btn"  
                        style={{
                            width: '179px',
                        }} onClick = {this.getOptionDetails.bind(this)}>Next</button>
                </div>
                <div className="col-sm-3 model_next_btn" style={{
                    float: 'right',
                }}>
                    <button type="button" class=" zb-button zb-button-secondary next_btn"
                        style={{
                            width: '181px',
                            marginRight: '0px'
                        }} onClick ={this.prevBotton.bind(this)}>Back to options</button>
                </div>
            </div>

            
        </div>);
    }
}

export default ModelIndexation;