import React, { Component } from 'react';
import '../../index.css';
import './modelNewDeal.css';
import {Tab, Tabs, TabList, TabPanel,} from 'react-tabs';
import "react-tabs/style/react-tabs.css"
import ModelNewDeal from './modelNewDeal.js';
import InModelNewDeal from './modelNewDeal.js';
import DepModelNewDeal from './modelNewDeal.js';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { RegisterLeaseInvoDepDeal } from '../../models/LeaseModelRegistry.js';
import { API_ENDPOINT } from '../../config/config.js';
import { HttpPost, HttpGet } from '../../services/api.js';
import { Lease_Constants } from '../../models/LeaseConstants';
import {CopyParentModel} from '../../models/CopyDeal.js';
import { withRouter } from 'react-router-dom';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css';
import Popup from '../../commonComponents/popupMessage';
import Modal from '@zambezi/sdk/modal';


class LeaseParentModel extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            enableIndexDep : false,
            status:'',
            dealNumber:'',
            dealReferenceNumber:'',
            invoicingDeal:null,
            depreciationDeal :null,
            validateInvoicing:false,
            validateDepreciation:false,
            singleDeal:null,
            leaseParentId:'',
            currentWorkflowNumber: '',
            onlineSolution: '',
            offlineSolution: '',
            dealCaptainRoleID: '',
            isModelNewDealDiabled:false
        }
        this.invoicingDealRef = React.createRef();
        this.depreciationDealRef = React.createRef();
    }

    componentWillMount(){
        var leaseParent = JSON.parse(localStorage.getItem('leaseResponseDataState'));
            
            if(leaseParent == null || leaseParent == undefined){
                localStorage.setItem('DealRequestType', 'SAVE_DEAL');
            } 
        if(this.props.location.state !== undefined && this.props.location.state !== null){
            if(this.props.location.state.onCreateInvoiceDepreciation !== null && 
                    this.props.location.state.onCreateInvoiceDepreciation !== undefined &&
                    this.props.location.state.onCreateInvoiceDepreciation == true){
                        this.setState({enableIndexDep:true});
                        var result = CopyParentModel(leaseParent);
                        this.setState(result);
                        if(this.props.location.state.dealUsageType == Lease_Constants.DEAL_USAGE_INVOICING){
                            this.setState({invoicingDeal:leaseParent.invoicingLeaseContract});
                            this.setState({depreciationDeal:leaseParent.invoicingLeaseContract});
                        } else if(this.props.location.state.dealUsageType == Lease_Constants.DEAL_USAGE_DEPRECIATION){
                            this.setState({invoicingDeal:leaseParent.depreciationLeaseContract});
                            this.setState({depreciationDeal:leaseParent.depreciationLeaseContract});
                        }
            } else if((this.props.location.state.onEditDeal !== null &&
                    this.props.location.state.onEditDeal !== undefined) ||
                    (this.props.location.state.onCopyDeal !== null &&
                    this.props.location.state.onCopyDeal !== undefined)){
                        var result = CopyParentModel(leaseParent);
                        this.setState(result);
                        if(this.props.location.state.dealUsageType == Lease_Constants.DEAL_USAGE_INVOICE_AND_DEPRECIATION){
                            this.setState({enableIndexDep:true});
                            this.setState({invoicingDeal:leaseParent.invoicingLeaseContract});
                            this.setState({depreciationDeal:leaseParent.depreciationLeaseContract});
                        } else if(this.props.location.state.dealUsageType == Lease_Constants.DEAL_USAGE_INVOICING){
                            this.setState({enableIndexDep:false});
                            this.setState({singleDeal:leaseParent.invoicingLeaseContract});
                        } else if(this.props.location.state.dealUsageType == Lease_Constants.DEAL_USAGE_DEPRECIATION){
                            this.setState({singleDeal:leaseParent.depreciationLeaseContract});
                            this.setState({enableIndexDep:false});
                        }
                        
            }
        }
        
    }

    validateinvDep = () => {
        var currentComponent = this;
        var validationErrorinvo = false;
        var validationErrorDep = false;
        if(currentComponent.invoicingDealRef.current !== null){
            validationErrorinvo = currentComponent.invoicingDealRef.current.validateField();
            currentComponent.invoicingDealRef.current.validateChildState();
        }

        if(currentComponent.depreciationDealRef.current !== null){
            validationErrorDep = currentComponent.depreciationDealRef.current.validateField();
            currentComponent.depreciationDealRef.current.validateChildState();
        }
        return (validationErrorinvo && validationErrorDep);
    }


    onsaveRoute(){
        var currentComponent = this;
        currentComponent.props.history.push({
            pathname: '/lms/mainSummaryTabsPage',
             state: { fromDealURL:"ModelANewDeal"}
        })
    }

    cancelRegistration = () => {
        var currentComponent = this;
        localStorage.setItem('DealRequestType', "SAVE_DEAL");
         currentComponent.props.history.push({
             pathname: '/lms/viewDealList',
         });
    }

    onInvoDepSave = () => {
        var currentComponent = this;
        // currentComponent.handleTabChange.bind(this);
        currentComponent.forceUpdate();
        localStorage.setItem('dealErrorStatus', 'false');
        localStorage.setItem('childValidationError', 'false');
        var validationError = this.validateinvDep();
        var dealErrorStatus = localStorage.getItem('dealErrorStatus');
        var childValidationError = localStorage.getItem('childValidationError');
        var payload = currentComponent.invoicingDealRef.current.generateDealContents();
        var payload2 = currentComponent.depreciationDealRef.current.generateDealContents();
        if(validationError == false && childValidationError == 'false' && dealErrorStatus == 'false'){
            let payLoadData = RegisterLeaseInvoDepDeal(this.state, payload, payload2);
            currentComponent.isModelNewDealDiabled = true;
            var toHit = API_ENDPOINT.MODEL_A_NEW_DEAL;
            let output = HttpPost(currentComponent, payLoadData, toHit)
            .then(function (response) {
                console.log("response received from server");
                console.log(response);
                console.log(response.data);
                localStorage.setItem('leaseResponseDataState',JSON.stringify(response.data));
                currentComponent.props.history.push({
                    pathname: '/lms/mainSummaryTabsPage',
                     state: { leaseResponseDataState: response.data , fromDealURL:"ModelANewDeal"}
                })
            })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
                // window.alert(error);
            });
        }
        
    }

    goToPage = (pagename) => {
        if(pagename == 'current'){
            return true;
        }
        this.props.history.push({
          pathname: '/lms/' + pagename
        })
        return true;
      }
    
    handleTabChange = () => {
        // var currentComponent = this;
        // if(currentComponent.invoicingDealRef.current !== null){
        //     this.setState({invoicingDeal : currentComponent.invoicingDealRef.current.generateDealContents()});
        // }

        // if(currentComponent.depreciationDealRef.current !== null){
        //     this.setState({depreciationDeal : currentComponent.depreciationDealRef.current.generateDealContents()});
        // }
        
    }
    render(){
        return(<div className="background">
                 <label className="model_title" style={{marginLeft: '90px', marginBottom: '10px'}}>Model new deal</label>
                    {this.state.enableIndexDep?
                    <div style={{position:'relative', zIndex:0, display:'block', float:'left'}}>
                         <Tabs  selectedTabClassName="selectedtlpGridTab"  style={{position:'relative'}}
                                    onSelect={this.handleTabChange.bind(this)}
                                    forceRenderTabPanel={true}
                            >
                            <TabList className="summaryTabList" style={{marginLeft:'50px'}}>
                                <Tab className="headerSummaryTab" >Invoicing</Tab>
                                <Tab className="headerSummaryTab">Depreciation</Tab>
                            </TabList>
                            <TabPanel style={{position:'relative'}}>
                                <InModelNewDeal leaseParentData={this.state} 
                                    enableIndexDep = {this.state.enableIndexDep} 
                                    isInvoicingDeal = {true} isDepreciationDeal = {false}
                                    leaseContract = {this.state.invoicingDeal}
                                    onInvoDepSave = {this.onInvoDepSave.bind(this)}
                                    ref={this.invoicingDealRef} 
                                    cancelRegistration = {this.cancelRegistration.bind(this)}
                                    goToPage = {this.goToPage.bind(this)}
                                />
                            </TabPanel>
                            <TabPanel style={{position:'relative'}}>
                                <DepModelNewDeal leaseParentData={this.state} 
                                enableIndexDep = {this.state.enableIndexDep} 
                                isInvoicingDeal = {false} isDepreciationDeal = {true}
                                leaseContract = {this.state.depreciationDeal}
                                onInvoDepSave = {this.onInvoDepSave.bind(this)}
                                ref={this.depreciationDealRef}
                                cancelRegistration = {this.cancelRegistration.bind(this)}
                                goToPage = {this.goToPage.bind(this)}
                                />
                            </TabPanel>
                        </Tabs>
                        </div>
                        :
                        <ModelNewDeal leaseParentData={this.state} style={{position:'relative'}}
                            enableIndexDep = {this.state.enableIndexDep} 
                            leaseContract = {this.state.singleDeal}
                            isSingleDeal = {true} onsaveRoute ={this.onsaveRoute.bind(this)}
                            cancelRegistration = {this.cancelRegistration.bind(this)}
                            goToPage = {this.goToPage.bind(this)}
                        />
                    }

                {this.state.enableIndexDep ?
                     <div class="modal-footer" style={{
                        display: 'table', border: 'none', margin: '10px auto auto 75px' }}>
                        <button type="button" onClick={this.onInvoDepSave.bind(this)} style={{padding: '2% 3%'}}
                        class="zb-button zb-button-primary main_summary_btn" disabled ={this.isModelNewDealDiabled}>Model deal</button>
                        <button type="button" class="zb-button zb-button-secondary main_summary_btn" 
                         >Cancel</button>
                    </div>:
                    null
                }
                <Popup headerTitle="Cancel saving"
                        headerbody="Are you sure you want to cancel? Any changes will be lost." buttontext1="Yes, cancel saving" buttontext2="No, don't cancel saving" 
                        datatarget="cancelSave" onClick={this.cancelRegistration.bind(this)} />
        </div>
        
     );
    }
    
}

export default withRouter(LeaseParentModel); 