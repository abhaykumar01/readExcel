import React from 'react';

import GridPage from '../../commonComponents/gridpage';
import '../../index.css';
import './creditInvoiceInterest.css';
import {Tab, Tabs, TabList, TabPanel,} from 'react-tabs';
// import { Icon } from '@zambezi/sdk/icons';
// import { Select } from '@zambezi/sdk/dropdown-list';

//--

import { calculateInterestForm, creditInvoicePayload } from '../../models/dataModel.js';
import Dropdown from '../../commonComponents/dropdown';
import InputfieldCustom from '../../commonComponents/inputInvoiceField';
import InputTwoFieldDisabled from '../../commonComponents/inputTwoFieldDisabled';
import Inputfield from '../../commonComponents/inputDealField';
import Calenderinputfield from '../../commonComponents/calenderInputInvoice.js';
import CalenderInputInvoiceFixed from '../../commonComponents/calenderInputInvoiceFixed.js';
import CalendarTwoInput from '../../commonComponents/calendarTwoInput.js';
import Dropdownfield from '../../commonComponents/DropdownField';
import Dropdownfieldcustom from '../../commonComponents/DropdownFieldCustom';
import DropdownInvoice from '../../commonComponents/DropdownInvoice';
import TLPGrid from '../../commonComponents/TLPGrid';
import help from '../../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { API_ENDPOINT } from '../../config/config.js';
import { HttpPost, HttpGet, HttpPut } from '../../services/api.js';
//import { validate } from '../../utils/validation.js';
import { validateCalculateInterest } from '../../utils/validation.js';
import moment from 'moment';
import Accordion from '@zambezi/sdk/accordion';
import { Notification } from '@zambezi/sdk/notification';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Icon } from '@zambezi/sdk/icons';
import ButtonGroup from '@zambezi/sdk/button-group';
import PopupModal from '../../commonComponents/popupModal';
import { RegisterLeaseModel } from '../../models/LeaseModelRegistry.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Popup from '../../commonComponents/popupMessage';
import InputTextfield from '../../commonComponents/inputField.js';
import { formatResultsErrors } from 'jest-message-util';
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;


    class creditInvoiceInterest extends React.Component {
        static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        var currentDate = new Date();
        this.state = {
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            invoiceUpdatedDate:currentDate,
            isRecalculateBtnDisable:true,
            isSaveBtnDisabled:true,
            pageStatus:"",
            fixedRateValidUntil: "",
            interestReviewDateFloat:"",
            interestReviewDateFixed:"",
            bookValueScalerFixed:0,
            bookValueScalerFloat: 0,
            interestRateFixed: 0,
            interestRateFloat: 0,
            noOfBpsAdjustment: 0,
            indexReviewNumber: 0,
            tlpValue:0,
            updatedInvoice:[],
            marginValue:0,
            rentRebate: 0,
            partyTypeSelect: true,
            otherManualAdjustment:0,
            vatableProportion: 0,
            otherSupportingComments: "",
            interestReviewDateErrorFloat: false,
            interestReviewDateErrorMessageFloat: "",
            interestReviewDateErrorFixed: false,
            interestReviewDateErrorMessageFixed:"",
            interestRateFloatError: false,
            interestRateFloatErrorMessage: "",
            interestRateFixedError: false,
            interestRateFixedErrorMessage: "",
            bookValueScalerFloatError: false,
            bookValueScalerFloatErrorMessage: "",
            bookValueScalerFixedError: false,
            bookValueScalerFixedErrorMessage: "",
            fixedRateValidUntilError:false,
            fixedRateValidUntilErrorMessage:"",
            noOfBpsAdjustmentError:false,
            noOfBpsAdjustmentErrorMessage:"",
            indexReviewNumberError:false,
            indexReviewNumberErrorMessage:"",
            tlpValueError:false,
            tlpValueErrorMessage:"",
            marginValueError:false,
            marginValueErrorMessage:"",
            rentRebateError:false,
            rentRebateErrorMessage:"",
            otherManualAdjustmentError:false,
            otherManualAdjustmentErrorMessage:"",
            vatableProportionError:false,
            vatableProportionErrorMessage:"",
            otherSupportingCommentsError:false,
            otherSupportingCommentsErrorMessage:"",
            formErrorStatus:true,
            currencyStatus:"",
            interestRateName: "",
            logicValue: "",
            invoicingFrequencyInt:0,
            rentAdjustment: 0,
            baseRent: "",
            baseRentFixed: "",
            interestAdjustment: "",
            interestAdjFixed:"",
            enableCreditInvoiceForm: true,
            totalRent:  "",
            totalRentFixed:"",
            propertyTax: "",
            invoiceType: "",
            spv:  "",
            customer: "",
            areaCode: "",
            currency:  "",
            pmtTerms:  "",
            invoicePeriod:  "",
            presentValue:"",
            futureValue:"",
            depreciation:"",
            margin:0,
            interestRateFloor:"",
            interestRateReviewDate:"",
            leaseFee:"",
            indexBaseDate: "",
            indexName:"",
            indexType: "",
            indexReviewDate:"",
            openDialog: false,
        };
        this.initForm();
        this.handleChange = this.handleChange.bind(this);
        this.getFixedRateValidUntil = this.getFixedRateValidUntil.bind(this);
        this.getInterestReviewDateFloat = this.getInterestReviewDateFloat.bind(this);
        this.getInterestReviewDateFixed = this.getInterestReviewDateFixed.bind(this);
    }

    componentDidMount() {
        this.initForm();
        this.getSelectedIndex.bind(this, 'credit')
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }
    initForm () {
        if(this.props.history.location.state != null && this.props.history.location.state != undefined) {
            var invoicingFrequencytemp;
            var baseRentFixedTemp;
            var interestAdjustmentTemp;
            var totalRentTemp;
            //this.getDropdownItem(this.props.history.location.state.rowID.original.interestRateName);
            if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Monthly') {
                this.setState({ invoicingFrequencyInt: 12});
                invoicingFrequencytemp = 12;
             } else if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Quarterly'){
                this.setState({ invoicingFrequencyInt: 4});
                invoicingFrequencytemp = 4;
             } else if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Semi-Annually'){
                this.setState({ invoicingFrequencyInt: 2});
                invoicingFrequencytemp = 2;
             } else if(this.props.history.location.state.rowID.original.invoicingfrequency ==='Annually'){
                this.setState({ invoicingFrequencyInt: 1});
                invoicingFrequencytemp = 1;
             }
             if(this.props.history.location.state.rowID.original.baseRentFixed == null){
                baseRentFixedTemp= 0;
             }
             else{
                baseRentFixedTemp=this.props.history.location.state.rowID.original.baseRentFixed;
             }
             if( this.props.history.location.state.rowID.original.interestAdjFixed == null){
                interestAdjustmentTemp =0;
             }else{
                interestAdjustmentTemp=this.props.history.location.state.rowID.original.interestAdjFixed;
             }
             if(this.props.history.location.state.rowID.original.totalRentFixed == null){
                 totalRentTemp=0;
             }else{
                 totalRentTemp=this.props.history.location.state.rowID.original.totalRentFixed;
             }
            

             this.state.interestRateName = this.props.history.location.state.rowID.original.interestRateName;
             console.log(' this.props.history.location.state.rowID.original.leaseContractNumber: '+ this.props.history.location.state.rowID.original.leaseContractNumber);
             this.setState({
                actionNeeded: this.props.history.location.state.rowID.original.actionneeded,
                bookValueScalerFloat:this.props.history.location.state.rowID.original.bookValueScaler,
                bookValueScalerFixed:this.props.history.location.state.rowID.original.bookValueScalerFixed,
                interestRateName:this.state.interestRateName,
                //logicValue:this.props.history.location.state.rowID.original.logicValue,
                interestReviewDateFloat:this.props.history.location.state.rowID.original.interestRateReviewDate,
                interestReviewDateFixed:this.props.history.location.state.rowID.original.interestRateReviewDate,
                fixedRateValidUntil:this.props.history.location.state.rowID.original.fixedRateValidUntil,
                interestRateFloat:this.props.history.location.state.rowID.original.interestRateFloating,
                interestRateFixed:this.props.history.location.state.rowID.original.interestRateFixed,
                tlpValue: this.props.history.location.state.rowID.original.tlp,
                otherManualAdjustment:this.props.history.location.state.rowID.original.indexAdjustment,
                rentRebate: this.props.history.location.state.rowID.original.rentRebate,
                rentAdjustment: this.props.history.location.state.rowID.original.rentAdjustment,
                otherSupportingComments:  this.props.history.location.state.rowID.original.comments,
                baseRent: this.props.history.location.state.rowID.original.baseRent,
                baseRentError: false,
                baseRentErrorMessage:"",
                baseRentFixed: baseRentFixedTemp,//this.props.history.location.state.rowID.original.baseRentFixed,
                interestAdjustment: this.props.history.location.state.rowID.original.interestAdjustment,
                interestAdjFixed:interestAdjustmentTemp,//this.props.history.location.state.rowID.original.interestAdjFixed,
                totalRent:  this.props.history.location.state.rowID.original.totalRent,
                totalRentFixed:totalRentTemp,//this.props.history.location.state.rowID.original.totalRentFixed,
                propertyTax: this.props.history.location.state.rowID.original.propertyTax,
                invoiceType: this.props.history.location.state.rowID.original.invoicetype,
                spv:  this.props.history.location.state.rowID.original.spv,
                customer: this.props.history.location.state.rowID.original.customer,
                areaCode: this.props.history.location.state.rowID.original.areaCode,
                currency:  this.props.history.location.state.rowID.original.currency,
                pmtTerms:  this.props.history.location.state.rowID.original.pmtterms,
                invoicingFrequencyInt:  invoicingFrequencytemp,
                invoicePeriod:  this.props.history.location.state.rowID.original.invoicePeriod,
                presentValue: this.props.history.location.state.rowID.original.presentValue,
                futureValue: this.props.history.location.state.rowID.original.futureValue,
                depreciation:this.props.history.location.state.rowID.original.depreciation,
                marginValue: this.props.history.location.state.rowID.original.margin,
                interestRateFloor: this.props.history.location.state.rowID.original.interestRateFloor,
                interestRateReviewDate: this.props.history.location.state.rowID.original.interestRateReviewDate,
                leaseFee:  this.props.history.location.state.rowID.original.leasefee,
                indexBaseNo:this.props.history.location.state.rowID.original.indexBaseNo,
                franchiseName:this.props.history.location.state.rowID.original.franchiseName,
                indexAdjustment: this.props.history.location.state.rowID.original.indexAdjustment,
              //currencyStatus: this.props.history.location.state.rowID.original.currencyStatus,
              //currencyName: this.props.history.location.state.rowID.original.currencyName,
                invoicingStartDate:  this.props.history.location.state.rowID.original.invoiceStartDate,
                invoicingEndDate:  this.props.history.location.state.rowID.original.invoiceEndDate,
                invoicingEndDateErrorMessage: "",
                invoicingEndDateError: false,
                index:  this.props.history.location.state.rowID.original.index,
                indexType:  this.props.history.location.state.rowID.original.indexType,
                indexScaling:  this.props.history.location.state.rowID.original.indexScaling,
                indexName: this.props.history.location.state.rowID.original.indexName,
                indexBaseDate: this.props.history.location.state.rowID.original.indexBaseDate,
                indexReviewDate:  this.props.history.location.state.rowID.original.indexReviewDate,
                indexReviewNumber: this.props.history.location.state.rowID.original.indexReviewNumber,
                indexBaseNumber:  this.props.history.location.state.rowID.original.indexBaseNumber,
                indexFloor:  this.props.history.location.state.rowID.original.indexFloor,
                rentAdjustmentPerBps:  this.props.history.location.state.rowID.original.rentAdjustmentPerBps,
                //numberBpsAdjustment: this.props.history.location.state.rowID.original.numberBpsAdjustment,
                vatableProportion:  this.props.history.location.state.rowID.original.vatableProportion,
                status: this.props.history.location.state.rowID.original.status,
                successMessage:"Invoice Updated Successfully",
                formErrorStatus:true,
                HeadingErrorMessage: "",
                HeadingError: false,
                leaseContractId: this.props.history.location.state.rowID.original.leaseContractId,
                indexReviewNo: this.props.history.location.state.rowID.original.indexReviewNo,
                invoiceId: this.props.history.location.state.rowID.original.invoiceId,
                invoiceCreatedDate: this.props.history.location.state.rowID.original.invoiceCreatedDate,
                invoiceEndDate: this.props.history.location.state.rowID.original.invoiceEndDate,
                invoiceStartDate: this.props.history.location.state.rowID.original.invoiceStartDate,
                numberBpsAdjustment: this.props.history.location.state.rowID.original.numberBpsAdjustment,
                rentAdjustmentBps: this.props.history.location.state.rowID.original.rentAdjustmentBps,
                leaseContractNumber: this.props.history.location.state.rowID.original.leaseContractNumber
            }, function(){
                this.forceUpdate();
            });
        }
    }

    handleChange = (e) => {
        if (e) {
            this.setState({isRecalculateBtnDisable:false});
            var val = e.target.value;
            var dataVal = val.trimLeft();
            if (e.target.name == "noofbpsadjustment") {
              
                this.setState({ noOfBpsAdjustment: dataVal });
            }
            else if (e.target.name == "indexreviewnumber") {
               
                this.setState({ indexReviewNumber: dataVal });
            }
            else if (e.target.name == "tlpvalue") {
               
                this.setState({ tlpValue: dataVal });
            }
            else if (e.target.name == "marginvalue") {
               
                this.setState({ marginValue: dataVal });
            }
            
            
            else if (e.target.name == "rentrebate") {
               
                this.setState({ rentRebate: dataVal });
            }
            else if (e.target.name == "othermanualadjustment") {
               
                this.setState({ otherManualAdjustment: dataVal });
            }
            else if (e.target.name == "interestratename") {
                this.setState({ interestRateName: dataVal });
            }
            else if (e.target.name == "logicvalue") {
                this.setState({ logicValue: dataVal });
            }
            
            else if (e.target.name == "fixedratevaliduntil") {
                
                this.setState({ fixedRateValidUntil: dataVal });
            }
            else if (e.target.name == "interestreviewdatefloat") {
                
                this.setState({ interestReviewDateFloat: dataVal });
            }
            else if (e.target.name == "interestreviewdatefixed") {
                
                this.setState({ interestReviewDateFixed: dataVal });
            }
            else if (e.target.name == "bookvaluescalerfloat") {
                
                this.setState({ bookValueScalerFloat: dataVal });
                if(dataVal == 0){
                    this.setState({ bookValueScalerFixed: 100 });
                }
                if(dataVal > 0){
                    this.setState({ bookValueScalerFixed: 100-dataVal });
                }
            }
            else if (e.target.name == "bookvaluescalerfixed") {
                
                this.setState({ bookValueScalerFixed: dataVal });
                if(dataVal == 0){
                    this.setState({ bookValueScalerFloat: 100 });
                }
                if(dataVal > 0){
                    this.setState({ bookValueScalerFloat: 100-dataVal });
                }
            }
            else if (e.target.name == "interestratefloat") {
                
                this.setState({ interestRateFloat: dataVal });
            }
            else if (e.target.name == "interestratefixed") {
                
                this.setState({ interestRateFixed: dataVal });
            }
            
            else if (e.target.name == "vatableproportion") {
                
                this.setState({ vatableProportion: dataVal });
            }
            else if (e.target.name == "othersupportingcomments") {
                
                this.setState({ otherSupportingComments: dataVal });
            }
        }
        this.finalCheck();
    }
    finalCheck(){
        let localVariable = localStorage.getItem('errorStatusCalculateInterest');
        if (this.state.bookValueScalerFloatError == true || this.state.bookValueScalerFixedError == true
             || this.state.interestRateFloatErrorMessage == true || this.state.interestRateFixedErrorMessage == true || this.state.otherManualAdjustmentError == true
             || this.state.marginValueErrorMessage == true || this.state.tlpValueErrorMessage) 
        {
            this.setState({ formErrorStatus: true });
        }
        if (this.state.bookValueScalerFloatError == false && this.state.bookValueScalerFixedError == false
        && this.state.interestRateFloatErrorMessage == false && this.state.interestRateFixedErrorMessage == false && this.state.otherManualAdjustmentError == false
            && this.state.marginValueErrorMessage == false && this.state.tlpValueErrorMessage)  
        {  
             this.setState({ formErrorStatus: false });
        }
    }
    validateField(){
        let v = validateCalculateInterest('bookvaluescalerfloat', this.state.bookValueScalerFloat);
        if (v[0] == null) {
            this.setState({ bookValueScalerFloatError: false, bookValueScalerFloatErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ bookValueScalerFloatError: !v[0], bookValueScalerFloatErrorMessage: v[1] });
        }
        let v1 = validateCalculateInterest('bookvaluescalerfixed', this.state.bookValueScalerFixed);
        if(v1[0] == null){
            this.setState({ bookValueScalerFixedError: false, bookValueScalerFixedErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ bookValueScalerFixedError: !v1[0], bookValueScalerFixedErrorMessage: v1[1] });
        }
        let v2 = validateCalculateInterest('interestratefloat', this.state.interestRateFloat);

        if(v2[0] == null){
            this.setState({ interestRateFloatError: false, interestRateFloatErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ interestRateFloatError: !v2[0], interestRateFloatErrorMessage: v2[1] });
        }
        let v3 = validateCalculateInterest('interestratefixed', this.state.interestRateFixed);

        if(v3[0] == null){
            this.setState({ interestRateFixedError: false, interestRateFixedErrorMessage: v3[1] });
        } else if (v3[0] != null) {
            this.setState({ interestRateFixedError: !v3[0], interestRateFixedErrorMessage: v3[1] });
        }
        
        let v5 = validateCalculateInterest('tlpvalue', this.state.tlpValue);

        if(v5[0] == null){
            this.setState({ tlpValueError: false, tlpValueErrorMessage: v5[1] });
        } else if (v5[0] != null) {
            this.setState({ tlpValueError: !v5[0], tlpValueErrorMessage: v5[1] });
        }
        let v6 = validateCalculateInterest('marginvalue', this.state.marginValue);

        if(v6[0] == null){
            this.setState({ marginValueError: false, marginValueErrorMessage: v6[1] });
        } else if (v6[0] != null) {
            this.setState({ marginValueError: !v6[0], marginValueErrorMessage: v6[1] });
        }
       

        
    }
        goToPage(pagename) {
            this.props.history.push({
                pathname: '/lms/' + pagename
            })
            return true;
        }
        generateData(type) {
            const data = [];
            if (type == "currency") {
                data.push(
                    "",
                    "GBP",
                    "EUR",              
                    "DKK",
                    "SEK",
                    "NOK"
                );
            } else if(type == "invoicetype") {
                data.push(
                    "",
                    "Interest",
                    "Index",
                    
                );
    
            } else if (type == "pmtterms") {
                data.push(
                    "",
                    "In arrears",
                    "In advanced",
                    
                );
    
            } else if (type == "invoicingfrequency") {
                data.push(
                    "",
                    "Monthly",
                    "Quarterly",
                    "Semi-Annually",
                    "Annually",
                    
                );
            } else if (type == "interestratename") {
                data.push(
                    "",
                    "EURIBOR",
                    "STIBOR",
                    "NIBOR",
                    "CIBOR"
                );
            }else if (type == "logicvalue") {
                data.push(
                    "",
                    "5th of the preceding month",
                    "20th of the preceding month",
                    "28th of the preceding month",
                    "1 WD of current month"
                );
            }
            
            return data;
            }

            getSelectedIndex(type) {
                if (type === 'credit') {
                    this.setState({
                        enableCreditInvoiceForm: true,
                        partyTypeSelect: true
                   
                    });
                    console.log(type+ this.state.enableCreditInvoiceForm);
    
                } else if (type === 'invoice'){
                    this.setState({
                        enableCreditInvoiceForm: false,
                        partyTypeSelect: false
                       
                    });
                    console.log(type+ this.state.enableCreditInvoiceForm);
                }
               
                return true;
            }

        getDropdownItem(event, val, type) {
            if (event == "currency") {
                if (type.value != "") {
                    this.setState({ currencyName: type.value, currencyStatus: false });
                } else {
                    this.setState({ currencyName: type.value, currencyStatus: true });
                }
            } else if (event == "invoicetype") {
                if(type.value != "") {
                    this.setState({ invoiceType: type.value});
                }
    
            }
            else if (event == "pmtterms") {
                if(type.value != "") {
                    this.setState({ pmtTerms: type.value});
                }
            }
            else if (event == "interestratename") {
                if(type.value != "") {
                    this.setState({ interestRateName: type.value});
                }
            }
            else if (event == "logicvalue") {
                if(type.value != "") {
                    this.setState({ logicValue: type.value});
                }
            } 
            else if (event == "invoicingfrequency") {
                if(type.value != "") {
                
                if(type.value ==='Monthly') {
                this.setState({ invoicingFrequency: 12});
                 } else if(type.value ==='Quarterly'){
                this.setState({ invoicingFrequency: 4});
                 } else if(type.value ==='Semi-Annually'){
                this.setState({ invoicingFrequency: 2});
                 } else if(type.value ==='Annually'){
                this.setState({ invoicingFrequency: 1});
                 }
                    
                }
            }
            return true;
        }
        saveUpdates(){
            this.setState({ isRecalculateBtnDisable: true});
            
            //this.initForm();
            var currentComponent = this;
            currentComponent.finalCheck();
            let payLoadData = [];
            var currentDate = new Date();
            if(this.state.updatedInvoice != undefined && this.state.updatedInvoice != null) {
                console.log('this.state.updatedInvoice: '+JSON.stringify(this.state.updatedInvoice));
                this.setState(prevState =>{
                    let updatedInvoice = Object.assign({}, prevState.updatedInvoice);
                    updatedInvoice[0].leaseContractNumber = this.props.history.location.state.rowID.original.leaseContractNumber;
                    updatedInvoice[0].invoiceUpdatedDate = this.state.invoiceUpdatedDate;
                    updatedInvoice[0].invoiceCreditStatus = this.props.history.location.state.rowID.original.invoiceCreditStatus;
                    updatedInvoice[0].isCreditNote = this.props.history.location.state.rowID.original.isCreditNote;
                    updatedInvoice[0].approvedDate = this.props.history.location.state.rowID.original.approvedDate;
                    updatedInvoice[0].creditDate = currentDate;
                    updatedInvoice[0].isNewInvoice = this.props.history.location.state.rowID.original.isNewInvoice; //value.isNewInvoiceValue,
                    updatedInvoice[0].bpsAdjValidDate = this.props.history.location.state.rowID.original.bpsAdjValidDate;
                    updatedInvoice[0].invoiceCreditType = this.props.history.location.state.rowID.original.invoiceCreditType;
                    updatedInvoice[0].indexGradeNumber= this.props.history.location.state.rowID.original.indexGradeNumber;
          
                    return {updatedInvoice};
                });
                payLoadData = creditInvoicePayload(this.state.updatedInvoice);
               // payLoadData = this.state.updatedInvoice; //this.props.history.location.state.rowID.original.leaseContractNumber,
            }
                let output = HttpPut(currentComponent, payLoadData, API_ENDPOINT.SAVE_UPDATED_INVOICE)
                .then(function (response) {
                    currentComponent.setState({ isSaveBtnDisabled: true});
                    window.scrollTo(0, 0);
                    currentComponent.setState({
                        actionNeeded: response.data[0].actionNeeded,
                        bookValueScalerFloat:response.data[0].bookValueScaler,
                        bookValueScalerFixed:response.data[0].bookValueScalerFixed,
                        interestRateName:response.data[0].interestRateName,
                        //logicValue:this.props.history.location.state.rowID.original.logicValue,
                        interestReviewDateFloat:response.data[0].interestRateReviewDate,
                        interestReviewDateFixed:response.data[0].interestRateReviewDate,
                        fixedRateValidUntil:response.data[0].fixedRateValidUntil,
                        interestRateFloat:response.data[0].interestRateFloating,
                        interestRateFixed:response.data[0].interestRateFixed,
                        tlpValue: response.data[0].tlp,
                        otherManualAdjustment:response.data[0].indexAdjustment,
                        rentRebate: response.data[0].rentRebate,
                        rentAdjustment: response.data[0].rentAdjustment,
                        otherSupportingComments:  response.data[0].comments,
                        baseRent: response.data[0].baseRent,
                        baseRentError: false,
                        baseRentErrorMessage:"",
                        baseRentFixed: response.data[0].baseRentFixed,
                        interestAdjustment: response.data[0].interestAdjustment,
                        interestAdjFixed:response.data[0].interestAdjFixed,
                        totalRent:  response.data[0].totalRent,
                        totalRentFixed:response.data[0].totalRentFixed,
                        propertyTax: response.data[0].propertyTax,
                        invoiceType: response.data[0].invoiceType,
                        spv:  response.data[0].spv,
                        customer: response.data[0].customer,
                        areaCode: response.data[0].areaCode,
                        currency:  response.data[0].currency,
                        pmtTerms:  response.data[0].pmtTerms,
                        invoicingFrequencyInt:  response.data[0].invoiceFrequency,
                        invoicePeriod:   response.data[0].invoicePeriod,
                        presentValue: response.data[0].presentValue,
                        futureValue: response.data[0].futureValue,
                        depreciation: response.data[0].depreciation,
                        marginValue:  response.data[0].margin,
                        interestRateFloor:  response.data[0].interestRateFloor,
                        //interestRateName:  response.data[0].interestRateName,
                        interestRateReviewDate: response.data[0].interestRateReviewDate,
                        leaseFee:  response.data[0].leaseFee,
        
        
                        indexBaseNo: response.data[0].indexBaseNo,
                        franchiseName: response.data[0].franchiseName,
                        indexAdjustment:  response.data[0].indexAdjustment,
                      //currencyStatus: this.props.history.location.state.rowID.original.currencyStatus,
                      //currencyName: this.props.history.location.state.rowID.original.currencyName,
                        invoicingStartDate:   response.data[0].invoiceStartDate,
                        invoicingEndDate:   response.data[0].invoiceEndDate,
                        invoicingEndDateErrorMessage: "",
                        invoicingEndDateError: false,
                        index:   response.data[0].index,
                        indexType:   response.data[0].indexType,
                        indexScaling:  response.data[0].indexScaling,
                        indexName:  response.data[0].indexName,
                        indexBaseDate: response.data[0].indexBaseDate,
                        indexReviewDate:  response.data[0].indexReviewDate,
                        indexReviewNumber: response.data[0].indexReviewNumber,
                        indexBaseNumber:   response.data[0].indexBaseNumber,
                        indexFloor:   response.data[0].indexFloor,
                        rentAdjustmentPerBps:   response.data[0].rentAdjustmentPerBps,
                        //numberBpsAdjustment: this.props.history.location.state.rowID.original.numberBpsAdjustment,
                        vatableProportion:   response.data[0].vatableProportion,
                        status:  response.data[0].status,
                        successMessage:"Invoice Updated Successfully",
                        formErrorStatus:true,
                        HeadingErrorMessage: "",
                        HeadingError: false,
                        leaseContractId:  response.data[0].leaseContractId,
                        indexReviewNo: response.data[0].indexReviewNo,
                        invoiceId:  response.data[0].invoiceId,
                        leaseContractNumber: response.data[0].leaseContractNumber,
                        
                        invoiceCreatedDate:  response.data[0].invoiceCreatedDate,
                        invoiceEndDate:  response.data[0].invoiceEndDate,
                        invoiceStartDate:  response.data[0].invoiceStartDate,
                        numberBpsAdjustment:  response.data[0].numberBpsAdjustment,
                        
                        
                        rentAdjustmentBps: response.data[0].rentAdjustmentBps,
                                
                            });
                     currentComponent.setState({pageStatus:"success"});
                    // currentComponent.setState({pageSuccessStatus:true});
                    //  //window.alert(JSON.stringify(response.data));
                    //  baseRentSummary = currentComponent.state.summaryData.data[0].baseRent.toString();
                    //  currencySummary = currentComponent.state.summaryData.data[0].currency.toString();
                     // currentComponent.initForm();
                })
                .catch(function (error) {
                    currentComponent.setState({ isSaveBtnDisabled: false});
                    currentComponent.setState({pageStatus:"error", successMessage: error});
                    //window.alert(error);
                });
            return true;
        }
        reCalculateInterestRent(){
            this.setState({isSaveBtnDisabled:false});
            this.initForm();
            var currentComponent = this;
            let payLoadData = calculateInterestForm(this.state);
            console.log('payLoadData:'+JSON.stringify(payLoadData));
                let output = HttpPost(currentComponent, payLoadData, API_ENDPOINT.RECALCULATION_MANUAL_INVOICE)
                .then(function (response) {
                    currentComponent.forceUpdate();
                    currentComponent.setState({
                actionNeeded: response.data[0].actionNeeded,
                bookValueScalerFloat:response.data[0].bookValueScaler,
                bookValueScalerFixed:response.data[0].bookValueScalerFixed,
                interestRateName:response.data[0].interestRateName,
                //logicValue:this.props.history.location.state.rowID.original.logicValue,
                interestReviewDateFloat:response.data[0].interestRateReviewDate,
                interestReviewDateFixed:response.data[0].interestRateReviewDate,
                fixedRateValidUntil:response.data[0].fixedRateValidUntil,
                interestRateFloat:response.data[0].interestRateFloating,
                interestRateFixed:response.data[0].interestRateFixed,
                tlpValue: response.data[0].tlp,
                otherManualAdjustment:response.data[0].indexAdjustment,
                rentRebate: response.data[0].rentRebate,
                rentAdjustment: response.data[0].rentAdjustment,
                otherSupportingComments:  response.data[0].comments,
                baseRent: response.data[0].baseRent,
                baseRentError: false,
                baseRentErrorMessage:"",
                baseRentFixed: response.data[0].baseRentFixed,
                interestAdjustment: response.data[0].interestAdjustment,
                interestAdjFixed:response.data[0].interestAdjFixed,
                totalRent:  response.data[0].totalRent,
                totalRentFixed:response.data[0].totalRentFixed,
                propertyTax: response.data[0].propertyTax,
                invoiceType: response.data[0].invoiceType,
                spv:  response.data[0].spv,
                customer: response.data[0].customer,
                areaCode: response.data[0].areaCode,
                currency:  response.data[0].currency,
                pmtTerms:  response.data[0].pmtTerms,
                invoicingFrequencyInt:  response.data[0].invoiceFrequency,
                invoicePeriod:   response.data[0].invoicePeriod,
                presentValue: response.data[0].presentValue,
                futureValue: response.data[0].futureValue,
                depreciation: response.data[0].depreciation,
                marginValue:  response.data[0].margin,
                interestRateFloor:  response.data[0].interestRateFloor,
                interestRateReviewDate: response.data[0].interestRateReviewDate,
                leaseFee:  response.data[0].leaseFee,
                indexBaseNo: response.data[0].indexBaseNo,
                franchiseName: response.data[0].franchiseName,
                indexAdjustment:  response.data[0].indexAdjustment,
              //currencyStatus: this.props.history.location.state.rowID.original.currencyStatus,
              //currencyName: this.props.history.location.state.rowID.original.currencyName,
                invoicingStartDate:   response.data[0].invoiceStartDate,
                invoicingEndDate:   response.data[0].invoiceEndDate,
                invoicingEndDateErrorMessage: "",
                invoicingEndDateError: false,
                index:   response.data[0].index,
                indexType:   response.data[0].indexType,
                indexScaling:  response.data[0].indexScaling,
                indexName:  response.data[0].indexName,
                indexBaseDate: response.data[0].indexBaseDate,
                indexReviewDate:  response.data[0].indexReviewDate,
                indexReviewNumber: response.data[0].indexReviewNumber,
                indexBaseNumber:   response.data[0].indexBaseNumber,
                indexFloor:   response.data[0].indexFloor,
                rentAdjustmentPerBps:   response.data[0].rentAdjustmentPerBps,
                //numberBpsAdjustment: this.props.history.location.state.rowID.original.numberBpsAdjustment,
                vatableProportion:   response.data[0].vatableProportion,
                status:  response.data[0].status,
                successMessage:"Invoice Updated Successfully",
                formErrorStatus:true,
                HeadingErrorMessage: "",
                HeadingError: false,
                leaseContractId:  response.data[0].leaseContractId,
                indexReviewNo: response.data[0].indexReviewNo,
                invoiceId:  response.data[0].invoiceId,
                leaseContractNumber: response.data[0].leaseContractNumber,
                
                invoiceCreatedDate:  response.data[0].invoiceCreatedDate,
                invoiceEndDate:  response.data[0].invoiceEndDate,
                invoiceStartDate:  response.data[0].invoiceStartDate,
                numberBpsAdjustment:  response.data[0].numberBpsAdjustment,
                
                
                rentAdjustmentBps: response.data[0].rentAdjustmentBps,
                        
                    });
                    currentComponent.setState({updatedInvoice:response.data});
                    //currentComponent.setState({pageStatus:"success"});
                    //currentComponent.initForm();
                })
                .catch(function (error) {
                    //currentComponent.setState({pageStatus:"error"});
                  // window.alert(error);
                });
            return true;
        }

        getFixedRateValidUntil(e) {
            if (e != null) {
                var startDate = Date.parse(e);
                this.state.fixedRateValidUntil = moment(startDate).format('YYYY-MM-DD');
                this.validateField();
                this.finalCheck();
            }
            return true;
        }
        getInterestReviewDateFloat(e) {
            if (e != null) {
                var startDate = Date.parse(e);
                this.state.interestReviewDateFloat = moment(startDate).format('YYYY-MM-DD');
                this.validateField();
                this.finalCheck();
            }
            return true;
        }
        getInterestReviewDateFixed(e) {
            if (e != null) {
                var startDate = Date.parse(e);
                this.state.interestReviewDateFixed = moment(startDate).format('YYYY-MM-DD');
                this.validateField();
                this.finalCheck();
            }
            return true;
        } 
        
        
    confirm = () => {
        this.props.history.push({
            pathname: '/lms/viewCustomerDetail',
            state: { rowID: this.state.partyid }
        })
        return true;
    }

    
    render() {
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btndisable = false;
        //check memberOf
        if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") <= 0){
            console.log("Sfs")
            btndisable = true;
        }
        console.log(btndisable);
        var customerNameHeading;
        var actionNeededHeading;
        var statusHeading;

        if(this.props.history.location.state != null && this.props.history.location.state != undefined) {
            
            customerNameHeading= this.props.history.location.state.rowID.original.spv+' '+this.props.history.location.state.rowID.original.customer;
            actionNeededHeading= this.props.history.location.state.rowID.original.actionneeded;
            statusHeading = this.props.history.location.state.rowID.original.status;
        }
        if(this.state.interestRateName != null && this.state.interestRateName != undefined){
            var interestRateNameTemp=this.state.interestRateName.toUpperCase();
        }
        
        // if(this.state.isChangesMade){

        // }
        return (
            <div className="background">
               

                <div onClick={this.goToPage.bind(this,'invoiceList')} style={{
                    
                    width: '1244px', marginLeft: '83px'}}>
                    <Icon name="chev-left-xsmall" size="xsmall" className="back_arrow" title=""/>
                        <span className="all_party" >All Invoices</span>
                </div>
                {
                    this.state.pageStatus=="error" ?
                        <Notification status='error' className="Confirmation_header_new" size='medium' title='Server error'>
                              {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                </Notification>
                        : null
                }
                {
                    this.state.pageStatus=="success" ?
                    <Notification className="Confirmation_header_new" style={{ width: '1100px' }} status='success' size='large' title={this.state.successMessage}>
                        
                </Notification>
                        : null
                }

                <div className="form-group row" style={{
                    margin: '6px auto 0px auto',
                    width: '1244px'
                }}>
                    <div className="col-sm-7">
                        <label className="model_title">Credit Invoice {customerNameHeading}</label>
                    </div>

                </div>
                <div style={{'marginLeft':'4.7em'}}>
                    <div className="col-sm-3">
                    <label style={{ color: '#666666', fontWeight: '100', fontSize: '16px' }}>Action required:</label>
                    <label style={{ marginLeft: '10px', fontSize: '16px' }}>{this.state.actionNeeded}</label>
                    
                    </div>
                    <div className="col-sm-6"></div>
                    <div className="col-sm-3">
                    <label style={{ color: '#666666', fontWeight: '100', fontSize: '16px' }}>Status:</label>
                    <label style={{ marginLeft: '10px', fontSize: '16px' }}>{this.state.status}</label>
                    </div>

                </div>
        

  <div style={{marginTop:'-15px'}}>
                <Tabs selectedTabClassName="selectedtlpGridTab" >
               
                
                <TabList className="creditInvoiceTabList">
                    <Tab className="headerSummaryTab">Invoice</Tab>
                    <Tab className="headerSummaryTab">Credit note</Tab>
                    <Tab className="headerSummaryTab">Credited invoice</Tab>
                    
                </TabList>
                <TabPanel>
                <div className="row">
                    <div className="col-sm-7">
                    {/* paddingBottom: '616px'  */}
                    <div class="invoice_container" style={{ marginBottom: '24px'}}>
                            <div class="inner_column">
                                <label class="label_title">Invoice calculations</label><br/>
                                <label className="help_label">
                                 Please provide the information below
                                 to re-calculate this invoice. For
                                </label> <br/>
                                <label class="help_label">fields that are irrelevant please type in value '0'.</label>
                                
                                
                            </div>

                            <div className="btn-group" style={{
                            width: '370px',
                            height: '44px',
                            border: 'solid 1px #c9c6c6',
                            backgroundColor: '#fff',
                            marginLeft:'28%',
                            marginTop: '1%'
                        }}>
                            <button type="button" className={"btn btn-primary customer_btn " + (this.state.partyTypeSelect ? 'invoicetype_selected' : 'invoicetype_notselected')} onClick={this.getSelectedIndex.bind(this, 'credit')}>Credit note</button>
                            <button type="button" className={"btn btn-primary customer_btn " + (!this.state.partyTypeSelect ? 'invoicetype_selected' : 'invoicetype_notselected')} onClick={this.getSelectedIndex.bind(this, 'invoice')}>Invoice and credit note</button>
                        </div>


                                <form class="user_form">
                                <div className="row"> 
                                <div className="col-sm-6" style={{marginLeft:'228px'}}>
                                <label class="col-sm-4">Floating</label>
                                <label class="col-sm-4">Fixed</label>
                                </div>
                                <div className="col-sm-6">
                                
                                </div>
                                </div>
                                {/* Index Manual Form */}
                                <div className="row"> 
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputTwoFieldDisabled  disabled={(this.state.enableCreditInvoiceForm)? "disabled" : ""} fieldTitle="Book value scaler"  customClass="input_Fields_percentage_invoice" customClass2="input_Fields_percentage_invoice_left"
                                        value={this.state.bookValueScalerFloat} value2={this.state.bookValueScalerFixed}
                                        inputType="text" inputType2="text" name="bookvaluescalerfloat" name2="bookvaluescalerfixed" 
                                        onChange={this.handleChange} onChange2={this.handleChange} 
                                        placeholder="Enter" errorStatus={this.state.bookValueScalerFloatError}
                                        placeholder2="Enter" errorStatus2={this.state.bookValueScalerFixedError}
                                        errorMessage={this.state.bookValueScalerFloatErrorMessage}
                                        errorMessage2={this.state.bookValueScalerFixedErrorMessage} />
                                        
            
                                        
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>
                                        <div className="row"> 
                                        <div className="col-sm-6" style={{marginLeft:'40px'}}>
                                        
                                        <DropdownInvoice customLabel="font_config" title="Interest rate name" 
                                        data={["","EURIBOR","STIBOR","NIBOR","CIBOR"]} name="interestratename" selectedValue={interestRateNameTemp}
                                        errorStatus={this.state.currencyStatus} errorMessage={this.state.interestRateNameErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'interestratename')} isDisabled='' />
                                        </div>
                                        <label class="col-sm-2" style={{marginLeft :'-212px'}}>Fixed</label>
                                        </div>
                                        <div className="row"> 
                                        <div className="col-sm-6" style={{marginLeft:'40px'}}>
                                        <DropdownInvoice customLabel="font_config" title="Logic"
                                        data={this.generateData('logicvalue')} name="logicvalue" selectedValue={this.state.logicValue}
                                        errorStatus={this.state.currencyStatus} errorMessage={this.state.logicValueErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'logicvalue')} isDisabled='' />
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>
                                        <div className="row"> 
                                        <div className="col-sm-8 form_field_adjustment">
                                        <CalendarTwoInput fieldTitle="Interest review date" 
                                        value={this.state.interestReviewDateFloat} customLabel="font_config"
                                        value2={this.state.interestReviewDateFixed}
                                        inputType="date" name="interestreviewdatefloat" name2="interestreviewdatefixed" 
                                        onChange={this.getInterestReviewDateFloat} onChange2={this.getInterestReviewDateFixed} 
                                        placeholder="DD/MM/YYYY" errorStatus={this.state.interestReviewDateErrorFloat}
                                        errorMessage={this.state.interestReviewDateErrorMessageFloat} errorStatus2={this.state.interestReviewDateErrorFixed}
                                        errorMessage2={this.state.interestReviewDateErrorMessageFixed}/>
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>
                                        <div className="row"> 
                                        <div className="col-sm-8 form_field_adjustment">
                                        <CalenderInputInvoiceFixed fieldTitle="Fixed rate valid until" customLabel="font_config"
                                        value={this.state.fixedRateValidUntil}
                                        inputType="date" name="fixedratevaliduntil" 
                                        onChange={this.getfixedRateValidUntil} 
                                        placeholder="DD/MM/YYYY" errorStatus={this.state.fixedRateValidUntilError}
                                        errorMessage={this.state.fixedRateValidUntilErrorMessage} />
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>
                                        <div className="row"> 
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputTwoFieldDisabled  disabled={(this.state.enableCreditInvoiceForm)? "disabled" : ""}   fieldTitle="Interest rate" customClass="input_Fields_percentage_invoice" customClass2="input_Fields_percentage_invoice_left"
                                        value={this.state.interestRateFloat} value2={this.state.interestRateFixed}
                                        inputType="text" inputType2="text" name="interestratefloat" name2="interestratefixed" 
                                        onChange={this.handleChange} onChange2={this.handleChange} 
                                        placeholder="Enter" errorStatus={this.state.interestRateFloatError}
                                        placeholder2="Enter" errorStatus2={this.state.interestRateFixedError}
                                        errorMessage={this.state.interestRateFloatErrorMessage}
                                        errorMessage2={this.state.interestRateFixedErrorMessage} />
                                        
            
                                        
                                        </div>
                                        <label class="col-sm-2 field_back_label"></label>
                                        </div>
                                        <div className="row hide">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Number of bps adjustment" maxlength="30" value={this.state.noOfBpsAdjustment} inputType="text"
                                        name="noofbpsadjustment" onChange={this.handleChange} placeholder="Enter"
                                        errorStatus={this.state.noOfBpsAdjustmentError}
                                        errorMessage={this.state.noOfBpsAdjustmentErrorMessage} 
                                        />
                                        </div>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage_invoice" fieldTitle="TLP" maxlength="30" value={this.state.tlpValue} inputType="text"
                                        name="tlpvalue" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.tlpValueError}
                                        errorMessage={this.state.tlpValueErrorMessage}
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_small_updated inputFieldUpdated">%</label>
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage_invoice" fieldTitle="Margin" maxlength="30" value={this.state.marginValue} inputType="text"
                                        name="marginvalue" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.marginValueError}
                                        errorMessage={this.state.marginValueErrorMessage}
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_small_updated inputFieldUpdated">%</label>
                                        </div>

                                        <div className="row hide">
                                        <div className="col-sm-8 form_field_adjustment">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Index review number" maxlength="30" value={this.state.indexReviewNumber} inputType="text"
                                        name="indexreviewnumber" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.indexReviewNumberError}
                                        errorMessage={this.state.indexReviewNumberErrorMessage}
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_small_updated"></label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Manual adjustment" maxlength="30" value={this.state.otherManualAdjustment} inputType="text"
                                        name="othermanualadjustment" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.otherManualAdjustmentError}
                                        errorMessage={this.state.otherManualAdjustmentErrorMessage}
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur"></label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8 form_field_adjustment">
                                        <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Rent rebate" maxlength="30" value={this.state.rentRebate} inputType="text"
                                        name="rentrebate" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.rentRebateError}
                                        errorMessage={this.state.rentRebateErrorMessage}
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur"></label>
                                        </div>

                                        

                                        <div className="row hide">
                                        <div className="col-sm-8 form_field_adjustment">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Vatable proportion" maxlength="30" value={this.state.vatableProportion} inputType="text"
                                        name="vatableproportion" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.vatableProportionError}
                                        errorMessage={this.state.vatableProportionErrorMessage}
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_small_updated">%</label>
                                        </div>
                                         <div className="row">
                                    <div className="col-sm-8 form_field_adjustment">
                                    <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Supporting comments" maxlength="30" value={this.state.otherSupportingComments} inputType="text"
                                        name="othersupportingcomments" onChange={this.handleChange} placeholder="Enter" errorStatus={this.state.otherSupportingCommentsError}
                                        errorMessage={this.state.otherSupportingCommentsErrorMessage}
                                        />  
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div>


                    <div className="Separator_line"></div>  
                      
                    {/* disabled={this.state.isRecalculateBtnDisable || btndisable} */}
            <div class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button type="button" className="zb-button zb-button-primary recalc_invoice_interest_btn" data-toggle="modal" data-target="#cancelSave"  onClick={this.reCalculateInterestRent.bind(this)}>Re-calculate rent</button>
                </div>
                                </form>
              
            </div>
          
        </div>
        
        <div className="col-sm-5" style={{marginLeft:'-40px'}}>
        <div class="invoice_container_darker" style={{ marginBottom: '24px' }}>
            <label class="label_title">Invoice summary</label>
            <div className="row">
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"></label>
                <label class="col-sm-4 label_Black">Floating</label>
                <label class="col-sm-4 label_Black_fixed">Fixed</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Book value scaler</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.bookValueScalerFloat == null ? "-" : this.state.bookValueScalerFloat}{this.state.bookValueScalerFloat == null  ? "" : "%"}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.bookValueScalerFixed == null ? "-" : this.state.bookValueScalerFixed}{this.state.bookValueScalerFixed == null ? "" : "%"}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Base rent</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.baseRent == null || this.state.baseRent == "" ? "-" : this.state.baseRent} {this.state.baseRent == null || this.state.baseRent == "" || this.state.baseRent== 0 ? "" : this.state.currency}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.baseRentFixed == null || this.state.baseRentFixed == "" ? "-" : this.state.baseRentFixed} {this.state.baseRentFixed == null || this.state.baseRentFixed == "" || this.state.baseRentFixed== 0 ? "" : this.state.currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest adjustment</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.interestAdjustment == null ? "-" : this.state.interestAdjustment} {this.state.interestAdjustment == null ? "" : this.state.currency}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.interestAdjFixed == null || this.state.interestAdjFixed == 0 ? "-" : this.state.interestAdjFixed}{this.state.interestAdjFixed == null || this.state.interestAdjFixed == 0 ? "" : this.state.currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Total rent</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.totalRent == null ? "-" : this.state.totalRent} {this.state.totalRent == null ? "" : this.state.currency}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.totalRentFixed == null || this.state.totalRentFixed == 0 ? "-" : this.state.totalRentFixed} {this.state.totalRentFixed == null || this.state.totalRentFixed == 0 ? "" : this.state.currency}</label>
                </div>
            </div><br/>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Rent rebate</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.rentRebate == null || this.state.rentRebate == "" || this.state.rentRebate == 0 ? "-" :this.state.rentRebate}</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Rent adjustment</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.rentAdjustment == null || this.state.rentAdjustment == "" || this.state.rentAdjustment == 0 ? "-" :this.state.rentAdjustment}</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Property tax</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.propertyTax == null || this.state.propertyTax == "" || this.state.propertyTax == 0 ? "-" :this.state.propertyTax}</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Grand total</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            
            </div>
            <div className="Separator_line"></div>  
        </div>
        

        <div class="invoice_container_darker" style={{ marginTop: '-25px' }}>
            <label class="label_title">Invoice details</label>
            <div className="row">
                <div className="col-sm-8">
            
                <label class="col-sm-6 field_heading_label">Invoice type</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoiceType == null || this.state.invoiceType == ""  ? "-" :this.state.invoiceType}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">SPV</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.spv == null || this.state.spv == ""  ? "-" :this.state.spv}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"> Customer</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.customer == null || this.state.customer == ""  ? "-" :this.state.customer}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Area code</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.areaCode == null || this.state.areaCode == ""  ? "-" :this.state.areaCode}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Currency</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.currency == null || this.state.currency == ""  ? "-" :this.state.currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">PMT terms</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.pmtTerms == null || this.state.pmtTerms == ""  ? "-" :this.state.pmtTerms}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoicing frequency</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoicingFrequencyInt == null || this.state.invoicingFrequencyInt == ""  ? "-" :this.state.invoicingFrequencyInt}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoicing period</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoicePeriod == null || this.state.invoicePeriod == ""  ? "-" :this.state.invoicePeriod}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">PV</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.presentValue == null || this.state.presentValue == ""  ? "-" :this.state.presentValue}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">FV</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.futureValue == null || this.state.futureValue == ""  ? "-" :this.state.futureValue}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Depreciation</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.depreciation == null || this.state.depreciation == ""  ? "-" :this.state.depreciation}{this.state.depreciation == null || this.state.depreciation == ""  ? "" : "?"} </label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Margin</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.marginValue == null || this.state.marginValue == ""  ? "-" :this.state.marginValue}{this.state.marginValue == null || this.state.marginValue == ""  ? "" : "%"} </label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">TLP</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.tlpValue == null || this.state.tlpValue == ""  ? "-" :this.state.tlpValue}{this.state.tlpValue == null || this.state.tlpValue == ""  ? "" : "%"} </label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Apply 0% interest rate floor</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.interestRateFloor == null || this.state.interestRateFloor == ""  ? "-" :this.state.interestRateFloor}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest rate name</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.interestRateName == null || this.state.interestRateName == ""  ? "-" :this.state.interestRateName}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest rate review date</label>
            <label class="col-sm-8 field_back_label_Black_Interest">{moment(this.state.interestRateReviewDate).format('YYYY-MM-DD')}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoice period number of days</label>
                <label class="col-sm-8 field_back_label_Black_Interest"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Lease fee</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.leaseFee == null || this.state.leaseFee == "" ? "-" :this.state.leaseFee} {this.state.leaseFee == null || this.state.leaseFee == "" ? "" : this.state.currency}</label>
                </div>
            </div>
            <div className="Separator_line"></div>    
        </div>

        <div class="invoice_container_darker" style={{marginTop: '-2px'}}>
            <label class="label_title">Other</label>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Other supporting comments</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.otherSupportingComments == null || this.state.otherSupportingComments == "" ? "-" : this.state.otherSupportingComments}</label>
                </div>
            </div>
            </div>
                    
        </div>
  </div>
                   
                </TabPanel>
               
                <TabPanel>
                <div className="row">
                  
        
        <div className="col-sm-5" style={{marginLeft:'0%'}}>
        <div class="invoice_container_darker" style={{ marginBottom: '24px' }}>
            <label class="label_title">Invoice summary</label>
            <div className="row">
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"></label>
                <label class="col-sm-4 label_Black">Floating</label>
                <label class="col-sm-4 label_Black_fixed">Fixed</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Book value scaler</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.bookValueScalerFloat == null ? "-" : this.state.bookValueScalerFloat}{this.state.bookValueScalerFloat == null  ? "" : "%"}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.bookValueScalerFixed == null ? "-" : this.state.bookValueScalerFixed}{this.state.bookValueScalerFixed == null ? "" : "%"}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Base rent</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.baseRent == null || this.state.baseRent == "" ? "-" : this.state.baseRent} {this.state.baseRent == null || this.state.baseRent == "" || this.state.baseRent== 0 ? "" : this.state.currency}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.baseRentFixed == null || this.state.baseRentFixed == "" ? "-" : this.state.baseRentFixed} {this.state.baseRentFixed == null || this.state.baseRentFixed == "" || this.state.baseRentFixed== 0 ? "" : this.state.currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest adjustment</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.interestAdjustment == null ? "-" : this.state.interestAdjustment} {this.state.interestAdjustment == null ? "" : this.state.currency}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.interestAdjFixed == null || this.state.interestAdjFixed == 0 ? "-" : this.state.interestAdjFixed}{this.state.interestAdjFixed == null || this.state.interestAdjFixed == 0 ? "" : this.state.currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Total rent</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.totalRent == null ? "-" : this.state.totalRent} {this.state.totalRent == null ? "" : this.state.currency}</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.totalRentFixed == null || this.state.totalRentFixed == 0 ? "-" : this.state.totalRentFixed} {this.state.totalRentFixed == null || this.state.totalRentFixed == 0 ? "" : this.state.currency}</label>
                </div>
            </div><br/>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Rent rebate</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.rentRebate == null || this.state.rentRebate == "" || this.state.rentRebate == 0 ? "-" :this.state.rentRebate}</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Rent adjustment</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.rentAdjustment == null || this.state.rentAdjustment == "" || this.state.rentAdjustment == 0 ? "-" :this.state.rentAdjustment}</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Property tax</label>
                <label class="col-sm-4 label_Black_Weight_Normal">{this.state.propertyTax == null || this.state.propertyTax == "" || this.state.propertyTax == 0 ? "-" :this.state.propertyTax}</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Grand total</label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                <label class="col-sm-4 label_Black_Weight_Normal"></label>
                </div>
            </div>
            
            </div>
            <div className="Separator_line"></div>  
        </div>
        

        <div class="invoice_container_darker" style={{ marginTop: '-25px' }}>
            <label class="label_title">Invoice details</label>
            <div className="row">
                <div className="col-sm-8">
            
                <label class="col-sm-6 field_heading_label">Invoice type</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoiceType == null || this.state.invoiceType == ""  ? "-" :this.state.invoiceType}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">SPV</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.spv == null || this.state.spv == ""  ? "-" :this.state.spv}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label"> Customer</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.customer == null || this.state.customer == ""  ? "-" :this.state.customer}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Area code</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.areaCode == null || this.state.areaCode == ""  ? "-" :this.state.areaCode}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Currency</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.currency == null || this.state.currency == ""  ? "-" :this.state.currency}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">PMT terms</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.pmtTerms == null || this.state.pmtTerms == ""  ? "-" :this.state.pmtTerms}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoicing frequency</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoicingFrequencyInt == null || this.state.invoicingFrequencyInt == ""  ? "-" :this.state.invoicingFrequencyInt}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoicing period</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoicePeriod == null || this.state.invoicePeriod == ""  ? "-" :this.state.invoicePeriod}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">PV</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.presentValue == null || this.state.presentValue == ""  ? "-" :this.state.presentValue}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">FV</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.futureValue == null || this.state.futureValue == ""  ? "-" :this.state.futureValue}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Depreciation</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.depreciation == null || this.state.depreciation == ""  ? "-" :this.state.depreciation}{this.state.depreciation == null || this.state.depreciation == ""  ? "" : "?"} </label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Margin</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.marginValue == null || this.state.marginValue == ""  ? "-" :this.state.marginValue}{this.state.marginValue == null || this.state.marginValue == ""  ? "" : "%"} </label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">TLP</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.tlpValue == null || this.state.tlpValue == ""  ? "-" :this.state.tlpValue}{this.state.tlpValue == null || this.state.tlpValue == ""  ? "" : "%"} </label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Apply 0% interest rate floor</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.interestRateFloor == null || this.state.interestRateFloor == ""  ? "-" :this.state.interestRateFloor}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest rate name</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.interestRateName == null || this.state.interestRateName == ""  ? "-" :this.state.interestRateName}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Interest rate review date</label>
            <label class="col-sm-8 field_back_label_Black_Interest">{moment(this.state.interestRateReviewDate).format('YYYY-MM-DD')}</label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Invoice period number of days</label>
                <label class="col-sm-8 field_back_label_Black_Interest"></label>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Lease fee</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.leaseFee == null || this.state.leaseFee == "" ? "-" :this.state.leaseFee} {this.state.leaseFee == null || this.state.leaseFee == "" ? "" : this.state.currency}</label>
                </div>
            </div>
            <div className="Separator_line"></div>    
        </div>

        <div class="invoice_container_darker" style={{marginTop: '-2px'}}>
            <label class="label_title">Other</label>
            <div className="row">
                <div className="col-sm-8">
                <label class="col-sm-6 field_heading_label">Other supporting comments</label>
                <label class="col-sm-8 field_back_label_Black_Interest">{this.state.otherSupportingComments == null || this.state.otherSupportingComments == "" ? "-" : this.state.otherSupportingComments}</label>
                </div>
            </div>
            </div>
                    
        </div>
  </div>
                </TabPanel>
                <TabPanel>
                <div className="row">
                  
        
                  <div className="col-sm-5" style={{marginLeft:'0%'}}>
                  <div class="invoice_container_darker" style={{ marginBottom: '24px' }}>
                      <label class="label_title">Invoice summary</label>
                      <div className="row">
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label"></label>
                          <label class="col-sm-4 label_Black">Floating</label>
                          <label class="col-sm-4 label_Black_fixed">Fixed</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Book value scaler</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.bookValueScalerFloat == null ? "-" : this.state.bookValueScalerFloat}{this.state.bookValueScalerFloat == null  ? "" : "%"}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.bookValueScalerFixed == null ? "-" : this.state.bookValueScalerFixed}{this.state.bookValueScalerFixed == null ? "" : "%"}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Base rent</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.baseRent == null || this.state.baseRent == "" ? "-" : this.state.baseRent} {this.state.baseRent == null || this.state.baseRent == "" || this.state.baseRent== 0 ? "" : this.state.currency}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.baseRentFixed == null || this.state.baseRentFixed == "" ? "-" : this.state.baseRentFixed} {this.state.baseRentFixed == null || this.state.baseRentFixed == "" || this.state.baseRentFixed== 0 ? "" : this.state.currency}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Interest adjustment</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.interestAdjustment == null ? "-" : this.state.interestAdjustment} {this.state.interestAdjustment == null ? "" : this.state.currency}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.interestAdjFixed == null || this.state.interestAdjFixed == 0 ? "-" : this.state.interestAdjFixed}{this.state.interestAdjFixed == null || this.state.interestAdjFixed == 0 ? "" : this.state.currency}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Total rent</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.totalRent == null ? "-" : this.state.totalRent} {this.state.totalRent == null ? "" : this.state.currency}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.totalRentFixed == null || this.state.totalRentFixed == 0 ? "-" : this.state.totalRentFixed} {this.state.totalRentFixed == null || this.state.totalRentFixed == 0 ? "" : this.state.currency}</label>
                          </div>
                      </div><br/>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Rent rebate</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.rentRebate == null || this.state.rentRebate == "" || this.state.rentRebate == 0 ? "-" :this.state.rentRebate}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal"></label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Rent adjustment</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.rentAdjustment == null || this.state.rentAdjustment == "" || this.state.rentAdjustment == 0 ? "-" :this.state.rentAdjustment}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal"></label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Property tax</label>
                          <label class="col-sm-4 label_Black_Weight_Normal">{this.state.propertyTax == null || this.state.propertyTax == "" || this.state.propertyTax == 0 ? "-" :this.state.propertyTax}</label>
                          <label class="col-sm-4 label_Black_Weight_Normal"></label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Grand total</label>
                          <label class="col-sm-4 label_Black_Weight_Normal"></label>
                          <label class="col-sm-4 label_Black_Weight_Normal"></label>
                          </div>
                      </div>
                      
                      </div>
                      <div className="Separator_line"></div>  
                  </div>
                  
          
                  <div class="invoice_container_darker" style={{ marginTop: '-25px' }}>
                      <label class="label_title">Invoice details</label>
                      <div className="row">
                          <div className="col-sm-8">
                      
                          <label class="col-sm-6 field_heading_label">Invoice type</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoiceType == null || this.state.invoiceType == ""  ? "-" :this.state.invoiceType}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">SPV</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.spv == null || this.state.spv == ""  ? "-" :this.state.spv}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label"> Customer</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.customer == null || this.state.customer == ""  ? "-" :this.state.customer}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Area code</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.areaCode == null || this.state.areaCode == ""  ? "-" :this.state.areaCode}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Currency</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.currency == null || this.state.currency == ""  ? "-" :this.state.currency}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">PMT terms</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.pmtTerms == null || this.state.pmtTerms == ""  ? "-" :this.state.pmtTerms}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Invoicing frequency</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoicingFrequencyInt == null || this.state.invoicingFrequencyInt == ""  ? "-" :this.state.invoicingFrequencyInt}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Invoicing period</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.invoicePeriod == null || this.state.invoicePeriod == ""  ? "-" :this.state.invoicePeriod}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">PV</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.presentValue == null || this.state.presentValue == ""  ? "-" :this.state.presentValue}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">FV</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.futureValue == null || this.state.futureValue == ""  ? "-" :this.state.futureValue}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Depreciation</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.depreciation == null || this.state.depreciation == ""  ? "-" :this.state.depreciation}{this.state.depreciation == null || this.state.depreciation == ""  ? "" : "?"} </label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Margin</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.marginValue == null || this.state.marginValue == ""  ? "-" :this.state.marginValue}{this.state.marginValue == null || this.state.marginValue == ""  ? "" : "%"} </label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">TLP</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.tlpValue == null || this.state.tlpValue == ""  ? "-" :this.state.tlpValue}{this.state.tlpValue == null || this.state.tlpValue == ""  ? "" : "%"} </label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Apply 0% interest rate floor</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.interestRateFloor == null || this.state.interestRateFloor == ""  ? "-" :this.state.interestRateFloor}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Interest rate name</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.interestRateName == null || this.state.interestRateName == ""  ? "-" :this.state.interestRateName}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Interest rate review date</label>
                      <label class="col-sm-8 field_back_label_Black_Interest">{moment(this.state.interestRateReviewDate).format('YYYY-MM-DD')}</label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Invoice period number of days</label>
                          <label class="col-sm-8 field_back_label_Black_Interest"></label>
                          </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Lease fee</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.leaseFee == null || this.state.leaseFee == "" ? "-" :this.state.leaseFee} {this.state.leaseFee == null || this.state.leaseFee == "" ? "" : this.state.currency}</label>
                          </div>
                      </div>
                      <div className="Separator_line"></div>    
                  </div>
          
                  <div class="invoice_container_darker" style={{marginTop: '-2px'}}>
                      <label class="label_title">Other</label>
                      <div className="row">
                          <div className="col-sm-8">
                          <label class="col-sm-6 field_heading_label">Other supporting comments</label>
                          <label class="col-sm-8 field_back_label_Black_Interest">{this.state.otherSupportingComments == null || this.state.otherSupportingComments == "" ? "-" : this.state.otherSupportingComments}</label>
                          </div>
                      </div>
                      </div>
                              
                  </div>
            </div>
                </TabPanel>
               
            </Tabs>
            </div>




{/* disabled={this.state.isSaveBtnDisabled} */}
  <div class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button type="button" data-dismiss="modal" data-toggle="modal" data-target='#saveUpdateModal'  className="zb-button zb-button-primary model_invoice_btn">Save updates</button> 
                    {/* onClick={this.saveInvoiceData.bind(this)} */}
                    <button type="button" className="zb-button zb-button-secondary cancel_invoice_btn" data-toggle="modal" data-target="#cancelSave">Cancel updates</button>
                </div>







                
                <div id="saveUpdateModal" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content" style={{ borderRadius: '0px' }}>
                                        <div class="modal-header">
                                            {/* <button type="button" class="close" data-dismiss='modal'>&times;</button> */}
                                            <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Interest invoice updates</h4>
                                        </div>
                                        <div class="modal-body" style={{ textAlign: 'left' }}>
                                            <p className="header_body">
                                            Do you want the invoice status to be changed as<br/>
                                            a.	Action Needed – No<br/>
                                            b.	Status – Finance Review</p>
                                        </div>
                                        <div class="modal-footer" style={{
                                            display: 'table',
                                            border: 'none',
                                            marginLeft: '34px',
                                            marginBottom: '20px',
                                            marginTop: '20px'
                                        }}>
                                            <button className='zb-button zb-button-primary cancel_pop_btn interest_doc_btn' data-dismiss="modal" onClick={this.saveUpdates.bind(this)}>Yes, save updates</button>&nbsp;&nbsp;
                                            <button className='zb-button zb-button-secondary save_pop_btn interest_doc_btn' data-dismiss="modal" >No, don't save update</button>
                                            

                                        </div>
                                    </div>

                                </div>
                            </div>
                
                
</div>
        )
    }
    }

    export default creditInvoiceInterest;