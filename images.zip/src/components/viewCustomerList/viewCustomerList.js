import React from 'react';
import './viewCustomerList.css';
import GridPage from '../../commonComponents/gridpage';
import '../../index.css';
import { Tabs, Tab } from 'react-bootstrap-tabs';
import { Icon } from '@zambezi/sdk/icons';
import { Select } from '@zambezi/sdk/dropdown-list';
import { AuthorizationContext } from '../authContext/index.js'

const PING = process.env.REACT_APP_PING;

class viewCustomerList extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            searchInput: "",
            recordView: '20',
            permissionData: {},
            memberOfDetail:'',
        }
        localStorage.setItem("approver", 'false');
    }

    componentDidMount() {
        // var abj= document.getElementsByClassName('dataTables_filter')[0].innerHTML;
        // console.log(abj);
        var data;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            memberOf =usersDetails.memberOf;
        } else { 
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            memberOf =localStorage.getItem('roleName');
        }
        this.setState({
            permissionData: data,
            memberOfDetail:memberOf
        });
    }

    HandleSelectChange(event, type) {//event, val, type
        this.setState({ recordView: type.value });
    }

    addParty() {
        this.props.history.push('/lms/addCustomer');
    }

    // generateData(type) {
    //     const data = [];
    //     if (type == "pageno") {
    //         data.push(
    //             "5",
    //             "10",
    //             "20",
    //             "25",
    //             "50",
    //         );
    //     }
    //     return data
    // }

    render() {
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        console.log(this.state.memberOfDetail);
        var btndisable = true;
        //check memberOf
        // if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0){
        // // if(this.state.memberOfDetail == "rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser"){
        //     for (var i = 0; i < datalen; i++) { 
        //         if (perData[i] == "Customer_Edit_Contact") { 
        //             btndisable = true; // test
        //         }
        //     }
        // }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Customer_Add") {
                    console.log("iiffi") 
                    btndisable = false; // test
                }
            }
        
        
        console.log("Button disabled");
        console.log(btndisable);
        return (
            <div className="background">
                <div className="inner_container1">
                    <label className="party_title">Customers</label>

                    <div className="inner_header"> 
                    
                        <div className={"col-sm-4 new_party_btn " + (btndisable ? 'disabledLabel' : '')} onClick={this.addParty.bind(this)}>
                            <Icon name="plus-xsmall" size='small' title=""/> <label className="uploadDocument" > Add customer</label>
                        </div>
                        <Tabs style={{ margin: '20px 0 0 0', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }} headerStyle={{ fontWeight: 'bold', background_color: '#fff', color: 'purple', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }} activeHeaderStyle={{ color: '#AD1982', background_color: '#fff', fontSize: '16px', fontFamily: 'RNFontRegularWoff' }}>
                            <Tab label="Current" >
                                <div className="grid_layout">
                                    <GridPage selectedRecord={parseInt(this.state.recordView)} />
                                    <span class="select-wrap -pageSizeOptions select_record">
                                        <span className="select_page">Per page</span>
                                        <Select
                                            defaultValue='20'
                                            suggestions={['20', '40', '60', '80', '100']}
                                            className='select_row_customer'
                                            isError={false}
                                            onChange={this.HandleSelectChange.bind(this)}
                                        />
                                    </span>
                                </div>

                            </Tab>
                            <Tab label="Archived">
                                Archived Data
                             </Tab>
                        </Tabs>
                    </div>

                </div>
            </div>
        )
    }
}

export default viewCustomerList;