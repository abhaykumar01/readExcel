import React from 'react';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Notification } from '@zambezi/sdk/notification';
import './verticalTable.css';


class verticalGridComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            selectedValue : '',
            isTableDataAvailable : false,
            isFilterRowDataAvailable : false,
        };
    }
    componentWillReceiveProps(props){
        let selectedName = this.state.selectedValue;
        if(props.data && props.data.length>0){
            this.setState({isTableDataAvailable : true});
        } else {
            this.setState({isTableDataAvailable : false});
        }

        if(props.filterRowData && props.filterRowData.length>0){
            this.setState({isFilterRowDataAvailable : true});
        } else {
            this.setState({isFilterRowDataAvailable : false});
        }

        if(!selectedName){
            this.setState({selectedValue : (props.filterRowData && props.filterRowData.length>0) ? props.filterRowData[0].name : ''});
        }
    }

    handleSelectChange(event, type, value) {
        this.props.filterOnChange(type.value);
        let selectedSuggestion = this.props.filterRowData.filter(element=>element.id === type.value)[0];
        this.setState({selectedValue : selectedSuggestion.name})
    }

    render(){
        return (
            <div>
                {!this.state.isTableDataAvailable && this.state.isFilterRowDataAvailable ?
                    <div style={{ padding: '15px' }}>
                        <Notification status="info" size="small">No data available for current selection</Notification>
                    </div> : null
                }
                {(!this.state.isTableDataAvailable && !this.state.isFilterRowDataAvailable) ?
                    <div style={{ padding: '30px' }}>
                        <Notification status="info" size="small">No data available</Notification>
                    </div>
                    : null }
                    <table className="rtable rtable--flip">
                        <thead>
                            <tr>
                            {this.props.columnHeaders && this.props.columnHeaders.length>0 ? <td key={'blank_cell'}></td> : null}
                                {this.props.filterRowData ?
                                    <td>
                                        <Select suggestions={this.props.filterRowData}
                                            getSuggestionValue={d => d.id}
                                            defaultValue={this.props.filterRowData.length ? this.props.filterRowData[0].id : null}
                                            renderSuggestion={(suggestion) => {
                                                return (<div>{suggestion.value}</div>)
                                            }}
                                            renderInput={props => {
                                                const {
                                                    'aria-label': ariaLabel,
                                                    'aria-labelledby': ariaLabelledBy,
                                                    value
                                                } = props
                                                const selectedSuggestion = props.suggestions.filter(element => element.id === value)[0]
                                                return (<div style={{ outline: 0, minWidth: '120px', height: '95%', textAlign: 'center', paddingTop : '6%'}}
                                                    role='textbox'
                                                    aria-label={ariaLabel}
                                                    aria-labelledby={ariaLabelledBy}>{selectedSuggestion ? selectedSuggestion.value : ''}</div>)
                                            }}
                                            onChange={this.handleSelectChange.bind(this)}></Select>
                                    </td>
                                    : null}
                                {this.props.rowHeaders.map((rowHeader, index) => {
                                    return <td key={index}>{rowHeader.value}</td>
                                })}
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.data.map((element, index) => {
                                return <tr key={index}>
                                   {this.props.columnHeaders && this.props.columnHeaders.length>0 ? <td>{this.props.columnHeaders[index]}</td> : null}
                                    {this.props.filterRowData ?
                                        <td>{this.state.selectedValue}</td>
                                        : null}
                                    {this.props.rowHeaders.map((rowHeader, i) => {
                                        return <td key={index * this.props.rowHeaders.length + i}>{element[rowHeader.key]}</td>
                                    })}
                                </tr>
                            })}
                        </tbody>
                    </table>
            </div>
        )
    }
}

export default verticalGridComponent;