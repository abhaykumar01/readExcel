import React from 'react';
import './uploadDealDocuments.css';
import Table from '../../../commonComponents/table';
import SPV from '../../../commonComponents/spv';
import { HttpPost, HttpGet, HttpPostDocuments } from '../../../services/api.js';
import { API_ENDPOINT } from '../../../config/config.js';
import { withRouter } from 'react-router-dom';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import { Icon } from '@zambezi/sdk/icons';
import DocumentUpload from '../../../commonComponents/documentsUpload';
import DocumentLeaseGrid from '../../../commonComponents/documentsLeaseGrid.js';
import { uploadDocuments, checkDocumentNamingFormat } from '../../../models/dataModel.js';
import { Notification } from '@zambezi/sdk/notification';
import { validate } from '../../../utils/validation.js';
import moment from 'moment';
import { Select } from '@zambezi/sdk/dropdown-list';
import ApproverLeaseDocumentGrid from '../../../commonComponents/approverLeaseDocumentsGrid';
import { AuthorizationContext } from '../../authContext/index.js';
const PING = process.env.REACT_APP_PING;

class uploadDealDocuments extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = this.getInitialState();
        this.inputOpenFileRef = React.createRef();
    }
    getInitialState = () => {
        const initialState = {
            userData: {},
            documentUploadStatus: true,
            uploadedFileName: '',
            documentDescription: '',
            selectedFile: '',
            textErrorStatus: false,
            textErrorMessage: '',
            dialogDismiss: '',
            docType: '',
            docLengthStatus: false,
            errorMessage: '',
                      
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            showData: false,
			//SonarFix.
          
            recordView: '10',
            rerender: false,
            racfID: '',
            permissionData: {},
            roleName: '',
            highRiskStatus: false
          
        };
        return initialState;
    }

    resetState = () => {
        const initialState = {
            documentUploadStatus: true,
            uploadedFileName: '',
            documentDescription: '',
            selectedFile: '',
            textErrorStatus: false,
            dialogDismiss: '',
            docType: '',
            docLengthStatus: false,
            errorMessage: '',
            checkboxStatus: false,          
            partyID: 0,
            showData: false,
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            recordView: '10',
            // docDeleteSuccess: false,
            // docDeleteCancel: false,
            pageStatus: '',
            highRiskStatus: false
        };
        return initialState;
     }

    componentDidMount() {
        window.scrollTo(0, 0);
        var userID = '';
        var roleName = '';
        console.log("Deal data");
        console.log(this.props.dealData);
        var data;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            userID = usersDetails.userID;
            data = usersDetails.permissions;
            roleName = usersDetails.memberOf;
        } else {
            userID = localStorage.getItem('racfID');
             let response = localStorage.getItem('permissions');
            data = JSON.parse(response);
            roleName = localStorage.getItem('roleName');
        }

        this.setState({
            racfID: userID,
            permissionData: data,
            roleName: roleName
         }, function () {
            console.log("UserID: " + this.state.racfID);
        });
        var saveStatus = localStorage.getItem('datasave');
        var changeStatus = localStorage.getItem('datachange');
        if (saveStatus == 'true') { 
            this.setState({ pageStatus: 'saveSuccess' });
            this.props.updateStatus('saveSuccess')
        }
        if (changeStatus == 'true') {
            this.setState({ pageStatus: 'changeSuccess' });
            this.props.updateStatus('changeSuccess')
            
        } else {
            
         }
       
        // let ID = localStorage.getItem("approver");
        // if (ID == "true") {
        //     localStorage.setItem("docUpload", "approverDocUpload1");
        // } else {
            localStorage.setItem("docUpload", "userDocUpload1");
            let message = localStorage.getItem("Message");
            if (message) { 
                var obj = JSON.parse(message);
                if (obj.status == "Approved") {
                    this.setState({
                        pageStatus: "docDeletedSuccess",
                        confirmMessage: obj.description
                    });
                    this.props.updateStatus('docDeletedSuccess')
                } else if (obj.status == "Rejected") { 
                    this.setState({
                        pageStatus: "docDeletedFailed",
                        failureMessage: obj.description,
                        rejectionReason: obj.reasonForRejection
                    });
                    this.props.updateStatus('docDeletedFailed')
                }
                
            }
        // }
    }

    fetchCustomerDocuments() { 
        var currentComponent = this;
        if (this.props.location.state != undefined) {
            this.setState({ partyID: this.props.location.state.rowID });
            localStorage.setItem('userID', this.props.location.state.rowID);
            let endPoint = API_ENDPOINT.GET_PARTY_DETAIL + '/' + this.props.location.state.rowID;
            console.log("Service call");
            HttpGet(currentComponent, endPoint).then(function (response) {
                console.log("User response received from server");
                console.log(response.data);
                console.log(response.data.partyName);
                localStorage.setItem('username', response.data.partyName);
                currentComponent.setState({ userData: response.data });
            }).catch(function (error) {
            })
        }
    }

    viewParty() {
        this.props.history.push('/lms/mainSummaryTabsPage');
        return true;
    }

    resetData() {
        this.setState(this.resetState(), function () {
        });
        return true;
    }

    uploadDocuments() {
        this.validateField();
        var obj = localStorage.getItem('errorStatus');
        if (this.state.rbsClassificationVal && this.state.rbsRecordVal && this.state.rbsRiskVal && this.state.documentDescription) {
            var currentComponent = this;
                this.setState({
                    dialogDismiss: 'modal',
                });
            var userID = '';
            var roleName = '';
            var userName = '';
            if (PING == 'true') {
                let { usersDetails, name } = this.context;
                userID = usersDetails.userID;
                roleName = usersDetails.memberOf;
                userName = name;
            } else {
                userID = localStorage.getItem('racfID');
                roleName = localStorage.getItem('roleName');
                userName = 'Joe Doe';
            }
            // let id = parseInt(localStorage.getItem('userID'));
            let doctype = ''
            if (this.state.docType == "") {
                doctype = "msg";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
                this.state.docType == "application/vnd.ms-excel") {
                doctype = "excel";
            } else if (this.state.docType == "application/pdf") {
                doctype = "pdf";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                doctype = "doc";
            } else if (this.state.docType == "application/msword") {
                doctype = "doc";
            } else if (this.state.docType == "image/png") {
                doctype = "png";
            } else if (this.state.docType == "image/jpeg") {
                doctype = "jpg";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
                doctype = "ppt";
            }
            doctype = doctype.toUpperCase();
            let isApprovalrequired = 0;
            let isHighRisk = 0;
            let isApproved = "Approved";
            let riskVal = '';
            if (this.state.rbsRiskVal == "High Risk") {
                riskVal = 'High risk';
                isHighRisk = 1;
                if (roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1) {
                    isApprovalrequired = 0;
                    isApproved = "Approved";
                } else {
                    isApprovalrequired = 1;
                    isApproved = "PendingApproval";
                }
            } else if (this.state.rbsRiskVal == "Secondary Risk") {
                riskVal = 'Secondary risk';
            } else if (this.state.rbsRiskVal == "Historical") {
                riskVal = 'Historical';
            }
            // var leaseContractID = parseInt(localStorage.getItem('leaseContractId'));
            var leaseContractID = this.props.leaseParentId;
            if(leaseContractID && leaseContractID !==''){
                let payLoadData = uploadDocuments(this.state.uploadedFileName, doctype, 
                    this.state.documentDescription, null,
                    this.state.rbsClassificationVal, this.state.rbsRecordVal, riskVal, null,
                    leaseContractID, userID, null, isApproved, isApprovalrequired, isHighRisk, userName);
                    let endPoint = API_ENDPOINT.UPLOAD_DOCUMENTS + '/uploadDoc/lease';
                    const formData = new FormData();
                    formData.append('file', this.state.selectedFile);
                formData.append('documentDetails', JSON.stringify(payLoadData));
                console.log("payLoadData:: ");
                console.log(payLoadData);
                let output = HttpPostDocuments(currentComponent, formData, endPoint)
                .then(function (response) {
                    if (response.status == 200 || response.status == 201) {
                            let docUpload = localStorage.getItem("docUpload");
                            if (docUpload == "userDocUpload") {
                                localStorage.setItem("docUpload", "userDocUpload1");
                            } else if (docUpload == "userDocUpload1") {
                                localStorage.setItem("docUpload", "userDocUpload");
                            }
                        currentComponent.setState({
                            dialogDismiss: 'modal',
                            docUploadSuccess: true,
                            pageStatus: 'docUploadSuccess',
                            showData: !currentComponent.state.showData
                        }, function () {
                            // currentComponent.handleSelectTab();
                            this.props.updateStatus('docUploadSuccess')
                            currentComponent.forceUpdate();
                        });
                        currentComponent.forceUpdate();
                    } else { 
                        currentComponent.setState({
                            
                            pageStatus: '',
                        });
                    }
                    currentComponent.forceUpdate();
                })
                .catch(function (error) {
                    currentComponent.setState({
                       
                        pageStatus: '',
                    });
                })
            }
            
            }
        
        return true;
    }

    onClickHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.inputOpenFileRef.current.click();
        const formData = new FormData();
        formData.append('file', this.state.selectedFile);
        return true;
    }

    onChangeCheckBox = (e, isChecked) => {
        this.setState({ checkboxStatus: isChecked }, function () { 
            this.fieldValidation();
        });
        return true;
    }

    fieldValidation() {
        // CPBNRP-1328 fixed
        var docDescription = this.state.documentDescription.split(" ").join("");
        var descriptionValid;
        if(docDescription === "" || docDescription === null){
        // alert("At least 8 characters are required!");
        descriptionValid = false
        }
        else{
            descriptionValid = true;
        }
        

        if (this.state.rbsClassificationVal && this.state.rbsRecordVal
            && this.state.rbsRiskVal && descriptionValid && this.state.checkboxStatus) {
            this.setState({
                dialogDismiss: 'modal',
                documentUploadStatus: false
            });
        } else { 
            this.setState({
                dialogDismiss: '',
                documentUploadStatus: true
            });
        }
        this.validateField();
        return true;
    }

    onChangeDocumentDescription = (e) => {
        var val = e.target.value;
        var dataVal = val.trimLeft();
        let v = validate('documentDescription', dataVal);
        if (v[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v[0], textErrorMessage: v[1] });
        }
        this.setState({
            documentDescription: dataVal,
        }, function () {
            this.fieldValidation();
        })
        return true;
    }

    onChangeHandler = event => {
        console.log("Selected file");
        console.log(event.target.files);
        if (event.target.files[0]) {
            var status = checkDocumentNamingFormat(event.target.files[0].name);
            if (!status) {
                var fileSize = (event.target.files[0].size / (1024 * 1024 * 1024));
                console.log("RIght file selected");

                if (event.target.files.length > 1) {
                    this.setState({
                        docLengthStatus: true,
                        errorMessage: 'Max 1 file can be uploaded in one go. Please select a file and try again.'
                    });
                } else {
                    console.log("RIght file selected1");
                    if (event.target.files[0] && fileSize <= 2) {
                        if (event.target.files[0].type == 'application/pdf' || event.target.files[0].type == 'image/png' ||
                            event.target.files[0].type == 'image/jpeg' ||
                            event.target.files[0].type == 'application/msword' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
                            event.target.files[0].type == 'application/vnd.ms-excel' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
                            console.log("RIght file selected2");
                            this.setState({
                                uploadedFileName: event.target.files[0].name,
                                docType: event.target.files[0].type,
                                selectedFile: event.target.files[0],
                                fileUploadStatus: true,
                                // documentUploadStatus: false,
                                docLengthStatus: false
                            });
                        } else {
                            this.setState({
                                docLengthStatus: true,
                                errorMessage: 'Invalid document type.'
                            });
                        }

                    } else {
                        this.setState({
                            docLengthStatus: true,
                            errorMessage: 'File size should be less then 2GB. Please select a file and try again.'
                        });
                    }
                }
            } else {
                this.setState({
                    docLengthStatus: true,
                    errorMessage: 'Please make sure that the document name is compliant with the naming convention'
                });
            }
        }
        return true;
    }

    deleteDocument() { 
        this.setState({
            uploadedFileName: '',
            selectedFile: '',
            fileUploadStatus: false,
            documentUploadStatus: true,
            rbsClassificationVal: '',
            rbsRecordVal: '',
            rbsRiskVal: '',
            rbsClassificationValErrorStatus: '',
            rbsRecordValErrorStatus: '',
            rbsRiskValErrorStatus: '',
            rbsClassificationValErrorMessage: '',
            rbsRecordValErrorMessage: '',
            rbsRiskValErrorMessage: '',
            documentDescription: '',
           

        });
        return true;
    }

   

    validateField() {
        let v = validate('dropdown', this.state.rbsClassificationVal);
        if (v[0] == null) {
            this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
        }
        let v1 = validate('dropdown', this.state.rbsRecordVal);
        if (v1[0] == null) {
            this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ rbsRecordValErrorStatus: !v1[0], rbsRecordValErrorMessage: v1[1] });
        }

        let v2 = validate('dropdown', this.state.rbsRiskVal);
        if (v2[0] == null) {
            this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ rbsRiskValErrorStatus: !v2[0], rbsRiskValErrorMessage: v2[1] });
        }

        let v3 = validate('documentDescription', this.state.documentDescription);
        if (v3[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v3[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v3[0], textErrorMessage: v3[1] });
        }

        return true;
    }

    getDropdownItem(event, ID, type) {
        if (event == "Classification") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
                
            } else if (v[0] != null) {
                this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
            }
            this.setState({ rbsClassificationVal: type.value }, function () { 
                this.fieldValidation();
            });
        } else if (event == "Record") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRecordValErrorStatus: !v[0], rbsRecordValErrorMessage: v[1] });
            }
            this.setState({ rbsRecordVal: type.value }, function () { 
                this.fieldValidation();
            });
        } else if (event == "Risk") {
            var isSeniorApprover = this.state.roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1
            console.log(!isSeniorApprover);
            if ((type.value).toLowerCase() == "high risk" && (!isSeniorApprover)) { 
                console.log("Inside hIgh risk");
                this.setState({ highRiskStatus: true });
            } else {
                this.setState({ highRiskStatus: false });
            }
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRiskValErrorStatus: !v[0], rbsRiskValErrorMessage: v[1] });
            }
            this.setState({ rbsRiskVal: type.value }, function () { 
                this.fieldValidation();
            });
        }
    }

    handleSelectTab = () => { 
        this.setState({ key: 3 });
    }

    DocumentDeleteRequestSent () { 
        this.setState({ pageStatus: 'docDeleteSuccess' });
        this.props.updateStatus('docDeleteSuccess')
    }

    DocumentDeleteCancelRequestSent() {
        this.setState({ pageStatus: 'docDeleteCancel' });
        this.props.updateStatus('docDeleteCancel')
    }

    pendingCount(count, uploadCount) { 
        console.log("Pending count");
        console.log(count);
        this.setState({
            pendingCount: count,
            pageStatus: 'docPendingApproval',
        }, function () {
            })
        this.props.dealData.pendingCount = count;
        this.props.dealData.uploadPendingCount = uploadCount;
               this.props.updateStatus('docPendingApproval')
        return true;
    }

    deletionStatus(count, docName, cname) { 
         let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pendingCount: count,
            deleteStatus: 'approverDocDeleted',
            pageStatus: 'docPendingApproval',
            deletedDocName: docName,
            docUserName: cname,
        }, function () {
                this.forceUpdate();
            })
        this.props.dealData.pendingCount = count;
        this.props.dealData.deletedDocName = docName;
        this.props.dealData.docUserName = cname;
        this.props.updateStatus('docPendingApproval')
        return true;
    }

     uploadApprovalStatus(docName, cname) {
        console.log("uploadApprovalStatus");
        console.log(docName);
        console.log(cname);
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pageStatus: 'docUploadApproved',
            deletedDocName: docName,
            docUserName: cname,
        }, function () {
                this.forceUpdate();
        })
        this.props.dealData.deletedDocName = docName;
        this.props.dealData.docUserName = cname;
         this.props.updateStatus('docUploadApproved')
        return true;
    }

    uploadRejectStatus(docName, reason, approverName) {
        // /docDeleteRejected
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pageStatus: 'docUploadRejected',
            deletedDocName: docName,
            rejectionReason: reason,
            approverName: approverName
        }, function () { 
                this.forceUpdate();
        })
         this.props.dealData.rejectionReason = reason;
        this.props.dealData.deletedDocName = docName;
        this.props.dealData.approverName = approverName;
        this.props.updateStatus('docUploadRejected')
        return true;
    }

    rejectStatus(docName) { 
        // /docDeleteRejected
        this.setState({
            pageStatus: 'docDeleteRejected',
            deletedDocName: docName,
        })
        this.props.dealData.deletedDocName = docName;
        this.props.updateStatus('docDeleteRejected')
        return true;
    }


    HandleSelectChange(event, type, value) {
        this.setState({ recordView: type.value }); 
       

    }

    documentDeleted() {
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        
        this.props.updateStatus('docDeletedSuccess1')
    }
    
    render() {

        let docUpload = localStorage.getItem("docUpload");
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else {
            datalen = 0;
        }
        var uploadDocumentEnable = false;
        for (var i = 0; i < datalen; i++) {
            if (perData[i] == "Deal_Doc_Request_Upload_High_Risk") {
                uploadDocumentEnable = true;
            }
        }
        if(!this.props.leaseParentId){
            uploadDocumentEnable = false;
        }

        
        return (
            <div className="dealBackground">

                {!uploadDocumentEnable ? <div>
                    <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                        {!this.props.leaseParentId ? <Notification status='info' size ='small'>Please save the deal first.</Notification> : null}
                        <div style={{ width: '175px' }}>
                            <Icon name="plus-xsmall" size='small' title="" /><label className="uploadDocument" >Upload documents</label>
                        </div>
                    </div>
                </div> : null}
                {uploadDocumentEnable ? <div onClick={this.resetData.bind(this)}>
                    <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                        <div data-toggle="modal" data-target="#upload" style={{ width: '175px' }}>
                            <Icon name="plus-xsmall" size='small' title="" /><label className="uploadDocument" >Upload documents</label>
                        </div>
                    </div>
                </div> : null}
                        
               

                {this.state.userData.cisCode ? <div style={{
                    margin: '12px auto 0px',
                    width: '1244px'
                }}>
                    <span className="investor_title">{this.state.userData.partyName}(CIS {this.state.userData.cisCode})</span>

                </div>
                    : null}

                {docUpload == "approverDocUpload" ? <div><ApproverLeaseDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                            userData={this.state.userData} deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)} />
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per page</span>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_row'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "approverDocUpload1" ? <div><ApproverLeaseDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                            userData={this.state.userData} 
                            deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)} />
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per pag</span>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_row'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "userDocUpload" ? <div><DocumentLeaseGrid
                        dealId={this.props.leaseParentId}
                    DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                    DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                    selectedRecord={parseInt(this.state.recordView)} dealData={this.props.dealData}
                    pendingCount={this.pendingCount.bind(this)}
                    deletionStatus={this.deletionStatus.bind(this)}
                    rejectStatus={this.rejectStatus.bind(this)}
                    uploadApprovalStatus={this.uploadApprovalStatus.bind(this)}
                    uploadRejectStatus={this.uploadRejectStatus.bind(this)}/>
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per page</span>
                                <Select
                                    defaultValue='10'
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_page_size'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "userDocUpload1" ? <div><DocumentLeaseGrid
                        dealId={this.props.leaseParentId}
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                    selectedRecord={parseInt(this.state.recordView)} dealData={this.props.dealData}
                    pendingCount={this.pendingCount.bind(this)}
                    deletionStatus={this.deletionStatus.bind(this)}
                    rejectStatus={this.rejectStatus.bind(this)}
                    uploadApprovalStatus={this.uploadApprovalStatus.bind(this)}
                    uploadRejectStatus={this.uploadRejectStatus.bind(this)}/>
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per page</span>
                                <Select
                                    defaultValue='10'
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_page_size'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}

                       <DocumentUpload onClick={this.onClickHandler.bind(this)}
                    onChangeDoc={this.onChangeHandler.bind(this)} reference={this.inputOpenFileRef}
                    id="upload" uploadStatus={this.state.documentUploadStatus} fileName={this.state.uploadedFileName}
                    value={this.state.documentDescription} onChange={this.onChangeDocumentDescription.bind(this)}
                    deleteDoc={this.deleteDocument.bind(this)} onUpload={this.uploadDocuments.bind(this)}
                    errorStatus={this.state.textErrorStatus} textErrorMessage={this.state.textErrorMessage} dialogDismiss={this.state.dialogDismiss}
                    docType={this.state.docType} docLengthStatus={this.state.docLengthStatus}
                    errorMessage={this.state.errorMessage} onCheckboxChange={this.onChangeCheckBox.bind(this)}
                    rbsClassificationVal={this.state.rbsClassificationVal} rbsRecordVal={this.state.rbsRecordVal}
                    rbsRiskVal={this.state.rbsRiskVal} getDropdownItem={this.getDropdownItem.bind(this)}
                    rbsClassificationValErrorStatus={this.state.rbsClassificationValErrorStatus} rbsClassificationValErrorMessage={this.state.rbsClassificationValErrorMessage}
                    rbsRecordValErrorStatus={this.state.rbsRecordValErrorStatus} rbsRecordValErrorMessage={this.state.rbsRecordValErrorMessage}
                    rbsRiskValErrorStatus={this.state.rbsRiskValErrorStatus} rbsRiskValErrorMessage={this.state.rbsRiskValErrorMessage} actionType="deal"
                    highRiskStatus={this.state.highRiskStatus}
                />
            
            </div>
        )
    }

}

export default withRouter(uploadDealDocuments);
