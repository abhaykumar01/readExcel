import React from 'react';
import Modal from '@zambezi/sdk/modal';
import { dealApprovalModalMessages  } from '../../../models/LeaseConstants';


class UnsavedChangesWarningModal extends React.Component{
    constructor(props){
        super(props);

        this.state={
        }
    }

    render(){
        return (
            <Modal 
                title="Unsaved changes" 
                className='dealApprovalModal' 
                confirm='Yes, proceed'
                cancel='Cancel'
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={() => { this.props.onConfirm() }}
                onCancel={() => { this.props.onCancel() }}
            >
                <label className="fieldLabel msgLabel">
                        { dealApprovalModalMessages['unSavedChangesMsg'] }
                    </label>  
            </Modal>
        )
    }
}

export default UnsavedChangesWarningModal;