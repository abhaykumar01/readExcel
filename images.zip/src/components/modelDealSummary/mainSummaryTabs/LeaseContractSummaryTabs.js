import React from 'react';
import '../../../index.css';
import {Tab, Tabs, TabList, TabPanel,} from 'react-tabs';
import "react-tabs/style/react-tabs.css"
import PeriodSummaryTL from '../leaseDataModelTimeline/periodSummaryTL';
import CurveSummaryTL from '../leaseDataModelTimeline/leaseCurveTimeLine/curveSummaryTL';
import UploadDealDocuments from '../../modelDealSummary/uploadDealsDocuments/uploadDealDocuments';
import SummaryDetail from '../SummaryDetail/SummaryDetail';
import Accordion from '@zambezi/sdk/accordion';
import './mainSummaryTabsPage.css';
import importImage from '../../../assets/images/import.png';
import { base64StringToBlob } from 'blob-util';
import YieldLineChart from '../../modelDealSummary/LeaseModelCharts/YieldLineChart';
import LeaseCashFlow from '../../modelDealSummary/LeaseModelCharts/LeaseCashFlow';
import MarginLeaseCashFlow from '../../modelDealSummary/LeaseModelCharts/MarginLeaseCashFlow';
import ReturnGraphTL from '../../modelDealSummary/LeaseModelCharts/returnGraphTL';
import DealAuditDetails from '../../modelDealSummary/leaseAudit/dealAuditDetails';
import exportImage from '../../../assets/images/fill-545.png';
import { API_ENDPOINT } from '../../../config/config.js';
import { HttpDownloadExcelFile } from '../../../services/api.js';

class LeaseContractSummaryTabs extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
        }
    }


    exportToExcel(){
        console.log("exportToExcel");
        var currentComponent = this;
        let leaseContract = this.props.leaseContract;
        let endPoint = API_ENDPOINT.LEASE_EXPORT_TO_EXCEL;
        let output1 = HttpDownloadExcelFile(currentComponent, leaseContract, endPoint).then(function (response) {
            console.log("Download document Response received from server");
            console.log(response);
            // console.log(response.data);
            // var byteArray = new Uint8Array(response.data);
            var blob = base64StringToBlob(response.data, 'application/xlsx');
            // const url = window.URL.createObjectURL(new Blob([byteArray]),  { type: 'application/octet-stream' });
            const url = window.URL.createObjectURL(blob);
            console.log(url);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'MasterNRLeaseModel.xlsm'); //or any other extension
            document.body.appendChild(link);
            link.click();
        })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
                window.alert("error"+error);
            })

    }

    render(){
        return(
            <div style={{marginTop:'-15px'}}>
                <Tabs selectedTabClassName="selectedtlpGridTab" >
                <div className=" export_btn" style ={{marginRight:'52px'}}> 
                    <img src={importImage} size='small' style={{marginBottom:'2px'}}/><label style={{ marginLeft: '5px', marginBottom:'2px' }} className="export-to-excel" > Download PDF</label>
                </div>
                <div className=" export_btn" onClick={this.exportToExcel.bind(this)}>
                 <img src={exportImage} size='small' style={{marginBottom:'2px'}} /><label style={{ marginLeft: '5px', marginBottom:'2px' }} className="export-to-excel" > Export to Excel</label>
                </div>
                <TabList className="summaryTabList">
                    <Tab className="headerSummaryTab">Summary</Tab>
                    <Tab className="headerSummaryTab">Charts</Tab>
                    <Tab className="headerSummaryTab">Timeline</Tab>
                    <Tab className="headerSummaryTab">Curves</Tab>
                    <Tab className="headerSummaryTab">Documents</Tab>
                    <Tab className="headerSummaryTab">Audit</Tab>
                </TabList>
                <TabPanel>
                    <SummaryDetail dataFromParent = {this.props.leaseContract} />
                </TabPanel>
                <TabPanel><div class="form-group row colour_white" style={{height: '1250px'}}>
                        <LeaseCashFlow dataFromParent={this.props.leaseContract} />
                        <MarginLeaseCashFlow dataFromParent={this.props.leaseContract} />
                        <ReturnGraphTL dataFromParent={this.props.leaseContract} />
                        <YieldLineChart /></div>
                </TabPanel>
                <TabPanel>
                    <PeriodSummaryTL dataFromParent = {this.props.leaseContract}/>
                </TabPanel>
                <TabPanel>
                    <CurveSummaryTL dataFromParent = {this.props.leaseContract}/>
                </TabPanel>
                <TabPanel style={{margin:'0px 0px 0px -15px'}}>
                    <UploadDealDocuments leaseParentId = {this.props.dealParentId} updateStatus = {this.props.updateStatus.bind(this)}/> 
                </TabPanel>
                <TabPanel>
                   <DealAuditDetails leaseParentId = {this.props.dealParentId}></DealAuditDetails>
                </TabPanel>
            </Tabs>
            </div>
        );
    }
}

export default LeaseContractSummaryTabs;