import React from 'react';
import '../../../index.css';
import LeaseContractSummaryTabs from './LeaseContractSummaryTabs';
import './mainSummaryTabsPage.css';
import { Lease_Constants } from '../../../models/LeaseConstants';


class LeaseParentSummaryTabs extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            setSummaryDealview: true,
            isToggleActive : false,
        }
    }


    componentWillMount(){
       var dealUsage = this.props.dealUsageType;
       if(dealUsage == Lease_Constants.DEAL_USAGE_DEPRECIATION){
        this.setState({setSummaryDealview:false});
       } else if(dealUsage == Lease_Constants.DEAL_USAGE_INVOICING){
        this.setState({setSummaryDealview:true});
       } else if(dealUsage === Lease_Constants.DEAL_USAGE_INVOICE_AND_DEPRECIATION){
           this.setState({
            setSummaryDealview:true,
            isToggleActive : true,
           })
       }
    }

    selectSummaryType(selectSummaryDataType) {
        if (selectSummaryDataType === 'dealView' && this.props.leaseParent.depreciationLeaseContract !== null
            && this.props.leaseParent.depreciationLeaseContract !== undefined) {
            this.props.setDealHeaderData(Lease_Constants.DEAL_USAGE_DEPRECIATION);
            this.setState({ setSummaryDealview: false });
        } else if (this.props.leaseParent.invoicingLeaseContract !== null
            && this.props.leaseParent.invoicingLeaseContract !== undefined) {
            this.props.setDealHeaderData(Lease_Constants.DEAL_USAGE_INVOICING);
            this.setState({ setSummaryDealview: true });
        }
        return true;
    }

    render(){
        return(
            <div>
                <div class="form-group row" style={{marginTop:'-7px'}}>
                <label class="viewModel">View model</label>
                    <div class= "zb-columns" style={{marginTop:'-10px'}}>
                        <div style={{marginLeft:'-1px'}}>
                            <div className={"btn-group dealUsageToogle "+ (this.state.isToggleActive ? '':'dealUsageToggleDisabled')}>
                                <button type="button" style={{borderRadius : '0px', height :'36px'}} className={"btn btn-primary " + (this.state.setSummaryDealview ? 'twoWayButton_selected' : 'twoWayButton_notselected')} 
                                    onClick={this.selectSummaryType.bind(this, 'spvView')}>Invoicing</button>
                                <button type="button" style={{borderRadius : '0px', height :'36px'}} className={"btn btn-primary " + (!this.state.setSummaryDealview ? 'twoWayButton_selected' : 'twoWayButton_notselected')} 
                                    onClick={this.selectSummaryType.bind(this, 'dealView')}>Depreciation</button>
                            </div>
                        </div>
                    </div> 
                </div>
                {this.state.setSummaryDealview ?
                    <LeaseContractSummaryTabs leaseContract={this.props.leaseParent.invoicingLeaseContract}
                        dealParentId={this.props.leaseParent.leaseParentId} 
                        updateStatus = {this.props.updateStatus.bind(this)} />
                    :
                    <LeaseContractSummaryTabs leaseContract={this.props.leaseParent.depreciationLeaseContract}
                        dealParentId={this.props.leaseParent.leaseParentId} 
                        updateStatus = {this.props.updateStatus.bind(this)}/>
                }
            </div>
        );
    }
}

export default LeaseParentSummaryTabs;