import React from 'react';
import Modal from '@zambezi/sdk/modal';
import { RadioButton } from '@zambezi/sdk/form-elements';
import { dealApprovalModalMessages , Lease_Constants } from '../../../models/LeaseConstants';


class UpdateDealStatusModal extends React.Component{
    constructor(props){
        super(props);

        this.state={
            selectedStatus : '',
            isConfirmDisabled : true,
        }
    }

    onSelectStatus(status, e, isSelected){
        if(isSelected){
            this.state.selectedStatus=status;
        }
        this.setState({isConfirmDisabled : !this.validateAllRequiredFields()});
    }

    validateAllRequiredFields(){
        if(null === this.state.selectedStatus || this.state.selectedStatus===''){
            return false;
        }
        return true;
    }

    render(){
        return (
            <Modal 
                title="Update deal status" 
                className='dealApprovalModal' 
                confirm='Update status'
                cancel='Cancel'
                withSectioning={false} 
                withPadding 
                isClosable
                open={this.props.open}
                onConfirm={() => { this.props.onConfirm(this.state.selectedStatus) }}
                onCancel={() => { this.props.onCancel() }}
                renderFooter={(onConfirm, onCancel) => {
                    return (
                        <div className="form-group">
                            <button className='zb-button zb-button-primary footerButton' disabled={this.state.isConfirmDisabled} onClick={onConfirm}>{'Update status'}</button>
                            <button className='zb-button zb-button-secondary footerButton transparent' onClick={onCancel}>{'Cancel'}</button>
                        </div>
                    )
                }}
                >
                <div className="form-group row noMargin">
                    <div className="row noMargin">
                        <label className="fieldLabel msgLabel" style={{marginBottom : '15px'}}>{ dealApprovalModalMessages['selectDealStatus'] }</label>
                    </div>
                    <div className="row noMargin" style={{marginBottom : '15px'}}>
                        <label htmlFor="newBusinessArea" className="col-sm-2 col-form-label fieldLabel" >Active</label>
                        <RadioButton id="dealStatus-radio-1" name="dealStatus" onChange={this.onSelectStatus.bind(this, Lease_Constants.LEASE_STATUS_ACTIVE)}/>
                    </div>
                    <div className="row noMargin" style={{marginBottom : '15px'}}>
                        <label htmlFor="newBusinessArea" className="col-sm-2 col-form-label fieldLabel" >Signed</label>
                        <RadioButton id="dealStatus-radio-2" name="dealStatus" onChange={this.onSelectStatus.bind(this, Lease_Constants.LEASE_STATUS_SIGNED)}/>
                    </div>
                </div>   
            </Modal>
        )
    }
}

export default UpdateDealStatusModal;