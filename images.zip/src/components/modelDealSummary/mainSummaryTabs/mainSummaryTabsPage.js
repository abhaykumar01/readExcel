import React from 'react';
import '../../../index.css';
import "react-tabs/style/react-tabs.css"
import './mainSummaryTabsPage.css';
import '../../../components/TLPgrid/emptyGrid.css';
import { HttpPost, HttpGet, HttpDownloadExcelFile, HttpPutWithoutBody, HttpDelete, HttpPut } from '../../../services/api.js';
import { Route, withRouter } from 'react-router-dom';
import { Icon } from '@zambezi/sdk/icons';
import exportImage from '../../../assets/images/fill-545.png';
import { Notification } from '@zambezi/sdk/notification';
import { API_ENDPOINT } from '../../../config/config.js';
import PopupApprovalWF from '../../../commonComponents/popupDeals.js';
import Popup from '../../../commonComponents/popupMessage';
import PopupInvDep from '../../../commonComponents/popupMessage.js';
import { AuthorizationContext } from '../../../components/authContext/index';
import { Lease_Constants, dealAuditMsg, defaultDealAuditObject, dealNotificationMessages } from '../../../models/LeaseConstants.js';
import UpdateDealStatusModal from './updateDealStatusModal';
import UnsavedChangesWarningModal from './unsavedChangesWarningModal';
import GeneralDealApprovalModal from '../../dealApprovals/dealApprovalModals/generalDealApprovalModal';
import LeaseParentSummaryTab from './LeaseParentSummaryTab';
const PING = process.env.REACT_APP_PING;


class mainSummaryTabsPage extends React.Component{
    static contextType = AuthorizationContext;
    unblockNav=null;
    constructor(props) {
        super(props);
        this.state = {
            tabIndex:0,
            dealId: "",
            customerName: "",
            spv: "",
            dealDescription:"",
            leaseParent:null,
            pageStatus:'',
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            
            dialogStatus:'closeDialog',
            saveLease:false,
            dealStatus:'',
            workflowType:'',
            isRequestedForArchived : 0,
            isArchived : 0,
            loadSuccess: false,
            approverName: "",
            deletedDocName: '',
            docUserName: '',
            failureMessage: '',
            rejectionReason: '',
            confirmMessage: '',
            pendingCount: 0,
            isUnsavedChanges : false,
            uploadPendingCount: 0,
            dealUsage:"",
            isSaveSuccessful:false,
        }
    }

    componentWillUnmount(){
        if(this.unblockNav){
            this.unblockNav();
        }
    }

    componentDidMount() {   
        console.log("lease response date state");
        console.log(localStorage.getItem('leaseResponseDataState'));
        if (localStorage.getItem('leaseResponseDataState') !== undefined) {
            console.log("lease response date state1");
            var leaseContract = JSON.parse(localStorage.getItem('leaseResponseDataState'));
            console.log(leaseContract);
            var leaseContractId = 1;
            var leaseDes = "";
            var custName = "";
            var spv1 = 1;
            var status = "Active";

            // if (leaseContract) { 
            //     leaseContractId = leaseContract.leaseParentId;
            //     leaseDes = leaseContract.contractDescription;
            //     custName = leaseContract.customerName;
            //     spv1 = leaseContract.spv;
            //     status = leaseContract.status;
            // } else {
            //     leaseContractId = 1;
            //     leaseDes = "Lease modelling";
            //     custName = "Model deal";
            //     spv1 = 1;
            //     status = "Active";
            // }
            // // var leaseContractId = leaseContract.leaseContractId;
            // console.log("leaseContractId");
            // console.log(leaseContractId);
			// localStorage.setItem('leaseContractId', leaseContractId);
            // this.setState({ dealStatus: status});
            // this.setState({dealId:leaseContractId, dealDescription: leaseDes, customerName: custName, spv: spv1});
            // this.setState({leaseData:leaseContract});
        }
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        }); 
    }
    componentWillMount(){
        this.hideNotification();

        if(this.props.location.state !== undefined && 
            (this.props.location.state.fromDealURL === "ModelANewDeal")){
                if(this.props.location.state.leaseResponseDataState !== undefined){
                    let leaseParent = this.props.location.state.leaseResponseDataState;
                    this.setLeaseState(leaseParent);
                } else if(localStorage.getItem('leaseResponseDataState') !== undefined){
                    let leaseParent = JSON.parse(localStorage.getItem('leaseResponseDataState'));
                    this.setLeaseState(leaseParent);
                }
                this.state.isUnsavedChanges= true;
                this.unblockNav = this.props.history.block((targetLocation, action)=> {
                    if(this.state.isUnsavedChanges && 
                        (targetLocation.pathname !== '/lms/serverDown' && targetLocation.pathname !== '/lms/LeaseModel')){
                        this.state.restrictedPath = targetLocation;
                        this.openModal('unsavedChangesWarning');
                        return false;
                    } else {
                        return true;
                    }
                });
        } else if (this.props.location.state != undefined) {
            let leaseParentId = this.props.location.state.leaseParentId;
            this.fetchDeal(leaseParentId);
        }      
    }

    fetchDeal(leaseParentId) {
        var currentComponent = this;
        if (leaseParentId !== null && leaseParentId !== undefined && leaseParentId !== '') {
            let endPoint = API_ENDPOINT.GET_DEAL_PARENT + '/' + leaseParentId;
            HttpGet(currentComponent, endPoint).then((response) => {
                console.log("User response received from server");
                console.log(response.data);
                console.log(response.data.leaseParentId);
                localStorage.setItem('leaseResponseDataState', JSON.stringify(response.data));
                localStorage.setItem('leaseParentId', response.data.leaseParentId);
                this.props.history.push({
                    state: { leaseResponseDataState: response.data,
                        leaseParentId: response.data.leaseParentId}
                })
                this.setLeaseState(response.data);
            }).catch(function (error) {
                console.log("Error received");
                //window.alert(error);
            })
        }
    }

    setLeaseState(leaseParent){
        var leaseParentId = leaseParent.leaseParentId;

        var leaseDes = "";
        var custName = "";
        var spv1 = "";
        var dealUsageType = "";
        var areaName = "";

        if(leaseParent.invoicingLeaseContract !== null && leaseParent.invoicingLeaseContract !== undefined){
            leaseDes = leaseParent.invoicingLeaseContract.contractDescription;
             custName = leaseParent.invoicingLeaseContract.customerName;
             spv1 = leaseParent.invoicingLeaseContract.spv;
             dealUsageType = Lease_Constants.DEAL_USAGE_INVOICING;
             areaName = leaseParent.invoicingLeaseContract.areaName;
        } else if(leaseParent.depreciationLeaseContract !== null && leaseParent.depreciationLeaseContract !== undefined){
             leaseDes = leaseParent.depreciationLeaseContract.contractDescription;
             custName = leaseParent.depreciationLeaseContract.customerName;
             spv1 = leaseParent.depreciationLeaseContract.spv;
             dealUsageType = Lease_Constants.DEAL_USAGE_DEPRECIATION;
             areaName = leaseParent.depreciationLeaseContract.areaName;
        }

        if(leaseParent.depreciationLeaseContract != null && leaseParent.depreciationLeaseContract != undefined &&
            leaseParent.invoicingLeaseContract != null && leaseParent.invoicingLeaseContract != undefined){
                dealUsageType = Lease_Constants.DEAL_USAGE_INVOICE_AND_DEPRECIATION;
            }
        
        var currentWorkflowNumber = leaseParent.currentWorkflowNumber;
        var onlineSolution = leaseParent.onlineSolution;
        var offlineSolution = leaseParent.offlineSolution;
        var dealNumber = leaseParent.dealNumber;
        var dealCaptainId = leaseParent.dealCaptainRoleID;
        var isRequestedForArchived = leaseParent.isRequestedForArchived;
        var isArchived = leaseParent.isArchived;
        var dealRefNumber = this.zeroPad(leaseParent.dealReferenceNumber);
        
        this.setState({ 
            dealStatus: leaseParent.status,
            dealId: leaseParentId,
            dealDescription: leaseDes,
            customerName: custName,
            spv: spv1,
            areaName: areaName,
            leaseParent: leaseParent,
            currentWorkflowNumber: currentWorkflowNumber,
            offlineSolution: offlineSolution,
            onlineSolution: onlineSolution,
            loadSuccess : true,
            dealNumber : dealNumber,
            dealCaptainId : dealCaptainId,
            isRequestedForArchived : isRequestedForArchived,
            isArchived : isArchived,
            dealRefNumber : dealRefNumber,
            dealUsage:dealUsageType,
            requestedBy:leaseParent.requestedBy
        },this.getSavedDealCaptain);
        var dealType = localStorage.getItem('DealRequestType');
            if(dealType == "EDIT_DEAL" && 
            (leaseParent.status !== Lease_Constants.LEASE_STATUS_MODELLED &&
                leaseParent.status !== Lease_Constants.LEASE_STATUS_BLANK)){
                this.setState({saveLease:false});
            } else {
                this.setState({saveLease:true});
            }
    }

    setDealHeaderData(dealUsageType){
        let customerName = '';
        let spvNumber='';
        let dealDescription ='';

        if(dealUsageType===Lease_Constants.DEAL_USAGE_DEPRECIATION){
            if(this.state.leaseParent && this.state.leaseParent.depreciationLeaseContract){
                customerName = this.state.leaseParent.depreciationLeaseContract.customerName || '';
                spvNumber = this.state.leaseParent.depreciationLeaseContract.spv || '';
                dealDescription = this.state.leaseParent.depreciationLeaseContract.contractDescription || '';
            }  
        } else if(dealUsageType===Lease_Constants.DEAL_USAGE_INVOICING){
            if(this.state.leaseParent && this.state.leaseParent.invoicingLeaseContract){
                customerName = this.state.leaseParent.invoicingLeaseContract.customerName || '';
                spvNumber = this.state.leaseParent.invoicingLeaseContract.spv || '';
                dealDescription = this.state.leaseParent.invoicingLeaseContract.contractDescription || '';
            }  
        }

        this.setState({
            customerName : customerName,
            spv : spvNumber,
            dealDescription : dealDescription,
        })
    }

    getSavedDealCaptain(){
        console.log(this.state.dealCaptainId)
        if(this.state.dealCaptainId != null && this.state.dealCaptainId != ""){
            let url = API_ENDPOINT.GET_SAVED_DEAL_CAPTAIN+this.state.dealCaptainId;
            HttpGet(this, url).then((response) => {
                if(response && response.data){
                    console.log(response.data)
                    this.setState({dealCaptainRacfID : response.data.userID});
                }
            }).catch((error) => {
                console.log(error);
            })
        }
        

        
    }
    zeroPad(num){
        if(num !== undefined && num !== null && num !== ""){
           return num.toString().padStart(9, "0");
        } else {
            return '';
        } 
   }


    saveDealDBCall(){
        var currentComponent = this;
        let payLoadData = JSON.parse(localStorage.getItem('leaseResponseDataState'));

            var dealType = localStorage.getItem('DealRequestType');
            var toHit = API_ENDPOINT.SAVE_DEAL_PARENT;
            if(dealType == "EDIT_DEAL"){
                toHit = API_ENDPOINT.UPDATE_DEAL_PARENT;
            }
            if((payLoadData.invoicingLeaseContract !== null &&
                payLoadData.invoicingLeaseContract !== undefined) || 
                (payLoadData.depreciationLeaseContract !== null
                    || payLoadData.depreciationLeaseContract !== undefined)){
                let output = HttpPost(currentComponent, payLoadData, toHit)
            .then(function (response) {
                console.log("response received from server");
                console.log(response);
                localStorage.setItem('leaseResponseDataState',JSON.stringify(response.data));
                currentComponent.state.isUnsavedChanges = false;
                currentComponent.setState({isSaveSuccessful : true});
                currentComponent.setLeaseState(response.data);
                currentComponent.onSaveDeal();
                localStorage.setItem('DealRequestType', 'SAVE_DEAL');
                localStorage.setItem('fromDealURL',"MainSummaryTab");
                currentComponent.updateStatus('saveDeal');
            })
            .catch(function (error) {
                console.log("Error received");
                console.log(error);
                // window.alert(error);
            });
            }
            
    }

    onCopyDeal = () => { 
		var currentComponent = this;
        localStorage.setItem('DealRequestType', "COPY_DEAL");
        currentComponent.props.history.push({
            pathname: '/lms/LeaseModel', 
            state:{dealUsageType :currentComponent.state.dealUsage,  onCopyDeal : true}
        });
    }

    onEditDeal = () => {
        var currentComponent = this;
        localStorage.setItem('DealRequestType', "EDIT_DEAL");
        currentComponent.props.history.push({
            pathname: '/lms/LeaseModel', 
            state:{dealUsageType :currentComponent.state.dealUsage,  onEditDeal : true}
        });
    }

    onCreateInvoiceDepreciation = () =>{
        var currentComponent = this;
        localStorage.setItem('DealRequestType', "SAVE_DEAL");
        if(this.unblockNav){
            this.unblockNav();
        }
        currentComponent.props.history.push({
            pathname: '/lms/LeaseModel',
            state: { onCreateInvoiceDepreciation: true, addInDep:true, dealUsageType :currentComponent.state.dealUsage}
        });
    }

    updateDealStatus(newStatus){
        if(newStatus && newStatus !== ''){
            let url = API_ENDPOINT.UPDATE_DEAL_STATUS+'/'+this.state.dealId+'/'+newStatus;

        HttpPutWithoutBody(this, url).then((response) => {
            let dealAuditInfo = newStatus+":"+dealAuditMsg.dealStatusUpdated+newStatus;
            let dealAuditData = [dealAuditInfo];
            this.saveDealAudit(dealAuditData);
            this.setState({dealStatus : newStatus});
            console.log("status updated");
        }).catch((error)=>{
            console.log(error);
            // window.alert(error);
        });
        }
    }

    saveDealAudit(auditInfo){
        let dealAuditData = [];
        let url = API_ENDPOINT.SAVE_DEAL_AUDIT;
        let userName = this.context.name;
        if(!userName){
            userName = "";
        }

        for (let i = 0; i < auditInfo.length; i++) {
            let auditObj = { ...defaultDealAuditObject };

            auditObj.leaseContractId = this.state.dealId;
            auditObj.dealAuditUserId = userName;
            auditObj.auditHistory = auditInfo[i];

            dealAuditData.push(auditObj);
        }

        HttpPost(this, dealAuditData, url).then(

        ).catch((error) => {
            console.log(error);
        })
    }

    onSaveDeal = () => {
        var currentComponent = this;
        var dealType = localStorage.getItem('DealRequestType');
        var newDealStatus = this.state.dealStatus && this.state.dealStatus !=='' ?  this.state.dealStatus : Lease_Constants.LEASE_STATUS_MODELLED ;
        if(dealType == "EDIT_DEAL"){

            if(this.state.workflowType == Lease_Constants.WORKFLOW_PARTIAL_WORKFLOW){
                if(this.state.dealStatus == Lease_Constants.LEASE_STATUS_AWAITING_APPROVED){
                    newDealStatus = Lease_Constants.LEASE_STATUS_MODELLED;
                } else if(this.state.dealStatus == Lease_Constants.LEASE_STATUS_APPROVED ||
                    this.state.dealStatus == Lease_Constants.LEASE_STATUS_SIGNED ||
                    this.state.dealStatus == Lease_Constants.LEASE_STATUS_ACTIVE){
                    newDealStatus = Lease_Constants.LEASE_STATUS_MODELLED;
                } 

            } else if (this.state.workflowType == Lease_Constants.WORKFOW_NEW_WORKFLOW){
                if(this.state.dealStatus == Lease_Constants.LEASE_STATUS_AWAITING_APPROVED){
                    newDealStatus = Lease_Constants.LEASE_STATUS_AWAITING_APPROVED;
                } else if(this.state.dealStatus == Lease_Constants.LEASE_STATUS_APPROVED ||
                    this.state.dealStatus == Lease_Constants.LEASE_STATUS_SIGNED ||
                    this.state.dealStatus == Lease_Constants.LEASE_STATUS_ACTIVE){
                    newDealStatus = Lease_Constants.LEASE_STATUS_AWAITING_APPROVED;
                } 
            } else {
                if(this.state.dealStatus == Lease_Constants.LEASE_STATUS_APPROVED ||
                    this.state.dealStatus == Lease_Constants.LEASE_STATUS_SIGNED ||
                    this.state.dealStatus == Lease_Constants.LEASE_STATUS_ACTIVE){
                    newDealStatus = Lease_Constants.LEASE_STATUS_AWAITING_APPROVED;
                } 
            }
            this.updateDealStatus(newDealStatus);
        } else if(dealType == "COPY_DEAL"){
            newDealStatus = Lease_Constants.LEASE_STATUS_MODELLED;
            this.updateDealStatus(newDealStatus);
        } else if(dealType === "SAVE_DEAL" && this.state.dealStatus === ""){
            newDealStatus = Lease_Constants.LEASE_STATUS_MODELLED;
            this.updateDealStatus(newDealStatus);
        }
    }

    onWorkFlowSelect(workflow){
        this.setState({
            workflowType : workflow
        },() => {
            this.saveDealDBCall();
            // this.openDealApprovals();
        });
    }

    downloadPDF(){
        }
        
    updateStatus(status) {
        // setState.pageStatus 
        console.log("SHow notification");
        console.log(this.state.pendingCount);
        this.setState({pageStatus: status});
    }

    openDealApprovals = () => {
        let dealRequiredData = {
            customerName : this.state.customerName,
            spvName : this.state.spv,
            dealId  : this.state.dealId,
            dealDescription : this.state.dealDescription,
            dealStatus : this.state.dealStatus,
            onlineSolution : this.state.onlineSolution ? this.state.onlineSolution : "",
            offlineSolution : this.state.offlineSolution ? this.state.offlineSolution : "",
            workflowNumber : this.state.currentWorkflowNumber ? this.state.currentWorkflowNumber : 1,
            workflowType : this.state.workflowType,
            dealNumber : this.state.dealNumber ? this.state.dealNumber : "",
            dealCaptainId : this.state.dealCaptainId ? this.state.dealCaptainId : "",
            dealRefNumber : this.state.dealRefNumber ? this.state.dealRefNumber : "",
        };

        this.props.history.push({
            pathname: '/lms/dealApprovals',
            state: { dealData : dealRequiredData}
        })

    }

    goToDealList = ()=>{
        this.props.history.push({
            pathname: '/lms/viewDealList',
        })
    }

    onConfirmUpdateStatus(newStatus){
        if(newStatus===Lease_Constants.LEASE_STATUS_ACTIVE){
            let url=API_ENDPOINT.SET_DEAL_STATUS_ACTIVE+this.state.dealId+'/';
            HttpPutWithoutBody(this,url).then((response)=>{
                if(response.data){
                    this.setState({
                        dealNumber : response.data,
                        dealStatus : Lease_Constants.LEASE_STATUS_ACTIVE,
                    },()=>{
                        let successMsg = 'Deal '+this.state.dealNumber+dealNotificationMessages.dealActiveSuccess;
                        this.setNotification('success',successMsg);
                    })
                }
            }).catch((error)=>{
                console.log(error);
            }).finally(()=>{
                this.closeModal('updateStatus');
                this.closeModal('updateStatusToActive');
            })
        } else{
            this.updateDealStatus(newStatus);
            this.closeModal('updateStatus');
            this.closeModal('updateStatusToActive');
        }
    }

    onDeleteDealConfirm(){
        if (this.state.dealId &&
            (this.state.dealStatus === Lease_Constants.LEASE_STATUS_BLANK ||
                this.state.dealStatus === Lease_Constants.LEASE_STATUS_MODELLED)) {
            let url = API_ENDPOINT.DELETE_DEAL + this.state.dealId;

            HttpDelete(this, null, url).then((response) => {
                this.closeModal('deleteDeal');
                this.goToDealList();
            }).catch((error) => {
                console.log(error);
            })
        } else {
            this.closeModal('deleteDeal');
            this.goToDealList();
        }
    }

    onArchiveClick(){
        if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_APPROVED ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_SIGNED ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_ACTIVE){
                this.openModal('archiveRequest');
            } else {
                this.openModal('archiveConfirm');
            }
    }

    onRequestArchiveDeal(flag){
        let dtoRequestArchival = {
            "requestedBy": this.state.racfData,
            "parentID":this.state.dealId,
            "DealName":this.state.dealNumber ? this.state.dealNumber :this.state.dealRefNumber,
            "userToBeNotified":this.state.dealCaptainRacfID ,
            "dealStatus" : this.state.dealStatus ? this.state.dealStatus :'',

        };
        if(flag == 0){
            dtoRequestArchival.requestedBy = this.state.requestedBy ? this.state.requestedBy : '';
            dtoRequestArchival.respondedBy =this.state.racfData;
        }
        
        let url = API_ENDPOINT.REQUEST_DEAL_ARCHIVE+this.state.dealId+'/'+flag+'/'+this.state.racfData;
        HttpPut(this,dtoRequestArchival, url).then((response) => {
            this.setState({isRequestedForArchived : flag});
            this.closeModal('archiveRequest');
            if(flag===1){
                this.setNotification('success', dealNotificationMessages.archiveRequestSuccess);
            }
        }).catch((error)=>{
            console.log(error);
            this.closeModal('archiveRequest');
        })
    }

    onConfirmArchiveDeal(){
        let confirmArchivalDTO = {
            "requestedBy": this.state.requestedBy ? this.state.requestedBy : '',
            "respondedBy" :this.state.racfData,
            "parentID":this.state.dealId,
            "DealName":this.state.dealNumber ? this.state.dealNumber :this.state.dealRefNumber,
            "userToBeNotified" : this.state.dealCaptainRacfID,
            "dealStatus" : this.state.dealStatus ? this.state.dealStatus :'',

        }
        let archiveURL = API_ENDPOINT.ARCHIVE_DEAL+this.state.dealId;
        HttpDelete(this, confirmArchivalDTO, archiveURL).then(()=>{
            // this.updateDealStatus(Lease_Constants.LEASE_STATUS_ARCHIVED); // Not updating this as we have Re-instate functionality to get the deal back to previous status.
            this.onRequestArchiveDeal(0);
            this.closeModal('archiveConfirm');
            this.goToDealList();
        }).catch((error) => {
            console.log(error);
            this.closeModal('archiveConfirm');
        })
    }

    onRejectArchiveDeal(){
        this.onRequestArchiveDeal(0);
        this.setNotification('info', dealNotificationMessages.archiveRejectSuccess);
        this.closeModal('rejectArchiveDeal');
    }

    setNotification(type, message){
        let notificationObj = {
            showNotification : true,
            notificationType : type,
            notificationMsg : message,
        }
        this.setState({notification : notificationObj},()=>{
            window.scrollTo(0, 0);
        });
    }

    hideNotification(){
        let notificationObj = {
            showNotification : false,
            notificationType : '',
            notificationMsg : '',
        }
        this.setState({notification : notificationObj});
    }

    unsavedChangesConfirm(){
        this.closeModal('unsavedChangesWarning');
        if(this.unblockNav){
            this.unblockNav();
        }
        
        if(this.state.restrictedPath && this.state.restrictedPath.pathname){
            this.props.history.push({
                pathname : this.state.restrictedPath.pathname,
                state: this.state.restrictedPath.state,
            })
        }
    }

    reinstateDeal(){
        let url = API_ENDPOINT.UPDATE_ARCHIVED_DEAL_FLAG+'0';
        let dealsToReinstate = [this.state.dealId];
        
        HttpDelete(this, dealsToReinstate, url).then((response)=>{
            this.closeModal('reinstateDeal');
            this.setNotification('success', dealNotificationMessages.reinstateDealSuccess);
            this.fetchDeal(this.state.dealId);
        }).catch((error) => {
            console.log(error);
        })
    }

    openModal(modalName){
        if(modalName==='updateStatus'){
            this.setState({isUpdateStatusModalOpen : true});
        } else if(modalName==='updateStatusToActive'){
            this.setState({isUpdateActiveModalOpen : true});
        } else if(modalName==='deleteDeal'){
            this.setState({isDeleteDealModal : true});
        }else if(modalName==='archiveConfirm'){
            this.setState({archiveConfirmModal : true});
        }else if(modalName==='archiveRequest'){
            this.setState({archiveRequestModal : true});
        }else if(modalName==='rejectArchiveDeal'){
            this.setState({rejectArchiveModal : true});
        }else if(modalName==='unsavedChangesWarning'){
            this.setState({unsavedChangesModal : true});
        }else if(modalName==='reinstateDeal'){
            this.setState({reinstateModal : true});
        }
    }

    closeModal(modalName){
        if(modalName==='updateStatus'){
            this.setState({isUpdateStatusModalOpen : false});
        } else if(modalName==='updateStatusToActive'){
            this.setState({isUpdateActiveModalOpen : false});
        }else if(modalName==='deleteDeal'){
            this.setState({isDeleteDealModal : false});
        }else if(modalName==='archiveConfirm'){
            this.setState({archiveConfirmModal : false});
        }else if(modalName==='archiveRequest'){
            this.setState({archiveRequestModal : false});
        }else if(modalName==='rejectArchiveDeal'){
            this.setState({rejectArchiveModal : false});
        }else if(modalName==='unsavedChangesWarning'){
            this.setState({unsavedChangesModal : false});
        }else if(modalName==='reinstateDeal'){
            this.setState({reinstateModal : false});
        }
    }

    render(){
        console.log(this.state.permissionData)
        console.log(this.state.dealCaptainRacfID)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btnReinstateDisable = true;
        var btnUpdateStatus = true;
        var btnCopyDealdisable = true;
        var btnEditDealDisable = true;
        var btnDeleteDealdisable = true;
        var manageApprovalBtnDisable = true;
        var saveDealBtn = true;
        var archiveDealBtn  = true;
        var btnAllowArchive = true;
        var btnDontAllowArchive = true;
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Copy") { 
                    btnCopyDealdisable = false;
                }
            }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Edit") { 
                    btnEditDealDisable = false;
                }
            }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Delete") { 
                    btnDeleteDealdisable = false;
                }
            }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Save") { 
                    saveDealBtn = false;
                }
            }
            for (var i = 0; i < datalen; i++) { 
                if (perData[i] == "Deal_Archive_Request") { 
                    archiveDealBtn = false;
                }
                if (perData[i] == "Deal_Update_Status") { 
                    btnUpdateStatus = false;
                }
                if (perData[i] == "Deal_Reinstate") { 
                    btnReinstateDisable = false;
                    if(this.state.memberOfDetail.indexOf("BusinessUser") > 0) {
                        if(this.state.dealCaptainRacfID == this.state.racfData){
                            btnReinstateDisable = false;
                        }
                        else{
                            btnReinstateDisable = true;
                        }
                    }
                }
                
            }
            
            if(this.props.location.state.leaseResponseDataState != undefined){
                if(this.props.location.state.leaseResponseDataState.requestedBy != undefined 
                && this.props.location.state.leaseResponseDataState.requestedBy != null){
                    if(this.props.location.state.leaseResponseDataState.requestedBy == this.state.racfData){
                        btnAllowArchive = true;
                        btnDontAllowArchive = true;
                    }
                    else{
                        for (var i = 0; i < datalen; i++) { 
                            if (perData[i] == "Deal_Archive_Approve") {
                                btnAllowArchive = false;
                                if(this.state.memberOfDetail.indexOf("BusinessUser") > 0) {
                                    if(this.state.dealCaptainRacfID == this.state.racfData){
                                        btnAllowArchive = false;
                                    }
                                    else{
                                        btnAllowArchive = true;
                                    }
                                }
                                // loggen in user with requestedBy
                                
                            }
                            if (perData[i] == "Deal_Archive_Reject") { 
                                // loggen in user with requestedBy
                                btnDontAllowArchive = false;
                                if(this.state.memberOfDetail.indexOf("BusinessUser") > 0) {
                                    if(this.state.dealCaptainRacfID == this.state.racfData){
                                        btnDontAllowArchive = false;
                                    }
                                    else{
                                        btnDontAllowArchive = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            
            
        
        
        //this.fetchResultData();
        let isDealApproved = false;
        if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_APPROVED ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_SIGNED ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_ACTIVE){
            isDealApproved = true;
        }

        let isDeleteVisible = false;
        if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_BLANK ||
            this.state.dealStatus === Lease_Constants.LEASE_STATUS_MODELLED){
            isDeleteVisible = true;
        }

        let saveButton;
         if(this.state.saveLease && this.state.dealUsage == Lease_Constants.DEAL_USAGE_DEPRECIATION){
            saveButton = <button type="button" disabled={this.state.isSaveSuccessful || saveDealBtn} class="zb-button zb-button-primary main_summary_btn" style={{whiteSpace : 'nowrap'}} 
            data-toggle="modal" data-target="#depreciationSelect"
            >Save deal</button>
        } else if(this.state.saveLease && this.state.dealUsage == Lease_Constants.DEAL_USAGE_INVOICING){
            saveButton = <button type="button" disabled={this.state.isSaveSuccessful || saveDealBtn} class="zb-button zb-button-primary main_summary_btn" style={{whiteSpace : 'nowrap'}}
            data-toggle="modal" data-target="#invoicingSelect"
            >Save deal</button>
        } else if(this.state.saveLease){
            saveButton = <button type="button" disabled={this.state.isSaveSuccessful || saveDealBtn} class="zb-button zb-button-primary main_summary_btn" style={{whiteSpace : 'nowrap'}}
            onClick = {this.saveDealDBCall.bind(this)}
            >Save deal</button>
        } else {
            saveButton = <button type="button" disabled={this.state.isSaveSuccessful || saveDealBtn } class="zb-button zb-button-primary main_summary_btn" style={{whiteSpace : 'nowrap'}}
            // onClick = {this.saveDealDBCall.bind(this)}
            data-toggle="modal" data-target="#workflowSelect"
            >Save deal</button>
        }

        let updateStatusButton;
        if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_APPROVED){
            updateStatusButton = <button type="button" class="zb-button zb-button-primary main_summary_btn" 
            style={{whiteSpace : 'nowrap'}} disabled={btnUpdateStatus} onClick={this.openModal.bind(this,'updateStatus')}>Update status</button>
        } else if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_SIGNED){
            updateStatusButton = <button type="button" class="zb-button zb-button-primary main_summary_btn" 
            style={{whiteSpace : 'nowrap'}} disabled={btnUpdateStatus} onClick={this.openModal.bind(this,'updateStatusToActive')}>Update status</button>
        } else if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_ACTIVE){
            updateStatusButton = null;
        }

        let statusText;
        if(this.state.isArchived===1){
            statusText=<label class="dealDescription_label" style={{marginLeft: "10px"}}> {Lease_Constants.LEASE_STATUS_ARCHIVED}</label>;
        } else {
            if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_ACTIVE){
                statusText=<label class="dealDescription_label" style={{marginLeft: "10px", color:'#429448'}}> {this.state.dealStatus}</label>;
            } else if(this.state.dealStatus === Lease_Constants.LEASE_STATUS_AWAITING_APPROVED){
                statusText=<div style={{verticalAlign:'middle', display:'flex', float:'right', marginLeft:'10px'}}>
                    <Icon name="clock-small" size='small' title="Awaiting approval"/>
                    <label class="dealDescription_label" style={{color:'#666666'}}> {this.state.dealStatus}</label>
                </div>
            } else{
                statusText=<label class="dealDescription_label" style={{marginLeft: "10px"}}> {this.state.dealStatus}</label>;
            }
        }

        return (<div className="background_mainSummary">
            
            {this.state.loadSuccess ? 
            <div className="summary_container">
            {/* //<form class="summaryForm"> */}
            <div className="dealMainSummary" style ={{marginLeft:'-12px'}}>
                <div className="dealBackButton">
                    <Icon name="chev-left-xsmall" size='xsmall' title="Back to deal"/>
                    <span onClick={this.goToDealList.bind(this)} >All deals</span>
                </div>
            </div>
            
            {this.state.notification.showNotification ?
                    <div className="dealSuccessMessage">
                        <Notification status={this.state.notification.notificationType} size="medium">
                            {this.state.notification.notificationMsg}
                        </Notification>
                    </div>
                    : null
            }
             
            {this.state.pageStatus == 'docUploadSuccess' ?
                    <Notification className="notification_header_deal" status='success' size='large' title='Your document has been uploaded'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'docDeleteSuccess' ?
                    <Notification className="notification_header_deal" style={{ width: '1244px' }} status='success' size='large' title='Your request for deletion has been sent'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */} 
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'docDeleteCancel' ?
                    <Notification className="notification_header_deal" style={{ width: '1244px' }} status='success' size='large' 
                        title='Your request for deletion has been cancelled'>
                       {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */} 
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'docDeletedFailed' ?
                    <Notification className="notification_header_deal" status='error' style={{ width: '1244px' }} size='large' title='Your request for deletion has been rejected'>
                            {this.state.failureMessage} {this.state.rejectionReason ? <span style={{ wordBreak: 'break-all' }}>Reason for rejection: {this.state.rejectionReason}</span> : null}
                    </Notification>
                     : null
                }
                {this.state.pageStatus == 'saveDeal' ?
                <Notification className="dealSuccessMessage" status='success' size='medium'>
                    Your deal has been saved
                    </Notification>
                     : null
                }
                {this.state.pageStatus == 'docDeletedSuccess' ?
                    <Notification className="notification_header_deal" style={{ width: '1244px' }} status='success' size='large' title='Your request for deletion has been approved'>
                        {this.state.confirmMessage}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docDeletedSuccess1' ?
                    <Notification className="notification_header_deal" style={{ width: '1244px' }} status='success' size='large' title='Your document has been deleted'>
                        {this.state.confirmMessage}
                    </Notification>
                    : null
                }

                {this.state.deleteStatus == 'approverDocDeleted' ?
                    <Notification className="notification_header_deal" style={{ width: '1244px' }} status='success' size='large' title='Deletion request has been approved'>
                        The document {this.state.deletedDocName} has been deleted. Notification email has been sent to {this.state.docUserName}.
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docPendingApproval' && this.state.pendingCount > 0 ?
                    <Notification className="notification_header_deal" status='warning' style={{ width: '1244px' }} size='large' title={this.state.pendingCount + ' Document deletion request pending your approval'}>
                        Please review the documents highlighted in yellow and approve/reject deletion request accordingly.
                    </Notification>
                    : null
                }
                    {this.state.pageStatus == 'docPendingApproval' && this.state.uploadPendingCount > 0 ?
                        <Notification className="notification_header_deal" status='warning' style={{ width: '1244px' }} size='large' title={this.state.uploadPendingCount + ' Document upload request pending your approval'}>
                            Please review the documents highlighted in yellow and approve/reject upload request accordingly.
                    </Notification>
                        : null
                    }
                {this.state.pageStatus == 'docDeleteRejected' ?
                    <Notification className="notification_header_deal" status='success' style={{ width: '1244px' }} size='large' title='Deletion request has been rejected'>
                        The document {this.state.deletedDocName} has not been deleted.
                    </Notification>
                    : null
                    }
                    {this.state.pageStatus == 'docUploadApproved' ?
                        <Notification className="Confirmation_header_new" status='success' style={{ width: '1244px' }} size='large' title='Document upload request has been approved.'>
                            The upload of document {this.state.deletedDocName} has been approved. A notification email has been sent to {this.state.docUserName}.
                    </Notification>
                        : null
                    }
                    {this.state.pageStatus == 'docUploadRejected' ?
                        <Notification className="Confirmation_header_new" status='error' style={{ width: '1244px' }}
                            size='large' title='Your request for document upload has been rejected'>
                            The request to upload document {this.state.deletedDocName} has been rejected by {this.state.approverName}. <br></br>
                            <span style={{ wordBreak: 'break-all' }}>Reason for rejection: {this.state.rejectionReason}</span>
                        </Notification>
                        : null
                    }


                {this.state.isUpdateStatusModalOpen ? 
                <UpdateDealStatusModal 
                    open={this.state.isUpdateStatusModalOpen}
                    onCancel={this.closeModal.bind(this,'updateStatus')}
                    onConfirm={this.onConfirmUpdateStatus.bind(this)}/> 
                    : null
                }

                {this.state.isUpdateActiveModalOpen ? 
                <GeneralDealApprovalModal
                    title="Update status"
                    confirmText='Yes, update status'
                    msgAccessor='updateStatusToActive'
                    open={this.state.isUpdateActiveModalOpen}
                    onConfirm={()=>this.onConfirmUpdateStatus(Lease_Constants.LEASE_STATUS_ACTIVE)}
                    onCancel={this.closeModal.bind(this,'updateStatusToActive')}
                />
                : null
                }

                {this.state.archiveConfirmModal ?
                    <GeneralDealApprovalModal
                        title="Archive deal"
                        confirmText='Yes, archive deal'
                        msgAccessor='archiveDealConfirmMsg'
                        open={this.state.archiveConfirmModal}
                        onConfirm={this.onConfirmArchiveDeal.bind(this)}
                        onCancel={this.closeModal.bind(this, 'archiveConfirm')}
                    />
                    : null
                }

                {this.state.archiveRequestModal ?
                    <GeneralDealApprovalModal
                        title="Archive deal"
                        confirmText='Yes, request archival'
                        msgAccessor='archiveDealRequestMsg'
                        open={this.state.archiveRequestModal}
                        onConfirm={this.onRequestArchiveDeal.bind(this, 1)}
                        onCancel={this.closeModal.bind(this, 'archiveRequest')}
                    />
                    : null
                }

                {this.state.rejectArchiveModal ?
                    <GeneralDealApprovalModal
                        title="Reject archive request"
                        confirmText='Yes, reject archival'
                        msgAccessor='rejectArchiveMsg'
                        open={this.state.rejectArchiveModal}
                        onConfirm={this.onRejectArchiveDeal.bind(this)}
                        onCancel={this.closeModal.bind(this, 'rejectArchiveDeal')}
                    />
                    : null
                }
                
                {this.state.isDeleteDealModal ? 
                <GeneralDealApprovalModal
                    title="Delete deal"
                    confirmText='Yes, delete deal'
                    msgAccessor='deleteDealMsg'
                    open={this.state.isDeleteDealModal}
                    onConfirm={this.onDeleteDealConfirm.bind(this)}
                    onCancel={this.closeModal.bind(this,'deleteDeal')}
                />
                : null
                }

                {this.state.unsavedChangesModal ?
                <UnsavedChangesWarningModal 
                    open={this.state.unsavedChangesModal}
                    onConfirm={this.unsavedChangesConfirm.bind(this)}
                    onCancel={this.closeModal.bind(this,'unsavedChangesWarning')}
                />
                : null
                }

                {this.state.reinstateModal ?
                    <GeneralDealApprovalModal
                        title="Reinstate deal"
                        confirmText='Yes, reinstate'
                        msgAccessor='dealReinstateMsg'
                        open={this.state.reinstateModal}
                        onConfirm={this.reinstateDeal.bind(this)}
                        onCancel={this.closeModal.bind(this, 'reinstateDeal')}
                    />
                    : null
                }

            <div className="dealApprovalsPage" style ={{ padding:'0px', marginLeft:'-12px'}}>
                <div className="dealTitleHeader">
                    <div><label className="modelTitle">{'Deal - '+(this.state.dealNumber ? this.state.dealNumber : '')}</label></div>
                    {this.state.customerName ? <div><label className="modelTitle customerName">{this.state.customerName}</label></div> : null}
                    {this.state.spv ? <div><label className="modelTitle spvName">{this.state.spv}</label></div> : null}
                    <div>
                        <label class="viewModel">{'Deal number '+this.state.dealRefNumber + (this.state.dealDescription ? ' | '+this.state.dealDescription : '')}</label>
                        <div style ={{float:'right', marginRight:'5%'}}>
                        <label class="status_label" style={{fontWeight:'400', marginLeft:'0px'}}>Status: </label>
                        {statusText}
                        {/* <label class="dealDescription_label" style={{marginLeft: "10px"}}> {this.state.dealStatus}</label> */}
                    </div>
                    </div>
                </div>
            </div>
        
            <LeaseParentSummaryTab leaseParent={this.state.leaseParent} setDealHeaderData={this.setDealHeaderData.bind(this)} dealUsageType={this.state.dealUsage} updateStatus = {this.updateStatus.bind(this)} ></LeaseParentSummaryTab>
            
            {this.state.isArchived === 1 ? 
            <div class="summary-footer">
                <button type="button" class="zb-button zb-button-primary main_summary_btn" style={{whiteSpace : 'nowrap'}} disabled={btnReinstateDisable} onClick={this.openModal.bind(this,'reinstateDeal')}>Reinstate</button>
                <div className="dealLinks">
                    <div className={"export_btn " + (btnDeleteDealdisable ? 'disabledLabel' : '')} style={{verticalAlign:'middle',display:'flex'}}>
                        <Icon name="trash-small" size='small' title="Delete deal"/>
                        <label style={{ marginLeft: '5px'}} className="export-to-excel" 
                        onClick={this.openModal.bind(this,'deleteDeal')}> Delete deal</label>
                    </div>
                    <div className={"export_btn " + (btnCopyDealdisable ? 'disabledLabel' : '')} style={{verticalAlign:'middle',display:'flex'}}>
                        <Icon name="subscription-small" size='small' title="Copy deal"/>
                        <label style={{ marginLeft: '5px', }} className="export-to-excel" 
                        onClick = {this.onCopyDeal.bind(this)}> Copy deal</label>
                    </div>
                </div>
            </div> 
            : 
            <div class="summary-footer">
                {this.state.isRequestedForArchived === 1 ? 
                <div>
                    <button type="button" disabled={btnAllowArchive} class="zb-button zb-button-primary main_summary_btn" style={{whiteSpace : 'nowrap'}}
                     onClick = {this.openModal.bind(this, 'archiveConfirm')} >Archive</button>
                    <button type="button" disabled={btnDontAllowArchive} class="zb-button zb-button-secondary main_summary_btn" style={{background :'transparent', whiteSpace : 'nowrap'}}
                    onClick = {this.openModal.bind(this, 'rejectArchiveDeal')}>Don't archive</button>
                </div> 
                : 
                <div>
                    {isDealApproved ? updateStatusButton : saveButton }
                    
                    <button type="button" class="zb-button zb-button-secondary main_summary_btn" style={{background :'transparent', whiteSpace : 'nowrap'}}
                     onClick = {this.openDealApprovals.bind(this)} disabled={this.state.isUnsavedChanges} >Manage approval</button>
                    <button type="button" disabled={btnEditDealDisable} class="zb-button zb-button-secondary main_summary_btn" style={{background :'transparent', whiteSpace : 'nowrap'}}
                    onClick = {this.onEditDeal.bind(this)}>Edit deal</button>
                    
                    <div className="dealLinks">
                        {isDeleteVisible ? 
                            <div className={"export_btn " + (btnDeleteDealdisable ? 'disabledLabel' : '')} style={{verticalAlign:'middle',display:'flex'}}>
                                {/* <img src={exportImage} size='small'  /> */}
                                <Icon name="trash-small" size='small' title="Delete deal"/>
                                <label style={{ marginLeft: '5px'}} className="export-to-excel" onClick={this.openModal.bind(this,'deleteDeal')}> Delete deal</label>
                            </div> 
                        : null }
                        
                        <div className={"export_btn " + (archiveDealBtn ? 'disabledLabel' : '')} >
                            <img src={exportImage} size='small'/>
                            <label style={{ marginLeft: '5px' }} className="export-to-excel"  onClick={this.onArchiveClick.bind(this)}> Archive deal</label>
                        </div>
                        <div className={"export_btn " + (btnCopyDealdisable ? 'disabledLabel' : '')} style={{verticalAlign:'middle',display:'flex'}}>
                            {/* <img src={importImage} size='small' /> */}
                            <Icon name="subscription-small" size='small' title="Copy deal"/>
                            <label style={{ marginLeft: '5px', }} className="export-to-excel" 
                            onClick = {this.onCopyDeal.bind(this)}> Copy deal</label>
                        </div>
                        
                    </div>
                </div>
                }
            </div>}
            <PopupApprovalWF headerTitle="Save deal" datatarget="workflowSelect"
                onClick={this.onWorkFlowSelect.bind(this)} openDialog ={this.state.dialogStatus} headerbody = ""
                buttontext1="Save deal" buttontext2="Cancel"/>
            <PopupInvDep headerTitle="Saving depreciation deal" datatarget="depreciationSelect"
                        headerbody="The deal you  are trying to save is depreciation only, do you want to model a corresponding invoice model too?" 
                        buttontext1="Yes" buttontext2="No" 
                        onClick={this.onCreateInvoiceDepreciation} OnClickButton2 = {this.saveDealDBCall.bind(this)}
                         />
            <PopupInvDep headerTitle="Saving invoicing deal" datatarget="invoicingSelect"
                        headerbody="The deal you  are trying to save is invoice only, do you want to model a corresponding depreciation model too?" 
                        buttontext1="Yes" buttontext2="No" 
                        onClick = {this.onCreateInvoiceDepreciation} OnClickButton2 = {this.saveDealDBCall.bind(this)}
                         />
    
            </div> : null}
            
        </div>);
    }
}

export default withRouter(mainSummaryTabsPage);
