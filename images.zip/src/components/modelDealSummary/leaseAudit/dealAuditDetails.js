import React from 'react';
import ReactTable from 'react-table';
import { connect } from "react-redux";
import 'react-table/react-table.css';
import { leaseAuditData, Lease_Constants } from '../../../models/LeaseConstants';
import { HttpGet } from '../../../services/api.js';
import { API_ENDPOINT } from '../../../config/config.js';
import { withRouter } from 'react-router-dom';
import moment from 'moment';
import Pagination from '../../../commonComponents/pagination.js';

class DealAuditDetails extends React.Component{
    constructor(props){
        super(props);
            this.state = {
                columns : [],
                auditRecords : [] ,
                pageSize: '20',
                dateFormat: 'DD/MM/YYYY hh:mm:ss A',
            }
        }

        componentWillReceiveProps(props){
            let dateFormat='DD/MM/YYYY hh:mm:ss A'
            if(props.locale){
                if(props.locale==='sv'){
                    dateFormat='YYYY-MM-DD hh:mm:ss A'
                }
            }
            this.setState({dateFormat : dateFormat});
        }

        componentWillMount(){
            this.setState({columns : this.generateColumns()});
            this.getAuditDealsData();                
        }       
       
        getDateCell(row){
            let date= moment(row.value).format(this.state.dateFormat);
            return(
                <div style={{ marginLeft:'5px', marginRight:'5px', textAlign: "center", fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                    {date}
                </div>
            )
        }

        getHistoryCell(row){
            let history=row.value.split(':');
            let status ='';
            let record ='';
            let statusType = 'Normal';
            if(history && history.length > 1){
                status=history[0];
                record=history[1];
                if (status === Lease_Constants.LEASE_STATUS_ACTIVE ||
                    status === Lease_Constants.LEASE_STATUS_CONFIRMED ||
                    status === Lease_Constants.LEASE_STATUS_APPROVED ||
                    status === Lease_Constants.LEASE_STATUS_SIGNED) {
                    statusType = 'Success';
                } else if (status === Lease_Constants.LEASE_STATUS_REJECTED ||
                    status === Lease_Constants.LEASE_STATUS_ARCHIVED) {
                    statusType = 'Reject';
                }
            }else {
                record= history[0];
            }
            return(
                <div>
                    {status !=='' ? <div className={'record'+statusType} >{status}</div> : null}
                    <div>{record}</div>
                </div>
            )
        }

        generateColumns(){
            const columns = [{
                id: 'auditTime',
                Header: 'Date',
                accessor: 'dealAuditTime',
                headerClassName: 'periodSummaryheader',
                filterable: false,
                className: 'periodSummary_cell',
                width: 220,
                Cell: this.getDateCell.bind(this),
            },
            {id: 'user',
                Header: 'User',
                accessor: 'dealAuditUserId',
                headerClassName: 'periodSummaryheader',
                filterable: false,
                className: 'periodSummary_cell',
                Cell: row => <div style={{ textAlign: "center", fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
                width:160
                },
            {id: 'auditHistory',
                Header: 'History',
                accessor: 'auditHistory',
                headerClassName: 'periodSummaryheader',
                filterable: false,
                className: 'periodSummary_cell',
                Cell: this.getHistoryCell.bind(this),
                minWidth:200
                }]                                      
            return columns;
        }
    
    getAuditDealsData() {
        let currentComponent = this;
        if(this.props.leaseParentId != null && this.props.leaseParentId !==''){
            let id = this.props.leaseParentId;
            let endPoint = API_ENDPOINT.GET_AUDIT_DETAILS_FOR_DEAL + '/' + id;
            let output1 = HttpGet(currentComponent, endPoint).then(function (response) {
                currentComponent.setState({ auditRecords: response.data });
            }).catch(function (error) {
                    console.log("Error received");
                    console.log(error);
                }) 
        }
    }

    
    handleSelectEventChange(event){
        this.setState({ pageSize: event.target.value });
    }

    render(){
        return (<div  className="form-group row colour_white" >
                <ReactTable
                    data={this.state.auditRecords}
                    columns={this.state.columns}               
                    className='-striped -highlight summaryTable auditdeal'
                    headerClassName= 'periodSummaryheader'
                    defaultPageSize={20}
                    showPagination={true}     
                    showPaginationTop={false}
                    showPaginationBottom={true}
                    showPageSizeOptions = {true}
                    defaultSortDesc = {false}
                    PaginationComponent={Pagination}
                    previousText = 'Previous'
                    nextText = 'Next'
                    loadingText = 'Loading...'
                    pageText= 'Page'
                    ofText= 'of'
                    rowsText= 'rows'     
                    minRows={1}
                />
                <div>
             {/* remove unused CSS */}
         <span class="select-wrap -pageSizeOptions select_recordSummary" style= {{marginRight:'15px' }}>
             <span className="select_pageSummary">Per page</span>
        <select id = "summaryId" aria-label="rows per page"
        defaultValue={this.state.pageSize} 
        onChange ={this.handleSelectEventChange.bind(this)} className="select_rowSummary">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="60">60</option>
            <option value="80">80</option>
            <option value="100">100</option>
        </select>
        </span>
        </div>                                     
</div>
        )
    }
}

const mapStateToProps = state => {
    return {
         locale: state.dataFormat,
    }
    
};

DealAuditDetails = connect(mapStateToProps)(DealAuditDetails);

export default withRouter (DealAuditDetails);

