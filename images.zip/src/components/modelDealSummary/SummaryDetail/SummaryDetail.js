import React from 'react';
import '../../../index.css';
import Accordion from '@zambezi/sdk/accordion';
import './summaryDetail.css';
import OutputLabel from '../../../commonComponents/OutputLabel';
import moment from 'moment';
import {roundedDecimal, precise} from '../../../utils/LeaseUtils.js';
import OptionSummaryGridTL from './optionSummaryGridTL';
import '../../../components/modelDealSummary/leaseDataModelTimeline/periodSummary.css'

class summaryDetail extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            setSummaryDealview: true,
            leaseData:null,
        }
        this.precise = precise;
        this.roundedDecimal = roundedDecimal;
        
    }

    componentWillMount() {
        // var leaseContract = localStorage.getItem('leaseResponseData');
        var leaseContract = this.props.dataFromParent;
        var stringdata = JSON.stringify(leaseContract);
        // window.alert('stringdata = ' + stringdata);
        if(leaseContract !== null){
            this.generateData(leaseContract);
            // this.setState({leaseData:leaseContract});
        }

    }

    componentWillReceiveProps(props){
        var leaseContract = props.dataFromParent;
        var stringdata = JSON.stringify(leaseContract);
        // window.alert('stringdata = ' + stringdata);
        if(leaseContract !== null){
            this.generateData(leaseContract);
            // this.setState({leaseData:leaseContract});
        }
    }


    generateData(leaseContract){
        console.log("lease contract");
        console.log(leaseContract);
        if (leaseContract !== null && leaseContract !== undefined){

            var modelDescription = leaseContract.modelType + ' , ' + leaseContract.paymentTerms;
            var leaseState = {
                'leaseType':leaseContract.leaseType,
                'modelType':leaseContract.modelType,
                'paymentTerms':leaseContract.paymentTerms,
                'contractDescription':leaseContract.contractDescription,
                'tenor':leaseContract.tenor,
                'spv':leaseContract.spv,
                'lossGivenDefault':leaseContract.lossGivenDefault,
                'tlp':leaseContract.tlp,
                'residualVal':this.precise(leaseContract.residualVal),
                'returnsModel':leaseContract.returnmodel,
                'vacantPossesionValue':this.precise(leaseContract.vacantPossesionValue),
                'leaseStartDate':leaseContract.leaseStartDate,
                'leaseEndDate':leaseContract.leaseEndDate,
                'invoicingFrequencyPerAnnum':leaseContract.invoicingFrequencyPerAnnum,
                'fxRate':leaseContract.fxRate,
                // 'franchiseName':leaseData.customerName,
                'firstPeriodReleaseFee':this.precise(leaseContract.firstPeriodReleaseFee),
                'currency':leaseContract.currency,
                'contractType':leaseContract.contractType,
                'acquistionCost':this.precise(leaseContract.acquistionCost),
                'firstYearLeasePayment':this.precise(leaseContract.firstYearLeasePayment),
                'firstPeriodYield':this.roundedDecimal(leaseContract.firstPeriodYield),
                'marginAvg':this.roundedDecimal(leaseContract.marginAvg),
                'refRateAvg':this.roundedDecimal(leaseContract.refRateAvg),
                'tlpAvg':this.roundedDecimal(leaseContract.tlpAvg),
                'rvByBv':this.roundedDecimal(leaseContract.rvByBv),
                'rvByRlv':this.roundedDecimal(leaseContract.rvByRlv),
                'rvByVpv':this.roundedDecimal(leaseContract.rvByVpv),
                'masterGradingScale':leaseContract.masterGradingScale,
                'counterPartyCreditRisk':this.precise(leaseContract.counterPartyCreditRisk),
                'reLetValue':leaseContract.reLetValue,
                'customerName':leaseContract.customerName,
                'dealType':leaseContract.dealType,
                'modelDescription':modelDescription,
                'minLeasePayment':this.precise(leaseContract.leaseModels[0].ead),
                'nominalMinLeasePay':this.precise(leaseContract.nominalMinLeasePay),
                'irrIncRes':this.roundedDecimal(leaseContract.irrIncludingResidual),
                'NPVByRLV':this.roundedDecimal(leaseContract.leaseModels[0].npvByRlv),
                'irr':this.roundedDecimal(leaseContract.irr),
                'day1Rwa':this.precise(leaseContract.leaseModels[0].day1Rwa),
                'cpbRoe':leaseContract.annualLeaseModel ? this.roundedDecimal(leaseContract.annualLeaseModel[0].cpbRoe) :null,
                'ioRwa': leaseContract.annualLeaseModel ? this.roundedDecimal(leaseContract.annualLeaseModel[0].ioRwa): null,

            //     Min lease payments NPV = “EAD” for first period
            // Nominal of minimum lease payment = “nominalMinLeasePay” in LeaseContract
            // IRR including residual = “irrIncludingResidual” in LeaseContract
            // NPV/RLV = npvByRlv for first period
            // IRR = “irr” in LeaseContract


            }

            this.setState({leaseData:leaseState});
        }
    }

    selectSummaryType(selectSummaryDataType) {
        if (selectSummaryDataType === 'dealView') {
            this.setState({ setSummaryDealview: true });
        } else {
            this.setState({ setSummaryDealview: false });
        }
        return true;
    }

    render() {
    return <div>
                <div class='zb-container'>

                    <div class="form-group row colour_white">
                        <div class= "zb-columns" style={{borderBottom: '1px solid #C9C6C6'}}>
                            <div class="summaryDetTwoWayBnt">
                                <div class="btn-group">
                                    <button type="button" className={"btn btn-primary standard_twoway_btn " + (this.state.setSummaryDealview ? 'twoWayButton_selected' : 'twoWayButton_notselected')} onClick={this.selectSummaryType.bind(this, 'dealView')}>Deal view</button>
                                    <button type="button" className={"btn btn-primary standard_twoway_btn " + (!this.state.setSummaryDealview ? 'twoWayButton_selected' : 'twoWayButton_notselected')} onClick={this.selectSummaryType.bind(this, 'spvView')}>SPV view</button>
                               
                                </div>
                            </div>
                        </div> {/*  // end zb-columns*/}

                        <div class='zb-columns' style={{marginTop:'20px'}}>
                            <div class=".zb-column-is-6 col-sm-6" >

                                <label>Overview</label> <br/>
                                <OutputLabel fieldTitle="Customer" value={this.state.leaseData ? this.state.leaseData.customerName : null} />
                                <OutputLabel fieldTitle="MGS" value={this.state.leaseData ? this.state.leaseData.masterGradingScale : null} />                           
                                <OutputLabel fieldTitle="SPV" value={this.state.leaseData ? this.state.leaseData.spv : null} />        
                                <OutputLabel fieldTitle="Model type / payment terms" value={this.state.leaseData ? this.state.leaseData.modelDescription : null} />
                                <OutputLabel fieldTitle="Lease type" value={this.state.leaseData ? this.state.leaseData.leaseType : null} />
                                <OutputLabel fieldTitle="Deal type" value={this.state.leaseData ? this.state.leaseData.dealType : null} />
                                <OutputLabel fieldTitle="Acquisition cost" type={'currency'} value={this.state.leaseData ? this.state.leaseData.acquistionCost : null} />
                                <OutputLabel fieldTitle="Total acquisition cost" type={'currency'} value={this.state.leaseData ? this.state.leaseData.acquistionCost : null} />
                                <OutputLabel fieldTitle="Counterparty credit risk" type={'currency'} value= {this.state.leaseData ? this.state.leaseData.counterPartyCreditRisk : null} />
                                <OutputLabel fieldTitle="Residual value" type={'currency'} value={this.state.leaseData ? this.state.leaseData.residualVal : null} />
                                <OutputLabel fieldTitle="Lease start" type={'date'} value={this.state.leaseData ? this.state.leaseData.leaseStartDate : null} />
                                <OutputLabel fieldTitle="Lease end" type={'date'} value={this.state.leaseData ? this.state.leaseData.leaseEndDate : null} />
                                <OutputLabel fieldTitle="Year 1 lease payment" type={'currency'} value={this.state.leaseData ? this.state.leaseData.firstYearLeasePayment : null} />
                                <OutputLabel fieldTitle="Period 1 lease payment" type={'currency'} value={this.state.leaseData ? this.state.leaseData.firstPeriodReleaseFee : null} />
                                {/*<OutputLabel fieldTitle="Option" value="" />*/}

                            </div> {/*.zb-column-is-6 */}

                            <div className=".zb-column-is-6 col-sm-6">

                                <label>Metrics</label> <br/>

                                <OutputLabel fieldTitle="Yield" value={this.state.leaseData ? this.state.leaseData.firstPeriodYield : null} postFixData="%" />
                                <OutputLabel fieldTitle="Margin average" value={this.state.leaseData ? this.state.leaseData.marginAvg : null} postFixData="%"/>
                                <OutputLabel fieldTitle="Reference rate average" value={this.state.leaseData ? this.state.leaseData.refRateAvg : null} postFixData="%"/>
                                <OutputLabel fieldTitle="TLP average" value={this.state.leaseData ? this.state.leaseData.tlpAvg : null} postFixData="%" />

                                <OutputLabel fieldTitle="CPB RoE" value={this.state.leaseData ? this.state.leaseData.cpbRoe : null} postFixData="%" />
                                <OutputLabel fieldTitle="loRWA" value={this.state.leaseData ? this.state.leaseData.ioRwa : null} postFixData="%" />
                                <OutputLabel fieldTitle="Day 1 RWA (GBP)" type={'currency'} value={this.state.leaseData ? this.state.leaseData.day1Rwa : null} />
                                <OutputLabel fieldTitle="VPV" type={'currency'} value={this.state.leaseData ? this.state.leaseData.vacantPossesionValue : null} />

                                <OutputLabel fieldTitle="RLV" type={'currency'} value={this.state.leaseData ? this.state.leaseData.reLetValue ? this.state.leaseData.reLetValue + " " + this.state.leaseData.currency : null : null} />
                                <OutputLabel fieldTitle="RV/BV" value={this.state.leaseData ? this.state.leaseData.rvByBv : null} postFixData="%"/>
                                <OutputLabel fieldTitle="RV/VPV" value={this.state.leaseData ? this.state.leaseData.rvByVpv ? this.state.leaseData.rvByVpv : "N/A" : null} postFixData="%" />
                                <OutputLabel fieldTitle="RV/RLV" value={this.state.leaseData ? this.state.leaseData.rvByRlv ? this.state.leaseData.rvByRlv : "N/A" : null} postFixData="%" />
                                
                                <OutputLabel fieldTitle="Min lease payments NPV" type={'currency'} value={this.state.leaseData ? this.state.leaseData.minLeasePayment : null}/>
                                <OutputLabel fieldTitle="Nominal of minimum lease payment" type={'currency'} value={this.state.leaseData ? this.state.leaseData.nominalMinLeasePay : null} />
                                
                                <OutputLabel fieldTitle="NPV/RLV" value={this.state.leaseData ? this.state.leaseData.NPVByRLV ? this.state.leaseData.NPVByRLV : "N/A" : null} postFixData="%" /> 
                                <OutputLabel fieldTitle="IRR" value={this.state.leaseData ? this.state.leaseData.irr : null} postFixData="%" />
                                <OutputLabel fieldTitle="IRR including residual" value={this.state.leaseData ? this.state.leaseData.irrIncRes : null} postFixData="%" />
                                
                                
                                
                            </div> {/* .zb-column-is-6 */}

                            <div class=".zb-column-is-6 col-sm-6" >
                            <label>Option Summary</label>
                            <OptionSummaryGridTL dataFromParent = {this.props.dataFromParent} />
                            </div>
                        </div> {/*  Bottom Section zb-columns*/}
                    </div>
                </div> {/*  zb-container*/}
        </div>;

    }

}

export default summaryDetail;

