import React from 'react';
import { connect } from "react-redux";
import 'react-table/react-table.css';
import { Route, withRouter } from 'react-router-dom';
import './SummaryDetail';
import { HttpPost, HttpGet } from '../../../services/api.js';
import moment, { locale } from 'moment';
import {precisePercentage, formatAmount} from '../../../utils/LeaseUtils.js';
import { formatDate, formatCurrencyValue } from '../../../commonComponents/localeFormattingFunctions';
import VerticalGridComponent from '../../../components/asset/verticalGridComponent';

class OptionSummaryGridTL extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            timelineCurrentpageSize: 5,
            userTableData: [],
            loading: false,
            rowHeaders : this.getOptionRowHeaders(),
            locale : props.locale,
        }
        this.precisePercentage = precisePercentage;
        this.formatAmount = formatAmount;
    }

    addPercent(x){
        return x.toString().concat('%');
    }

    componentWillReceiveProps(props){
        if(props.locale){
            this.setState({locale: props.locale}, this.generateData);
        }
    }

    componentDidMount(){
        this.generateData();
    }

    generateData(){
        var currentComponent = this;
        var leaseContract = this.props.dataFromParent;
        var stringObject = JSON.stringify(leaseContract);
        if(leaseContract !== null && leaseContract !== undefined ){
            var dataFormat = {
                test: '',
                UpfrontOptionPremium:0.00,
                OptionStrikePrice:0.00,
                OptionPaidAtOptionExcise:0.00,
                TotalOptionPrice: 0.00,
                TotalAcquisitionCost: 0.00,
            }
            var output = [];
			if(leaseContract.optionDTO != null && leaseContract.optionDTO != undefined)
            {
            var recordCount = leaseContract.optionDTO.length;
            console.log("21365236647------> "+leaseContract.optionDTO.length);
            for (var j = 0; j < recordCount; j++) {
                var OptionDate = formatDate(leaseContract.optionDTO[j].optionDate, this.state.locale);
                dataFormat = {
                    test: OptionDate,
                    UpfrontOptionPremium: formatCurrencyValue(leaseContract.optionDTO[j].upfrontOptionPremium, this.state.locale),
                    OptionStrikePrice: formatCurrencyValue(leaseContract.optionDTO[j].optionStrikePrice, this.state.locale),
                    OptionPaidAtOptionExcise: formatCurrencyValue(leaseContract.optionDTO[j].premiumPaidOptionExDate, this.state.locale),
                    TotalOptionPrice: formatCurrencyValue(leaseContract.optionDTO[j].totalOptionPrice, this.state.locale),
                    TotalAcquisitionCost: currentComponent.addPercent(currentComponent.precisePercentage(leaseContract.optionDTO[j].totalAcquisitionCost)),
                }
                var temp = JSON.parse(JSON.stringify(dataFormat));
                output.push(temp);
            }
            currentComponent.setState({userTableData:output});
			}
        }
    }

    handleSelectEventChange(event){
        var currentComponent = this;
        currentComponent.setState({ timelineCurrentpageSize: event.target.value });
    }

    getOptionRowHeaders(){
        return [
            {key : 'test', value :''},
            {key : 'UpfrontOptionPremium', value :'Upfront Option Premium'},
            {key : 'OptionStrikePrice', value :'Option Strike Price'},
            {key : 'OptionPaidAtOptionExcise', value :'Premium paid at  option exercise'},
            {key : 'TotalOptionPrice', value :'Total Option Price'},
            {key : 'TotalAcquisitionCost', value :'Option price/Total acquisition costs'},
        ]
    }

    render(){
       try{
            /*const columns = [{
                id: 'Test',
                Header: '',
                accessor: 'test',
                headerClassName: 'periodSummaryheader',
                filterable: false,
                className: 'periodSummary_cell',
                width: 200,
                Cell: column => <div style={{ marginLeft:'5px', marginRight:'5px', textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{column.value}</div>,
            },
            {id: 'UpfrontOptionPremium',
            Header: 'Upfront Option Premium',
            accessor: 'UpfrontOptionPremium',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            Cell: column => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{column.value}</div>,
            width:200
            },
            {id: 'OptionStrikePrice',
            Header: 'Option Strike Price',
            accessor: 'OptionStrikePrice',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width:200
            },
            {id: 'OptionPaidAtOptionExcise',
            Header: 'Premium paid at  option exercise',
            accessor: 'OptionPaidAtOptionExcise',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width:200
            },
            {id: 'TotalOptionPrice',
            Header: 'Total Option Price',
            accessor: 'TotalOptionPrice',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width:200
            },
            {id: 'TotalAcquisitionCost',
            Header: 'Option price/Total acquisition costs',
            accessor: 'TotalAcquisitionCost',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
            width:200
            },
        ];*/

        return <div className="grid_layout" style={{width:'204%'}}>
         <VerticalGridComponent  rowHeaders={this.state.rowHeaders}
         data={this.state.userTableData} 
        />
            
        </div>

        }catch(error){
            window.alert(error);
        }


    }

}

const mapStateToProps = state => {
    return {
         locale: state.dataFormat,
    }
    
};

OptionSummaryGridTL = connect(mapStateToProps)(OptionSummaryGridTL);
export default OptionSummaryGridTL;