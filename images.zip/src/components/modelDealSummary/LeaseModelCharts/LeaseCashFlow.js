import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';
import moment from 'moment';
import {precisePercentage, precise} from '../../../utils/LeaseUtils.js';

class LeaseCashFlow extends Component {
 constructor(props) {
   super(props);   
   this.precise = precise;
   this.precisePercentage = precisePercentage;
  this.getPeriodicModelledDealData(props.dataFromParent.leaseModels);
  this.getAnnualModelledDealData(props.dataFromParent);
  this.generateDataForCharts('line');  
}

getPeriodicModelledDealData(leaseModels){
  var currentComponent = this;
  if(leaseModels !== null && leaseModels !== undefined ){
  
      var dataFormat = {
      openingBalance:0.00,       
      rateRefAmount: 0.00,
      marginAmount: 0.00,
      tlpAmount: 0.00,
      depreciation: 0.00,
      RWA:0.00,
      loRWA:0.00,
      cpbRoE:0.00,
      hloRWA:0.00
  }
      var output = [];
      var recordCount = leaseModels.length;
      for (var j = 0; j < recordCount; j++) {
        var periodstartDate = moment(leaseModels[j].periodStartDate).format('DD/MM/YYYY');
      dataFormat = {
          dates:periodstartDate,
          openingBalance: currentComponent.precise(leaseModels[j].openingBalance),
          rateRefAmount: currentComponent.precise(leaseModels[j].rateRefAmount),
          marginAmount: currentComponent.precise(leaseModels[j].marginAmount),
          tlpAmount: currentComponent.precise(leaseModels[j].tlpAmount),
          depreciation: currentComponent.precise(leaseModels[j].depreciation),
          RWA: currentComponent.precise(leaseModels[j].totalRWA),
          loRWA: currentComponent.addPercent(precisePercentage(leaseModels[j].ioRwa)),
          cpbRoE: currentComponent.addPercent(precisePercentage(leaseModels[j].cpbRoe)),
          hloRWA: currentComponent.addPercent("4.00")
          }
          var temp = JSON.parse(JSON.stringify(dataFormat));
          output.push(temp);

      }
      localStorage.setItem('datasave', JSON.stringify(output));
   }
}

getAnnualModelledDealData(leaseContract){
  var currentComponent = this;
  if(leaseContract !== null && leaseContract !== undefined ){
      var dataFormat = {
      openingBalance:0.00,      
      rateRefAmount: 0.00,
      marginAmount: 0.00,
      tlpAmount: 0.00,
      depreciation: 0.00,    
      RWA:0.00,
      loRWA:0.00,
      cpbRoE:0.00,
      hloRWA:0.00,
      exitYield:0.00
  }
      var output = [];
      var recordCount = leaseContract.annualLeaseModel.length;
      for (var j = 0; j < recordCount; j++) {
        var periodstartDate = moment(leaseContract.annualLeaseModel[j].periodStartDate).format('DD/MM/YYYY');
      dataFormat = {
          dates:periodstartDate,
          openingBalance: currentComponent.precise(leaseContract.annualLeaseModel[j].openingBalance),
          rateRefAmount: currentComponent.precise(leaseContract.annualLeaseModel[j].rateRefAmount),
          marginAmount: currentComponent.precise(leaseContract.annualLeaseModel[j].marginAmount),
          tlpAmount: currentComponent.precise(leaseContract.annualLeaseModel[j].tlpAmount),
          depreciation: currentComponent.precise(leaseContract.annualLeaseModel[j].depreciation),
          RWA: currentComponent.precise(leaseContract.annualLeaseModel[j].totalRWA),
          loRWA: currentComponent.addPercent(currentComponent.precisePercentage(leaseContract.annualLeaseModel[j].ioRwa)),
          cpbRoE: currentComponent.addPercent(currentComponent.precisePercentage(leaseContract.annualLeaseModel[j].cpbRoe)),
          hloRWA: currentComponent.addPercent("4.00"),
          exitYield: currentComponent.addPercent(currentComponent.precisePercentage(leaseContract.annualLeaseModel[j].yield))
          }
          var temp = JSON.parse(JSON.stringify(dataFormat));
          output.push(temp);

      }
      localStorage.setItem('annualSummaryTLData', JSON.stringify(output));
   }
}
nFormatter(num) {
   return (num / 1000000);
}
addPercent(x){
  return x.toString().concat('%');
}
generateDataForCharts(chartType)
{  
  let ID;
 this.state = {
   yAxisDepriciationAmount:[],
   yAxisTLPAmount:[],
   yAxisInterestRateAmount:[],
   yAxisMarginAmount:[],
   yAxisOpeningBalanceAmount:[],
   doubleYAxisOpeningBalPercentage :[],
   xAxisValue:[],
   chartType:chartType,
   graphType: chartType,
   leaseContract: {},
   isPercentageClicked: false,
   titleColor: 'black',
   titleColor1: '#ad1982'
 }
 
 ID = (chartType === 'bar')? localStorage.getItem('annualSummaryTLData'):
  localStorage.getItem('datasave');  
 let IDstr = JSON.parse(ID);
 this.state.leaseContract = this.props.dataFromParent;

 if(IDstr !== undefined){
   for (var j = 0; j < IDstr.length; j++) {
     this.state.yAxisDepriciationAmount.push(this.nFormatter(IDstr[j].depreciation.replace(/,/g, "")));
     this.state.yAxisTLPAmount.push(this.nFormatter(IDstr[j].tlpAmount.replace(/,/g, "")));
     this.state.yAxisMarginAmount.push(this.nFormatter(IDstr[j].marginAmount.replace(/,/g, "")));
     this.state.yAxisInterestRateAmount.push(this.nFormatter(IDstr[j].rateRefAmount.replace(/,/g, "")));
     this.state.yAxisOpeningBalanceAmount.push(this.nFormatter(IDstr[j].openingBalance.replace(/,/g, "")));
     if(this.state.leaseContract !== null && this.state.leaseContract != undefined){          
       this.state.doubleYAxisOpeningBalPercentage.push(
         (IDstr[j].openingBalance.replace(/,/g, "")/ parseInt(this.state.leaseContract.acquistionCost)));
     }
     let date =(new Date(IDstr[j].dates));
     if (chartType === 'bar' || j === 0 || !this.state.xAxisValue.includes(date.getFullYear())) {
       this.state.xAxisValue.push(date.getFullYear());
     }
     else {
       this.state.xAxisValue.push('');
     }
     }      
           
 }
}
setOptions(){
 return {
   xAxis: {
     type: "category",
     boundaryGap: true,
     data:this.state.xAxisValue,
     axisLabel: {
       show: true,
       margin: 5,
     },
   },
   tooltip: {
     trigger: 'axis',
     axisPointer: {
         type: 'cross',
         label: {
             backgroundColor: '#6a7985'
         }
     },
     formatter: function (params) {
      var colorSpan = color => '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + color + '"></span>';
      let response = '<p>' + params[0].axisValue + '</p>';
      params.forEach(item => {
          var xx = '<p>'  + colorSpan(item.color) + '' + item.seriesName + ': ' + item.data.toFixed(2) + '</p>'
          response += xx;
      });
      return response;
  }
 },
   yAxis:[ {
     name: 'million('+ this.state.leaseContract.currency +')',
     type: "value" ,
     splitLine: {
      show: false
     }
   },
   { 
     type: "value" ,
     splitLine: {
      show: false
     } 
   }],
   title: {
     text: 'Lease cash Flows',
     align: 'center'
   },
   legend: {
     icon: 'rect',
     bottom: 0
    },
   series: [          
   { 
     name: "Depreciation",
     data: this.state.yAxisDepriciationAmount,
     type: this.state.chartType === 'bar'? "bar": "line",
     yAxisIndex: 0,
     color: '#42145f',
     stack: 'data',
     areaStyle: {},
     showSymbol: false
   },
   {
     data:  this.state.yAxisInterestRateAmount,
     type: this.state.chartType === 'bar'? "bar": "line",
     name: 'Interest rate',
     yAxisIndex: 0,
     color: '#fecf33',
     stack: 'data',
     areaStyle: {},
     showSymbol: false
 },      
   { 
     name: "TLP",
     yAxisIndex: 0,
     data: this.state.yAxisTLPAmount,
     type: this.state.chartType === 'bar'? "bar": "line",
     color: '#516cb3',
     stack: 'data',
     areaStyle: {},
     showSymbol: false
   },
   {
     data: this.state.yAxisMarginAmount,
     type: this.state.chartType === 'bar'? "bar": "line",
     name: 'Margin',
     yAxisIndex: 0,
     color: '#ce3b57',
     stack: 'data',
     areaStyle: {},
     showSymbol: false
 },
   {
     data: !this.state.isPercentageClicked?
      this.state.yAxisOpeningBalanceAmount: this.state.doubleYAxisOpeningBalPercentage,
     type: 'line',
     name: 'Opening balance',
     yAxisIndex: 1,
     color: '#009fac',
     showSymbol: false
 }]
 }
}

showChart(type){
  this.state.chartType = type;
  var barChartButton = document.getElementById('btnBarChart');
  var graphButton = document.getElementById('btnGraph');
  if (type === 'bar') {
    barChartButton.classList.remove('twoWayButton_notselected');
    barChartButton.classList.add('twoWayButton_selected');
    graphButton.classList.remove('twoWayButton_selected');
    graphButton.classList.add('twoWayButton_notselected');
  }
  else {

    graphButton.classList.remove('twoWayButton_notselected');
    graphButton.classList.add('twoWayButton_selected');
    barChartButton.classList.remove('twoWayButton_selected');
    barChartButton.classList.add('twoWayButton_notselected');
  }
   this.generateDataForCharts(this.state.chartType);
   let echarts_instance = this.echarts_react.getEchartsInstance();
   echarts_instance.setOption(this.setOptions());
}

onTLPChartsLinkClick(percentClick) {
 this.state.isPercentageClicked = percentClick;
 let echarts_instance = this.echarts_react.getEchartsInstance();
  echarts_instance.setOption(this.setOptions());
  if(this.state.isPercentageClicked == true){
  this.setState({titleColor: '#ad1982'});
  this.setState({titleColor1: 'black'});
}else{
  this.setState({titleColor1: '#ad1982'});
  this.setState({titleColor: 'black'});
}
}
 render() {
      
  return (      
 <div id ='echartsData' style={{position:'relative'}} class="col-md-6">
 
  <div class="chartsTwoWayBnt"><div class="btn-group chartSwitchButtonGroup">
 <button id = 'btnGraph' type="button" className={"btn btn-primary standard_twoway_btn twoWayButton_selected"}
 onClick={this.showChart.bind(this,'line')}>Graph</button>
 <button  id ='btnBarChart'  type="button" className={"btn btn-primary standard_twoway_btn twoWayButton_notselected "} 
 onClick={this.showChart.bind(this,'bar')}>Bar Chart</button> 
  </div>  </div> 

  <div style={{position:'absolute', zIndex: '99', marginLeft:'79%',marginTop:'3%'}}> 
  <label style={{color: this.state.titleColor, fontWeight:'normal', fontSize:'82%', marginRight:'12px'}} onClick= {this.onTLPChartsLinkClick.bind(this, false)}> million({this.state.leaseContract.currency})  </label>
 <label style={{color: this.state.titleColor1 , fontWeight:'normal', fontSize:'82%'}} onClick={this.onTLPChartsLinkClick.bind(this, true)}>  %</label> 
  </div> 

<ReactEcharts ref={(e) => { this.echarts_react = e; }}
  option={this.setOptions()} />
     </div>
   );
   
 }
}

export default LeaseCashFlow;