// src/App.js
import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';
class YieldLineChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      output:[],
      xAxisValue:[]
    }
    let ID =  localStorage.getItem('annualSummaryTLData');     
    let IDstr = JSON.parse(ID); 
   
    if(IDstr !== undefined){
      for (var j = 0; j < IDstr.length; j++) {
        this.state.output.push(IDstr[j].exitYield.replace('%',''));
        let date =(new Date(IDstr[j].dates));
        this.state.xAxisValue.push(date.getFullYear());
      }
    }
}
  
  render() {
    return (
      <div style={{margin:'38% 0%', width:' 100%', position: 'relative'}} >
      <ReactEcharts
        option={{
          xAxis: {
            type: 'category',
            boundaryGap: false,
            data:  this.state.xAxisValue
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
          yAxis: {
            type: 'value',
            name: ' Yield %',
            splitLine: {
              show: false
             }
          },
          legend:{
          bottom:0,          
          left: '10%',
          icon: 'rect'},          
          series: [{ 
            data: this.state.output,
            type: 'line',
            name: 'Yield'
          }],
          title: {
            text: 'Yield',
            align:'left'
          },

        }}
      /></div>
    )   
  }
}
export default YieldLineChart;