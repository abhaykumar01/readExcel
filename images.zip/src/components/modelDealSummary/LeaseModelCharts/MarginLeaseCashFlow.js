import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';
class MarginLeaseCashFlow extends Component {
  constructor(props) {
    super(props);
    this.generateDataForCharts('line');  
}
nFormatter(num) {
  return (num / 1000000);
}
generateDataForCharts(chartType)
{  
  let ID;
  this.state = {
    yAxisDepriciationAmount:[],
    yAxisInterestRateAmount:[],
    yAxisMarginAmount:[],
    yAxisOpeningBalanceAmount:[],
    doubleYAxisOpeningBalPercentage :[],
    xAxisValue:[],
    leaseContract: {},
    chartType: chartType,
    isPercentageClicked: false,
    titleColor: 'black',
    titleColor1: '#ad1982'
  }

  ID = (this.state.chartType === 'bar')? localStorage.getItem('annualSummaryTLData'):
  localStorage.getItem('datasave');  
 let IDstr = JSON.parse(ID);
 this.state.leaseContract = this.props.dataFromParent;
    
  if(IDstr !== undefined){
    for (var j = 0; j < IDstr.length; j++) {
      this.state.yAxisDepriciationAmount.push(this.nFormatter(IDstr[j].depreciation.replace(/,/g, "")));
      this.state.yAxisMarginAmount.push
      (this.nFormatter(IDstr[j].marginAmount.replace(/,/g, "")) + this.nFormatter(IDstr[j].tlpAmount.replace(/,/g, "")));
      this.state.yAxisInterestRateAmount.push(this.nFormatter(IDstr[j].rateRefAmount.replace(/,/g, "")));
      this.state.yAxisOpeningBalanceAmount.push(this.nFormatter(IDstr[j].openingBalance.replace(/,/g, "")));
      if(this.state.leaseContract !== null && this.state.leaseContract != undefined){          
        this.state.doubleYAxisOpeningBalPercentage.push(
          (IDstr[j].openingBalance.replace(/,/g, "")/ parseInt(this.state.leaseContract.acquistionCost)));
      }
      let date =(new Date(IDstr[j].dates));
      if (this.state.chartType === 'bar' || j === 0 || !this.state.xAxisValue.includes(date.getFullYear())) {
        this.state.xAxisValue.push(date.getFullYear());
      }
      else {
        this.state.xAxisValue.push('');
      }
    }
  }
}

showChart(type){
  this.state.chartType = type;
  var barChartButton = document.getElementById('btnBarCharts');
  var graphButton = document.getElementById('btnGraphs');
  if (type === 'bar') {
    barChartButton.classList.remove('twoWayButton_notselected');
    barChartButton.classList.add('twoWayButton_selected');
    graphButton.classList.remove('twoWayButton_selected');
    graphButton.classList.add('twoWayButton_notselected');
  }
  else {
    graphButton.classList.remove('twoWayButton_notselected');
    graphButton.classList.add('twoWayButton_selected');
    barChartButton.classList.remove('twoWayButton_selected');
    barChartButton.classList.add('twoWayButton_notselected');
  }
     this.generateDataForCharts(this.state.chartType);
     let echarts_instance = this.echarts_react.getEchartsInstance();
     echarts_instance.setOption(this.setOptions());
  }

onMarginChartsLinkClick(percentClick) {
  this .state.isPercentageClicked = percentClick;
  let echarts_instance = this.echarts_react.getEchartsInstance();
   echarts_instance.setOption(this.setOptions());
   if(this.state.isPercentageClicked == true){
    this.setState({titleColor: '#ad1982'});
    this.setState({titleColor1: 'black'});
  }else{
    this.setState({titleColor1: '#ad1982'});
    this.setState({titleColor: 'black'});
  }
 }

setOptions() {
return {
  xAxis: {
    type: "category",
    boundaryGap: true,
    data:this.state.xAxisValue,
    position: 'bottom'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
        type: 'cross',
        label: {
            backgroundColor: '#6a7985'
        }
    },
    formatter: function (params) {
      var colorSpan = color => '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + color + '"></span>';
      let response = '<p>' + params[0].axisValue + '</p>';
      params.forEach(item => {
          var xx = '<p>'  +  colorSpan(item.color) + ' ' + item.seriesName + ': ' + item.data.toFixed(2) + '</p>'
          response += xx;
      });
      return response;
  }
},
  yAxis:[ {
    name: 'million(' + this.state.leaseContract.currency + ')',
    type: "value" ,
    splitLine: {
      show: false
     }
  },
  {
    type: "value" ,
    splitLine: {
      show: false
     }           
  }],
  title: {
    text: 'Lease cash Flows (Margin)',
    align: 'center'
  },
  legend: {
    icon: 'rect',
    bottom: 0
   },
  series: [          
  { 
    name: "Depreciation",
    data: this.state.yAxisDepriciationAmount,
    type: this.state.chartType === 'bar'? "bar": "line",
    yAxisIndex: 0,
    color: '#42145f',
    stack: 'data',
    areaStyle: {},
    showSymbol: false
  },
  {
    data:  this.state.yAxisInterestRateAmount,
    type: this.state.chartType === 'bar'? "bar": "line",
    name: 'Interest rate',
    yAxisIndex: 0,
    color: '#fecf33',
    stack: 'data',
    areaStyle: {},
    showSymbol: false
},
  {
    data: this.state.yAxisMarginAmount,
    type: this.state.chartType === 'bar'? "bar": "line",
    name: 'Margin',
    yAxisIndex: 0,
    color: '#ce3b57',
    stack: 'data',
    areaStyle: {},
    showSymbol: false
},
  {
    data:!this.state.isPercentageClicked?
    this.state.yAxisOpeningBalanceAmount: this.state.doubleYAxisOpeningBalPercentage,
    type: 'line',
    name: 'Opening balance',
    yAxisIndex: 1,
    color: '#009fac',
    showSymbol: false
}]
}
}

  render() {
    
    return (
      
  <div style={{ position:'relative'}} class="col-md-6">
 
  <div class="chartsTwoWayBnt"><div class="btn-group chartSwitchButtonGroup">
  <button type="button" id="btnGraphs" onClick={this.showChart.bind(this,'line')} class="btn btn-primary standard_twoway_btn twoWayButton_selected">Graph</button>
  <button type="button" id="btnBarCharts"  onClick={this.showChart.bind(this,'bar')} class="btn btn-primary standard_twoway_btn twoWayButton_notselected">Bar Chart</button>
  </div></div>

  <div style={{position:'absolute', zIndex: '111', marginLeft:'79%',marginTop:'3%'}}> 
  <label style={{color: this.state.titleColor ,fontWeight:'normal', fontSize:'82%', marginRight: '15px'}} 
  onClick= {this.onMarginChartsLinkClick.bind(this, false)}> million({this.state.leaseContract.currency})  </label>
 <label style={{color: this.state.titleColor1, fontWeight:'normal', fontSize:'82%'}} onClick={this.onMarginChartsLinkClick.bind(this, true)}> %</label> 
  </div> 

<ReactEcharts ref={(e) => { this.echarts_react = e; }} option={this.setOptions()} /></div>);}
}

export default MarginLeaseCashFlow;

