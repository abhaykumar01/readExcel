import React from 'react';
import moment from 'moment';
import ReactEcharts from 'echarts-for-react';

 class ReturnGraphTL extends React.Component {
  
  constructor(props) {
    super(props);

    this.state = {
      output1: [],
      output2: [],
      output3: [],
      output4: [],
      xAxis: [],
      yAxisLabel: [],
    };
  }

  componentDidMount() {
    var IDstr = JSON.parse(localStorage.getItem('datasave'));
    var leaseContract = this.props.dataFromParent;
    //var stringdata = JSON.stringify(leaseContract);
    var currencyLabel= leaseContract.currency;
    //var recordCount = leaseContract.annualLeaseModel.length;
    var year=[];
    var yLabel="";

    var hurdleRWA=[];
    var IoRWA=[];
    var CPBRoe=[];
    var rwa=[];
    var rwa1=[];
    if(IDstr !== undefined){
    for(var i=0; i<IDstr.length; i++){
      hurdleRWA.push(IDstr[i].hloRWA.replace('%',''));
      IoRWA.push(IDstr[i].loRWA.replace('%',''));
      CPBRoe.push(IDstr[i].cpbRoE.replace('%',''));
      if("-" != IDstr[i].RWA){
      rwa.push(IDstr[i].RWA.replace(/,/g, ''));}
      let date =(new Date(IDstr[i].dates.split('-')[0]))
      if (i === 0 || !year.includes(date.getFullYear())) {
        year.push(date.getFullYear());
        }
        else {
        year.push('');
        } 
      
    }
    //var maxRwa=Math.max.apply(Math, rwa);
    let maxRwa = rwa.reduce(function(a, b) {
    return Math.max(a, b);
    });
    for(var j=0; j<rwa.length; j++){
     
        if(maxRwa<1000000 && maxRwa >-1000000){
        rwa1.push(rwa[j]/1000);
        yLabel="Thousand";
        }else if(maxRwa<1000000000 && maxRwa>-1000000000){
          rwa1.push(rwa[j]/1000000);
          yLabel="Million";
        }
        else if(maxRwa>1000000000 && maxRwa<-1000000000){
          rwa1.push(rwa[j]/1000000000);
          yLabel="Billion";
        }
    }
    this.setState({output1:hurdleRWA});
    this.setState({output2:CPBRoe});
    this.setState({output3:IoRWA});
    this.setState({output4:rwa1});
    this.setState({output5:rwa});
    this.setState({xAxis:year});
    this.setState({yAxisLabel: yLabel+" ("+currencyLabel+")"});
  }
}
  render() {
    return (
      <div id="chart" style={{marginTop:'19%', position: 'relative'}}>
      <div class="col-md-6">
      
        <ReactEcharts
                option={{
                  tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                      type: 'cross',
                      label: {
                          backgroundColor: '#6a7985'
                      }
                  },
                  formatter: function (params) {
                   var colorSpan = color => '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + color + '"></span>';
                   let response = '<p>' + params[0].axisValue + '</p>';
                   var xx = '';
                   params.forEach(item => {
                    if(item.seriesName == 'RWA(Right)'){
                        xx = '<p>'  + colorSpan(item.color) + '' + item.seriesName + ': ' + item.data.toFixed(2) + ' Millions'+'</p>'
                       
                    }else{
                       xx = '<p>'  + colorSpan(item.color) + '' + item.seriesName + ': ' + item.data + '</p>'
                     
                    }
                    response += xx;
                   });
                   return response;
                   
               } 
                },
        
                  xAxis: {
                    type: "category",
                    boundaryGap: false,
                    data:this.state.xAxis,
                    axisLabel:{
                      margin: '10'
                    }
                  },
                  yAxis:[ {
                    name: '%',
                    type: "value",
                    axisLabel: {
                      formatter: '{value}'
                  },
                  splitLine: {
                    show: false
                    }
                  },
                  {
                    name: this.state.yAxisLabel,
                    type: "value",
                    axisLabel: {
                      formatter:'{value}'
                    },
                    splitLine: {
                      show: false
                      }
                  }],
                  title: {
                    text: 'Returns & capital',
                    align: 'left'
                  },
                  legend: {
                    align: 'left',
                    bottom: 0,
                    itemGap: 40,
                    selectedMode: false,
                    icon: 'rect'
                  },
                  series: [
                    { 
                      name: "IoRWA",
                      data: this.state.output3,
                      type: "line",
                      yAxisIndex: 0,
                      color: "#42145f",
                      symbol: 'none'
                    },
                    { 
                    name: "hurdleRWA",
                    data: this.state.output1,
                    type: "line",
                    yAxisIndex: 0,
                    color: "#516cb3",
                    symbol: 'none'
                  },
                  { 
                    name: "CPB RoE",
                    data: this.state.output2,
                    type: "line",
                    yAxisIndex: 0,
                    color: "#fbba20",
                    symbol: 'none'
                  },
                  { 
                    name: "RWA(Right)",
                    yAxisIndex: 1,
                    data: this.state.output4,
                    type: "line",
                    color: "#ce3b57",
                    symbol: 'none',
                    
                    }]
                }}
              /></div>
              <div class="col-md-6">
              <ReactEcharts
                option={{
                  tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                      type: 'cross',
                      label: {
                          backgroundColor: '#6a7985'
                      }
                  },
                },
                  xAxis: {
                    type: "category",
                    boundaryGap: false,
                    data:this.state.xAxis
                  },
                  yAxis:[ {
                    name: '%',
                    type: "value",
                    axisLabel: {
                      formatter: '{value}'
                  },
                  splitLine: {
                    show: false
                    }
                  },
                  {
                    type: "value",
                    splitLine: {
                      show: false
                      }
                  }],
                  title: {
                    text: 'Returns',
                    align: 'left'
                  },
                  legend: {
                    align: 'left',
                    bottom: 0,
                    itemGap: 40,
                    selectedMode: false,
                    icon: 'rect',
                  },
                  series: [ { 
                    name: "IoRWA",
                    data: this.state.output3,
                    type: "line",
                    yAxisIndex: 0,
                    color: "#42145f",
                    symbol: 'none'
                  },
                  { 
                  name: "hurdleRWA",
                  data: this.state.output1,
                  type: "line",
                  yAxisIndex: 0,
                  color: "#516cb3",
                  symbol: 'none'
                },
                { 
                  name: "CPB RoE",
                  data: this.state.output2,
                  type: "line",
                  yAxisIndex: 0,
                  color: "#fbba20",
                  symbol: 'none'
                }]
                }} 
              /></div>
        </div>


    );
  }
}

export default ReturnGraphTL;