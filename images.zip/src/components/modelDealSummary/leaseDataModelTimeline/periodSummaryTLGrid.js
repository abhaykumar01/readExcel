import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { Route, withRouter } from 'react-router-dom';
import './periodSummary.css';
import Pagination from '../../../commonComponents/pagination.js';
import { HttpPost, HttpGet } from '../../../services/api.js';
import moment from 'moment';
import { FormattedAmount } from '@zambezi/sdk/formatted-input';
import {precisePercentage, precise} from '../../../utils/LeaseUtils.js';
import LocaleFormattedValue from '../../../commonComponents/LocaleFormattedValue';

class PeriodSummaryTLGrid extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            timelineCurrentpageSize: 20,
            userTableData: [],
            loading: false,
        }
        this.precise = precise;
    }

    addPercent(x){
        return x.toString().concat('%');
    }
    
    componentDidMount(){
        var currentComponent = this;
        var leaseModels = this.props.dataFromParent;
        if(leaseModels !== null && leaseModels !== undefined ){
        
            var dataFormat = {
            openingBalance:0.00,
            closingBalance:0.00,
            leaseFee:0.00,
            modelIndex: 0,
            rateRefAmount: 0.00,
            marginAmount: 0.00,
            tlpAmount: 0.00,
            depreciation: 0.00,
            // cashFlow:0.00,
            RWA:0.00,
            loRWA:0.00,
            cpbRoE:0.00,
            hloRWA:0.00,
            exitYield:0.00,
            day1Rwa:0.00,
        }
            var output = [];
            var recordCount = leaseModels.length;
            for (var j = 0; j < recordCount; j++) {
              var periodstartDate = leaseModels[j].periodStartDate;
              var periodendDate = leaseModels[j].periodEndDate;
            dataFormat = {
                dates:[periodstartDate, periodendDate],
                openingBalance: currentComponent.precise(leaseModels[j].openingBalance),
                closingBalance:currentComponent.precise(leaseModels[j].closingBalance),
                leaseFee:currentComponent.precise(leaseModels[j].leaseFee),
                modelIndex: currentComponent.addPercent(precisePercentage(leaseModels[j].modelIndex)),
                rateRefAmount: currentComponent.precise(leaseModels[j].rateRefAmount),
                marginAmount: currentComponent.precise(leaseModels[j].marginAmount),
                tlpAmount: currentComponent.precise(leaseModels[j].tlpAmount),
                depreciation: currentComponent.precise(leaseModels[j].depreciation),
                // cashFlow: currentComponent.precise(leaseModels[j].cashFlow),
                RWA: currentComponent.precise(leaseModels[j].totalRWA),
                loRWA: currentComponent.addPercent(precisePercentage(leaseModels[j].ioRwa)),
                cpbRoE: currentComponent.addPercent(precisePercentage(leaseModels[j].cpbRoe)),
                day1Rwa: currentComponent.addPercent(precisePercentage(leaseModels[j].day1Rwa)),
                hloRWA: currentComponent.addPercent("4.00"),
                exitYield: currentComponent.addPercent(precisePercentage(leaseModels[j].yield)),
                }
                var temp = JSON.parse(JSON.stringify(dataFormat));
                output.push(temp);

            }
            currentComponent.setState({userTableData:output});
         }
    }

    handleSelectEventChange(event){
        var currentComponent = this;
        currentComponent.setState({ timelineCurrentpageSize: event.target.value });
    }

    handleOnLoadPagination(event){
        var currentComponent = this;
       // window.alert(this.state.timelineCurrentpageSize);
    }
    
    render(){
        try{
        const columns = [{
            id: 'Dates',
            Header: 'Dates',
            accessor: 'dates',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            width: 200,
            Cell: row => <div style={{ marginLeft:'5px', marginRight:'5px', textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                            <LocaleFormattedValue type={'dateRange'} delimiter={'-'} value={row.value} />
                        </div>,
        },{id: 'openingBalance',
        Header: 'Opening balance',
        accessor: 'openingBalance',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width:140
        },
        {id: 'closingBalance',
        Header: 'Closing balance',
        accessor: 'closingBalance',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'Increase',
        Header: 'Increase',
        accessor: 'Increase',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'Depreciation',
        Header: 'Depreciation',
        accessor: 'depreciation',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'leaseFee',
        Header: 'Lease Fee',
        accessor: 'leaseFee',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'interestRate',
        Header: 'Interest rate',
        accessor: 'rateRefAmount',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'TLP',
        Header: 'TLP',
        accessor: 'tlpAmount',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'margin',
        Header: 'Margin',
        accessor: 'marginAmount',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'index',
        Header: 'Index',
        accessor: 'modelIndex',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        width: 140},
        // {id: 'cashFlow',
        // Header: 'Cash Flow',
        // accessor: 'cashFlow',
        // headerClassName: 'periodSummaryheader',
        // filterable: false,
        // className: 'periodSummary_cell',
        // Cell: row => <div style={{textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        // width: 140}
        {id: 'RWA',
        Header: 'RWA',
        accessor: 'RWA',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                            <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 140},
        {id: 'loRWA',
        Header: 'loRWA',
        accessor: 'loRWA',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        width: 140},
        {id: 'cpbRoE',
        Header: 'CPB RoE',
        accessor: 'cpbRoE',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        width: 140},
        // {id: 'day1Rwa',
        // Header: 'day1Rwa',
        // accessor: 'day1Rwa',
        // headerClassName: 'periodSummaryheader',
        // filterable: false,
        // className: 'periodSummary_cell',
        // Cell: row => <div style={{textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        // width: 140},
        // {id: 'hloRWA',
        // Header: 'Hurdle loRWA',
        // accessor: 'hloRWA',
        // headerClassName: 'periodSummaryheader',
        // filterable: false,
        // className: 'periodSummary_cell',
        // Cell: row => <div style={{textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        // width: 140},
        {id: 'exitYield',
        Header: 'Break Even exit yield',
        accessor: 'exitYield',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>{row.value}</div>,
        width: 140}
    ];

        return <div className="grid_layout" >
            <ReactTable
            data={this.state.userTableData} 
            columns={columns}
            // loading={this.state.loading}
            showPagination={true}
            showPaginationTop={false}
            showPaginationBottom={true}
            showPageSizeOptions = {true}
            defaultSortDesc = {false}
            className='-striped -highlight summaryTable'
            headerClassName= 'periodSummaryheader'
            defaultPageSize={20}
            pageSize = {this.state.timelineCurrentpageSize}
            onFilteredChange={false}
            defaultSortDesc={false}
            PaginationComponent={Pagination}
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
         />
         <div>
             {/* remove unused CSS */}
         <span class="select-wrap -pageSizeOptions select_recordSummary" style= {{marginRight:'15px' }}>
             <span className="select_pageSummary">Per page</span>
        <select id = "summaryId" aria-label="rows per page"
        defaultValue={this.state.timelineCurrentpageSize} 
        onChange ={this.handleSelectEventChange.bind(this)} className="select_rowSummary">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="60">60</option>
            <option value="80">80</option>
            <option value="100">100</option>
        </select>
        </span>
        </div>
        </div>;

}catch(error){
    window.alert(error);
}
    } 
    
}

export default PeriodSummaryTLGrid;