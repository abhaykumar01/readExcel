import React from 'react';
import '../../../../index.css';
import Dropdownfield from '../../../../commonComponents/DropdownField';
import { Select } from '@zambezi/sdk/dropdown-list';
import PrismCurveTLGrid from './prismCurveTLGrid'
import CurveToCustomerTLGrid from './curveToCustomerTLGrid';


class CurveSummaryTL extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            userTableData : [],
            selectTimelineTypeData: 'standard',
            setTimelinebutton :  true,
            currency:'',
            timelineCurrentpageSize:20,
            showPeriodTL:true,
            leaseData:null,
            showInterestRateSens: false,

        }
    }

    componentDidMount(){
          // var leaseContract = localStorage.getItem('leaseResponseData');
          var leaseContract = this.props.dataFromParent;
        //   var stringdata = JSON.stringify(leaseContract);
          // window.alert(stringdata);
          if(leaseContract !== null){
            //   this.generateData(leaseContract);
              this.setState({currency:leaseContract.currency});
              this.setState({leaseData:leaseContract});
          }
    }

    selectTimelineType(selectTimelineTypeData) {
        console.log("Deal type", selectTimelineTypeData);
        if (selectTimelineTypeData === 'standard') {
            this.setState({ setTimelinebutton: true  });
        } else {
            this.setState({ setTimelinebutton: false });
        }
        return true;
    }

    handleSelectEventChange(event){
        var currentComponent = this;
        currentComponent.setState({ timelineCurrentpageSize: event.target.value });
    }

    generateData(type) {

        const data = [];
        if (type == "curveType") {
            // window.alert('inside invoice freq'+ this.state.invoiceFeq);
            data.push(
                "Lease fee",
                "Guarantee amount"
            );
        } else if (type == "language") {
            // window.alert('inside invoice freq'+ this.state.invoiceFeq);
            data.push(
                "English",
                "Swedish",
                "Finnish"
            );
        }
        return data
    }

    render(){
        
        return (<div>
            <div>
            <div class="form-group row colour_white">
                 <div className="col-sm-4" >
                     <div class="summary_type_model">
                             <div class="btn-group">
                                    <button type="button" className={"btn btn-primary standard_twoway_btn " + (this.state.setTimelinebutton ? 'periodSummarytype_selected' : 'periodSummarytype_notselected')} onClick={this.selectTimelineType.bind(this, 'standard')}>Curve to customer</button>
                                    <button type="button" className={"btn btn-primary standard_twoway_btn " + (!this.state.setTimelinebutton ? 'periodSummarytype_selected' : 'periodSummarytype_notselected')} onClick={this.selectTimelineType.bind(this, 'construction')}>Prism curve</button>
                                </div>
                            </div>
                     </div>
                     <div>
                         {this.state.setTimelinebutton ?
                            <div>
                                <label for="inputState" 
                                style={{color:'#666666', marginRight:'3px' , marginLeft:'100px', marginTop:'25px', fontWeight:'400', fontSize:'16px'}} >Language:</label>
                                    <Select className ="periodTimelineComboBox"
                                        suggestions={this.generateData('language')}
                                    />
                                    
                                <label for="inputState" 
                                style={{color:'#666666', marginRight:'3px' , marginLeft:'20px', marginTop:'25px', fontWeight:'400', fontSize:'16px'}} >Type:</label>
                                    <Select className ="periodTimelineComboBox"
                                        suggestions={this.generateData('curveType')}
                                    />
                            <label class="dealDescription_label" style={{color:'#666666', marginRight:'3px', marginLeft:'25px', marginTop:'25px', fontWeight:'400'}}>Currency:</label>
                            <label class="dealDescription_label">{this.state.currency}</label>
                            </div>:<div>
                                <label class="dealDescription_label" style={{color:'#666666', marginRight:'3px', marginLeft:'100px', marginTop:'25px', fontWeight:'400'}}>Currency:</label>
                                <label class="dealDescription_label">{this.state.currency}</label>
                            </div>
                         }
                    </div>
                    
                    {(()=>{
                         if(this.state.setTimelinebutton == true){
                           return <CurveToCustomerTLGrid dataFromParent = {this.props.dataFromParent.leaseModels} />;
                        } else {
                           return <PrismCurveTLGrid dataFromParent = {this.props.dataFromParent.leaseModels} />;
                        }
                    })()}
                    
                </div>
                
            </div>
            <div>
            </div>
        </div>);
    }

}

export default CurveSummaryTL;