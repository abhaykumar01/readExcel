import React from 'react';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import { Route, withRouter } from 'react-router-dom';
import './../periodSummary.css';
import Pagination from '../../../../commonComponents/pagination.js';
import { HttpPost, HttpGet } from '../../../../services/api.js';
import moment from 'moment';
import { FormattedAmount } from '@zambezi/sdk/formatted-input';
import {precisePercentage, precise} from '../../../../utils/LeaseUtils.js';
import LocaleFormattedValue from '../../../../commonComponents/LocaleFormattedValue';

class PrismCurveTLGrid extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            timelineCurrentpageSize: 20,
            userTableData: [],
            loading: false,
        }
        this.precise = precise;
    }

    addPercent(x){
          return x.toString().concat('%');
      }
    componentDidMount(){
        var currentComponent = this;
        var leaseModels = this.props.dataFromParent;
        if(leaseModels !== null && leaseModels !== undefined ){
        
            var dataFormat = {
                operatingLease:0.00,
                residualValue:0.00,
            }
            var output = [];
            var recordCount = leaseModels.length;
            for (var j = 0; j < recordCount; j++) {
            //   var periodstartDate = moment(leaseModels[j].periodStartDate).format('DD/MM/YYYY');
            //   var periodendDate = moment(leaseModels[j].periodEndDate).format('DD/MM/YYYY');
              var periodstartDate = leaseModels[j].periodStartDate;
              var periodendDate = leaseModels[j].periodEndDate;
                dataFormat = {
                    dates:[periodstartDate, periodendDate],
                    operatingLease: currentComponent.precise(leaseModels[j].operatingLease),
                    residualValue:currentComponent.precise(leaseModels[recordCount-1].closingBalance),
                    }
                var temp = JSON.parse(JSON.stringify(dataFormat));
                output.push(temp);

            }
            currentComponent.setState({userTableData:output});
         }
    }

    handleSelectEventChange(event){
        var currentComponent = this;
        currentComponent.setState({ timelineCurrentpageSize: event.target.value });
    }

    handleOnLoadPagination(event){
        var currentComponent = this;
       // window.alert(this.state.timelineCurrentpageSize);
    }
    
    render(){
        try{
        const columns = [{
            id: 'Dates',
            Header: 'Dates',
            accessor: 'dates',
            headerClassName: 'periodSummaryheader',
            filterable: false,
            className: 'periodSummary_cell',
            width: 200,
            Cell: row => <div style={{ marginLeft:'5px', marginRight:'5px', textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                            <LocaleFormattedValue type={'dateRange'} delimiter={'-'} value={row.value} />
                        </div>,
        },{id: 'openingLease',
        Header: 'Operating lease',
        accessor: 'operatingLease',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width:140
        },
        {id: 'residualValue',
        Header: 'Non-agg facility (residual value)',
        accessor: 'residualValue',
        headerClassName: 'periodSummaryheader',
        filterable: false,
        className: 'periodSummary_cell',
        Cell: row => <div style={{ textAlign: "center", lineHeight: '2.42857', fontFamily: 'RNFontRegularWoff', fontSize: '16px' }}>
                        <LocaleFormattedValue type={'currency'} value={row.value} />
                    </div>,
        width: 160},
        {}
    ];

        return <div className="grid_layout" >
            <ReactTable
            data={this.state.userTableData} 
            columns={columns}
            // loading={this.state.loading}
            showPagination={true}
            showPaginationTop={false}
            showPaginationBottom={true}
            showPageSizeOptions = {true}
            defaultSortDesc = {false}
            className='-striped -highlight summaryTable'
            headerClassName= 'periodSummaryheader'
            defaultPageSize={20}
            pageSize = {this.state.timelineCurrentpageSize}
            onFilteredChange={false}
            defaultSortDesc={false}
            PaginationComponent={Pagination}
            previousText = 'Previous'
            nextText = 'Next'
            loadingText = 'Loading...'
            pageText= 'Page'
            ofText= 'of'
            rowsText= 'rows'
         />
         <div>
             {/* remove unused CSS */}
         <span class="select-wrap -pageSizeOptions select_recordSummary" style= {{marginRight:'15px' }}>
             <span className="select_pageSummary">Per page</span>
        <select id = "summaryId" aria-label="rows per page"
        defaultValue={this.state.timelineCurrentpageSize} 
        onChange ={this.handleSelectEventChange.bind(this)} className="select_rowSummary">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="60">60</option>
            <option value="80">80</option>
            <option value="100">100</option>
        </select>
        </span>
        </div>
        </div>;

}catch(error){
    window.alert(error);
}
    } 
    
}

export default PrismCurveTLGrid;