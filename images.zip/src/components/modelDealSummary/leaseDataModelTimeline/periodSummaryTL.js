import React from 'react';
import '../../../index.css';
import PeriodSummaryTLGrid from './periodSummaryTLGrid'
import AnnualSummaryTLGrid from './annualSummaryTLGrid';
import Dropdownfield from '../../../commonComponents/DropdownField';
import { Select } from '@zambezi/sdk/dropdown-list';
import PeriodInterestRateGrid from './InterestRateSensitivity/periodInterestRateGrid';
import AnnualInterestRateGrid from './InterestRateSensitivity/annualInterestRateGrid';

class PeriodSummaryTL extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            userTableData : [],
            selectTimelineTypeData: 'standard',
            setTimelinebutton :  true,
            currency:'',
            invoiceFeq:'',
            timelineCurrentpageSize:20,
            showPeriodTL:true,
            leaseData:null,
            showInterestRateSens: false,

        }
    }

    componentDidMount(){
          // var leaseContract = localStorage.getItem('leaseResponseData');
          var leaseContract = this.props.dataFromParent;
        //   var stringdata = JSON.stringify(leaseContract);
          // window.alert(stringdata);
          if(leaseContract !== null){
            //   this.generateData(leaseContract);
              this.setState({currency:leaseContract.currency});
              this.setState({leaseData:leaseContract});

              var leasefeqPerPeriod = "Annually"
              if(leaseContract.invoicingFrequencyPerAnnum == 4){
                    leasefeqPerPeriod = "Quaterly"
              } else if (leaseContract.invoicingFrequencyPerAnnum == 2){
                    leasefeqPerPeriod = "Semi-Annually"
              } else if (leaseContract.invoicingFrequencyPerAnnum == 12){
                    leasefeqPerPeriod = "Monthly"
            }
            this.setState({invoiceFeq:leasefeqPerPeriod});
          }

    }

    selectTimelineType(selectTimelineTypeData) {
        if (selectTimelineTypeData === 'standard') {
            this.setState({ setTimelinebutton: true  });
        } else {
            this.setState({ setTimelinebutton: false });
        }
        return true;
    }

    handleSelectEventChange(event){
        var currentComponent = this;
        // window.alert("Dropdown change value:: "+ event.target.value);
        currentComponent.setState({ timelineCurrentpageSize: event.target.value });
        // window.alert(this.state.timelineCurrentpageSize);
    }

    getDropdownItem(event, val, type) { 
        // window.alert("getDropdownItem"+type.value + event);
        if (event == "invoiceFeqType") {
            // window.alert("invoiceFeqType");
            if (type.value == "Annually") {
                //window.alert("getDropdownItem Annually");
                this.setState({ showPeriodTL: false});
            } else {
                // window.alert("getDropdownItem+ not Annually");
                this.setState({ showPeriodTL: true});
            }
        }
    }

    generateData(type) {
        // window.alert('inside generateData' + type);
        var data = [];
        if (type == "invoiceFeqType" && this.props.dataFromParent.invoicingFrequencyPerAnnum !== 1) {
            // window.alert('inside invoice freq'+ this.state.invoiceFeq);
            data.push(
                this.state.invoiceFeq,
                // "Quaterly",
                "Annually"
            );
        } 
        else {
            data.push(
                "Annually"
            );
        }
        return data
    }

    render(){
        
        return (<div>
            <div>
            <div class="form-group row colour_white">
                 <div className="col-sm-4" >
                     <div class="summary_type_model">
                             <div class="btn-group">
                                    <button type="button" className={"btn btn-primary standard_twoway_btn " + (this.state.setTimelinebutton ? 'periodSummarytype_selected' : 'periodSummarytype_notselected')} onClick={this.selectTimelineType.bind(this, 'standard')}>Period summary</button>
                                    <button type="button" className={"btn btn-primary standard_twoway_btn " + (!this.state.setTimelinebutton ? 'periodSummarytype_selected' : 'periodSummarytype_notselected')} onClick={this.selectTimelineType.bind(this, 'construction')}>Interest rate sensitivity</button>
                                </div>
                            </div>
                     </div>
                     <div >
                        <label for="inputState" 
                        style={{color:'#666666', marginRight:'3px' , marginLeft:'100px', marginTop:'25px', fontWeight:'400', fontSize:'16px'}} >Summary:</label>
                            <Select className ="periodTimelineComboBox"
                                defaultValue={this.state.invoiceFeq} placeholder='Select'
                                suggestions={this.generateData('invoiceFeqType')}
                                onChange={this.getDropdownItem.bind(this, 'invoiceFeqType')}
                            />
                        <label class="dealDescription_label" style={{color:'#666666', marginRight:'3px', marginLeft:'30px', marginTop:'25px', fontWeight:'400'}}>Currency:</label>
                            <label class="dealDescription_label">{this.state.currency}</label>
                    </div>
                    
                    {(()=>{
                        //window.alert("this.state.setTimelinebutton"+this.state.setTimelinebutton +"this.state.showPeriodTL"+this.state.showPeriodTL);
                        if(this.state.setTimelinebutton == true){
                            if(this.state.showPeriodTL == true){
                               return <PeriodSummaryTLGrid dataFromParent = {this.props.dataFromParent.leaseModels} />;
                            } else {
                              return <AnnualSummaryTLGrid dataFromParent = {this.props.dataFromParent} />;
                            }

                        } else {
                            if(this.state.showPeriodTL == true){
                                return <PeriodInterestRateGrid dataFromParent = {this.props.dataFromParent} />;
                             } else {
                               return <AnnualInterestRateGrid dataFromParent = {this.props.dataFromParent} />;
                             }
                        }
                    })()}
                    
                </div>
                
            </div>
            <div>
            </div>
        </div>);
    }

}

export default PeriodSummaryTL;