import React from 'react';
import { HttpPost} from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';

class SPVSectionComponent extends React.Component {
    constructor(props){
        super(props);
        this.state= {'spvData':[]};
    }
    componentDidMount(){
        const endPoint = API_ENDPOINT.GET_CUSTOMER_SPV+"/"+this.props.spvdata.partyID;
        const data = this.props.spvdata
        HttpPost(this, data , endPoint).then( (response)=> {
            this.setState({'spvData':response.data})
        })
    }
    
    render() {
        return (
            
            <div className="row" style={{ margin: '2% 0 2% 0' }}>
             { this.state.spvData.map( (item, index) =>{
               return(
            <div class="itemCol">
                        <div className="itemRow">
                            <label className="title">SPV number</label>
                            <label className="titleVal">{item.spvNumber}</label>
                        </div>
                        <div className="itemRow">
                            <label className="title">Active deals</label>
                            <label className="titleVal">
                            { item.activeDealNumbersList.map( (itemchild, index) =>{
                                    return(<span >{itemchild}</span>)
                                })}
                            </label>
                        </div>
                        <div className="itemRow">
                            <label className="title">Pending deals</label>
                            <label className="titleVal">
                            { item.pendingDealNumbersList.map( (itemchild, index) =>{
                                    return(<span >{itemchild}</span>)
                                })}
                            </label>

                        </div>
                    </div>)})}          
           
            </div>
        )
    }
}

export default SPVSectionComponent;