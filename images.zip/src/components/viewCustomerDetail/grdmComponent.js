import React from 'react';

const GRDMComponent=(props) =>{
    return(<div className="row grdmDetailRow" >
                    <div className="col-xs-4">
                        <div className="row">
                            <label className="titleLabel">RWA</label>
                            <label className="valLabel"><b>{props.data.totalRWASum}</b></label>
                        </div>
                        <div className="row">
                            <label className="titleLabel">BV</label>
                            <label className="valLabel"><b>{props.data.bookValue}</b></label>
                        </div>
                        <div className="row">
                            <label className="titleLabel">RV</label>
                            <label className="valLabel"><b>{props.data.residualValueSum}</b></label>
                        </div>
                    </div>
                    <div className="col-xs-4">
                        <div className="row">
                            <label className="titleLabel">RV/VPV</label>
                            <label className="valLabel"><b>{props.data.residualValueByVPVSum}</b></label>
                        </div>
                        <div className="row">
                            <label className="titleLabel">loRWA</label>
                            <label className="valLabel"><b>{props.data.ioRWASum}</b></label>
                        </div>
                        <div className="row">
                            <label className="titleLabel">Margin</label>
                            <label className="valLabel"><b>{props.data.marginPercentage}</b></label>
                        </div>
                    </div>
                    <div className="col-xs-4">
                        <div className="row">
                            <label className="titleLabel">Number of deals</label>
                            <label className="valLabel"><b>{props.data.numberOfDeals}</b></label>
                        </div>
                    </div>
                        
                    </div>
    )
}
export default GRDMComponent;