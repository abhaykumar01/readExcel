export const initialState =
  {
    "partyID": 304,
    "partyComment": null,
    "enityTypeID": null,
    "externalName": null,
    "partyName": "Edward",
    "sector": "Private",
    "taxNR": null,
    "tradingAsName": null,
    "isCustomer": "Y",
    "custInvTemplateID": null,
    "custOverdueInterest": null,
    "customerTypeID": 200,
    "companyType": null,
    "isTenant": "N",
    "isSPV": "N",
    "isSeller": "N",
    "sellerIsOCC": null,
    "partyStatus": "Active",
    "cisCode": "121",
    "creditRating": 23,
    "kycStatus": "Active",
    "nonAggregatedFacilityId": 124354,
    "operatingLeaseFacilityId": 12345,
    "createdOn": "2019-06-18T12:09:42.049+0000",
    "webPageUrl": null,
    "competitors": null,
    "masterGradingScale": 3,
    "organisationNo": 125,
    "isAllowedToAllUsers": null,
    "country": "sweden",
    "annualReviewDate": null,
    "bookValue": null,
    "totalRWASum": null,
    "residualValueSum": null,
    "residualValueByVPVSum": null,
    "ioRWASum": null,
    "marginPercentage": null,
    "numberOfDeals": null,
    "partyContacts": [
      {
        "contactID": 308,
        "contactType": null,
        "businessEmailAddress": "anithnanthi",
        "partyID": 304,
        "contactName": "Anitha",
        "contactRole": "CEO",
        "officeTelephoneNumber": "8870",
        "mobileTelephoneNumber": "88709",
        "countryCode": null,
        "countryName": "india",
        "streetAddressLine1": "8 eswaran",
        "streetAddressLine2": "bhuvanagiri",
        "streetAddressLine3": "Tamil nadu",
        "postCode": "608601",
        "cityName": null,
        "suburbName": null,
        "partyContactHistoryID": null
      },
      {
        "contactID": 309,
        "contactType": null,
        "businessEmailAddress": "anithnanthi",
        "partyID": 304,
        "contactName": "Suriya",
        "contactRole": "CEO",
        "officeTelephoneNumber": "8870",
        "mobileTelephoneNumber": "88709",
        "countryCode": null,
        "countryName": "india",
        "streetAddressLine1": "8 eswaran",
        "streetAddressLine2": "bhuvanagiri",
        "streetAddressLine3": "Tamil nadu",
        "postCode": "608601",
        "cityName": null,
        "suburbName": null,
        "partyContactHistoryID": null
      }
    ],
    "partyBankAccounts": [],
    "partyCreditRatings": [],
    "partyUsers": [],
    "partyRestrictions": [],
    "partyComments": [
      {
        "partyCommentID": 63,
        "partyID": 761,
        "partyCommentDescription": "FirstComment",
        "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
      },
      {
        "partyCommentID": 45,
        "partyID": 761,
        "partyCommentDescription": "FirstComment",
        "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
      },
      {
        "partyCommentID": 65,
        "partyID": 761,
        "partyCommentDescription": "FirstComment",
        "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
      },
      {
        "partyCommentID": 34,
        "partyID": 761,
        "partyCommentDescription": "FirstComment",
        "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
      }
    ],
    "partyFlag": "MAIN",
    "partyHistoryID": null
  };
  export const comments =[
    {
      "partyCommentID": 63,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },
    {
      "partyCommentID": 45,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },
    {
      "partyCommentID": 65,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },
    {
      "partyCommentID": 34,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },
    {
      "partyCommentID": 34,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },
    {
      "partyCommentID": 34,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },
    {
      "partyCommentID": 34,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    },{
      "partyCommentID": 34,
      "partyID": 761,
      "partyCommentDescription": "FirstComment",
      "partyCommentCreatedOn": "2020-03-13T10:49:54.553+0000"
    }
  ]
   export const dummycontacts=[{
    "contactID": 308,
    "contactType": null,
    "businessEmailAddress": "anithnanthi",
    "partyID": 304,
    "contactName": "Anitha",
    "contactRole": "CEO",
    "officeTelephoneNumber": "8870",
    "mobileTelephoneNumber": "88709",
    "countryCode": null,
    "countryName": "india",
    "streetAddressLine1": "8 eswaran",
    "streetAddressLine2": "bhuvanagiri",
    "streetAddressLine3": "Tamil nadu",
    "postCode": "608601",
    "cityName": null,
    "suburbName": null,
    "partyContactHistoryID": null
  },
  {
    "contactID": 309,
    "contactType": null,
    "businessEmailAddress": "anithnanthi",
    "partyID": 304,
    "contactName": "Suriya",
    "contactRole": "CEO",
    "officeTelephoneNumber": "8870",
    "mobileTelephoneNumber": "88709",
    "countryCode": null,
    "countryName": "india",
    "streetAddressLine1": "8 eswaran",
    "streetAddressLine2": "bhuvanagiri",
    "streetAddressLine3": "Tamil nadu",
    "postCode": "608601",
    "cityName": null,
    "suburbName": null,
    "partyContactHistoryID": null
  }]
  
export const resetState = {
    documentUploadStatus: true,
    uploadedFileName: '',
    documentDescription: '',
    selectedFile: '',
    textErrorStatus: false,
    dialogDismiss: '',
    docType: '',
    docLengthStatus: false,
    errorMessage: '',          
    partyID: 0,
    showData: false,
    rbsClassificationVal: '',
    rbsRecordVal: '',
    rbsRiskVal: '',
    rbsClassificationValErrorStatus: '',
    rbsRecordValErrorStatus: '',
    rbsRiskValErrorStatus: '',
    rbsClassificationValErrorMessage: '',
    rbsRecordValErrorMessage: '',
    rbsRiskValErrorMessage: '',
    recordView: '10',
    showCustomerDocuments: true,
    pendingCount: 0,
    deleteStatus: '',
    deletedDocName: '',
    docUserName: '',
    retrieveDoc: false,            
    pageStatus: '',
    showDocData: true,
    confirmMessage: '',
    failureMessage: '',
    rejectionReason: '',
    contactLength: 3,
    racfID: ''
};
export const deleteObj = {
    uploadedFileName: '',
    selectedFile: '',
    fileUploadStatus: false,
    documentUploadStatus: true,
    rbsClassificationVal: '',
    rbsRecordVal: '',
    rbsRiskVal: '',
    rbsClassificationValErrorStatus: '',
    rbsRecordValErrorStatus: '',
    rbsRiskValErrorStatus: '',
    rbsClassificationValErrorMessage: '',
    rbsRecordValErrorMessage: '',
    rbsRiskValErrorMessage: '',
    documentDescription: ''
}
export const modalMessage={
  "deleteMsg":"Are you sure you want to delete the customer ? This cannot be undone.",
  "archiveMsg":["Are you sure you want to delete the customer ?" , "It will require secondary approval by another authoriser"],
}
export const customerMandatoryFields=[
  "masterGradingScale",
  "partyName",
  "sector",
  "customerTypeID",
  "cisCode",
  "kycStatus",
  "companyType",
  "country"  
]