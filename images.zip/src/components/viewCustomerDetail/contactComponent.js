import React, { Fragment } from 'react';

class ContactDetailComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = { }
    }
    componentWillMount() {
        let stateData = [];
        var contactIdArray = [];
        

        if(this.props.userData.partyStatus==="In Progress" && this.props.prevData !== null){
            var userdata =  this.props.userData;
            var prevData = this.props.prevData;
            for(var i=0; i<prevData.partyContacts.length; i++){
                contactIdArray.push(prevData.partyContacts[i].contactID)
            }

            if(userdata.removedPartyContacts.length > 0){
                userdata.partyContacts =  [...userdata.partyContacts, ...userdata.removedPartyContacts]
            }
            
            userdata.partyContacts.map( (item, index) =>{   
                var id = item.contactID;
                if(id === null){
                    stateData.push(this.compareContactData(item, null));
                    stateData[index].contactDetailFlag = 2
                }else if(contactIdArray.indexOf(id) < 0){
                    stateData.push(this.compareContactData(item, null));
                    stateData[index].contactDetailFlag = 1
                }else{
                    const _prevdata = prevData.partyContacts.filter(function(item){
                        if(item.contactID === id){ return item} 
                    })
                    stateData.push(this.compareContactData(item, _prevdata[0]));
                    stateData[index].contactDetailFlag = 0
                }
            });

        }else{
            this.props.userData.partyContacts.map( (item, index) =>{
                stateData.push(this.compareContactData(item, null));
            });
            
        }
        this.setState({contactdata:[...stateData] })
     }
     compareContactData(item, prevdata){
         let stateData = []
        let objectToCheck = ["contactName", "contactRole", "officeTelephoneNumber", "mobileTelephoneNumber", "businessEmailAddress", "address", "cityName", "postCode", "countryName"];
        const objectKeyMap = {
            "contactName": "Contact name",
            "contactRole": "Contact role",
            "officeTelephoneNumber": "Office number",
            "mobileTelephoneNumber": "Mobile number",
            "businessEmailAddress": "Email address",
            "address": "Address",
            "cityName": "City",
            "postCode": "Postcode",
            "countryName": "Country"
        }
        if(this.props.userData.partyStatus === "In Progress" && prevdata !== null){
            for (var i = 0; i < objectToCheck.length; i++) {
                stateData.push({
                    "name": objectKeyMap[objectToCheck[i]],
                    "value": item[objectToCheck[i]],
                    "isEdited": (item[objectToCheck[i]] !== prevdata[objectToCheck[i]]) ? true : false,
                    "oldValue": (item[objectToCheck[i]] !== prevdata[objectToCheck[i]]) ? prevdata[objectToCheck[i]] : ''
                })
            }
        }else {
            for (var i = 0; i < objectToCheck.length; i++) {
                stateData.push({
                    "name": objectKeyMap[objectToCheck[i]],
                    "value": item[objectToCheck[i]],
                    "isEdited": false,
                    "oldValue": ''
                })
            }
        }
        
        return stateData;
       
     }
     checkcontactFlag =(e, item)=>{
        let _toreturn = "contactBox"
        if(item.contactDetailFlag === 1){
            _toreturn = "contactBox deletedComponent"
        }else if(item.contactDetailFlag === 2){
            _toreturn = "contactBox addedComponent"
        }else{
            _toreturn = "contactBox editedComponent"
        }
        return _toreturn;
     }
     headerStatus =(e, item)=>{
        let _toreturn = ""
        if(item.contactDetailFlag === 1){
            _toreturn = "- Removed"
        }else if(item.contactDetailFlag === 2){
            _toreturn = "- Added"
        }
        return _toreturn;
     }
    render() {
        /*
        Fix this componenwill
        let address = this.props.userContact.streetAddressLine1
         if (this.props.userContact.streetAddressLine2) { 
             address += ' ' + this.props.userContact.streetAddressLine2
         } */
        // let address =  this.props.userContact.streetAddressLine1 + ' ' + this.props.userContact.streetAddressLine2;
        //"contactBox"
        return (
            <div className="row " style={{ 'margin': '2% 0 2% 0', 'display':'flex','flexWrap':'wrap' }}>
               {
                    this.state.contactdata.map( (item, index) =>{
                    return (<div class={this.checkcontactFlag(this, item)}>
                                <div className="header">Contact {index + 1} <span className="headerstatus" style={{'padding': '0 5px'}}>{this.headerStatus(this, item)}</span></div>
                                {
                                    item.map( (itemchild, childindex) =>{
                                        return(<div className="contactBoxRow" >
                                        <div className="leftcolumn">{itemchild.name}</div>
                                        <div className="rightcolumn"><label className={(itemchild.isEdited) ? "highlighted " : "activeValue"}>{itemchild.value}</label>
                                            {(itemchild.isEdited) ? <div className="oldText">{itemchild.oldValue}</div> : null}
                                        </div>
                                    </div>)
                                    })
                                }
                        </div>)
                    }) 
                }
            </div>
            
        );
    }
}

export default ContactDetailComponent