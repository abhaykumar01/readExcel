import React, { Fragment } from 'react';
import './viewCustomerDetail.css';
import CompanyDetaillComponent from './companyDetailComponent';
import ContactDetailComponent from './contactComponent';
import SPVSectionComponent from './spvSectionComponent';
import { HttpGet, HttpPostDocuments , HttpDelete, HttpPut, HttpPutWithoutBody} from '../../services/api.js';
import { API_ENDPOINT } from '../../config/config.js';
import { withRouter } from 'react-router-dom';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import { Icon } from '@zambezi/sdk/icons';
import DocumentUpload from '../../commonComponents/documentsUpload';
import DocumentGrid from '../../commonComponents/documentsGrid';
import ApproverDocumentGrid from '../../commonComponents/approverDocumentsGrid';
import { uploadDocuments, RequestApproval, ApproveRejectParty,checkDocumentNamingFormat } from '../../models/dataModel.js';
import { Notification } from '@zambezi/sdk/notification';
import { validate } from '../../utils/validation.js';
import moment from 'moment';
import { Select } from '@zambezi/sdk/dropdown-list';
import { AuthorizationContext } from '../authContext/index.js'
import { formatResultsErrors } from 'jest-message-util';
import { initialState, resetState, deleteObj, comments, dummycontacts, modalMessage, customerMandatoryFields } from './constants';
import GRDMComponent from './grdmComponent';
import ModalPopup from './modal';


const PING = process.env.REACT_APP_PING;

class viewCustomerDetail extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = { 'partyID': localStorage.getItem('userID'), 'partyStatus': localStorage.getItem('userStatus'), 'partyFlag':localStorage.getItem('partyFlag'),"partyHistoryID":localStorage.getItem('partyHistory') , userData: null , prevData: null ,isDelete: false, commentEdited:true, isArchive:false, emptyMandatoryFields : [],pendingRequestApprovalData: true};
        this.inputOpenFileRef = React.createRef();
    }
    componentDidMount() {
        
        window.scrollTo(0, 0);
        let ID = localStorage.getItem("approver");
        console.log("on mount");
        console.log(ID);
        var userID = '';
        var roleName = '';
        var data;
        if (PING == 'true') {
            let { usersDetails, name } = this.context;
            userID = usersDetails.userID;
            data = usersDetails.permissions;
            roleName = usersDetails.memberOf;
        } else {
            userID = localStorage.getItem('racfID');
            let response = localStorage.getItem('permissions');
            data = JSON.parse(response);
            roleName = localStorage.getItem('roleName');
        }
        console.log("userID");
        console.log(userID);
        this.setState({
            racfID: userID,
            permissionData: data,
            roleName: roleName
        });
        // if (ID == "true") {
        //     localStorage.setItem("docUpload", "approverDocUpload1");
        // } else {
            localStorage.setItem("docUpload", "userDocUpload1");
            let message = localStorage.getItem("Message");
            if (message) { 
                var obj = JSON.parse(message);
                if (obj.status == "Approved") {
                    this.setState({
                        pageStatus: "docDeletedSuccess",
                        confirmMessage: obj.description
                    });
                } else if (obj.status == "Rejected") { 
                    this.setState({
                        pageStatus: "docDeletedFailed",
                        failureMessage: obj.description,
                        rejectionReason: obj.reasonForRejection
                    });
                }
                
            }
        // }
        var saveStatus = localStorage.getItem('datasave');
        var changeStatus = localStorage.getItem('datachange');
        if (saveStatus == 'true') { 
            this.setState({ pageStatus: 'saveSuccess' });
        }
        if (changeStatus == 'true') {
            this.setState({ pageStatus: 'changeSuccess' });
        } else {
         }
        this.fetchCustomerDocuments();
        
    }
    componentWillUnmount(){
        localStorage.setItem('datasave', 'false');
        localStorage.setItem('datachange', 'false');
    }
    displayApproveRejectButton() {
        if (this.state.roleName.indexOf('rAppNordiskLMS-GeneralFinanceUser') == -1 && this.state.userData.partyStatus == "Pending Approval" &&
            this.state.userData.requestedBy !== this.state.racfID) {
            this.setState({ showApproveRequestButton: true });
        }
        else {
            this.setState({ showApproveRequestButton: false });
        }
    }

    fetchCustomerDocuments() {
        var currentComponent = this;
        let partyID = currentComponent.state.partyFlag ==="COPY" ? currentComponent.state.partyHistoryID: currentComponent.state.partyID
        let endPoint = API_ENDPOINT.GET_PARTY_DETAIL + '/' + currentComponent.state.partyFlag + "/"+ partyID;
        console.log("Service call");
        let userData={}, partyStatus="";
        HttpGet(currentComponent, endPoint).then( (response)=> {
            localStorage.setItem('username', response.data.partyName);
            userData=  response.data
            partyStatus= response.data.partyStatus
        }).then( ()=>{
            if(currentComponent.state.partyFlag === "COPY"){
                let url = API_ENDPOINT.GET_PARTY_DETAIL + '/MAIN/'+ currentComponent.state.partyID;
                HttpGet(currentComponent, url).then( (response)=> {
                    currentComponent.setState({
                        'partyID': partyID,                    
                        'partyStatus': partyStatus,
                        'contactLength': userData.partyContacts.length,
                        'userData':  userData,
                        'prevData':response.data || {}
                    })                  
                    this.displayApproveRejectButton();
                })
            }else{
                currentComponent.setState({
                    'partyID': partyID,                    
                    'partyStatus': partyStatus,
                    'contactLength': userData.partyContacts.length,
                    'userData':  userData,
                    'prevData': null
                })
                this.displayApproveRejectButton();
            }          
            
        }).catch(function (error) {
        })
    }


    viewParty() {
        this.props.history.push('/lms/viewCustomerList');
        return true;
    }

    resetData() {
        this.setState({ ...resetState }, function () {
        });
    }

    pendingCount(count) { 
        this.setState({
            pendingCount: count,
            pageStatus: 'docPendingApproval',
        }, function () {
        })
        return true;
    }

    deletionStatus(count, docName, cname) { 
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pendingCount: count,
            deleteStatus: 'approverDocDeleted',
            pageStatus: 'docPendingApproval',
            deletedDocName: docName,
            docUserName: cname,
        }, function () {
                this.forceUpdate();
        })
        return true;
    }

    uploadApprovalStatus(docName, cname) {
        console.log("uploadApprovalStatus");
        console.log(docName);
        console.log(cname);
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pageStatus: 'docUploadApproved',
            deletedDocName: docName,
            docUserName: cname,
        }, function () {
                this.forceUpdate();
        })
        return true;
    }

    uploadRejectStatus(docName, reason, approverName) {
        // /docDeleteRejected
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({
            pageStatus: 'docUploadRejected',
            deletedDocName: docName,
            rejectionReason: reason,
            approverName: approverName
        }, function () { 
                this.forceUpdate();
        })
        return true;
    }

    rejectStatus(docName) { 
        // /docDeleteRejected
        this.setState({
            pageStatus: 'docDeleteRejected',
            deletedDocName: docName,
        })
        return true;
    }

    uploadDocuments() {
        var userID = '';
        var roleName = '';
        var userName = '';
        if (PING == 'true') {
            let { usersDetails, name } = this.context;
            userID = usersDetails.userID;
            roleName = usersDetails.memberOf;
            userName = name;
        } else {
            userID = localStorage.getItem('racfID');
            roleName = localStorage.getItem('roleName');
            userName = 'Joe Doe';
        }
        this.validateField();
        var obj = localStorage.getItem('errorStatus');
        if (this.state.rbsClassificationVal && this.state.rbsRecordVal && this.state.rbsRiskVal && this.state.documentDescription) {
            var currentComponent = this;
                this.setState({
                    dialogDismiss: 'modal',
                });
            let id = parseInt(localStorage.getItem('userID'));
            let doctype = ''

            if (this.state.docType == "") {
                doctype = "msg";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || 
                this.state.docType == "application/vnd.ms-excel") { 
                doctype = "excel";
            } else if (this.state.docType == "application/pdf") {
                doctype = "pdf";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                doctype = "doc";
            } else if (this.state.docType == "application/msword") {
                doctype = "doc";
            } else if (this.state.docType == "image/png") {
                doctype = "png";
            } else if (this.state.docType == "image/jpeg") {
                doctype = "jpg";
            } else if (this.state.docType == "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
                doctype = "ppt";
            }
            doctype = doctype.toUpperCase();
            let isApprovalrequired= 0;
            let isHighRisk = 0;
            let isApproved = "Approved";
            let riskVal = '';
            console.log("Role name");
            console.log(roleName);
            console.log(roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1)
            if (this.state.rbsRiskVal == "High Risk") {
                riskVal = 'High risk';
                isHighRisk = 1;
                if (roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1) {
                        isApprovalrequired = 0;
                        isApproved = "Approved";
                    } else { 
                        isApprovalrequired = 1;
                        isApproved = "PendingApproval";
                    }                
            } else if (this.state.rbsRiskVal == "Secondary Risk") {
                riskVal = 'Secondary risk';
            } else if (this.state.rbsRiskVal == "Historical") { 
                riskVal = 'Historical';
            }
            console.log("Doctype:: ", doctype);
            console.log("Risk:: " + riskVal);
            console.log("RacfID:: " + this.state.racfID);
            let payLoadData = uploadDocuments(this.state.uploadedFileName, doctype, this.state.documentDescription, id,
                this.state.rbsClassificationVal, this.state.rbsRecordVal, riskVal, null, null, userID, null,
                isApproved, isApprovalrequired, isHighRisk, userName);
                let endPoint = API_ENDPOINT.UPLOAD_DOCUMENTS + '/uploadDoc/customer';
                const formData = new FormData();
                formData.append('file', this.state.selectedFile);
            formData.append('documentDetails', JSON.stringify(payLoadData));
            this.setState({ showData: true });
            console.log("payLoadData:: ");
            console.log(payLoadData);
            let output = HttpPostDocuments(currentComponent, formData, endPoint)
                .then(function (response) {
                    console.log("Service response");
                    console.log(response)
                    if (response.status == 200 || response.status ==  201) {
                        // let ID = localStorage.getItem("approver");
                            let docUpload = localStorage.getItem("docUpload");
                            console.log("Doc Upload");
                        console.log(docUpload);
                            if (docUpload == "userDocUpload") {
                                localStorage.setItem("docUpload", "userDocUpload1");
                            } else if (docUpload == "userDocUpload1") {
                                localStorage.setItem("docUpload", "userDocUpload");
                            }
                        currentComponent.setState({
                            dialogDismiss: 'modal',
                            docUploadSuccess: true,
                            pageStatus: 'docUploadSuccess',
                            showDocData: false,
                        }, function () {
                            // currentComponent.handleSelectTab();
                            currentComponent.forceUpdate();
                        });
                    } else { 
                        currentComponent.setState({
                            // docUploadSuccess: false,
                            pageStatus: '',
                        });
                    }
                })
                .catch(function (error) {
                    currentComponent.setState({
                        // docUploadSuccess: false
                        pageStatus: '',
                    });
                })
            }
        
        return true;
    }

    onClickHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        this.inputOpenFileRef.current.click();
        const formData = new FormData();
        formData.append('file', this.state.selectedFile);
        return true;
    }

    onChangeCheckBox = (e, isChecked) => {
        this.setState({ checkboxStatus: isChecked }, function () { 
            this.fieldValidation();
        });
        return true;
    }

    fieldValidation() {
        // CPBNRP-1328 fixed
        var docDescription = this.state.documentDescription.split(" ").join("");
        var descriptionValid;
        if(docDescription === "" || docDescription === null){
        // alert("At least 8 characters are required!");
        descriptionValid = false
        }
        else{
            descriptionValid = true;
        }
        

        if (this.state.rbsClassificationVal && this.state.rbsRecordVal
            && this.state.rbsRiskVal && descriptionValid && this.state.checkboxStatus) {
        // CPBNRP-1328 changes in if condition
            this.setState({
                dialogDismiss: 'modal',
                documentUploadStatus: false
            });
        } else { 
            this.setState({
                dialogDismiss: '',
                documentUploadStatus: true
            });
        }
        this.validateField();
        return true;
    }

    onChangeDocumentDescription = (e) => {
        var val = e.target.value;
        var dataVal = val.trimLeft();
        let v = validate('documentDescription', dataVal);
        if (v[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v[0], textErrorMessage: v[1] });
        }
        this.setState({
            documentDescription: dataVal,
        }, function () { 
                this.fieldValidation();
        })
        return true;
    }

    onChangeHandler = event => {
        console.log("Selected file");
        console.log(event.target.files);
        if (event.target.files[0]) {
            var status = checkDocumentNamingFormat(event.target.files[0].name);
            if (!status) {
                var fileSize = (event.target.files[0].size / (1024 * 1024 * 1024));
                console.log("RIght file selected");
                
                if (event.target.files.length > 1) {
                    this.setState({
                        docLengthStatus: true,
                        errorMessage: 'Max 1 file can be uploaded in one go. Please select a file and try again.'
                    });
                } else {
                    console.log("RIght file selected1");
                    if (event.target.files[0] && fileSize <= 2) {
                        if (event.target.files[0].type == 'application/pdf' || event.target.files[0].type == 'image/png' ||
                            event.target.files[0].type == 'image/jpeg' ||
                            event.target.files[0].type == 'application/msword' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
                            event.target.files[0].type == 'application/vnd.ms-excel' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
                            event.target.files[0].type == 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
                            console.log("RIght file selected2");
                            this.setState({
                                uploadedFileName: event.target.files[0].name,
                                docType: event.target.files[0].type,
                                selectedFile: event.target.files[0],
                                fileUploadStatus: true,
                                // documentUploadStatus: false,
                                docLengthStatus: false
                            });
                        } else {
                            this.setState({
                                docLengthStatus: true,
                                errorMessage: 'Invalid document type.'
                            });
                        }

                    } else {
                        this.setState({
                            docLengthStatus: true,
                            errorMessage: 'File size should be less then 2GB. Please select a file and try again.'
                        });
                    }
                }
            } else {
                this.setState({
                    docLengthStatus: true,
                    errorMessage: 'Please make sure that the document name is compliant with the naming convention'
                });
            }
        } 
        return true;
    }

    deleteDocument() {
        this.setState({ ...deleteObj });
    }

    gotoEditCustomerPage() {
        let partyFlag = this.state.userData.partyFlag;
        let partyID = this.state.userData.partyID;
        if(partyFlag === 'COPY'){
            partyID = this.state.userData.partyHistoryID;
        }

        if((partyFlag && partyFlag !== '') &&
        (partyID && partyID !== '')){
            this.props.history.push({
                pathname: '/lms/EditCustomer',
                state: { 
                    partyFlag: partyFlag, 
                    partyID: partyID,
                    emptyMandatoryFields : this.state.emptyMandatoryFields,
                }
            });
        }
        return true;
    }

    validateField() {
        let v = validate('dropdown', this.state.rbsClassificationVal);
        if (v[0] == null) {
            this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
        } else if (v[0] != null) {
            this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
        }
        let v1 = validate('dropdown', this.state.rbsRecordVal);
        if (v1[0] == null) {
            this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v1[1] });
        } else if (v1[0] != null) {
            this.setState({ rbsRecordValErrorStatus: !v1[0], rbsRecordValErrorMessage: v1[1] });
        }

        let v2 = validate('dropdown', this.state.rbsRiskVal);
        if (v2[0] == null) {
            this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v2[1] });
        } else if (v2[0] != null) {
            this.setState({ rbsRiskValErrorStatus: !v2[0], rbsRiskValErrorMessage: v2[1] });
        }

        let v3 = validate('documentDescription', this.state.documentDescription);
        if (v3[0] == null) {
            this.setState({ textErrorStatus: false, textErrorMessage: v3[1] });
        } else if (v[0] != null) {
            this.setState({ textErrorStatus: !v3[0], textErrorMessage: v3[1] });
        }

        return true;
    }

    getDropdownItem(event, ID, type) {
        if (event == "Classification") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsClassificationValErrorStatus: false, rbsClassificationValErrorMessage: v[1] });
                
            } else if (v[0] != null) {
                this.setState({ rbsClassificationValErrorStatus: !v[0], rbsClassificationValErrorMessage: v[1] });
            }
            this.setState({ rbsClassificationVal: type.value }, function () { 
                this.fieldValidation();
            });
        } else if (event == "Record") {
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRecordValErrorStatus: false, rbsRecordValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRecordValErrorStatus: !v[0], rbsRecordValErrorMessage: v[1] });
            }
            this.setState({ rbsRecordVal: type.value }, function () { 
                this.fieldValidation();
            });
        } else if (event == "Risk") {
            console.log("HIgh risk");
            console.log(this.state.roleName);
            console.log(this.state.roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1);
            console.log((type.value).toLowerCase() == "high risk");
            var isSeniorApprover = this.state.roleName.indexOf('rAppNordiskLMS-SeniorApproverUser') > -1
            console.log(!isSeniorApprover);
            if ((type.value).toLowerCase() == "high risk" && (!isSeniorApprover)) { 
                console.log("Inside hIgh risk");
                this.setState({ highRiskStatus: true });
            } else {
                this.setState({ highRiskStatus: false });
            }
            let v = validate('dropdown', type.value);
            if (v[0] == null) {
                this.setState({ rbsRiskValErrorStatus: false, rbsRiskValErrorMessage: v[1] });
            } else if (v[0] != null) {
                this.setState({ rbsRiskValErrorStatus: !v[0], rbsRiskValErrorMessage: v[1] });
            }
            this.setState({ rbsRiskVal: type.value }, function () { 
                this.fieldValidation();
            });
        }
    }

    handleSelectTab = () => { 
        this.setState({ key: 3 });
    }

    DocumentDeleteRequestSent () { 
        this.setState({ pageStatus: 'docDeleteSuccess' });
    }

    DocumentDeleteCancelRequestSent() {
        let ID = localStorage.getItem("approver");
        // if (ID == "true") {
        //     var docUploadType = localStorage.getItem("docUpload");
        //     if (docUploadType == "approverDocUpload") {
        //         localStorage.setItem("docUpload", "approverDocUpload1");
        //     } else if (docUploadType == "approverDocUpload1") {
        //         localStorage.setItem("docUpload", "approverDocUpload");
        //     }

        // } else {
            let docUpload = localStorage.getItem("docUpload");
            if (docUpload == "userDocUpload") {
                localStorage.setItem("docUpload", "userDocUpload1");
            } else if (docUpload == "userDocUpload1") {
                localStorage.setItem("docUpload", "userDocUpload");
            }
        // }
        this.setState({ pageStatus: 'docDeleteCancel' });
    }

    HandleSelectChange(event, type, value) {
        localStorage.setItem('recordview', type.value);
        this.setState({ recordView: type.value });
    }

    changeTab(datum, index) { 
        console.log("Tab changed::");
        var record = localStorage.getItem('recordview');
        if (record) {
            this.setState({ recordView: record });
        } else {
            this.setState({ recordView: 10 });
        }
    }

    documentDeleted() { 
        let docUpload = localStorage.getItem("docUpload");
        if (docUpload == "userDocUpload") {
            localStorage.setItem("docUpload", "userDocUpload1");
        } else if (docUpload == "userDocUpload1") {
            localStorage.setItem("docUpload", "userDocUpload");
        }
        this.setState({ pageStatus: 'docDeletedSuccess1' });
    }
    handleTypeChange(e) {
        const elem = e.target.name;
        const value = e.target.value;
        if (value.length > 1000) { return; };
        this.state.userData[elem] = value;
        const Obj = {...this.state, commentEdited: (value==="") ? true : false}
        this.setState(Obj);
    }
    saveComments(){
        const currentComponent= this;
        this.state.userData.partyComments.push({
            "partyCommentDescription":this.state.userData.partyComment
        });
        const payLoadData = this.state.userData;
        HttpPut(currentComponent, payLoadData, API_ENDPOINT.CREATE_PARTY).then((response) => {
            currentComponent.props.history.push({
                pathname: '/lms/viewCustomerDetail',
                state: { rowID: response.data.partyID }
            }); 
            currentComponent.setState({userData:response.data})
        }).catch((error) => {
            })

    }
    clearCommentSection(){
        this.state.userData.partyComment = "";
        const Obj = {...this.state, commentEdited:true}
        this.setState(Obj);
    }
    checkrequestbtnDisable = () => {
        let _toreturn = true;
        if (this.state.userData.partyStatus === "In Progress" ) {
            _toreturn = false;
        }
        return _toreturn
    }

    checkeditbtnDisable = () => {
        let _toreturn = false;
        if (this.state.userData.partyStatus === "Active" && this.state.userData.disableEdit) {
            _toreturn = true;
        }
        const statusArray = ["Rejected","Pending Approval", "Archived"]
        if(statusArray.indexOf(this.state.userData.partyStatus) >= 0 ){
            _toreturn = true;
        }
        return _toreturn
    }
    deleteCustomer() {
        if (this.state.userData.partyStatus !== "In Progress") {
            return;
        } else {
            if(!this.state.isDelete){
                this.setState({'isDelete':true})
            }
        }
    }
    confirmClick = () => {
        if(this.state.isDelete){
            const URL = API_ENDPOINT.DELETE_PARTY+"/"+localStorage.getItem('userID');
            const deletePayLoadData = this.state.userData;
            const currentComponent = this;
            HttpDelete(currentComponent, deletePayLoadData, URL).then((response) => {
                currentComponent.props.history.push('viewCustomerList');
            }).catch((error) =>{
                console.log(error);
            })

        }
    }
    closemodal = () => {
        const Obj= {
            'isDelete':false,
            'isArchive':false
        }
        this.setState(Obj);
        
    }
    enablearchiveBtn(){
        let _val= false;
        const statusArray = ["Pending Approval", "Rejected", "Archived"]
        if (statusArray.indexOf(this.state.userData.partyStatus) >= 0) {
            _val= true;
        }
        if(this.state.userData.partyStatus === "Active" && this.state.userData.disableEdit){
            _val= true;
        }
        return _val
       
    }
   
    archiveCustomer(){
        if (this.state.userData.partyStatus === "In Progress") {
            if(!this.state.isArchive){
                this.setState({'isArchive':true})
            }
        }
        if(this.state.userData.partyStatus === "Active" && this.state.prevData !== null){
            if(!this.state.isArchive){
                this.setState({'isArchive':true})
            }
        }
    }

    confirmArchive =() =>{
        if(this.state.isArchive){
            const currentComponent = this;
            const dto = {
                "documentID": 0,
                "documentName": "string",
                "isHighRiskDocument": 0,
                "leaseApprovalID": 0,
                "leaseContractID": 0,
                "noOfInvoices": 0,
                "notificationID": 0,
                "notificationName": "string",
                "partyID": currentComponent.state.partyID,
                "partyName": "string",
                "propertyID": 0,
                "reasonForRejection": "string",
                "requestedBy": "string",
                "respondedBy": "string",
                "spvID": 0,
                "tlpBaseTableRequestNo": 0,
                "userToBeNotified": "string"
              }
            const url =  API_ENDPOINT.ARCHIVE_PARTY+"/"+currentComponent.state.partyID+ "/"+ currentComponent.state.userData.partyFlag+"/"+localStorage.getItem('racfID');
            HttpPut(currentComponent, dto, url).then( (response) =>{
                currentComponent.props.history.push('viewCustomerList');
            }).catch((error) =>{
                console.log(error);
            })
        }
    }


    checkRequestApproval() {
        let emptyFields=[];
        
        for (let prop of customerMandatoryFields){
            if(this.state.userData[prop]===null || this.state.userData[prop]===undefined || this.state.userData[prop]===''){
                emptyFields.push(prop);
            }
        }

        if(emptyFields.length > 0){
            this.setState({
                pendingRequestApprovalData : true,
                emptyMandatoryFields : emptyFields,
            });
        } else{
            this.setState({pendingRequestApprovalData : false});
        }
    }
    
    approvePartyRequest() {
        var currentComponent = this;
        var ID = localStorage.getItem('racfID')
        let payLoadData = ApproveRejectParty(this.state, ID);          
        let output = HttpPut(currentComponent, payLoadData, 
            API_ENDPOINT.APPROVE_PARTY + '/'+ this.state.partyID + '/' + 'Active' + '/' + this.state.userData.partyFlag + '/'+ ID)
            .then(function (response) {
                currentComponent.setState({pageStatus: 'ApproveRejectSuccess'});
                let usersData = currentComponent.state.userData;
                usersData.partyStatus = 'Active';
                currentComponent.setState({userData: usersData});                          
            })            
            this.forceUpdate();
        } 

    rejectPartyRequest() {
        var currentComponent = this;
        var respondedBy = localStorage.getItem('racfID')
        let payLoadData = ApproveRejectParty(this.state, respondedBy);
        let partystatus;
        if (this.state.userData.partyFlag === 'MAIN') {
                partystatus = 'In Progress';
        }
        else {
            partystatus = 'Archieved';
        }
        let output = HttpPut(currentComponent, payLoadData,
            API_ENDPOINT.REJECT_PARTY + '/' + this.state.partyID + '/' + partystatus + '/' + this.state.userData.partyFlag + '/' + respondedBy)
            .then(function (response) {
                currentComponent.setState({pageStatus: 'ApproveRejectSuccess'});
                let usersData = currentComponent.state.userData;
                usersData.partyStatus = partystatus;
                currentComponent.setState({userData: usersData});                  
            })
            this.forceUpdate();
    } 
    
    sendRequestForApproval() {
        var currentComponent = this;
        var ID = localStorage.getItem('racfID')
        let payLoadData = RequestApproval(this.state, ID);          
        let output = HttpPut(currentComponent, payLoadData, 
            API_ENDPOINT.APPROVAL_REQUEST + '/'+ this.state.partyID + '/' + 'Pending Approval' + '/' + this.state.userData.partyFlag + '/'+ ID)
            .then(function (response) {
                currentComponent.setState({pageStatus: 'partyRequestSent'});
                let usersData = currentComponent.state.userData;
                usersData.partyStatus = 'Pending Approval';
                currentComponent.setState({userData: usersData});   
            })
            this.forceUpdate();
        } 
        
    render() {
        if (this.state.userData === null) { return (<div></div>) }
        let { name } = this.context;
        // console.log(this.state.userData.partyContacts == undefined);
        // console.log(Object.keys(this.state.userData.partyContacts).length);
        // const contactLength = 0;
        let docUpload = localStorage.getItem("docUpload");
       
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else {
            datalen = 0;
        }
        var uploadDocumentEnable = false;
        var editCustomerBtn = true;
        var requestForApprovalBtn= true;
        var deleteCustomerLabel = true;
        var archiveCustomerLabel = true;
        var approveRequestBtn = true;
        var rejectRequestBtn = true;
        console.log(this.state.userData.requestedBy);
        console.log(this.state.racfID)
        for (var i = 0; i < datalen; i++) {
            if (perData[i] == "Customer_Doc_Request_Upload_High_Risk") {
                uploadDocumentEnable = true;
            }
            if (perData[i] == "Customer_Edit") {
                editCustomerBtn = false;
            }
            if (perData[i] == "Customer_Request_Approval") {
                requestForApprovalBtn = false;
            }
            if (perData[i] == "Customer_Removal") {
                deleteCustomerLabel = false;
            }
            if (perData[i] == "Customer_Archive") {
                archiveCustomerLabel = false;
            }
            if (perData[i] == "Customer_Approve"){
                if(this.state.userData.requestedBy != undefined && this.state.userData.requestedBy != null){
                    if(this.state.userData.requestedBy != this.state.racfID){
                        approveRequestBtn = false;
                    }
                }
            }
            if (perData[i] == "Customer_Reject" && this.state.userData.requestedBy != this.state.racfID) {
                if(this.state.userData.requestedBy != undefined && this.state.userData.requestedBy != null){
                    if(this.state.userData.requestedBy != this.state.racfID){
                        rejectRequestBtn = false;
                    }
                }
                
            }
        }
        
        
        console.log("Permission data");
        console.log(perData);
        console.log(uploadDocumentEnable)
        return (

            <div className="container-fluid viewcustomerDetail">
                <ModalPopup headerTitle="Delete customer" className={'assetpageModal'} confirmBtnText="Yes, delete customer" open={this.state.isDelete} confirm={this.confirmClick} close={this.closemodal} data={this.state.userData} modalbody={modalMessage["deleteMsg"]} />
                <ModalPopup headerTitle="Archive customer" className={'assetpageModal'} cancelBtnText= "No, don’t archive customer" confirmBtnText="Yes, archive customer" open={this.state.isArchive} confirm={this.confirmArchive} close={this.closemodal} data={this.state.userData} modalbody={modalMessage["archiveMsg"]} />
                <div style={{ padding: '0 1%' }}>
                    <Icon name="chev-left-xsmall" size="xsmall" className="back_arrow" title="" />
                    <span className="all_Customers" onClick={this.viewParty.bind(this)}>All customers</span>
                </div>

                {this.state.pageStatus == 'docUploadSuccess' ?
                    <Notification className="Confirmation_header_new" style={{width: '1244px'}} status='success' size='large' title='Your document has been uploaded'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'docDeleteSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Your request for deletion has been sent'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar.  */}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docDeleteCancel' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' 
                        title='Your request for deletion has been cancelled'>
                       {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar.  */}
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'saveSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Your customer has been saved'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar.  */}
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'changeSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Your customer changes have been saved'>
                        {/* Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque finibus eros at dictum pulvinar. */}
                    </Notification>
                    : null
                }

                {this.state.pageStatus == 'docDeletedSuccess' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Your request for deletion has been approved'>
                        {this.state.confirmMessage}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docDeletedSuccess1' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Your document has been deleted'>
                        {this.state.confirmMessage}
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docDeletedFailed' ?
                <Notification className="Confirmation_header_new" status='error' style={{ width: '1244px' }} size='large' title='Your request for deletion has been rejected'>
                        {this.state.failureMessage} {this.state.rejectionReason ? <span style={{ wordBreak: 'break-all' }}>Reason for rejection: {this.state.rejectionReason}</span> : null}
                    </Notification>
                     : null
                }
                {this.state.deleteStatus == 'approverDocDeleted' ?
                    <Notification className="Confirmation_header_new" style={{ width: '1244px' }} status='success' size='large' title='Deletion request has been approved'>
                        The document {this.state.deletedDocName} has been deleted. Notification email has been sent to {this.state.docUserName}.
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docPendingApproval' && this.state.pendingCount > 0 ?
                    <Notification className="Confirmation_header_new" status='warning' style={{ width: '1244px' }} size='large' title={this.state.pendingCount + ' Document deletion request pending your approval'}>
                        Please review the documents highlighted in yellow and approve/reject deletion request accordingly.
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docDeleteRejected' ?
                    <Notification className="Confirmation_header_new" status='success' style={{ width: '1244px' }} size='large' title='Deletion request has been rejected'>
                        The document {this.state.deletedDocName} has not been deleted.
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docUploadApproved' ?
                    <Notification className="Confirmation_header_new" status='success' style={{ width: '1244px' }} size='large' title='Document upload request has been approved.'>
                        The upload of document {this.state.deletedDocName} has been approved. A notification email has been sent to {this.state.docUserName}.
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'docUploadRejected' ?
                    <Notification className="Confirmation_header_new" status='error' style={{ width: '1244px' }}
                        size='large' title='Your request for document upload has been rejected'>
                        The request to upload document {this.state.deletedDocName} has been rejected by {this.state.approverName}. <br></br>
                        <span style={{ wordBreak: 'break-all' }}>Reason for rejection: {this.state.rejectionReason}</span>
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'partyRequestSent' ?
                    <Notification className="Confirmation_header_new" status='success' style={{ width: '1244px' }} size='large'>
                    Your customer record has been sent for approval. You will receive a notification once your customer record has been approved / rejected
                    </Notification>
                    : null
                }
                {this.state.pageStatus == 'ApproveRejectSuccess' ?
                    <Notification className="Confirmation_header_new" status='success' style={{ width: '1244px' }} size='large'>
                   Your decision on customer record has been sent successfully.
                    </Notification>
                    : null
                }
              

               
              <div style={{ padding: '0 1%' }}>
                    <span className="investor_title">{this.state.userData.partyName}(CIS {this.state.userData.cisCode})</span>
                </div>
                <div className="row labelRow">
                    <div className="col-xs-6">
                        <label>Type:</label>
                        <b>Customer</b></div>
                    <div className="col-xs-6" style={{ 'textAlign': 'right' }}><label>Status:</label>
                        <b>{this.state.userData.partyStatus}</b></div>
                </div>
                <Tabs selectedIndex={this.state.key}
                    className="customerdocGridTab" selectedTabClassName="selectedtlpGridTab" style={{ marginBottom: '85px' }}
                    onSelect={this.changeTab.bind(this)}>
                    <div style={{ 'display': 'block', 'height': '37px' }}>
                        <TabList style={{ 'border': 'none', 'marginLeft': '-6px', 'float': 'left' }}>
                            <Tab className="headertlpGridTab">Details</Tab>
                            {/* <Tab className="headertlpGridTab">Deals</Tab>
                        <Tab className="headertlpGridTab">Rent invoices</Tab> */}
                        <Tab className="headertlpGridTab">Documents</Tab>
                    </TabList>
                    <div className="exportButtonGroup">
                            <div className="col-sm-6">
                                <Icon name="export-small" size='small' /> <label className="uploadDocument"> Export to Excel</label>
                            </div>
                            <div className="col-sm-6">
                                <Icon name="download-small" size='small' /> <label className="uploadDocument"> Download PDF</label>
                            </div>
                        </div>
                    </div>    
                    <TabPanel className="selectedtlpgridTabPanel">
                        <GRDMComponent data={this.state.userData} />
                        <div className="contact_detail_container"></div>
                        <div className="row" style={{ margin: '0 0 2% 0' }}>
                            <label className="viewcustomer_title">Company details</label>
                            <CompanyDetaillComponent userData={this.state.userData} prevData={this.state.prevData} />
                        </div>

                        <div className="contact_detail_container"></div>
                        <div className="row" style={{ margin: '0 0 2% 0' }}>
                            <label className="viewcustomer_title">Contact details</label>
                            <ContactDetailComponent userData={this.state.userData} prevData={this.state.prevData} />
                        </div>
                        <div className="contact_detail_container"></div>
                        <div className="row" style={{ margin: '2% 0 2% 0' }}>
                            <span className="spv_caption">Special Purpose Vehicles</span>
                            <SPVSectionComponent spvdata={this.state.userData} />
                        </div>
                        <div className="contact_detail_container"></div>
                        <div className="row" style={{ margin: '2% 0 2% 0' }}>
                            <span className="spv_caption">Relationships</span>
                            <div className="form-group row " style={{ margin: '1% 10% 2% 0%' }}>
                                <div className="bullet_Rectangle"></div>
                                <span className="col-sm-4" style={{ marginTop: '-16px' }}> Parent Company</span>
                            </div>
                        </div>
                        <div className="contact_detail_container"></div>
                        <div className="row" style={{ margin: '2% 0% 2% 0' }}>
                            <span className="spv_caption">User access</span>
                            <div className="row " style={{ margin: '1% 10% 2% -1%' }}>
                                <div class="col-xs-12">
                                    {this.state.userData.partyRestrictions ?
                                        this.state.userData.partyRestrictions.map((object, i) => (
                                            <div className="user_access_label">
                                                <label className="spv_title">User</label>
                                                <label className="text-right">{this.state.userData.partyRestrictions[i].userName}</label>
                                            </div>
                                        ))
                                        : null}
                                </div>
                            </div>
                        </div>
                        <div className="contact_detail_container"></div>
                        <div className="row" style={{ margin: '2% 0 2% 0' }}>
                            <span className="spv_caption">Customer notes</span>
                            <div className="row commentRow" style={{ margin: '20px 0px 0px 0px' }}>
                                <textarea name="partyComment"  className="form-control input_Fields" placeholder="Tap to enter comments" onChange={this.handleTypeChange.bind(this)}></textarea>
                            </div>
                            <div className="row" style={{ margin: '20px 0px 20px 0px' }}>
                                <button disabled={this.state.commentEdited} className='zb-button zb-button-primary footerButton' onClick={
                                    this.saveComments.bind(this)}>Save comment</button>
                                <button disabled={this.state.commentEdited} className="zb-button zb-button-secondary footerButton transparent" onClick={this.clearCommentSection.bind(this)}>Clear</button>
                            </div>
                            {this.state.userData.partyComments.length > 0 ?
                                <div className="row commentFeeds" >
                                    {this.state.userData.partyComments.map((item, index) => {
                                        return (
                                            <div className="commentFeedRow">
                                                <label className="customerDetails">
                                                    <span className="customerName">{item.partyID}</span>
                                                    <span className="timeStamp">{item.partyCommentCreatedOn}</span>
                                                </label>
                                                <label className="customerComment">{item.partyCommentDescription}</label>
                                            </div>
                                        )
                                    })
                                    }
                                </div>
                                : null}
                        </div>

                    </TabPanel >
                    {/* <TabPanel>
                       Deals Data
                    </TabPanel>
                     <TabPanel>
                        Rent invoices
                    </TabPanel> */}
                    
                    <TabPanel style={{ backgroundColor: '#ffffff', marginBottom: '85px' }}
                        >
                        {!uploadDocumentEnable ? <div>
                            <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                                <div style={{ width: '175px' }}>
                                    <Icon name="plus-xsmall" size='small' title="" /><label className="uploadDocument" >Upload documents</label>
                                </div>
                            </div>
                        </div> : null}
                        {uploadDocumentEnable ? <div onClick={this.resetData.bind(this)}>
                            <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                                <div data-toggle="modal" data-target="#upload" style={{ width: '175px' }}>
                                    <Icon name="plus-xsmall" size='small' title="" /><label className="uploadDocument" >Upload documents</label>
                                </div>
                            </div>
                        </div> : null}
                        {docUpload == "approverDocUpload" ? <div><ApproverDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                            userData={this.state.userData} deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)} />
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per page</span>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_row'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "approverDocUpload1" ? <div><ApproverDocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)} pendingCount={this.pendingCount.bind(this)}
                            userData={this.state.userData} deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)} />
                            <span class="select-wrap -pageSizeOptions select_record">
                                <span className="select_page">Per pag</span>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_row'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "userDocUpload" ? <div><DocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)}
                            documentDeleted={this.documentDeleted.bind(this)}
                            userData={this.state.userData}
                            deletionStatus={this.deletionStatus.bind(this)}
                            rejectStatus={this.rejectStatus.bind(this)}
                            uploadApprovalStatus={this.uploadApprovalStatus.bind(this)}
                            uploadRejectStatus={this.uploadRejectStatus.bind(this)}/>
                            <span class="select_record_doc">
                                <label className="select_page_doc">Per page</label>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_page_size'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        {docUpload == "userDocUpload1" ? <div><DocumentGrid
                            DocumentDeleteRequestSent={this.DocumentDeleteRequestSent.bind(this)}
                            DocumentDeleteCancelRequestSent={this.DocumentDeleteCancelRequestSent.bind(this)}
                            selectedRecord={parseInt(this.state.recordView)}
                            documentDeleted={this.documentDeleted.bind(this)}
                            deletionStatus={this.deletionStatus.bind(this)}
                            userData={this.state.userData}
                            rejectStatus={this.rejectStatus.bind(this)}
                            uploadApprovalStatus={this.uploadApprovalStatus.bind(this)}
                            uploadRejectStatus={this.uploadRejectStatus.bind(this)}/>
                            <span class="select_record_doc">
                                <label className="select_page_doc">Per page</label>
                                <Select
                                    defaultValue={this.state.recordView}
                                    suggestions={['5', '10', '15', '20']}
                                    className='select_page_size'
                                    isError={false}
                                    onChange={this.HandleSelectChange.bind(this)}
                                />
                            </span> </div> : null}
                        </TabPanel> 
                </Tabs>
                <DocumentUpload onClick={this.onClickHandler.bind(this)}
                    onChangeDoc={this.onChangeHandler.bind(this)} reference={this.inputOpenFileRef}
                    id="upload" uploadStatus={this.state.documentUploadStatus} fileName={this.state.uploadedFileName}
                    value={this.state.documentDescription} onChange={this.onChangeDocumentDescription.bind(this)}
                    deleteDoc={this.deleteDocument.bind(this)} onUpload={this.uploadDocuments.bind(this)}
                    errorStatus={this.state.textErrorStatus} textErrorMessage={this.state.textErrorMessage} dialogDismiss={this.state.dialogDismiss}
                    docType={this.state.docType} docLengthStatus={this.state.docLengthStatus}
                    errorMessage={this.state.errorMessage} onCheckboxChange={this.onChangeCheckBox.bind(this)}
                    rbsClassificationVal={this.state.rbsClassificationVal} rbsRecordVal={this.state.rbsRecordVal}
                    rbsRiskVal={this.state.rbsRiskVal} getDropdownItem={this.getDropdownItem.bind(this)}
                    rbsClassificationValErrorStatus={this.state.rbsClassificationValErrorStatus}
                    rbsClassificationValErrorMessage={this.state.rbsClassificationValErrorMessage}
                    rbsRecordValErrorStatus={this.state.rbsRecordValErrorStatus} rbsRecordValErrorMessage={this.state.rbsRecordValErrorMessage}
                    rbsRiskValErrorStatus={this.state.rbsRiskValErrorStatus} rbsRiskValErrorMessage={this.state.rbsRiskValErrorMessage}
                actionType="party"
                highRiskStatus={this.state.highRiskStatus}
                />
            {this.state.showApproveRequestButton == false ?
                <div className="form-group row">
                    <div className="col-lg-9  col-xs-7 leftPane">
                        <button disabled={this.checkrequestbtnDisable() || requestForApprovalBtn} onClick={this.checkRequestApproval.bind(this)} data-toggle="modal" data-target= {this.state.pendingRequestApprovalData === true  ? "#requestapprovalPending" : "#requestapproval"} className='zb-button zb-button-primary footerButton'>
                        Request approval</button>
                        <button disabled={this.checkeditbtnDisable() || editCustomerBtn} className="zb-button zb-button-secondary footerButton transparent" onClick={this.gotoEditCustomerPage.bind(this)}>Edit customer</button>
                    </div>
                    <div className="col-lg-3  col-xs-5 rightpane">
                        <div className={ (this.enablearchiveBtn() || archiveCustomerLabel) ? "archiveButtonFooter disabledLabel" : "archiveButtonFooter"} style={{ 'display': 'flex' }}><Icon name="trash-small" size='small' /><label className="footerLinks" onClick={this.archiveCustomer.bind(this)}>Archive customer</label></div>
                        <div className={this.state.userData.partyStatus !== "In Progress" || deleteCustomerLabel ? "archiveButtonFooter disabled" : "archiveButtonFooter"} style={{ 'display': 'flex' }}><Icon name="trash-small" size='small' />
                            <label className="footerLinks" onClick={this.deleteCustomer.bind(this)}>Delete customer</label></div>
                    </div>
                </div>:null}
                {this.state.showApproveRequestButton == true? <div className="form-group row">
                    <div className="col-lg-9  col-xs-7 leftPane">
                        <button  disabled = {this.state.userData.partyStatus !== 'Pending Approval' || approveRequestBtn} onClick={this.approvePartyRequest.bind(this)} className='zb-button zb-button-primary footerButton'>
                        Approve customer Request</button>
                        <button disabled = {this.state.userData.partyStatus !== 'Pending Approval' || rejectRequestBtn} className="zb-button zb-button-secondary footerButton transparent" onClick={this.rejectPartyRequest.bind(this)}>Reject Customer Request</button>
                    </div>
                </div> :null }
                <div id="requestapproval" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">                                               
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Request customer approval</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">Are you sure you want to request approval for this customer? <br></br>You won't be able to make changes until it's either been approved or rejected.  </p></div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '20px'
                                            }}>
                                                <button className='zb-button zb-button-primary save_pop_btn' data-dismiss="modal" onClick={this.sendRequestForApproval.bind(this)}>Yes, request approval</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                              
                                <div id="requestapprovalPending" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style={{ borderRadius: '0px' }}>
                                            <div class="modal-header">                                               
                                                <h4 class="modal-title header_title" style={{ textAlign: 'left' }} >Request customer approval</h4>
                                            </div>
                                            <div class="modal-body" style={{ textAlign: 'left' }}>
                                                <p className="header_body">The following fields needs to be completed before the customer can be submitted for approval<br></br>
                                                - MGS <br></br>
                                                - KYC Status <br></br>
                                                - CIS Code <br></br>
                                                - Country<br></br>
                                                - Company Type<br></br> 
                                                - Customer Sector <br></br>                                               
                                                - Organization Number <br></br>
                                                - Annual Review Date<br></br>
                                                - Customer Type<br></br>
                                        </p></div>
                                            <div class="modal-footer" style={{
                                                display: 'table',
                                                border: 'none',
                                                marginLeft: '34px',
                                                marginBottom: '20px',
                                                marginTop: '205px'
                                            }}>
                                                <button style={{width:'50%'}} className='zb-button zb-button-primary save_pop_btn' data-dismiss="modal" onClick={this.gotoEditCustomerPage.bind(this)}>Complete customer details</button>
                                                <button className='zb-button zb-button-secondary cancel_pop_btn' data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
            </div>


        )
    }

}

export default withRouter(viewCustomerDetail);

