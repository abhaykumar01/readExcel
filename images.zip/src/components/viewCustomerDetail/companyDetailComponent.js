import React from 'react';


class CompanyDetaillComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    componentWillMount() {
         var customerTypeObj = {
           200 : "Primary",
           201 : "Secondry",
           202 : "Tenant"
       }
       
       let creditRatingArray = [];
       let creditrating = '';
       
       
       if (this.props.userData != undefined) {
        let len = this.props.userData.partyCreditRatings !== null ? this.props.userData.partyCreditRatings.length : 0;
        
        if (len > 0) {
            for( var i=0; i<this.props.userData.partyCreditRatings.length; i++){
                const rating = (this.props.userData.partyCreditRatings[i].creditRating != null) ? this.props.userData.partyCreditRatings[i].creditRating : "";
                const ratingsource = (this.props.userData.partyCreditRatings[i].creditRatingSource != null) ? this.props.userData.partyCreditRatings[i].creditRatingSource : "";
                const webpage = (this.props.userData.partyCreditRatings[i].ratingSourceWebpage != null) ? this.props.userData.partyCreditRatings[i].ratingSourceWebpage : "";

                creditrating = rating + " / " +ratingsource+ " ("+webpage+")";
               
                creditRatingArray.push(creditrating);
            }
            
        }else{
            this.props.userData.partyCreditRating1 = creditrating;

        }
        if(len > 0){
            for( var i=0; i< this.props.userData.partyCreditRatings.length; i++){
                if( i==0 ){
                    this.props.userData.creditrating1 = creditRatingArray[i]
                }else if(i == 1){
                    this.props.userData.creditrating2 = creditRatingArray[i]
                }else if( i == 2){
                    this.props.userData.creditrating3 = creditRatingArray[i]
                }
               
            }
        }
    }
     this.props.userData.customerType = customerTypeObj[this.props.userData.customerTypeID];
     if(this.props.userData.partyFlag === "COPY"){
        this.props.prevData.customerType = customerTypeObj[this.props.prevData.customerTypeID];
     }
     
    }
    componentDidMount() {
        console.log(this.props);
        
        let stateData = [];
        let objectToCheck = ["partyName","customerType", "sector", "companyType", "country", "cisCode", "organisationNo", "annualReviewDate","creditrating1","creditrating2","creditrating3", "masterGradingScale", "kycStatus", "competitors", "webPageUrl"];
        const objectKeyMap = {
            "partyName": "Customer Name",
            "customerType": "Customer Type",
            "sector": "Customer sector/sub-sector",
            "companyType": "Company type",
            "country":"Country",
            "cisCode": "CIS code",
            "organisationNo": "Organisation number",
            "annualReviewDate": "Annual review date",
            "creditrating1": "Credit rating 1",
            "creditrating2": "Credit rating 2",
            "creditrating3": "Credit rating 3",
            "masterGradingScale": "MGS",
            "kycStatus": "KYC status",
            "competitors": "Peers",
            "webPageUrl": "Webpage"
        }
        if(this.props.userData.partyCreditRatings){
            const _length = this.props.userData.partyCreditRatings.length;
            console.log(_length);
            if(_length === 0){
                delete objectKeyMap.creditrating1; delete objectKeyMap.creditrating2; delete objectKeyMap.creditrating3;
                objectToCheck.splice(objectToCheck.indexOf("creditrating1") ,1); objectToCheck.splice(objectToCheck.indexOf("creditrating2") ,1); objectToCheck.splice(objectToCheck.indexOf("creditrating3"), 1);
            }
            if(_length > 0){
                delete objectKeyMap.creditrating2; delete objectKeyMap.creditrating3;
                objectToCheck.splice(objectToCheck.indexOf("creditrating2") ,1); objectToCheck.splice(objectToCheck.indexOf("creditrating3"), 1);
            }
            if(_length > 1){
                delete objectKeyMap.creditrating3;
                objectToCheck.splice(objectToCheck.indexOf("creditrating3"), 1);
            }
        }
        if(this.props.userData.partyStatus === "In Progress" && this.props.prevData !== null){
            for (var i = 0; i < objectToCheck.length; i++) {
                stateData.push({
                    "name": objectKeyMap[objectToCheck[i]],
                    "value": this.props.userData[objectToCheck[i]],
                    "isEdited": (this.props.userData[objectToCheck[i]] !== this.props.prevData[objectToCheck[i]]) ? true : false,
                    "oldValue": (this.props.userData[objectToCheck[i]] !== this.props.prevData[objectToCheck[i]]) ? this.props.prevData[objectToCheck[i]] : ''
                })
            }
        }else{
            for (var i = 0; i < objectToCheck.length; i++) {
                
                stateData.push({
                    "name": objectKeyMap[objectToCheck[i]],
                    "value": this.props.userData[objectToCheck[i]],
                    "isEdited": false,
                    "oldValue": ''
                })
            }
        }
        this.setState({ contactData: [...stateData] })

    }
    render() {
        return (
            <div className="row" style={{ margin: '0 0 2% 0' }}>
                    <div className="customerDetailTable">
                        {
                            Object.keys(this.state).length > 0 ? this.state.contactData.map((item, index) => {
                                return (<div className="row" style={{ 'display': 'flex', 'margin': '5px 0' }}>
                                    <div className="leftcolumn">{item.name}</div>
                                    <div className="rightcolumn"><label className={(item.isEdited) ? "highlighted " : "activeValue"}>{item.value}</label>
                                        {(item.isEdited) ? <div className="oldText">{item.oldValue}</div> : null}
                                    </div>
                                </div>)
                            }) : null
                        }

                    </div>
            </div>
        )
    }
}

export default CompanyDetaillComponent;