import React from 'react';
import Enzyme, { shallow, mount, render } from 'enzyme';
import ViewCustomerDetail from './viewCustomerdetail.js';
import Adapter from 'enzyme-adapter-react-16';
import renderer from 'react-test-renderer';
import { create } from "react-test-renderer";
import { BrowserRouter as Router } from 'react-router-dom';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import DocumentUpload from '../../commonComponents/documentsUpload';

Enzyme.configure({ adapter: new Adapter() });

let wrapper;
beforeEach(() => {
    wrapper = shallow(<ViewCustomerDetail />);
});

describe('Customer component', () => {
    test('should shallow correctly', () => {
        expect(wrapper).toMatchSnapshot()
    })
   
    test('should mount correctly', () => {
        expect(mount(
            <Router>
                <ViewCustomerDetail />
            </Router>
        )).toMatchSnapshot()
    })
    test('should render correctly', () => {
        expect(render(
            <Router>
                <ViewCustomerDetail />
            </Router>
            
        )).toMatchSnapshot()
    })

    test('should render <button>', () => {
        expect(wrapper.find('button')).toHaveLength(0);
    });
    // it('should be handling selectDealType function', () => {
    //     const wrapper1 = shallow(<ViewCustomerDetail />);
    //     expect(wrapper1.instance().fieldValidation()).toEqual(true);
    // });
});