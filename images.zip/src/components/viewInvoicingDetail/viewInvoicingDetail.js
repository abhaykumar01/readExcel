import React from 'react';
import './viewInvoicingDetail.css';
import GridPage from '../../commonComponents/gridpage';
import '../../index.css';

import { Tabs, Tab } from 'react-bootstrap-tabs';
// import { Icon } from '@zambezi/sdk/icons';
// import { Select } from '@zambezi/sdk/dropdown-list';

//--
import InputfieldCustom from '../../commonComponents/inputInvoiceField';
import InputFieldDisabled from '../../commonComponents/inputInvoiceFieldDisabled';
import Dropdownfieldcustom from '../../commonComponents/DropdownFieldCustom';
import { manualInvoiceForm } from '../../models/dataModel.js';
import Dropdown from '../../commonComponents/dropdown';
import Inputfield from '../../commonComponents/inputDealField';
import Calenderinputfield from '../../commonComponents/calenderInputInvoice.js';
import Dropdownfield from '../../commonComponents/DropdownField';
import TLPGrid from '../../commonComponents/TLPGrid';
import help from '../../assets/images/help.png';
import { Flyout, FlyoutTrigger } from '@zambezi/sdk/flyout';
import '../../../node_modules/@zambezi/sdk-themes/zb-natwest-nonpersonal-standard/theme.min.css'
import { API_ENDPOINT } from '../../config/config.js';
import { HttpPost, HttpGet } from '../../services/api.js';
import { validateInvoice } from '../../utils/validation.js';
//import {validateInvoice} from '../../utils/invoiceValidation.js'
import moment from 'moment';
import Accordion from '@zambezi/sdk/accordion';
import { Notification } from '@zambezi/sdk/notification';
import { Select } from '@zambezi/sdk/dropdown-list';
import { Icon } from '@zambezi/sdk/icons';
import ButtonGroup from '@zambezi/sdk/button-group';

import { RegisterLeaseModel } from '../../models/LeaseModelRegistry.js';
import InputPercField from '../../commonComponents/inputDealPercField';
import Popup from '../../commonComponents/popupMessage';
import InputTextfield from '../../commonComponents/inputField.js';
import { AuthorizationContext } from '../authContext/index.js'
const PING = process.env.REACT_APP_PING;

class viewInvoicingDetail extends React.Component {
    static contextType = AuthorizationContext
    constructor(props) {
        super(props);
        this.state = {
            racfData:'',
            permissionData: {},
            memberOfDetail:'',
            exportButton: true,
            recalculateInvoice: true,
            baseRent: 0,
            baseRentError: false,
            baseRentErrorMessage:"",
            indexAdjustment: 0,
            interestAdjustment:0,
            interestAdjustmentDesc:"",
            rentRebateDesc:"",
            rentAdjustmentDesc:"",
            propertyTaxDesc:"",
            rentRebate:0,
            rentAdjustment:0,
            totalRent: 0,
            propertyTax:0,
            currencyStatus:"",
            currencyName:"",
            invoiceType:"Index",
            spv: "",
            customer:"",
            areaCode:"",
            pmtTerms: "",
            invoicingFrequency: "",
            invoicingStartDate: "",
            invoicingEndDate: "",
            invoicingEndDateErrorMessage: "",
            invoicingEndDateError: false,
            leaseFee: 0,
            index: 0,
            indexType: "Fixed",
            indexScaling: 0,
            indexName: "",
            indexBaseDate: "",
            indexReviewDate: "",
            indexReviewNumber:0,
            indexBaseNumber: 0,
            indexFloor: 0,
            rentAdjustmentPerBps: 0,
            numberOfBpsAdjustment: 0,
            vatableProportion: 0,
            otherSupportingComments: "",
            partyTypeSelect:false,
            successMessage:"",
            formErrorStatus:true,
            customerNameErrorMessage: "",
            customerNameError: false,
            leaseContractId:"",
            pageSuccessStatus:false,
            serverError:false,
            isLoading:false,
            languagePreference:"English",
            apiErrorMessage:'',
            baseRentDesc:"",
            indexAdjustmentDesc:"",
          
        };
        
        this.initForm();
        this.handleChange = this.handleChange.bind(this);
        this.getInvoicingStartDate = this.getInvoicingStartDate.bind(this);
        this.getInvoicingEndDate = this.getInvoicingEndDate.bind(this);
        this.getIndexBaseDate = this.getIndexBaseDate.bind(this);
        this.getIndexReviewDate = this.getIndexReviewDate.bind(this);
    }

    componentDidMount() {
        this.getSelectedIndex('fixed');
        this.initForm();
        var data;
        var racfDetail;
        var memberOf;
        if (PING == 'true') {
            let { usersDetails } = this.context;
            console.log(usersDetails);
            console.log(usersDetails.permissions);
            data = usersDetails.permissions;
            racfDetail = usersDetails.userID;//racfID;
            memberOf =usersDetails.memberOf;

        } else {
            let response = localStorage.getItem('permissions');
            console.log(JSON.parse(response));
            let res = JSON.parse(response);
            data = JSON.parse(response);
            racfDetail = localStorage.getItem('racfID');
            memberOf ="rAppNordiskLMS-BusinessUsers";
        }
        this.setState({
            permissionData: data,
            racfData : racfDetail,
            memberOfDetail:memberOf
        });
    }
    initForm(){
        if(this.props.history.location.state != null && this.props.history.location.state != undefined) {
            this.state.currencyName = this.props.history.location.state.rowID.original.currency;
            this.state.pmtTerms = this.props.history.location.state.rowID.original.pmtterms;
            this.state.invoicingFrequency=this.props.history.location.state.rowID.original.invoicingfrequency;
            this.state.indexType=this.props.history.location.state.rowID.original.indexType;
            // this.state.languagePreference=this.props.history.location.state.rowID.original.languagePreference,

            this.setState({
                leaseContractId:this.props.history.location.state.rowID.original.leaseContractId,
                baseRent:this.props.history.location.state.rowID.original.baseRent,
                baseRentDesc:this.props.history.location.state.rowID.original.baseRentDescription,
                indexAdjustment:this.props.history.location.state.rowID.original.indexAdjustment,
                indexAdjustmentDesc:this.props.history.location.state.rowID.original.indexAdjDescription,
                interestAdjustment:this.props.history.location.state.rowID.original.interestAdjustment,
                rentRebate:this.props.history.location.state.rowID.original.rentRebate,
                rentAdjustment:this.props.history.location.state.rowID.original.rentAdjustment,
                propertyTax:this.props.history.location.state.rowID.original.propertyTax,
                totalRent:this.props.history.location.state.rowID.original.totalRent,
                spv:this.props.history.location.state.rowID.original.spv,
                customer:this.props.history.location.state.rowID.original.customer,
                areaCode:this.props.history.location.state.rowID.original.areaCode,
                currencyName :this.state.currencyName,
                pmtTerms:this.state.pmtTerms,
                invoicingFrequency:this.state.invoicingFrequency,
                invoicingStartDate:this.props.history.location.state.rowID.original.invoiceStartDate,
                invoicingEndDate:this.props.history.location.state.rowID.original.invoiceEndDate,
                leaseFee:this.props.history.location.state.rowID.original.leasefee,
                index:this.props.history.location.state.rowID.original.index,
                indexScaling:this.props.history.location.state.rowID.original.indexScaling,
                indexType:this.state.indexType,
                indexName:this.props.history.location.state.rowID.original.indexName,
                indexBaseDate:this.props.history.location.state.rowID.original.indexBaseDate,
                indexBaseNumber:this.props.history.location.state.rowID.original.indexBaseNo,
                indexFloor:this.props.history.location.state.rowID.original.indexFloor,
                indexReviewDate:this.props.history.location.state.rowID.original.indexReviewDate,
                indexReviewNumber:this.props.history.location.state.rowID.original.indexReviewNo,
                rentAdjustmentPerBps:this.props.history.location.state.rowID.original.rentAdjustmentBps,
                numberOfBpsAdjustment:this.props.history.location.state.rowID.original.rentAdjustment,
                vatableProportion:this.props.history.location.state.rowID.original.vatableProportion,
                otherSupportingComments:this.props.history.location.state.rowID.original.comments,
                //languagePreference:this.state.languagePreference,
                interestAdjustmentDesc:this.props.history.location.state.rowID.original.interestAdjDescription,
                rentRebateDesc:this.props.history.location.state.rowID.original.rentRebateDescription,
                rentAdjustmentDesc:this.props.history.location.state.rowID.original.rentAdjDescription,
                propertyTaxDesc:this.props.history.location.state.rowID.original.propertyTaxDescription,
                
                

            }, function(){
                if(this.state.indexType != null && this.state.indexType != undefined){
                    this.getSelectedIndex(this.state.indexType.toLowerCase());
                }
                this.forceUpdate();
            });
        }
    }

    handleChange = (e) => {
      
        

        if (e) {
            this.setState({exportButton:false});
            var val = e.target.value;
            var dataVal = val.trimLeft();
            
            if (e.target.name == "baserent") {
              
                this.setState({ baseRent: dataVal,  totalRent: parseFloat(this.state.indexAdjustment) + parseFloat(dataVal) + parseFloat(this.state.interestAdjustment) + parseFloat(this.state.rentRebate) + parseFloat(this.state.rentAdjustment) + parseFloat(this.state.propertyTax)});
               
            }
            else if (e.target.name == "indexadjustment") {
               
                this.setState({ indexAdjustment: dataVal, totalRent: parseFloat(dataVal) + parseFloat(this.state.baseRent) + parseFloat(this.state.interestAdjustment) + parseFloat(this.state.rentRebate) + parseFloat(this.state.rentAdjustment) + parseFloat(this.state.propertyTax)});
            }
            else if (e.target.name == "interestadjustment") {
        
                this.setState({ interestAdjustment: dataVal, totalRent: parseFloat(this.state.indexAdjustment) + parseFloat(this.state.baseRent) + parseFloat(dataVal) + parseFloat(this.state.rentRebate) + parseFloat(this.state.rentAdjustment) + parseFloat(this.state.propertyTax)});
            }
            else if (e.target.name == "rentrebate") {
                
                this.setState({ rentRebate: dataVal, totalRent: parseFloat(this.state.indexAdjustment) + parseFloat(this.state.baseRent) + parseFloat(this.state.interestAdjustment) + parseFloat(dataVal) + parseFloat(this.state.rentAdjustment) + parseFloat(this.state.propertyTax)  });
            }
            else if (e.target.name == "rentadjustment") {
                
                this.setState({ rentAdjustment: dataVal, totalRent: parseFloat(this.state.indexAdjustment) + parseFloat(this.state.baseRent) + parseFloat(this.state.interestAdjustment) + parseFloat(this.state.rentRebate) + parseFloat(dataVal) + parseFloat(this.state.propertyTax)  });
            }
            // else if (e.target.name == "totalrent") {
                
            //     this.setState({ totalRent: dataVal });
            // } 
            else if (e.target.name == "propertytax") {
                
                this.setState({ propertyTax: dataVal, totalRent: parseFloat(this.state.indexAdjustment) + parseFloat(this.state.baseRent) + parseFloat(this.state.interestAdjustment) + parseFloat(this.state.rentRebate) + parseFloat(this.state.rentAdjustment) + parseFloat(dataVal)  });
            }
            else if (e.target.name == "spv") {
                
                this.setState({ spv: dataVal });
            }
            else if (e.target.name == "customer") {
                
                this.setState({ customer: dataVal });
            }
            else if (e.target.name == "areacode") {
                
                this.setState({ areaCode: dataVal });
            }
            else if (e.target.name == "currency") {
                
                this.setState({ currency: dataVal });
            }
            else if (e.target.name == "pmtterms") {
                
                this.setState({ pmtTerms: 'NR '+dataVal }); 
            }
            else if (e.target.name == "invoicingfrequency") {
                
                this.setState({ invoicingFrequency: dataVal });
            }
            else if (e.target.name == "invoicingstartdate") {
                
                this.setState({ invoicingStartDate: dataVal });
            }
            else if (e.target.name == "invoicingenddate") {
                
                this.setState({ invoicingEndDate: dataVal });
            }
            else if (e.target.name == "leasefee") {
                
                this.setState({ leaseFee: dataVal });
            }
            else if (e.target.name == "leasecontractid") {
                
                this.setState({ leaseContractId: dataVal });
            }
            else if (e.target.name == "index") {
                
                this.setState({ index: dataVal });
            }
            else if (e.target.name == "indextype") {
                
                this.setState({ indexType: dataVal });
            }
            else if (e.target.name == "indexscaling") {
                
                this.setState({ indexScaling: dataVal });
            }
            else if (e.target.name == "indexname") {
                
                this.setState({ indexName: dataVal });
            }
            else if (e.target.name == "indexbasedate") {
                
                this.setState({ indexBaseDate: dataVal });
            }
            else if (e.target.name == "indexreviewdate") {
                
                this.setState({ indexReviewDate: dataVal });
            }
            else if (e.target.name == "indexreviewnumber") {
                
                this.setState({ indexReviewNumber: dataVal });
            } 
            else if (e.target.name == "indexbasenumber") {
                
                this.setState({ indexBaseNumber: dataVal });
            }
            else if (e.target.name == "indexfloor") {
                
                this.setState({ indexFloor: dataVal });
            }
            else if (e.target.name == "rentadjustmentperbps") {
                
                this.setState({ rentAdjustmentPerBps: dataVal });
            }
            else if (e.target.name == "numberofbpsadjustment") {
                
                this.setState({ numberOfBpsAdjustment: dataVal });
            }
            else if (e.target.name == "vatableproportion") {
                
                this.setState({ vatableProportion: dataVal });
            }
            else if (e.target.name == "othersupportingcomments") {
                
                this.setState({ otherSupportingComments: dataVal });
            }
            else if (e.target.name == "baserentdescription") {
                
                this.setState({ baseRentDesc: dataVal });
            }
            else if (e.target.name == "rentrebatedescription") {
                
                this.setState({ rentRebateDesc: dataVal });
            }
            else if (e.target.name == "indexadjustmentdescription") {
                
                this.setState({ indexAdjustmentDesc: dataVal });
            }
            else if (e.target.name == "interestadjustmentdescription") {
                
                this.setState({ interestAdjustmentDesc: dataVal });
            }
            else if (e.target.name == "rentadjustmentdescription") {
                
                this.setState({ rentAdjustmentDesc: dataVal });
            }
            else if (e.target.name == "propertytaxdescription") {
                
                this.setState({ propertyTaxDesc: dataVal });
            }

        
       // this.validateField(e.target.name);
        

        }
        
      
       
        
    
        
        
    }

    totalRentFunc(e) {
       
        var value = e;
        
           
        this.setState({
            totalRent: parseFloat(this.state.indexAdjustment) + parseFloat(this.state.baseRent) + parseFloat(this.state.interestAdjustment) + parseFloat(this.state.rentRebate) + parseFloat(this.state.rentAdjustment) + parseFloat(this.state.propertyTax) 
        }, () => {
            this.handleChange(this.state)
             
        }) 
    }

    finalCheck () {
        let localVariable = localStorage.getItem('errorStatusInvoice');
        if (this.state.customerNameError == true || this.state.invoicingEndDateError == true || this.state.baseRentError == true) {
            this.setState({ formErrorStatus: true });
        }
        if (this.state.customerNameError == false && this.state.invoicingEndDateError == false && this.state.baseRentError == false)  
        {   this.setState({ formErrorStatus: false });
        }
    }



    validateField(fieldName) {
      
        let v = validateInvoice('customer', this.state.customer);
        if (v[0] == null && fieldName=='customer') {
            this.setState({ customerNameError: false, customerNameErrorMessage: v[1] });
        } else if (v[0] != null && fieldName=='customer') {
            this.setState({ customerNameError: !v[0], customerNameErrorMessage: v[1] });
        }
        let v1 = validateInvoice('invoicingenddate', this.state.invoicingEndDate);

        if(v1[0] == null && fieldName=='invoicingenddate'){
            this.setState({ invoicingEndDateError: false, invoicingEndDateErrorMessage: v1[1] });
        } else if (v1[0] != null && fieldName=='invoicingenddate') {
            this.setState({ invoicingEndDateError: !v1[0], invoicingEndDateErrorMessage: v1[1] });
        }

        let v2 = validateInvoice('baserent', this.state.baseRent);

        if(v2[0] == null && fieldName=='baserent'){
            this.setState({ baseRentError: false, baseRentErrorMessage: v2[1] });
        } else if (v2[0] != null && fieldName=='baserent') {
            this.setState({ baseRentError: !v2[0], baseRentErrorMessage: v2[1] });
        }
       

        this.finalCheck();
    }
    
    generateData(type) {
        const data = [];
        if (type == "currency") {
            data.push(
                "",
                "GBP",
                "EUR",              
                "DKK",
                "SEK",
                "NOK"
                
            );
        } else if(type == "invoicetype") {
            data.push(
                "",
                "Index",
                "Interest ",
                
            );

        } else if (type == "pmtterms") {
            data.push(
                "",
                "In Arrears",
                "In Advance",
                
            );

        } else if (type == "invoicingfrequency") {
            data.push(
                "",
                "Monthly",
                "Quarterly",
                "Semi-Annually",
                "Annually",
                
            );
        } else if (type == "languagepreference") {
            data.push(
                "",
                "English",
                "Finnish",
                "Swedish"
            );
        }
        return data;
        }

        saveInvoiceData(){
            var currentComponent = this;
            // currentComponent.validateField();
            // currentComponent.finalCheck();
            // currentComponent.validateField();
            // currentComponent.finalCheck();
           
           
            
            //  window.alert("this.state"+ JSON.stringify(this.state));
            // window.alert(this.state.modeltype);
           // window.alert("this.state"+ this.state.leaseTenure);
           //this.validateField();
            let payLoadData = manualInvoiceForm(this.state);
            currentComponent.setState({ formError: false });
            currentComponent.setState({ isLoading: true });
            currentComponent.setState({ serverError: false });
            currentComponent.setState({ pageSuccessStatus: false });

            window.scrollTo(0, 0);
            // window.alert(payLoadData);
            // window.alert("this.state"+ JSON.stringify(payLoadData));
            if(this.state.formErrorStatus == false){
                let output = HttpPost(currentComponent,payLoadData, API_ENDPOINT.SAVE_MANUAL_INVOICE+'/'+this.state.languagePreference)
                .then(function (response) {

                    currentComponent.setState({ formError: false, exportButton: true });
                    currentComponent.setState({ isLoading: false });
                    currentComponent.setState({ pageSuccessStatus: true });
                    window.scrollTo(0, 0);    
                        
             
                   // window.alert(JSON.stringify(response.data));
                   
                })
                .catch(function (error) {
                    //window.alert(error);
                    currentComponent.setState({ isLoading: false });
                    currentComponent.setState({ serverError: true, apiErrorMessage: error.response.data});
                    
                    currentComponent.setState({ pageSuccessStatus: false });
                    window.scrollTo(0, 0);
                });
             }
             else{
                currentComponent.setState({ isLoading: false });
                currentComponent.setState({ formError: true, exportButton: true });
             }
            // }
            return true;
        }

        getIndexBaseDate(e) {
            if (e != null) {
                var endDate = Date.parse(e);
            this.state.indexBaseDate = moment(endDate).format('YYYY-MM-DD');
       //     this.validateField(e.target.name);
            this.finalCheck();
        }

            return true;
        }

        getIndexReviewDate(e) {
            if (e != null) {
                var endDate = Date.parse(e);
            this.state.indexReviewDate = moment(endDate).format('YYYY-MM-DD');
        }

            return true;
        }

        getInvoicingStartDate(e) {
            if (e != null) {
               // this.validateField(e.target.name);
                var startDate = Date.parse(e);
                this.state.invoicingStartDate = moment(startDate).format('YYYY-MM-DD');
                this.finalCheck();
            }
    
            // if (e != "") {
            //     this.setState({ leaseStartDate: e, leaseStartDateError: false }, function () {
            //         this.forceUpdate();
            //     });
            // } else {
            //     this.setState({ leaseStartDate: "", leaseStartDateError: true });
            // }
            return true;
        } 

        getInvoicingEndDate(e){
            if (e != null) {
                var endDate = Date.parse(e);
            this.state.invoicingEndDate = moment(endDate).format('YYYY-MM-DD');
       //     this.validateField(e.target.name);
            this.finalCheck();
        }
            // if (e != null && e != "") {
            //     var endDate = Date.parse(e);
            //     this.state.leaseStartDate =  moment(endDate).subtract('year', parseFloat(this.state.leaseTenure)).format('L');
            //     this.setState({ leaseEndDate: e, leaseEndDateError: false }, function () {
            //         this.forceUpdate();
            //     });
            // } else {
            //     this.setState({ leaseEndDate: "", leaseEndDateError: true });
            // }
        
            
            return true;
        }
        getSelectedIndex(type) {
            if (type === 'fixed') {
                this.setState({
                    indexType: 'Fixed',
                    partyTypeSelect: true
               
                });
            } else {
                this.setState({
                    indexType: 'CPI',
                    partyTypeSelect: false
                   
                });
            }
            return true;
        }

        
    confirm = () => {
        this.props.history.push({
            pathname: '/lms/viewCustomerDetail',
            state: { rowID: this.state.partyid }
        })
        // this.generateState(this.state.userRecord);
        return true;
    }

    goToPage(pagename) {
        this.props.history.push({
            pathname: '/lms/' + pagename
        })
        return true;
    }

    getDropdownItem(event, val, type) {
        this.setState({exportButton:false}); 
        if (event == "currency") {
            if (type.value != "") {
                this.setState({ currencyName: type.value, currencyStatus: false });
            } else {
                this.setState({ currencyName: type.value, currencyStatus: true });
            }
        } else if (event == "invoicetype") {
            if(type.value != "") {
                this.setState({ invoiceType: type.value});
            }

        }
        else if (event == "languagepreference") {
            if(type.value != "") {
                this.setState({ languagePreference: type.value});
            }

        }
        else if (event == "pmtterms") {
            if(type.value != "") {
                this.setState({ pmtTerms: 'NR '+type.value});
            }
        }
        else if (event == "invoicingfrequency") {
            if(type.value != "") {
           
            if(type.value ==='Monthly') {
            this.setState({ invoicingFrequency: 12});
             } else if(type.value ==='Quarterly'){
              this.setState({ invoicingFrequency: 4});
             } else if(type.value ==='Semi-Annually'){
             this.setState({ invoicingFrequency: 2});
             } else if(type.value ==='Annually'){
         this.setState({ invoicingFrequency: 1});
             }
                
            }
        }
        return true;
    }
    
    render() {
        console.log(this.state.permissionData)
        var perData = this.state.permissionData;
        var datalen;
        if (perData) {
            datalen = perData.length;
        } else { 
            datalen = 0;
        }
        
        console.log(perData);
        var btndisable = false;
        //rAppNordiskLMS-GeneralFinanceUser,rAPPNordiskLMS-TestSuperUser
        //check memberOf
        //this.state.memberOfDetail.indexOf("GeneralFinanceUser") > 0
        if(this.state.memberOfDetail.indexOf("GeneralFinanceUser") <= 0){
            console.log("Sfs")
            btndisable = true;
        }
        console.log(btndisable);
        
        return (
            <div className="background">
               

                
                 
                <div  onClick={this.goToPage.bind(this,'invoiceList')} style={{
                    
                    width: '1244px', marginLeft: '83px'}}>
                    <Icon name="chev-left-xsmall" size="xsmall" className="back_arrow" title=""/>
                        <span className="all_party" >All Invoices</span>
                </div>
                {
                    this.state.serverError ?
                        <Notification status='error' className="Confirmation_header_new" size='medium' title={this.state.apiErrorMessage}>
                     
                </Notification>
                        : null
                }
                  {
                    this.state.formError ?
                        <Notification status='error' className="Confirmation_header_new" size='medium' title='Form inputs are not valid, Please enter all the fields and try again'>
                     
                </Notification>
                        : null
                }
                {
                    this.state.pageSuccessStatus ?
                    <Notification className="Confirmation_header_new" style={{ width: '1100px' }} status='success' size='large' title='Export to oracle is completed successfully'>
                        
                </Notification>
                        : null
                }  
                {this.state.isLoading == true ? 
                        <div  style={{ marginLeft: '50px' }}>
                            <div className="zb-loader-block zb-loader-block-inverted">
                            <div className="zb-loader-content">
                                <span className="zb-loader" />
                                <span className="zb-loader-text">
                                Loading...
                                </span>
                            </div>
                            </div>
                    </div> : null } 
                

                <div className="form-group row" style={{
                    margin: '64px auto 0px 1%',
                    width: '1244px'
                }}>
                    <div className="col-sm-7">
                        <label className="model_title">Invoice {this.state.spv} {this.state.customer}</label>
                    </div>

                </div>

               
                <div className="model_invoice_container ">

                   
                                  <div style={{ backgroundColor: '#ffffff', padding: '25px' }} >
                                <div data-toggle="modal" data-target="#upload" style={{ width: '175px' }}>
                                    <Icon name="plus-xsmall" size='small' title=""/><label className="uploadDocument" >Add supporting information</label>
                                </div>
                            </div>

                </div>

               
                        <div class="invoice_container" style={{ marginBottom: '24px' }}>
                            <div class="inner_column">
                                <label class="label_title">Invoice summary</label>
                                </div>
                                <form class="user_form">
                                {/* Index Manual Form */}
                                <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Deal ID" maxlength="30"
                                     value={this.state.leaseContractId} inputType="text"
                                        name="leasecontractid" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div> 
                                <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Base rent"
                                         maxlength="30" value={this.state.baseRent} inputType="number"
                                        name="baserent" onChange={this.handleChange} placeholder="Enter" 
                                        errorStatus={this.state.baseRentError}
                                        errorMessage={this.state.baseRentErrorMessage}/>
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Base rent description"
                                         maxlength="30" value={this.state.baseRentDesc} inputType="text"
                                        name="baserentdescription" onChange={this.handleChange} placeholder="Enter"/>
                                        </div>
                                       
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Index adjustment" 
                                        maxlength="30" value={this.state.indexAdjustment} inputType="number"
                                        name="indexadjustment" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Index adjustment description" maxlength="30"  
                                        inputType="text" value={this.state.indexAdjustmentDesc}
                                        name="indexadjustmentdescription" onChange={this.handleChange} placeholder="Enter"/>
                                        </div>
                                       
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Interest adjustment" maxlength="30" 
                                        value={this.state.interestAdjustment} inputType="number"
                                        name="interestadjustment" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Interest adjustment description" maxlength="30"  
                                        inputType="text" value={this.state.interestAdjustmentDesc}
                                        name="interestadjustmentdescription" onChange={this.handleChange} placeholder="Enter"/>
                                        </div>
                                       
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Rent rebate" maxlength="30" value={this.state.rentRebate} inputType="number"
                                        name="rentrebate" onChange={this.handleChange} placeholder="Enter" 
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Rent rebate description" maxlength="30"  
                                        inputType="text" value={this.state.rentRebateDesc}
                                        name="rentrebatedescription" onChange={this.handleChange} placeholder="Enter"/>
                                        </div>
                                       
                                        </div>

                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Rent adjustment" maxlength="30" value={this.state.rentAdjustment} inputType="number"
                                        name="rentadjustment" onChange={this.handleChange} placeholder="Enter" 
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Rent adjustment description" maxlength="30"  
                                        inputType="text" value={this.state.rentAdjustmentDesc}
                                        name="rentadjustmentdescription" onChange={this.handleChange} placeholder="Enter"/>
                                        </div>
                                       
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur"
                                         fieldTitle="Property tax" maxlength="30" value={this.state.propertyTax} inputType="number"
                                        name="propertytax" onChange={this.handleChange} placeholder="Enter" 
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                                        <div className="row">
                                        <div className="col-sm-8">
                                        <InputfieldCustom customClass="input_Fields_eur" 
                                        fieldTitle="Property tax description" maxlength="30"  
                                        inputType="text" value={this.state.propertyTaxDesc}
                                        name="propertytaxdescription" onChange={this.handleChange} placeholder="Enter"/>
                                        </div>
                                       
                                        </div>

                                        <div className="row" >
                                        <div className="col-sm-8">
                                        <InputFieldDisabled disabled={true} customClass="input_Fields_eur"
                                         fieldTitle="Total rent" maxlength="30" value={this.state.totalRent} inputType="text"
                                        name="totalrent" onChange={this.handleChange} placeholder="Enter" 
                                        /> 
                                        </div>
                                        <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                        </div>
                               
                                 
                                
                                
                               
                                 

                                        <div className="Separator_line"></div>  

                                       
                                <div class="inner_column">
                                <label class="label_title">Invoice details</label>
                                </div>
                                <Dropdownfieldcustom customLabel="field_label_model_select" 
                                title="Invoice type" classname="font_config_custom" 
                                    data={this.generateData('invoicetype')} name="invoicetype"
                                    errorStatus={this.state.currencyStatus} errorMessage={this.state.dealErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'invoicetype')} selectedValue='Index' isDisabled='true'/>
                                
                              
                                <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="SPV" maxlength="30" 
                                    value={this.state.spv} inputType="text"
                                        name="spv" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div>

                                <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Customer" maxlength="30"
                                     value={this.state.customer} inputType="text"
                                        name="customer" onChange={this.handleChange} placeholder="Enter" 
                                        errorStatus={this.state.customerNameError}
                                        errorMessage={this.state.customerNameErrorMessage}/> 
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div>

                                <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Area code" maxlength="30"
                                     value={this.state.areaCode} inputType="text"
                                        name="areacode" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div>
                                        
                                
                                <Dropdownfieldcustom customLabel="field_label_model_select" title="Currency" classname="font_config_custom" 
                                    data={this.generateData('currency')} name="currency" 
                                    selectedValue={this.state.currencyName}
                                    errorStatus={this.state.currencyStatus} errorMessage={this.state.dealErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'currency')} isDisabled='' />
                                <Dropdownfieldcustom customLabel="field_label_model_select" title="PMT terms" classname="font_config_custom" 
                                    data={this.generateData('pmtterms')} name="pmtterms"
                                     selectedValue={this.state.pmtTerms}
                                    errorStatus={this.state.currencyStatus} errorMessage={this.state.dealErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'pmtterms')} isDisabled=''/>
                                 <Dropdownfieldcustom customLabel="field_label_model_select" title="Invoicing frequency"
                                 classname="font_config_custom" 
                                    data={this.generateData('invoicingfrequency')} name="invoicingfrequency" 
                                    selectedValue={this.state.invoicingFrequency}
                                    errorStatus={this.state.currencyStatus} errorMessage={this.state.dealErrorMessage}
                                        onChange={this.getDropdownItem.bind(this, 'invoicingfrequency')} isDisabled=''/>


                                    <div className="row">
                                    <div className="col-sm-8">
                                    <Calenderinputfield fieldTitle="Invoicing start date" 
                                     value={this.state.invoicingStartDate}
                                    inputType="date" name="invoicingstartdate" 
                                     onChange={this.getInvoicingStartDate} 
                                    placeholder="DD/MM/YYYY" />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div>

                                    <div className="row">
                                    <div className="col-sm-8">
                                    <Calenderinputfield fieldTitle="Invoicing end date" 
                                     value={this.state.invoicingEndDate} 
                                    inputType="date" name="invoicingenddate" 
                                   onChange={this.getInvoicingEndDate}
                                     placeholder="DD/MM/YYYY"  errorStatus={this.state.invoicingEndDateError}
                                     errorMessage={this.state.invoicingEndDateErrorMessage}/>
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div>

                                    <div className="row">
                                    <div className="col-sm-8">
                                    <InputfieldCustom customClass="input_Fields_eur" fieldTitle="Lease fee" 
                                    maxlength="30" value={this.state.leaseFee} inputType="text"
                                    name="leasefee" onChange={this.handleChange} placeholder="Enter" 
                                        />  
                                    </div>
                                    <label class="col-sm-2 field_back_label_eur">{this.state.currencyName}</label>
                                    </div>

                                
                                

                                        
                                <div className="Separator_line"></div>  

                                       
                                <div class="inner_column">
                                <label class="label_title">Indexation figures</label>
                                </div>

                                <div className="row">
                                        <div className="col-sm-8">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Index" 
                                        maxlength="30" value={this.state.index} inputType="text"
                                        name="index" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_small">%</label>
                                        </div>


                                        <div className="row">
                                        <div className="col-sm-8">
                                        <div className="container">
                            <div className="row">
                            <div className="col-sm-5 customer_type" style={{ marginLeft: '-148px' }}>
                            <label className="col-sm-11 col-form-label field_label_model" style={{ marginLeft: '-8px' }}>Index type</label>
                            </div>
                            <div className="col-sm-5 customer_type" style={{ marginLeft: '-62px', paddingBottom: '8px', Top: '2px' }}>
                        <div className="btn-group" style={{
                            width: '218px',
                            height: '44px',
                            border: 'solid 1px #c9c6c6',
                            backgroundColor: '#fff'
                        }}>
                            <button type="button" className={"btn btn-primary customer_btn " + (this.state.partyTypeSelect ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.getSelectedIndex.bind(this, 'fixed')}>Fixed</button>
                            <button type="button" className={"btn btn-primary customer_btn " + (!this.state.partyTypeSelect ? 'dealtype_selected' : 'dealtype_notselected')} onClick={this.getSelectedIndex.bind(this, 'cpi')}>CPI</button>
                        </div>
                    </div>
                    </div>
                    </div>                   
                    </div>
                                        <label class="col-sm-2 field_back_label_small"></label>
                                        </div>

                                        { this.state.indexType == 'CPI' ? <div className="row">
                                        <div className="col-sm-8">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Index scaling" maxlength="30" value={this.state.indexScaling} inputType="text"
                                        name="indexscaling" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_small">%</label>
                                        </div> : null }
                                        { this.state.indexType == 'CPI' ?  <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Index Name" maxlength="30" value={this.state.indexName} inputType="text"
                                        name="indexname" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div> : null }
                                        { this.state.indexType == 'CPI' ?  <div className="row">
                                    <div className="col-sm-8">
                                    <Calenderinputfield fieldTitle="Index base date" 
                                     value={this.state.indexBaseDate}
                                    inputType="date" name="indexbasedate" 
                                     onChange={this.getIndexBaseDate} 
                                    placeholder="DD/MM/YYYY" />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div> : null }
                                        { this.state.indexType == 'CPI' ? 
                                    <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Index base number" maxlength="30"
                                     value={this.state.indexBaseNumber} inputType="text"
                                        name="indexbasenumber" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div> : null }
                                        { this.state.indexType == 'CPI' ?  <div className="row">
                                        <div className="col-sm-8">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage" fieldTitle="Index floor"
                                         maxlength="30" value={this.state.indexFloor} inputType="text"
                                        name="indexfloor" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_small">%</label>
                                        </div> : null }
                                        { this.state.indexType == 'CPI' ?    <div className="row">
                                    <div className="col-sm-8">
                                    <Calenderinputfield fieldTitle="Index review date" 
                                     value={this.state.indexReviewDate}
                                    inputType="date" name="indexreviewdate" 
                                     onChange={this.getIndexReviewDate} 
                                    placeholder="DD/MM/YYYY" />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                    </div> : null }
                                        { this.state.indexType == 'CPI' ? <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Index review number" maxlength="30" 
                                    value={this.state.indexReviewNumber} inputType="text"
                                        name="indexreviewnumber" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div>   : null }
                                        
                                 
                                        
                            
                        
                                       

                               

                                

                               

                                     

                                    <div className="row hide">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Index review number" maxlength="30" value={this.state.indexReviewNumber} inputType="text"
                                        name="indexreviewnumber" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div> 

                    
                            <div className="Separator_line"></div>  

                                       
                    <div class="inner_column">
                    <label class="label_title">Interest adjustment</label>
                    </div> 

                     <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Rent adjustment per bps" maxlength="30" 
                                    value={this.state.rentAdjustmentPerBps} inputType="text"
                                        name="rentadjustmentperbps" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div> 

                                <div className="row">
                                    <div className="col-sm-8">
                                    <Inputfield fieldTitle="Number of bps adjustments" maxlength="30"
                                     value={this.state.numberOfBpsAdjustment} inputType="text"
                                        name="numberofbpsadjustment" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                    </div>
                                    <label class="col-sm-2 field_back_label"></label>
                                </div> 

                   

<div className="Separator_line"></div>                      
                    <div class="inner_column">
                    <label class="label_title">Other</label>
                    </div> 

                    <div className="row">
                                        <div className="col-sm-8">
                                       
                                        <InputfieldCustom customClass="input_Fields_percentage"
                                         fieldTitle="Vatable proportion" maxlength="30" 
                                         value={this.state.vatableProportion} inputType="text"
                                        name="vatableproportion" onChange={this.handleChange} placeholder="Enter" 
                                        />
                                        </div>
                                        <label class="col-sm-2 field_back_label_small">%</label>
                                        </div>

                                        

                                        <div className="row">
                                        <label className="col-sm-3 col-form-label field_label_model" style={{"marginLeft":"-1px"}}>Other supporting comments</label>
                                        <div className="col-sm-8">
                                        <textarea
                                        maxlength="150" 
                                        value={this.state.otherSupportingComments}
                                        name="othersupportingcomments" onChange={this.handleChange} placeholder="Enter" 
                                        style={{
                                            width: 280
                                        }}
                                        rows="5"
                                        className="zb-textarea"
                                        aria-invalid="true"
                                        />
                                        {/* <Inputfield fieldTitle="Other supporting comments" maxlength="30" 
                                        value={this.state.otherSupportingComments} inputType="text"
                                        name="othersupportingcomments" onChange={this.handleChange} placeholder="Enter" 
                                        />   */}
                                        </div>
                                        <label class="col-sm-2 "></label>
                                        </div>

                                        <Dropdownfieldcustom customLabel="field_label_model_select" 
                                        title="Language preference" classname="font_config_custom" 
                                        data={this.generateData('languagepreference')} name="languagepreference"
                                        onChange={this.getDropdownItem.bind(this, 'languagepreference')} 
                                        selectedValue='English' isDisabled=''/>
                                
                                <br/>
                                  
                    


                                </form>
                                </div>
                                <div class="modal-footer" style={{
                    display: 'table', border: 'none', margin: '10px auto auto 38px', paddingLeft:'52px'}}>
                    <button type="button" disabled= {this.state.exportButton} onClick={this.saveInvoiceData.bind(this)} className="zb-button zb-button-primary model_invoice_btn">Export to Oracle</button> 
                    {/* onClick={this.saveInvoiceData.bind(this)} */}
                    <button type="button" disabled= {this.state.recalculateInvoice} className="zb-button zb-button-secondary cancel_invoice_btn" data-toggle="modal" data-target="#cancelSave">Re-calculate invoice</button>
                </div>
                              
                                
               
            
               
              
            </div>
        )
    }
}

export default viewInvoicingDetail;