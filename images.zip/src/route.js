import 'react-app-polyfill/ie9';
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React, { Fragment, PureComponent } from 'react'
import ReactDOM from 'react-dom';
import './index.css';
import addCustomer from './components/addCustomer/customer';
import viewCustomerList from './components/viewCustomerList/viewCustomerList';
import viewCustomerDetail from './components/viewCustomerDetail/viewCustomerdetail';
import modelNewDeal from './components/modelDeal/modelNewDeal';
import intrestInvoicingForm from './components/intrestInvoicingForm/intrestInvoicingForm'
import EditCustomer from './components/addCustomer/editCustomer';
import EmptyTLPGrid from './components/TLPgrid/emptyTLPGrid';
import UpdateTLPGrid from './components/TLPgrid/updateGrid';
import ApproveTLPGrid from './components/TLPgrid/approveTLPGrid';
import viewInvoicingDetail from './components/viewInvoicingDetail/viewInvoicingDetail';
import Home from './components/home/home';
import Header from './commonComponents/header.js';
import { Route, Redirect, Switch } from 'react-router-dom';
import LoginError from './components/login/loginError';
import ServerDown from './components/login/serverDown';
import { AuthorizationContext } from './components/authContext/index';
import { BASE_URL, API_ENDPOINT, REACT_APP_IAM_BASE_URI, REACT_APP_IAM_CLIENT_ID } from '../src/config/config';
import Notification from './components/notification/notification';
import invoiceList from './components/invoiceList/invoice';
import PeriodSummaryTL from './components/modelDealSummary/leaseDataModelTimeline/periodSummaryTL';
import mainSummaryTabsPage from './components/modelDealSummary/mainSummaryTabs/mainSummaryTabsPage';
import DealApprovalsMain from './components/dealApprovals/dealApprovalsMain';
import calculateIndexInvoice from './components/calculateIndexInvoice/recalculateIndex';
import creditInvoice from './components/creditInvoice/creditInvoice';
import creditInvoiceInterest from './components/creditInvoiceInterest/creditInvoiceInterest';
import calculateInterest from './components/intrestInvoicingForm/calculateInterest';
import invoiceListApprover from './components/invoiceListApprover/invoiceApprover';
import viewAssets from './components/assets/viewAssetList';
import addAsset from './components/assets/addNewAsset';
import editAsset from './components/assets/editasset';
import assetDetails from './components/assets/assetDetails'
import viewDealList from './components/modelDealList/viewDealList';
import invoiceSummaryScreen from './components/invoiceSummary/invoiceSummaryScreen';
import LeaseParentModel from './components/modelDeal/LeaseParentModel';
const PING = process.env.REACT_APP_PING; //Development URl
export default class Router extends PureComponent {

  static contextType = AuthorizationContext;

  render() {
    const { token, isAdmin, serviceStatus } = this.context;
    var serviceCount = localStorage.getItem('serviceCount');
    var internalServerError = false;
    const appURL = window.location.href;
    var path = window.location.href;
    localStorage.setItem('path', appURL);
    console.log("Path :" + path + "appURL :" + appURL);
    console.log("Dynamic BASE_URL: " + BASE_URL)
    if (path == appURL + '#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-nft.edi01-apps.dev-pcf2.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-nft.apps.dev-pcf.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-dev2.apps.dev-pcf.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-uat.apps.dev-pcf.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-uat.edi01-apps.dev-pcf2.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-dev.edi01-apps.dev-pcf2.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://lmsui-dev.apps.dev-pcf.lb1.rbsgrp.net/#error_description=Employee+ID+is+Invalid&error=access_denied' || path == 'https://vstspes05d.server.rbsgrp.mde:6401/as/authorization.oauth2?client_id=client_staff_wiam01_NordiskLMS&response_type=token&redirect_uri=https://lmsui-uat.edi01-apps.dev-pcf2.lb1.rbsgrp.net/') {
      localStorage.setItem('errorCode', '401');
      internalServerError = true;
      serviceCount = 2;

    }

    return (
      <div>
        {PING == 'true' ?
          <div className="">
            {token != '' && isAdmin == true && internalServerError == false ?
              <Fragment>
                <Header />
                <Switch>
                  <Route exact path="/" component={Home} />
                  <Route exact path="/lms/addCustomer" component={addCustomer} />
                  <Route exact path="/lms/viewCustomerList" component={viewCustomerList} />
                  <Route exact path="/lms/viewCustomerDetail" component={viewCustomerDetail} />
                  <Route exact path="/lms/modelNewDeal" component={modelNewDeal} /> 
                  <Route exact path="/lms/emptyTLPGrid" component={EmptyTLPGrid} />.
                  <Route exact path="/lms/updateTLPGrid" render={() => <UpdateTLPGrid />} />
                  <Route exact path="/lms/ApproveTLPGrid" component={ApproveTLPGrid} />
                  <Route exact path="/lms/EditCustomer" component={EditCustomer} />
                  <Route exact path="/lms/Notification" component={Notification} />
                  {/* <Route exact path="/lms/PeriodSummaryTL" component={PeriodSummaryTL} /> */}
                  <Route exact path="/lms/mainSummaryTabsPage" component={mainSummaryTabsPage} />
                  <Route exact path="/lms/LoginError" component={LoginError} />
                  <Route exact path="/lms/serverDown" component={ServerDown} />
                  <Route exact path="/lms/viewAssetDetail" component={viewAssets} />
				          <Route exact path="/lms/viewDealList" component={viewDealList} />
                  <Route exact path="/lms/LeaseModel" component={LeaseParentModel} />
                  <Route exact path="/lms/Home" component={Home} />
                  <Route exact path="/" component={Home} />
                  <Route exact path="/lms/viewInvoicingDetail" component={viewInvoicingDetail} />
                  <Route exact path="/lms/interestInvoicingForm" component={intrestInvoicingForm} /> 
                  <Route exact path="/lms/invoiceList" component={invoiceList} />
                  <Route exact path="/lms/invoiceListApprover" component={invoiceListApprover} />
                  <Route exact path="/lms/calculateIndexInvoice" component={calculateIndexInvoice} />
                  <Route exact path="/lms/calculateInterest" component={calculateInterest} />
                  <Route exact path="/lms/dealApprovals" component={DealApprovalsMain} />
                  <Route exact path="/lms/property" component={addAsset} />
                  <Route exact path="/lms/editasset" component={editAsset} />
                  <Route exact path="/lms/asset" component={assetDetails} />
                  <Route exact path="/lms/invoiceSummaryScreen" component={invoiceSummaryScreen} />
                  <Route exact path="/lms/creditInvoice" component={creditInvoice} />
                  <Route exact path="/lms/creditInvoiceInterest" component={creditInvoiceInterest} />
                </Switch>
              </Fragment> : (parseInt(serviceCount) == 2 ?
                <Fragment>
                  {/* <Header /> */}
                  <Switch>
                    {/* <Route exact path="/lms/Error" component={LoginError} /> */}
                    <Route exact path="/" component={LoginError} />
                  </Switch>
                </Fragment> : null
              )
            }
          </div> :
          <div>
            <Fragment>
              <Header />
              <Switch>
                <Route exact path="/" component={Home} />
                <Route exact path="/lms/addCustomer" component={addCustomer} />
                <Route exact path="/lms/viewCustomerList" component={viewCustomerList} />
                <Route exact path="/lms/viewCustomerDetail" component={viewCustomerDetail} />
                <Route exact path="/lms/modelNewDeal" component={modelNewDeal} />
                <Route exact path="/lms/emptyTLPGrid" component={EmptyTLPGrid} />
                <Route exact path="/lms/updateTLPGrid" render={() => <UpdateTLPGrid />} />
                <Route exact path="/lms/ApproveTLPGrid" component={ApproveTLPGrid} />
                <Route exact path="/lms/EditCustomer" component={EditCustomer} />
                <Route exact path="/lms/Notification" component={Notification} />
                {/* <Route exact path="/lms/PeriodSummaryTL" component={PeriodSummaryTL} /> */}
                <Route exact path="/lms/mainSummaryTabsPage" component={mainSummaryTabsPage} />
                <Route exact path="/lms/LoginError" component={LoginError} />
                <Route exact path="/lms/serverDown" component={ServerDown} />
                <Route exact path="/lms/viewAssetDetail" component={viewAssets} />
                <Route exact path="/lms/LeaseModel" component={LeaseParentModel} />
                <Route exact path="/lms/Home" component={Home} />
                <Route exact path="/" component={Home} />
                <Route exact path="/lms/viewInvoicingDetail" component={viewInvoicingDetail} />
                <Route exact path="/lms/interestInvoicingForm" component={intrestInvoicingForm} /> 
                <Route exact path="/lms/calculateInterest" component={calculateInterest} /> 
                <Route exact path="/lms/invoiceList" component={invoiceList} />
                <Route exact path="/lms/invoiceListApprover" component={invoiceListApprover} />
                <Route exact path="/lms/calculateIndexInvoice" component={calculateIndexInvoice} />
                <Route exact path="/lms/dealApprovals" component={DealApprovalsMain} />
                <Route exact path="/lms/property" component={addAsset} />
                <Route exact path="/lms/editasset" component={editAsset} />
                <Route exact path="/lms/asset" component={assetDetails} />
                <Route exact path="/lms/viewDealList" component={viewDealList} />
                <Route exact path="/lms/invoiceSummaryScreen" component={invoiceSummaryScreen} />
                <Route exact path="/lms/creditInvoice" component={creditInvoice} />
                <Route exact path="/lms/creditInvoiceInterest" component={creditInvoiceInterest} />
              </Switch>
            </Fragment>
          </div>
        }
      </div>
    )
  }
}
