import React, { Component } from 'react';
// import console = require('console');

export const validation = {
    customername: {
        presence: {
            message: 'Customer name is a mandatory field.  Please enter a valid customer name.'
        }
    },
    country: {
        /*presence: {
            message: 'Please select country value.'
        }*/
    },
    documentDescription: {
        presence: {
            message: 'Please enter the document description.'
        }
    },
    dropdown: {
        presence: {
            message: 'Please select option from the dropdown'
        }
    },
    customertype: {
        presence: {
            message: 'Customer Type is a mandatory field. '
        }
    },
    postcode: {
        /* presence:{
             message:'Postal code is a mandatory field.'
         },*/
        length: {
            maximum: {
                val: 10,
                message: "Length should not be greater than 10"
            }
        }
    },
    contactname: {
        /* presence:{
             message:'Contact Name is a mandatory field.'
         }*/
    },
    contactrole: {
        /* presence:{
             message:'Field is required'
         },*/
        length: {
            maximum: {
                val: 20,
                message: "Length should not be greater than 20"
            }
        }
    },
    address: {
        /*presence: {
             message: 'Address is a mandatory field.'
        },*/
        format: {
            pattern: /^[A-Za-z0-9,.-\s]*$/,
            message: 'Please enter valid address'
        }
    },

    creditrating: {
        format: {
            pattern: /^[a-zA-Z_0-9+-]*$/,
            message: "Please enter valid credit rating"
        }
    },
    webpage: {
        format: {
            pattern: /^[a-zA-Z_0-9@:._//]*$/,
            message: "Please enter valid rating Source Webpage"
        }
    },
    webpageText: {
        format: {
            pattern: /^[a-zA-Z_0-9@:._//]*$/,
            message: "Please enter valid webpage value"
        }
    },
    tenor: {
        // format: {
        //     pattern: /^\d+\d{0,2}$/,
        //     message: "Please enter valid tenor value"
        // },
        presence: {
            message: 'Please complete this field'
        },
        length: {
            maximum: {
                val: 5,
                message: "Please enter valid tenor value"
            }
        },
        type: {
            message: "Please enter valid tenor value"
        }
        // range: {
        //     maximum: {
        //         val: 2,
        //         message: "Please enter valid tenor value"
        //     }
        // }
    },
    mobilenumber: {
        /* presence: {
             message: 'Please enter a valid mobile number'
         },*/
        format: {
            pattern: /^[0-9+-]*$/,
            message: "Please enter valid mobile number"
        },
        length: {
            minimum: {
                val: 10,
                message: "Length should not be less than 10"
            },
            maximum: {
                val: 15,
                message: "Length should not be greater than 15"
            }
        }
    },
    officenumber: {
        /* presence:{
             message:'Please enter a valid office number'
         },*/
        format: {
            pattern: /^[0-9+-]*$/,
            message: "Please enter valid office number"
        },
        length: {
            minimum: {
                val: 10,
                message: "Length should not be less than 10"
            },
            maximum: {
                val: 15,
                message: "Length should not be greater than 15"
            }
        }
    },
    mgs: {
        format: {
            pattern: /^[0-9]*$/,
            message: "Please enter valid master grading scale value"
        },
        // range: {
        //     maximum: {
        //         val: 27,
        //         message: "Please enter valid master grading scale value"
        //     }
        // }

    },
    email: {
        /* presence:{
             message:'Please enter a valid email address'
         },*/
        format: {
            //            pattern: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            pattern: /^([A-Za-z0-9_+-]*)@([a-z0-9][-a-z0-9\.]*[a-z0-9]\.(arpa|root|aero|biz|cat|com|coop|edu|gov|info|int|jobs|mil|mobi|museum|name|net|org|pro|tel|travel|ac|ad|ae|af|ag|ai|al|am|an|ao|aq|ar|as|at|au|aw|ax|az|ba|bb|bd|be|bf|bg|bh|bi|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|cr|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|ee|eg|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|im|in|io|iq|ir|is|it|je|jm|jo|jp|ke|kg|kh|ki|km|kn|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|mv|mw|mx|my|mz|na|nc|ne|nf|ng|ni|nl|no|np|nr|nu|nz|om|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tl|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)|([0-9]{1,3}\.{3}[0-9]{1,3}))$/,
            message: "Please enter valid email address"
        }
    },
    city: {
        format: {
             pattern: /^[A-Za-z0-9,.-\s]*$/,
            message: "Please enter valid city"
        }
    },
    addressline2: {
        format: {
             pattern: /^[A-Za-z0-9,.-\s]*$/,
            message: 'Please enter valid address'
        }
    }
}

export function validate(nameField, value) {
    let resp = [null, ""];
    
    if(validation.hasOwnProperty(nameField)){
        let v = validation[nameField];
        if (nameField == 'tenor') { 
            let val = value.toString().split(".")[0];
            if (val > 99) { 
                resp[0] = false
                resp[1] = "Tenor should not be greater than 99"
                localStorage.setItem('errorStatus', 'true');
            }
            if (Math.sign(value) === -1) {
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('errorStatus', 'true');
            }
            // if(val.length > )
        }
        if (nameField == 'mgs') { 
            if (value > 27) { 
                resp[0] = false
                resp[1] = "Master grading scale should not be greater than 27"
                localStorage.setItem('errorStatus', 'true');
            }
        }
        if (value === "" || value == null) {
            console.log("namefield:: ", nameField);
            resp[0] = false;
            // if (nameField != 'creditrating' && nameField != 'webpage' && nameField != 'webpageText'
            //     && nameField != 'city' && nameField != 'addressline2') {
            if (nameField == 'customername' || nameField == 'customertype' || nameField == 'tenor' ||
                nameField == 'documentDescription' || nameField == 'dropdown') {
                resp[1] = v['presence']['message']
            } else {
                resp[0] = true;
            }
            localStorage.setItem('errorStatus', 'false');
        } else if (v.hasOwnProperty('format')) {
            let emailvalidation = v['format'];
            if (emailvalidation["pattern"].test(value) == false) {
                resp[0] = false
                resp[1] = emailvalidation['message']
                localStorage.setItem('errorStatus', 'true');
            }
        } else if (v.hasOwnProperty("format") && !v['format']['pattern'].test(value)) {
            resp[0] = false
            resp[1] = v['format']['message']
            localStorage.setItem('errorStatus', 'true');
        }  else if (v.hasOwnProperty('length')) {
            let l = v['length'];
            if (l.hasOwnProperty('minimum') && value.length < l['minimum']['val']) {
                resp[0] = false
                resp[1] = l['minimum']['message']
                localStorage.setItem('errorStatus', 'true');
            } else if (value != null && l.hasOwnProperty('maximum') && value.length > l['maximum']['val']) {
                resp[0] = false
                resp[1] = l['maximum']['message']
                localStorage.setItem('errorStatus', 'true');
            }
        } else {
            localStorage.setItem('errorStatus', 'false');
            resp[0] = true
        }
    } else {
        localStorage.setItem('errorStatus', 'false');
        resp[0] = true
    }
    return resp;
}

export const invoiceValidation={
    customer:{
        presence:{
            message:'Customer name is a mandatory field. Please enter a valid customer name.'
        }
    },
    invoicingenddate:{ 
        presence:{
            message:'Invoicing end date name is a mandatory field. Please enter a valid Invoicing end date.'
        }
    },
    baserent:{ 
        presence:{
            message:'Base rent is a mandatory field. Please enter a valid base rent.'
        }
    }
}


export function validateInvoice(nameField, value) {
    let resp = [null, ""];
    
    if(invoiceValidation.hasOwnProperty(nameField)){
        let v = invoiceValidation[nameField];
      
        if(value == "" || value == null){
            resp[0] = false;
            if (nameField == 'customer' || nameField == 'invoicingenddate'||nameField == 'baserent') {
                resp[1] = v['presence']['message']
            } else { 
                resp[0] = true;
            }
            localStorage.setItem('errorStatusInvoice', 'true');
        } 
    } else {
        localStorage.setItem('errorStatusInvoice', 'false');
        resp[0] = true
    }
    return resp;


}


export const calculateInterestValidation={
    // bookvaluescalerfloat:{
    //     presence:{
    //         message:'Book value scaler float is a mandatory field. Please enter a valid book value scaler.'
    //     }
    // },
    // bookvaluescalerfixed:{ 
    //     presence:{
    //         message:'Book value scaler fixed is a mandatory field. Please enter a valid book value scaler.'
    //     }
    // },
    // interestratefloat:{ 
    //     presence:{
    //         message:'Interest rate float is a mandatory field. Please enter a valid interest rate.'
    //     }
    // },
    // interestratefixed:{ 
    //     presence:{
    //         message:'Interest rate fixed is a mandatory field. Please enter a valid interest rate .'
    //     }
    // },
    // tlpvalue:{ 
    //     presence:{
    //         message:'TLP is a mandatory field. Please enter a valid TLP.'
    //     }
    // },
    // marginvalue:{ 
    //     presence:{
    //         message:'Margin is a mandatory field. Please enter a valid margin.'
    //     }
    // }
    
}



export function validateCalculateInterest(nameField, value) {
    let resp = [null, ""];
    
    if(calculateInterestValidation.hasOwnProperty(nameField)){
        let v = calculateInterestValidation[nameField];
      
        if(value == "" || value == null){
            resp[0] = false;
            if (nameField == 'bookvaluescalerfloat' || nameField == 'bookvaluescalerfixed' || nameField == 'interestratefloat'
            ||nameField == 'interestratefixed' ||nameField == 'tlpvalue' || nameField == 'marginvalue' ) 
            {
                resp[1] = v['presence']['message']
            } else { 
                resp[0] = true;
            }
            localStorage.setItem('errorStatusCalculateInterest', 'true');
        } 
    } else {
        localStorage.setItem('errorStatusCalculateInterest', 'false');
        resp[0] = true
    }
    return resp;


}
