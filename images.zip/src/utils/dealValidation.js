import React, {Component} from 'react';
// import console = require('console');

export const dealValidation={
    customerName:{
        format: {
            pattern: /^[a-zA-Z ]+|[\b]+$/,
            message: 'Please enter valid Customer Name'
        },
        length:{
           maximum:{
            val: 30,
           } 
        }
    },
    spv:{
        format: {
            pattern: /^[a-zA-Z0-9 ]+|[\b]+$/,
            message: 'Please enter valid SPV'
                },
        length:{
            maximum:{
                val: 15,
            }
        }
    },
    description:{
        presence: {
            message: 'Please enter the description.'
        },
        format: {
            pattern: /^[a-zA-Z0-9 ]+|[\b]+$/,
            message: "Please enter valid description"
                },
        length:{
            maximum:{
                val: 150,
            }
        }
    },
    returnModel:{
        presence: {
            message: 'Please complete this field'
        }
    },
    LGD: {
        presence: {
            message: 'Please complete this field'
        },
        format: {
            pattern: /^[0-9]{0,2}.?[0-9]{0,2}$/,
            message: 'Please enter valid LGD value'
        },
        length: {
            maximum: {
                val: 5,
            }
        },
        type: {
            message: "Please enter valid LGD value"
        }
    },
    FirstPeriodLeaseFee:{
        presence:{
            message: "Please complete this field."
        },
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: "Please enter valid FirstPeriodLeaseFee"
        },
        length: {
            maximum: {
                val: 15,
            }
        },
        
    },
    ResidualValue:{
        presence:{
            message: "Please complete this field."
        },
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid ResidualValue Value'
        },
        length: {
            maximum: {
                val: 18,
                message: "Please enter valid ResidualValue value"
            }
        },
        type: {
            message: "Please enter valid ResidualValue value"
        }
    },
    VPV: {
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid VPV Value'
        },
        length: {
            maximum: {
                val: 18,
            }
        },
        type: {
            message: "Please enter valid VPV value"
        }
    },
    RLV: {
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid RLV Value'
        },
        length: {
            maximum: {
                val: 18,
            }
        },
        type: {
            message: "Please enter valid RLV value"
        }
    },
    AquisitionCost:{
        presence:{
            message: "Please complete this field."
        },
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid AcquisitionCost Value'
        },
        length: {
            maximum: {
                val: 18,
            }
        },
        type: {
            message: "Please enter valid Acquisition Cost value"
        }
    },
    CorporateTaxRate: {
        format: {
            pattern: /^[0-9]{0,2}.?[0-9]{0,2}$/,
            message: 'Please enter valid CorporateTaxRate value'
        },
        length: {
            maximum: {
                val: 5,
            }
        },
        type: {
            message: "Please enter valid CorporateTaxRate value"
        } 
    },
    fxRate: {
        format: {
            pattern: /^[0-9]{0,2}.?[0-9]{0,4}$/,
            message: 'Please enter valid FxRate Value'
        },
        length: {
            maximum: {
                val: 7,
            }
        },
        type: {
            message: "Please enter valid FxRate value"
        } 
    },
    Turnover: {
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid Turnover Value'
        },
        presence: {
            message: 'Please complete this field'
        },
        length: {
            maximum: {
                val: 18,
            }
        },
        type: {
            message: "Please enter valid Turnover value"
        }
    },
    Indexation: {
        presence: {
            message: 'Please complete this field.'
        },
        format: {
            pattern: /^-?[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Indexation value'
        },
        length: {
            maximum:{
                val: 5,
            }
        },
        type: {
            message: 'Please enter valid Indexation value'
        }
    },
    Floor: {
        format: {
            pattern: /^[0-9]{0,2}.?[0-9]{0,2}$/,
            message: 'Please enter valid Floor Value'
        },
        length: {
            maximum: {
                val: 5,
            }
        },
        type: {
            message: "Please enter valid Floor value"
        } 
    },
    IndexationScaling: {
        presence: {
            message: "Please complete this field."
        },
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Indexation Scaling value'
        },
        length: {
            maximum: {
                val: 6,
            }
        },
        type: {
            message: "Please enter valid Indexation Scaling value"
        } 
    },
    indexationName: {
        format: {
            pattern: /^[a-zA-Z0-9 ]+|[\b]+$/,
            message: 'Please enter valid Indexation Name'
                },
        length:{
            maximum:{
                val: 30,
            }
        }
    },
    baseIndexNumber: {
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Base Index Number Value'
        },
        length: {
            maximum: {
                val: 6,
            }
        },
        type: {
            message: "Please enter valid Base Index Number value"
        } 
    },
    TLPPeriod: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid TLP period value'
        },
        length: {
            maximum: {
                val: 3,
            }
        },
        type: {
            message: "Please enter valid TLP Period value"
        }
    },
    MarginPeriod: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Margin Period Value'
        },
        length: {
            maximum: {
                val: 6,
            }
        },
        type: {
            message: "Please enter valid Margin Period value"
        }
    },
    ReferenceRatePeriod: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Reference Rate Period Value'
        },
        length: {
            maximum: {
                val: 6,
            }
        },
        type: {
            message: "Please enter valid Reference Rate Period value"
        }
    },
    UpfrontOptionPremium: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid Upfront Option Premium value'
        },
        length: {
            maximum: {
                val: 15,
            }
        },
        type: {
            message: "Please enter valid Upfront option premium value"
        }
    },
    UpfrontOptionPremiumPercent: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Upfront Option Premium value'
        },
        length: {
            maximum: {
                val: 15,
            }
        },
        type: {
            message: "Please enter valid Upfront option premium value"
        }
    },
    PremiumAtExerciseDate: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9,]{0,15}.?[0-9]{0,2}$/,
            message: 'Please enter valid Exercise premium Value'
        },
        length: {
            maximum: {
                val: 15,
            }
        },
        type: {
            message: "Please enter valid Upfront Exercise premium value"
        }
    },
    PremiumAtExerciseDatePercent: {
        presence:{
            message: "Please complete this field"
        },
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Exercise premium Value'
        },
        length: {
            maximum: {
                val: 15,
            }
        },
        type: {
            message: "Please enter valid Upfront Exercise premium value"
        }
    },
    UpfrontFee:{        
        format: {
            pattern: /^[0-9]{0,3}.?[0-9]{0,2}$/,
            message: 'Please enter valid Upfront fee Value'
        },
        length: {
            maximum: {
                val: 6,
            }
        },
        type: {
            message: "Please enter valid Upfront fee value"
        }
    }

}

function removeCommas(str) {
    if(str != "" && str != undefined && str != null){
        while (str.search(",") >= 0) {
            str = (str + "").replace(',', '');
        }
        return str;
      }else{
        return str;
        }
};


export function dealValidate(nameField, value) {
    let resp = [null, ""];
    console.log(nameField);
    if(dealValidation.hasOwnProperty(nameField)){
        let v = dealValidation[nameField];
        console.log("range::: " + v.hasOwnProperty("range") + value);
        if (nameField == 'FirstPeriodLeaseFee' || nameField == 'ResidualValue' || nameField == 'RLV'
        || nameField == 'VPV' || nameField == 'AquisitionCost'
        || nameField == 'UpfrontOptionPremium' || nameField == 'PremiumAtExerciseDate') { 
             var a = removeCommas(value);
			 if(a !== null && a !== undefined){
				 let val = a.toString().split(".");
				let val1 = val[0];
				let val2 = val[1];
				console.log(nameField+" value");
				console.log(val);
				if (val1> 999999999999) { 
					resp[0] = false
					resp[1] = nameField+" should not be greater than 999,999,999,999.99"
					localStorage.setItem('dealErrorStatus', 'true');
				}
			 }
             
            
            if (Math.sign(value) === -1) {
                console.log("type111::::");
                console.log(Math.sign(value))
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
           
        }
        if (nameField == 'Turnover') { 
             var a = removeCommas(value);
             let val = a.toString().split(".");
            let val1 = val[0];
            let val2 = val[1];
            console.log(nameField+" value");
            console.log(val);
            if (val1> 50000000) { 
                resp[0] = false
                resp[1] = nameField+" should not be greater than 50000000"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            
            if (Math.sign(value) === -1) {
                console.log("type111::::");
                console.log(Math.sign(value))
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
           
        }
       if (nameField == 'LGD' || nameField == 'CorporateTaxRate' 
            || nameField == 'Floor') { 
        let val = value.toString().split(".");
        let val1 = val[0];
        let val2 = val[1];
        console.log(nameField+" value");
        console.log(val);
        if (val1 > 99 ) { 
            resp[0] = false
            resp[1] = nameField+" should not be greater than 99.99"
            localStorage.setItem('dealErrorStatus', 'true');
        }
        if (Math.sign(value) === -1) {
            console.log("type111::::");
            console.log(Math.sign(value))
            resp[0] = false
            resp[1] = v['type']['message']
            localStorage.setItem('dealErrorStatus', 'true');
        }
    }
       if (nameField == 'Indexation' || nameField == 'PremiumAtExerciseDatePercent'
            || nameField == 'UpfrontOptionPremiumPercent') { 
            let val = value.toString().split(".");
            let val1 = val[0];
            let val2 = val[1];
            console.log("Indexation value");
            console.log(val);
            if (val1 > 500) { 
                resp[0] = false
                resp[1] = nameField+" should not be greater than 500.00"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            if (val1< -99) { 
                resp[0] = false
                resp[1] = nameField+" should not be less than -99.99"
                localStorage.setItem('dealErrorStatus', 'true');
            } 
            if (val2 > 0 && val1 == 500) { 
            resp[0] = false
            resp[1] = nameField+" should not be greater than 500.00"
            localStorage.setItem('dealErrorStatus', 'true');
            }

    }
        if (nameField == 'fxRate') { 
            let val = value.toString().split(".");
            let val1 = val[0];
            let val2 = val[1];
            console.log("FX Rate value");
            console.log(val);
            if (val1 > 99 ) { 
                resp[0] = false
                resp[1] = "FX Rate should not be greater than 99.9999"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            if (val2 > 9999 ) { 
                resp[0] = false
                resp[1] = "FX Rate should not be greater than 99.9999"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            
            if (Math.sign(value) === -1) {
                console.log("type111::::");
                console.log(Math.sign(value))
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
            
        }
        if (nameField == 'IndexationScaling' || nameField == 'ReferenceRatePeriod'
        || nameField == 'TLPPeriod' || nameField == 'UpfrontFee') { 
            let val = value.toString().split(".");
            let val1 = val[0];
            let val2 = val[1];
            console.log(nameField+" value");
            console.log(val);
            if (val1 > 100 ) { 
                resp[0] = false
                resp[1] = nameField+" should not be greater than 100.00"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            if(val1 === '100'){
                if(val2 > 0){
                resp[0] = false
                resp[1] = nameField+" should not be greater than 100.00"
                localStorage.setItem('dealErrorStatus', 'true');
                }
            }
            if (Math.sign(value) === -1) {
                console.log("type111::::");
                console.log(Math.sign(value))
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
            
        }
        if (nameField == 'MarginPeriod') { 
            let val = value.toString().split(".");
            let val1 = val[0];
            let val2 = val[1];
            console.log("MarginPeriod value");
            console.log(val);
            if (val1 > 500) { 
                resp[0] = false
                resp[1] = nameField+" should not be greater than 500.00"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            if (val1< -99) { 
                resp[0] = false
                resp[1] = nameField+" should not be less than -99.99"
                localStorage.setItem('dealErrorStatus', 'true');
            } 
            if (val2 > 0 && val1 == 500) { 
            resp[0] = false
            resp[1] = nameField+" should not be greater than 500.00"
            localStorage.setItem('dealErrorStatus', 'true');
            }
            if (Math.sign(value) === -1) {
                console.log("type111::::");
                console.log(Math.sign(value))
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
        
    }
        if (nameField == 'baseIndexNumber') { 
            let val = value.toString().split(".")[0];
           console.log("Base Index Number value");
            console.log(val);
            if (val > 999 ) { 
                resp[0] = false
                resp[1] = "Base Index Number should not be greater than 999.99"
                localStorage.setItem('dealErrorStatus', 'true');
            }
            if (Math.sign(value) === -1) {
                console.log("type111::::");
                console.log(Math.sign(value))
                resp[0] = false
                resp[1] = v['type']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }    
        }
         if(value == "" || value == null){
            resp[0] = false;
            if (nameField != 'customerName' && nameField != 'spv' && nameField != 'VPV' && nameField != 'RLV'
            && nameField != 'CorporateTaxRate' && nameField != 'fxRate' && nameField != 'Floor' 
            && nameField != 'indexationName' && nameField != 'baseIndexNumber' && nameField != 'FirstPeriodLeaseFee'
            && nameField != 'Turnover' && nameField != 'ResidualValue' && nameField != 'UpfrontFee') {
                resp[1] = v['presence']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            } else { 
                resp[0] = true;
            }
            
        }  else if(v.hasOwnProperty('format')){
            let numbervalidation = v['format'];
            if(numbervalidation["pattern"].test(value) == false){
                resp[0] = false
                resp[1] = numbervalidation['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
        } else if(v.hasOwnProperty("format")&&!v['format']['pattern'].test(value)){
            resp[0] = false
            resp[1] = v['format']['message']
            localStorage.setItem('dealErrorStatus', 'true');
        } else if(v.hasOwnProperty('length')){
            let l = v['length'];
            if(l.hasOwnProperty('minimum') && value.length<l['minimum']['val']){
                resp[0] = false
                resp[1] = l['s']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }else if(l.hasOwnProperty('maximum') && value.length>l['maximum']['val']){
                resp[0] = false
                resp[1] = l['maximum']['message']
                localStorage.setItem('dealErrorStatus', 'true');
            }
        }   else {
            localStorage.setItem('dealErrorStatus', 'false');
            resp[0] = true
        }
    }else {
        localStorage.setItem('dealErrorStatus', 'false');
        resp[0] = true
    }

    return resp;
}

