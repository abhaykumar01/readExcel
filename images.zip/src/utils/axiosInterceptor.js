import axios from 'axios'
// import console = require('console');

const SetupInterceptor = (token, onLogout) => {
  axios.defaults.baseURL = `${process.env.REACT_APP_IAM_BASE_URI}/lms/`
  axios.defaults.headers.common.Authorization = `Bearer ${token}`
  axios.interceptors.response.use(
    config => config
    , function (response) {
      // alert('interceptors');
      
      return response;

    }
  , error => {
    if (error.response.status === 401) {
        onLogout()
      }
    }
  )
  
  // axios.interceptors.response.use(function (response) {
  //   // Do something with response data
  //   return response;
  // }, function (error) {
  //   // Do something with response error
  //   return Promise.reject(error);
  // });
}

export default SetupInterceptor