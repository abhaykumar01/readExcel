import React from 'react';
import moment from 'moment';

export function roundedDecimal(x) {
    if(x != null && x !== null && x !== undefined && x!= ''){
        let numberStr = Number.parseFloat(x).toFixed(2).toString();
        // if(numberStr.indexOf(".") == -1){
        //     let numberStr = Number.parseFloat(x).toString().concat('.00');
        //     let temp = numberStr.slice(0, (numberStr.indexOf(".")+3));
        //     return temp;
        // } else {
        //     let numberStr = Number.parseFloat(x).toString().concat('00');
        //     let temp = numberStr.slice(0, (numberStr.indexOf(".")+3));
        // return temp;
        // }   
        return numberStr;
     } 
  }

export function Comma(num) { 
    if(num != '' && num != undefined){
    num = num.toString().replace(/,/g, '');
    var x = num.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1))
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    return x1 + x2;
    }
}

export function removeComma(str) {
    let strWithoutComma = '';
    if(str != '' && str != undefined){
        if(str !== undefined && str != '') {
            strWithoutComma = str.replace(/,/g, '');
        }
    }
    
    return strWithoutComma;
}

export function precisePercentage(x) {
    if(x != null && x !== null && x !== undefined){
        var numberStr = Number.parseFloat(x).toFixed(2).toString();
       // window.alert(numberStr);
        // if(numberStr.indexOf(".") == -1){
        //     let numberStr = numberStr.toString().concat('.00');
        //     let temp = numberStr.slice(0, (numberStr.indexOf(".")+3));
        //     return temp;
        // } else {
        //     let numberStr = numberStr.toString().concat('00');
        //     let temp = numberStr.slice(0, (numberStr.indexOf(".")+3));
        //     return temp;
        // }   
        return numberStr;
     } else {
         return "-";
     }
  }

export function nullCheck(temp){
    var result = temp ? temp:'';
    return result;
}

export function precise(x) {
    if(x != null && x !== null && x !== undefined){
        let number= Number.parseFloat(x).toFixed(0).toString();
        //let number= Math.trunc(Number.parseFloat(x));
        return new Intl.NumberFormat('en-GB').format(number);
     } else {
         return "-";
     }
  }
  
  export function formatAmount(x) {
    if(x != null && x !== null && x !== undefined){
        let number= Number.parseFloat(x).toFixed(2).toString();
        //let number= Math.trunc(Number.parseFloat(x));
        return new Intl.NumberFormat('en-GB').format(number);
    } else {
         return "-";
     }
  }
