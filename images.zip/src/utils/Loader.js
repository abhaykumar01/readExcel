import React from 'react'

const Loader = () => (
  <div>
    <div className="zb-loader-block">
      <div className="zb-loader-content">
        <span className="zb-loader" />
      </div>
    </div>
  </div>
)

export default Loader
