// import React from 'react';
// import './customer.css';
// import SPV from '../../assets/images/spv.png';
// import Form from '../../commonComponents/form.js';
// import axios from 'axios';
// import Dropdown from '../../commonComponents/dropdown.js';
// import Api from '../../services/api.js'; 
// import Inputfield from '../../commonComponents/inputField.js';

// class addCustomer extends React.Component {
//     state = {
//         isOpenDropdown: false,
//         contactForm1: false,
//         contactForm2: false,
//         contactCount: 1,
//         partyType: "",
//         customerName: "",
//         customerType: "",
//         customerStatus: "",
//         CISCode: "",
//         orgNumber: "",
//         creditRating: "",
//         postCode: "",
//         country: "",
//         customerContactDetail1: {
//             contactName: "",
//             contactRole: "",
//             officeNumber: "",
//             mobileNumber: "",
//             EmailAddress: "",
//             addressLine1: "",
//             addressLine2: "",
//             addressLine3: ""
//         },
//         customerContactDetail2: {
//             contactName: "",
//             contactRole: "",
//             officeNumber: "",
//             mobileNumber: "",
//             EmailAddress: "",
//             addressLine1: "",
//             addressLine2: "",
//             addressLine3: ""
//         },
//         customerContactDetail3: {
//             contactName: "",
//             contactRole: "",
//             officeNumber: "",
//             mobileNumber: "",
//             EmailAddress: "",
//             addressLine1: "",
//             addressLine2: "",
//             addressLine3: ""
//         },
//         SPV: "",
//         partyName: "",
//         relationshipType: ""
//       };

//     // toggleOpen = () => this.setState({ isOpenDropdown: !this.state.isOpenDropdown });

//     addMoreContact () {
//         if(this.state.contactCount == 1){
//             this.setState({ contactForm1: !this.state.contactForm1 });
//             this.setState({ contactCount: this.state.contactCount +1 })
//         } else if(this.state.contactCount == 2) {
//             this.setState({ contactForm2: !this.state.contactForm2 });
//             // this.setState({ contactCount: this.state.contactCount +1 })
//         }
//     } 

//     deleteMoreContact(val) {
//         if(val == 2){
//             this.setState({ contactForm2: !this.state.contactForm2 });
//             this.setState({ contactCount: 2 })
//         } else if(val == 1) {
//             this.setState({ contactForm1: !this.state.contactForm1 });
//             this.setState({ contactCount: 1 })
//         }
//     }

//     saveUserData() {
//         axios.get("http://11.14.25.126:8088/getName")
//         .then(function (response) {
//             //callback(response.data['name']);
//         })
//         .catch(function (error) {
//             if (error.response) {
//                 if (error.response.status === 404) {
//                     //callback(`\u2014`)
//                 }
//             }
//         })  
//         // Api.postData();
//     }

//     handleChange = (e) => {
//         // let val = e.target.value;
//         this.setState({partyType:e.target.value});
//     }


//     render() {
//         // const menuClass = `dropdown-menu${this.state.isOpenDropdown ? " show" : ""}`;
//         var showContactBlock;
//         var showContactBlock1;
//         if(this.state.contactForm1 === true){
//             showContactBlock = <div className="contact_block"><span class="glyphicon glyphicon-remove-circle close" onClick={this.deleteMoreContact.bind(this,1)}></span><Form /></div>
//         }
//         else{
//             showContactBlock = null
//         }
//         if(this.state.contactForm2 == true) {
//             showContactBlock1 = <div className="contact_block"><span class="glyphicon glyphicon-remove-circle close" onClick={this.deleteMoreContact.bind(this,2)}></span><Form /></div>
//         }
//         else{
//             showContactBlock1 = null
//         }
//         return(
//             <div className="background">
//                 <div className="inner_container">
//                     <div class="field_name">
//                         <div class="form-group row">
//                             <label className="customer_title">Add a party</label>
//                         </div>
//                     </div>

//                     <div class="field_name">
//                        <Dropdown partyType="Party type" name="partyType" onChange={this.handleChange} option1="Customer" option2="Special Purpose Vehicle" option3="" option4=""/>
//                     </div>
//                     <div className="row row_container">
//                             <div class="col-xs-6 col-xs-6 left_column">
//                                 <div class="inner_column">
//                                     <img src={SPV} class="spv_img"/>
//                                     <label>Company details</label>
//                                     <form class="user_form">
//                                     {/* fieldTitle, inputType, name, onChange, placeholder */}
//                                         <Inputfield fieldTitle="Customer name" inputType="text" name="customername" onChange={this.handleChange} placeholder="Customer name"/>
//                                         {/* <div class="form-group row">
//                                             <label for="staticEmail" class="col-sm-3 col-form-label">Customer name</label>
//                                             <div class="col-sm-8">
//                                             <input type="text" name="customername" onChange={(name) => {this.setState({customerName: name})}}  class="form-control" placeholder="Customer name" />
//                                             </div>
//                                         </div> */}
//                                         <Dropdown partyType="Customer type" name="customerType" onChange={this.handleChange} option1="Primary" option2="Secondary" option3="Tenant"/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputState" class="col-sm-3 col-form-label">Customer type</label>
//                                             <div class="col-sm-8">
//                                                 <select id="inputState" class="form-control">
//                                                     <option selected>Primary</option>
//                                                     <option>Secondary</option>
//                                                     <option>Tenant</option>
//                                                 </select>
//                                             </div>
//                                         </div> */}
//                                         <Dropdown partyType="Status" name="statusType" onChange={this.handleChange} option1="Active" option2="Inactive" option3=""/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputState" class="col-sm-3 col-form-label">Status</label>
//                                             <div class="col-sm-8">
//                                                 <select id="inputState" class="form-control">
//                                                     <option selected>Active</option>
//                                                     <option>Inactive</option>
//                                                 </select>
//                                             </div>
//                                         </div> */}
//                                          <Inputfield fieldTitle="CIS code" inputType="text" name="ciscode" onChange={this.handleChange} placeholder="CIS code"/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputPassword" class="col-sm-3 col-form-label">CIS code</label>
//                                             <div class="col-sm-8">
//                                             <input type="text" class="form-control" id="" placeholder="CIS code" />
//                                             </div>
//                                         </div> */}
//                                         <Inputfield fieldTitle="Org number" inputType="text" name="orgnumber" onChange={this.handleChange} placeholder="Organization number"/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputPassword" class="col-sm-3 col-form-label">Org number</label>
//                                             <div class="col-sm-8">
//                                             <input type="text" class="form-control" id="" placeholder="Org number" />
//                                             </div>
//                                         </div> */}
//                                         <Inputfield fieldTitle="Credit rating" inputType="number" name="creditrating" onChange={this.handleChange} placeholder="Credit rating"/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputPassword" class="col-sm-3 col-form-label">Credit rating</label>
//                                             <div class="col-sm-8">
//                                             <input type="text" class="form-control" id="" placeholder="Credit rating" />
//                                             </div>
//                                         </div> */}
//                                         <Inputfield fieldTitle="Postcode" inputType="number" name="postcode" onChange={this.handleChange} placeholder="Postcode"/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputPassword" class="col-sm-3 col-form-label">Postcode</label>
//                                             <div class="col-sm-8">
//                                             <input type="text" class="form-control" id="" placeholder="Postcode" />
//                                             </div>
//                                         </div> */}
//                                         <Inputfield fieldTitle="Country" inputType="text" name="country" onChange={this.handleChange} placeholder="Country"/>
//                                         {/* <div class="form-group row">
//                                             <label for="inputPassword" class="col-sm-3 col-form-label">Country</label>
//                                             <div class="col-sm-8">
//                                             <input type="text" class="form-control" id="" placeholder="Country" />
//                                             </div>
//                                         </div> */}
//                                     </form>
//                                 </div>
                                
//                                 <div class="inner_column right_column">
//                                     <img src={SPV} class="spv_img"/>
//                                     <label>Special Purpose Vehicle</label>
//                                     <form class="spv_form">
//                                         <div class="form-group row">
//                                             <label for="staticEmail" class="col-sm-3 col-form-label">SPV</label>
//                                             <div class="col-sm-8 inner-addon right-addon search_column">
//                                                     <input type="text" class="form-control" placeholder="Party name" />
//                                                     <div class="input-group-btn">
//                                                         <button class="btn btn-default" type="submit">
//                                                             <i class="glyphicon glyphicon-search"></i>
//                                                         </button>
//                                                     </div>
//                                                 </div>
//                                         </div>
//                                         <div class="spv_btn">
//                                             <button type="button" class="btn btn-info">
//                                                 <span class="glyphicon glyphicon-plus-sign"></span> Add another SPV
//                                             </button>
//                                         </div>
//                                     </form>
//                                 </div>
//                             </div>

//                             <div class="col-xs-6 col-sm-6 ">
//                             <div class="contact_inner_column right_column">
//                                     <img src={SPV} class="spv_img"/>
//                                     <label>Contact details</label>
//                                         <Form />
//                                         {showContactBlock}
//                                         {showContactBlock1}                                        
//                                         <div class="spv_btn">
//                                             <button type="button" class="btn btn-info" onClick={this.addMoreContact.bind(this)} >
//                                                 <span class="glyphicon glyphicon-plus-sign"></span> Add another Contact
//                                             </button>
//                                         </div>
                                   
//                                 </div>


//                                 <div class="inner_column right_column">
//                                     <img src={SPV} class="spv_img"/>
//                                     <label>Relationships</label>
//                                     <form class="spv_form">
//                                         <div class="form-group row">
//                                             <label for="staticEmail" class="col-sm-3 col-form-label">Party name</label>
//                                             {/* <div class="col-sm-8 inner-addon right-addon">
//                                                 <input type="text"  class="form-control" id="staticEmail" placeholder="Party name" />
//                                                 <i class="glyphicon glyphicon-search"></i>
//                                             </div> */}
//                                             <div class="col-sm-8 inner-addon right-addon search_column">
//                                                 <input type="text" class="form-control" placeholder="Party name" />
//                                                 <div class="input-group-btn">
//                                                     <button class="btn btn-default" type="submit">
//                                                         <i class="glyphicon glyphicon-search"></i>
//                                                     </button>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                         <div class="form-group row">
//                                             <label for="inputState" class="col-sm-3 col-form-label">Relationship type</label>
//                                             <div class="col-sm-8">
//                                                 <select id="inputState" class="form-control">
//                                                     <option selected>Subsidary</option>
//                                                 </select>
//                                             </div>
//                                         </div>

//                                         <div class="spv_btn">
//                                             <button type="button" class="btn btn-info">
//                                                 <span class="glyphicon glyphicon-plus-sign"></span> Add another party
//                                             </button>
//                                         </div>
//                                     </form>
//                                 </div>
//                             </div>
//                             <div class="footer">
//                                 <button type="button" class="btn btn-default cancel_btn">Cancel</button>
//                                 <button type="button" class="btn btn-primary save_btn" onClick={this.saveUserData.bind(this)}>Save changes</button>
//                             </div>
//                     </div>
                    
//                 </div>
//             </div>
//         )
    
//     }
// }

// export default addCustomer
