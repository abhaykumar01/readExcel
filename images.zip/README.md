### LMS User Interface

Installation

Take checkout of repository
git clone -b <branchname> <repository url>
open terminal come inside the folder and run below command to install all the dependant packages
    npm install
    npm start

To run unit test cases use below comand
    npm test -- --watchAll (To see if there is any change happen). If some test fail just press u to get the updates.
    or
    npm test (To see all written test result)
    or
    npm test -- --coverage (To see Test result report)

    
